<?php

use App\Http\Controllers\BankAccountController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\CountryController;
use App\Http\Controllers\CurrencyController;
use App\Http\Controllers\FileUploadController;
use App\Http\Controllers\FiscalYearController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\MasterTypeController;
use App\Http\Controllers\ModuleController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\StateController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Artisan;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::fallback(function(){
    return response()->json([
        'message' => 'Page Not Found. If error persists, contact info@rnjcs.in'], 404);
});

Route::post('/login',[LoginController::class, 'login']);

Route::middleware(['auth:api','masterauth'])->group(function () {

    Route::get('generate_link', function (){
        Artisan::call('storage:link');
        echo 'ok';
    });
    
    Route::any('change_password',[LoginController::class,'change_password']);
    Route::any('/logout',[LoginController::class,'logout']);

    Route::any('/testing',[LoginController::class,'testing']);

    Route::resource('user', UserController::class);
    Route::any('user_getlist',[UserController::class,'getlist']);
    Route::any('user_menu',[UserController::class,'createMenu']);
    Route::any('user_page_access',[UserController::class,'checkUserPageAccess']);
    Route::any('user_headers',[UserController::class,'headers']);
    Route::any('user_actionall',[UserController::class,'actionall']);

    Route::resource('page', PageController::class);
    Route::any('page_headers',[PageController::class,'headers']);
    Route::any('page_actionall',[PageController::class,'actionall']);

    Route::resource('module', ModuleController::class);
    Route::any('module_getlist',[ModuleController::class,'getlist']);
    Route::any('module_headers',[ModuleController::class,'headers']);
    Route::any('module_actionall',[ModuleController::class,'actionall']);

    Route::resource('role', RoleController::class);
    Route::any('role_getlist',[RoleController::class,'getlist']);
    Route::any('role_headers',[RoleController::class,'headers']);
    Route::any('role_actionall',[RoleController::class,'actionall']);

    Route::resource('bank_account', BankAccountController::class);
    Route::any('bank_account_headers',[BankAccountController::class,'headers']);
    Route::any('bank_account_actionall',[BankAccountController::class,'actionall']);

    Route::resource('branch', BranchController::class);
    Route::any('branch_getlist',[BranchController::class,'getlist']);
    Route::any('branch_headers',[BranchController::class,'headers']);
    Route::any('branch_actionall',[BranchController::class,'actionall']);

    Route::resource('country',CountryController::class);
    Route::any('country_headers',[CountryController::class,'headers']);
    Route::any('country_actionall',[CountryController::class,'actionall']);

    Route::resource('state',StateController::class);
    Route::any('state_getlist',[StateController::class,'getlist']);
    Route::any('state_headers',[StateController::class,'headers']);
    Route::any('state_actionall',[StateController::class,'actionall']);

    Route::resource('currency',CurrencyController::class);
    Route::any('currency_headers',[CurrencyController::class,'headers']);
    Route::any('currency_actionall',[CurrencyController::class,'actionall']);

    Route::resource('fiscalyear',FiscalYearController::class);
    Route::any('fiscalyear_headers',[FiscalYearController::class,'headers']);

    Route::any('fileupload',[FileUploadController::class,'fileupload']);
    Route::post('filedownload',[FileUploadController::class,'filedownload']);

    Route::resource('type', MasterTypeController::class);
    Route::any('type_headers',[MasterTypeController::class,'headers']);
    Route::any('type_actionall',[MasterTypeController::class,'actionall']);
});
