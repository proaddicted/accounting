<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Modules\Customer\Entities\OpeningBalance;

class BankAccount extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;

    protected $fillable = ['name','account_name','account_no','bank_name','branch_name','ifsc_code','micr_code','status'];
    
    protected $searchableColumns = ['name','account_name','account_no','bank_name','branch_name','ifsc_code','micr_code'];

    protected $appends = ['is_delete','is_edit','creator','editor','display_name'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function getDisplayNameAttribute()
    {
        $display_name = $this->bank_name;
        $display_name .=empty($this->attributes['account_no'])?'':"(".$this->attributes['account_no'] . ')';
        $this->attributes['display_name'] = $display_name;
        return $this->attributes['display_name'];
    }

    protected static function boot() 
    {
        parent::boot();
    
       
        self::creating(function($model){
                                 
        });

        self::created(function($model){
            if(request()->opening_balance > 0)
            {
                $opening_balance = new OpeningBalance();
                $opening_balance->main_id = $model->id;
                $opening_balance->identifier = 'bank';
                $opening_balance->date = request()->date;
                $opening_balance->amount = request()->opening_balance;
                $opening_balance->save();
            } 
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
        });

       
    }
}
