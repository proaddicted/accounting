<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class State extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;

    protected $fillable = ['name','gst_code','iso_code','status','country_id'];

    protected $searchableColumns = ['name','gst_code','iso_code','country.name'];

    protected $appends = ['is_delete','is_edit','creator','editor'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function country()
    {
        return $this->belongsTo(Country::class,'country_id');
    }
}
