<?php

namespace App\Models;

use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;

class NotificationTemplate extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,Eloquence,PermissionTrait;

    protected $fillable = ['sms_body','name','display_name','email_body','status','subject','notification_body'];
    
    protected $searchableColumns = ['name','display_name','subject'];

    protected $appends = ['is_delete','is_edit','creator','editor'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
}
