<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Illuminate\Support\Facades\Auth;

class RolePermission extends Model
{
    use HasFactory,Userstamps,MasterTrait,SoftDeletes,PermissionTrait;

    protected $fillable = ['module_id','page_id','permission_id','access'];

    protected $appends = ['is_delete','is_edit','creator','editor'];

    protected $table = 'role_permission';

}
