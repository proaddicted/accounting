<?php

namespace App\Mail;

use App\Models\NotificationTemplate;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SendGrid extends Mailable
{
    use Queueable, SerializesModels;

    public $data, $message,$subject;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($data)
    {
       $this->data = $data;

       if( $this->data['template'] && !empty( $this->data['template']))
       {
            $template = $this->data['template'];

            $this->data['variables']['[SENDER_NAME]'] = isset($this->data['from']) ? $this->data['from'] : env('APP_NAME');
            $this->message = $this->replace_variable($this->data['variables'],$this->data['template']['email_body']);
            $this->subject = $this->replace_variable($this->data['variables'],$this->data['template']['subject']);
       }

    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        
        $header = $this->asString($this->data['header']);
        
        $this->withSwiftMessage(function ($message) use ($header) {
            $message->getHeaders()
                    ->addTextHeader('X-SMTPAPI', $header);
        });
        $mail = $this->html($this->message)->subject($this->subject);

        if(isset($this->data['from']) && $this->data['from'] != "")
        {
            $mail->from($this->data['from_address'], $this->data['from']);
        }
        if(isset($this->data['attachments']) && count($this->data['attachments']) > 0)
        {
            foreach($this->data['attachments'] as $filePath => $fileParameters){
                $mail->attach($filePath, $fileParameters);
            }
        }
        
        return $mail;
    }

    private function asJSON($data)
    {
        $json = json_encode($data);
        $json = preg_replace('/(["\]}])([,:])(["\[{])/', '$1$2 $3', $json);

        return $json;
    }


    private function asString($data)
    {
        $json = $this->asJSON($data);

        return wordwrap($json, 76, "\n   ");
    }

    private function replace_variable($variable_array,$original_body)
    {
        preg_match_all('~{[A-Z_]+}([^{]*){\/[A-Z_]+}~',$original_body,$matches);

                
        if(count($matches)>0)
        {
            $str=array();
            $replaces=array();

            foreach($matches[1] as $key=>$value)
            {
                
                $str[$key] = "";
                preg_match('~\[[A-Z_]+\]~',$value,$matches1);
                
                if(count($matches1) > 0)
                    {
                    if(array_key_exists($matches1[0], $variable_array) && !($variable_array[$matches1[0]]=="" || $variable_array[$matches1[0]]=="false"))
                        $str[$key] =str_replace(array_keys( $variable_array), $variable_array ,$value);
                    
                    $replaces[$key]= '~{'.$matches1[0].'+}([^{]*){\/'.$matches1[0].'+}~';
                    }
                else
                    {
                        //echo htmlentities($matches[0][$key]);
                        preg_match('~\{[A-Z_]+\}~',$matches[0][$key],$matches1);
                        //print_r($matches1); echo "<br>";
                        if(count($matches1) > 0)
                            {
                            $matches1[0] = str_replace("{","[",$matches1[0]);
                            $matches1[0] = str_replace("}","]",$matches1[0]);
                            
                            if(array_key_exists($matches1[0], $variable_array))
                                {
                                    $str[$key] = str_replace(array_keys( $variable_array), $variable_array ,$value);
                                    $replaces[$key]= '~{'.$matches1[0].'+}'. $str[$key] . '{\/'.$matches1[0].'+}~';
                                }
                            else
                                    $replaces[$key]= '~{'.$matches1[0].'+}([^{]*){\/'.$matches1[0].'+}~';
                            }
                            
                    }
                    
            }

            
            $replaced_body=preg_replace($replaces,$str,$original_body,1);
        }
        
        $replaced_body = str_replace(array_keys($variable_array), $variable_array, $replaced_body);

        return $replaced_body;
    }
}
