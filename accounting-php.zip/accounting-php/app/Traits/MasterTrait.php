<?php

namespace App\Traits;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

trait MasterTrait
{
    /**
     * Trait for Master ID Appending
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */


    /**
     * This is a protected boot function it appends master_id to all models data saving and appends
     * master_id to all query (If this trait is used in model)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */

    protected static function bootMasterTrait()
    {

        static::creating(function ($model) {
            $model->master_id = request()->master_id;
        });

        static::addGlobalScope(function ($query) {
            $query->where($query->qualifyColumn('master_id'), '=', request()->master_id);
         });

    }


}
