<?php

namespace App\Traits;

use App\Models\State;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;
use Modules\Customer\Entities\Customer;
use Modules\Invoice\Entities\Item;
use Modules\Invoice\Entities\TcsSection;
use Modules\Invoice\Entities\TdsSection;
use PDF;

trait InvoiceModuleTrait
{
    /**
     * Trait for Invoice, Purchase, Report Modules Common Functions
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */



     /**
     * This Function is Used To Set Account Related Informations into [VARIABLES]
     *
     * @param $account,$section
     * @return @array
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function set_account_data($account,$section)
    {
        $data = array();
        
        $account_state=State::where('name',$account['state'])->first();
        
        $data['[ACCOUNT_NAME]']=$account['name'];
        $data['[ACCOUNT_ADDRESS]']=$account['address'];
        $data['[ACCOUNT_CITY]']=$account['city'];
        $data['[ACCOUNT_PIN]']=$account['pincode'];
        $data['[ACCOUNT_STATE]']=$account['state'];
        $data['[ACCOUNT_GSTIN]']=$account['gstin'];
        
        $data['[DECLARATION]']=$account[$section.'_delcaration'];
        $data['[ACCOUNT_PAN]']=$account['pan_no'];
        $data['[ACCOUNT_CIN]']=$account['cin_no'];
        
        $data['[ACCOUNT_PHONE]']=$account['phone'];
        $data['[ACCOUNT_EMAIL]']=$account['email'];

        if($account['banks'] && count($account['banks']) > 0)
        {
            $data['[ACCOUNT_BANK]']=$account['banks'][0]['bank_name'];
            $data['[ACCOUNT_MICR]']=$account['banks'][0]['micr_code'];
            $data['[ACCOUNT_NO]']=$account['banks'][0]['account_no'];
            $data['[ACCOUNT_IFSC]']=$account['banks'][0]['ifsc_code'];
            $data['[ACCOUNT_BRANCH]']=$account['banks'][0]['branch_name'];
        }    
        
        if($account_state)
            $data['[ACCOUNT_STATE_GSTCODE]']=$account_state->gst_code;

        return $data;    
    }
    /**
     * This Function is Used To Set Customer Related Informations into [VARIABLES]
     *
     * @param  $customer,$section
     * @return @array
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function set_customer_data($customer,$section)
    {
        $data = array();
        
        if(!empty($customer))
        {
            $billing_address = "";
            $billing_address = !empty($customer['address']) ? $customer['address']. ", " : "";
            $billing_address .= !empty($customer['city']) ? $customer['city'] . ", " : "";
            $billing_address .= !empty($customer['state']) ? $customer['state'] .", " : "";
            $billing_address .= !empty($customer['pincode']) ? "Pin-" . $customer['pincode'] : "";
            $data['[BILLING_ADDRESS]']=$billing_address;

            
            $data['[BILLING_ADDRESS_STATE]']=$customer['state'];
           
            $billing_address_gst_code=State::where('name',$customer['state'])->first();
            if($billing_address_gst_code)
                $data['[BILLING_ADDRESS_STATE_GST]']=$billing_address_gst_code->gst_code;

            $data['[BILLING_ADDRESS_GSTIN]']=$customer['gstin'];
            $data['[BILLING_ADDRESS_LINEONE]'] = trim(str_replace(",,",",",str_replace(", ,",",",str_replace(", ,",",",$customer['address']))),","); 
            
            $data['[BILLING_ADDRESS_CITY]'] = $customer['city'];
            $data['[BILLING_ADDRESS_PIN]'] = $customer['pincode'];
            $data['[BILLING_ADDRESS_PAN_NO]']=$customer['pan_no'];
            
            if(!empty($customer['legal_name']))
                $data['[CUSTOMER_NAME]']=$customer['legal_name'];
            else
                $data['[CUSTOMER_NAME]']=$customer['full_name'];
                
            $data['[CUSTOMER_EMAIL]']=$customer['email'];
            $data['[CUSTOMER_PHONE]']=$customer['mobile'];


        }

        return $data;
    }
    /**
     * This Function is Used To Set Invoice Related Informations into [VARIABLES]
     *
     * @param  $items,$body
     * @return @array
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function set_invoice_data($invoice,$section)
    {
        $data = array();

        $data['[NUMBER]']=$invoice['number'];
        $data['[CREATOR]']=$invoice['creator']['name'];
        $data['[FORMATTED_NUMBER]'] = $invoice['formatted_number'];
        $data['[INVOICE_DATE]']=date('F jS, Y',strtotime($invoice['date']));
        $data['[DATE_OF_SUPPLY]']=date('F jS, Y',strtotime($invoice['date']));
        $data['[PLACE_OF_SUPPLY]']=$invoice['place_of_supply'];
        $data['[NOTES]']=$invoice['note'];

        $place_of_supply_gst_code=State::where('name',$invoice['place_of_supply'])->first();
        if($place_of_supply_gst_code)
            $data['[PLACE_OF_SUPPLY_GST]']=$place_of_supply_gst_code->gst_code;

        $data['[BEFORE_TOTAL]']=number_format($invoice['before_total'], 2);
        $data['[AFTER_TOTAL]']=number_format($invoice['after_total'], 2);
        $data['[AFTER_ROUND_OFF]']=number_format(round($invoice['after_total']), 2);
        $data['[TOTAL_IN_WORDS]']=ucwords($this->convertNumberToWord(number_format(round($invoice['after_total']), 2)));
        $data['[TOTAL_IN_WORDS_DECIMAL]']=ucwords($this->convertNumberToWord(number_format($invoice['after_total'], 2)));
        $data['[TOTAL_CGST]']=number_format(empty($invoice['cgst'])?0:$invoice['cgst'], 2);
        $data['[TOTAL_SGST]']=number_format(empty($invoice['sgst'])?0:$invoice['sgst'], 2);
        $data['[TOTAL_IGST]']=number_format(empty($invoice['igst'])?0:$invoice['igst'], 2);

        if($section == 'credit_note' || $section == 'debit_note')
        {
            $data['[INVOICE_FORMATTED_NUMBER]'] = $invoice['invoice']['formatted_number'];
            $data['[INVOICE_ISSUE_DATE]']=date('F jS, Y',strtotime($invoice['invoice']['date']));
            $data['[INVOICE_AMOUNT]'] = number_format(round($invoice['invoice']['after_total']), 2);
        }

        if($section == 'invoice' || $section == 'proforma_invoice')
        {
            $data['[TOTAL_TDS]'] = number_format(empty($invoice['tds'])?0:$invoice['tds'], 2);
            $data['[TOTAL_TCS]'] = number_format(empty($invoice['tcs'])?0:$invoice['tcs'], 2);

            $data['[TOTAL_TDS_PERCENT]'] = !empty($invoice['tds_section'])?$invoice['tds_section']['rate']:0;
            $data['[TOTAL_TCS_PERCENT]'] = !empty($invoice['tcs_section'])?$invoice['tcs_section']['rate']:0;
            
        }

        return $data;
    }

    /**
     * This Function is Used To Set Payslip Related Informations into [VARIABLES]
     *
     * @param  $items,$body
     * @return @array
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function set_payslip_data($purchase,$section)
    {
        $data = array();

        $data['[NUMBER]']=$purchase['number'];
        $data['[CREATOR]']=$purchase['creator']['name'];
        $data['[FORMATTED_NUMBER]'] = $purchase['formatted_number'];
        $data['[PAYMENT_DATE]']=date('F jS, Y',strtotime($purchase['date']));
        $data['[ISSUE_DATE]']=date('F jS, Y',strtotime($purchase['date']));

        $data['[BEFORE_TOTAL]']=number_format($purchase['before_total'], 2);
        $data['[AFTER_TOTAL]']=number_format($purchase['after_total'], 2);
        $data['[AFTER_ROUND_OFF]']=number_format(round($purchase['after_total']), 2);
        $data['[TOTAL_IN_WORDS]']=ucwords($this->convertNumberToWord(number_format(round($purchase['after_total']), 2)));
        
        $data['[MONTH_NAME]']=$purchase['month_name'];
        $data['[NO_OF_DAYS]']=$purchase['no_of_days'];

        return $data;
    }

     /**
     * This Function is Used To Set Payment Related Informations into [VARIABLES]
     *
     * @param  $items,$body
     * @return @array
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function set_payment_data($purchase_payment,$section)
    {
        $data = array();
        
        $data['[CREATOR]']=$purchase_payment['creator']['name'];
        $data['[PAYMENT_DATE]']=date('F jS, Y',strtotime($purchase_payment['date']));
        $data['[REMARKS]']=$purchase_payment['remarks'];
        $data['[TOTAL_AMOUNT]']=number_format($purchase_payment['amount'], 2);
        $data['[TOTAL_TDS]']=number_format($purchase_payment['tds'], 2);
        $data['[TOTAL_TCS]']=number_format($purchase_payment['tcs'], 2);
        $data['[TOTAL_ODS]']=number_format($purchase_payment['ods'], 2);
        $data['[TOTAL_IN_WORDS_DECIMAL]']=ucwords($this->convertNumberToWord(number_format($purchase_payment['amount'], 2)));
        $data['[PAYMENT_TYPE]']=ucwords($purchase_payment['payment_type']);
        $data['[TRANSACTION_TYPE]']=ucwords($purchase_payment['transaction_type']);
        $data['[TRANSACTION_ID]']=$purchase_payment['transaction_id'];
        $data['[TRANSACTION_DATE]']=$purchase_payment['transaction_date'];

        if(!empty($purchase_payment['bank_account']))
        {
            $data['[BANK_NAME]']=ucwords($purchase_payment['bank_account']['display_name']);
        }

        return $data;
    }
    
    /**
     * This Function is Used To Replace Loop Section to HTML Body Passed in Parameter
     *
     * @param  $items,$body
     * @return @mixed array (raw html and array)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function set_item_data($items,$body)
    {
        if(count($items)>0)
        {
            $item_str="";
            $total_cgst_percent=0;
            $total_sgst_percent=0;
            $total_igst_percent=0;
            $i=0;
            
            $print_data_loop=array();
            foreach ($items as  $value) 
            {   
                
                $i++;
                
                $hsn_or_sac="";
               
                // if($value['hsn_code']!="")
                //     $hsn_or_sac=$value['hsn_code'];
                // elseif($value['sac_code']!="")
                //     $hsn_or_sac=$value['sac_code'];
                // elseif($value['sac_code']!="" && $value['hsn_code']!="")
                //     $hsn_or_sac=$value['sac_code'].'/'.$value['hsn_code'];

                $hsn_or_sac=$value['hsn_sac_code'];

                $print_data_loop['[SLNO]']=$i;
                $print_data_loop['[ITEM_NAME]']=$value['name'];
                $print_data_loop['[DESCRIPTION]']=$value['pivot']['description'];
                
                $print_data_loop['[RATE]']=number_format($value['pivot']['rate'],2);
                $print_data_loop['[SAC_HSN]']=$hsn_or_sac;
                $print_data_loop['[UQC]']=$value['pivot']['quantity'];

                if(isset($value['pivot']['operator']))
                {
                    $print_data_loop['[AMOUNT]']= $value['pivot']['operator'] == 2  ? "(-) ".number_format($value['pivot']['before_total'],2):number_format($value['pivot']['before_total'],2);
                }
                else
                    $print_data_loop['[AMOUNT]']=number_format($value['pivot']['before_total'],2);
                $print_data_loop['[DISCOUNT]'] = $value['pivot']['discount_amount'];
                
                preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$body,$matches);

                $item_str .= $this->loop($matches,$print_data_loop);
                    
                $total_cgst_percent=$total_cgst_percent+$value['pivot']['cgst'];
                $total_sgst_percent=$total_sgst_percent+$value['pivot']['sgst'];
                $total_igst_percent=$total_igst_percent+$value['pivot']['igst']; 
            }
            /*********extra bottom space under item table*******************/
            $print_data_loop_extra = array();
            for($j=$i; $j<=6; $j++) 
            {   
                $print_data_loop_extra['[SLNO]']='&nbsp;';
                $print_data_loop_extra['[DESCRIPTION]']='';
                $print_data_loop_extra['[SAC_HSN]']='';
                $print_data_loop_extra['[UQC]']='';
                $print_data_loop_extra['[AMOUNT]']='';
                $print_data_loop_extra['[DISCOUNT]'] = '';
                
                $item_str .= $this->loop($matches,$print_data_loop_extra);
            }
            /*********extra bottom space under item table*******************/
            if(count($matches) > 0 && isset($matches[0][0]))
                $invoice_body =str_replace($matches[0][0], $item_str,$body);
            else
                $invoice_body = $body;

            $data['[TOTAL_IGST_PERCENT]']=number_format($total_igst_percent / count($items), 2);
            $data['[TOTAL_CGST_PERCENT]']=number_format($total_cgst_percent / count($items), 2);
            $data['[TOTAL_SGST_PERCENT]']=number_format($total_sgst_percent / count($items), 2);  
        }

        return ['data'=>$data,'body'=>$invoice_body];
    }


     /**
     * This Function is Used To Replace Loop Section to HTML Body Passed in Parameter
     *
     * @param  $items,$body
     * @return @mixed array (raw html and array)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function set_payments_item_data($payment,$items,$body){

        if(count($items)>0)
        {
            $i = 0;
            $item_str="";
            $data = array();
            $print_data_loop=array();
            foreach ($items as  $value) 
            { 
                $i++;
                $print_data_loop['[SLNO]']=$i;

                if(!empty($value['number']))
                    $print_data_loop['[DESCRIPTION]']="Invoice No. ".$value['number'].",Dated -".date('F jS, Y',strtotime($payment['date']));
                else
                    $print_data_loop['[DESCRIPTION]']="Invoice Dated -".date('F jS, Y',strtotime($payment['date']));
                
                $print_data_loop['[AMOUNT]']=number_format($value['pivot']['amount'],2);
                $print_data_loop['[DTAX]']=$value['pivot']['tds'] > 0 ? number_format($value['pivot']['tds'],2) : "0.00";
                $print_data_loop['[CTAX]']=$value['pivot']['tds'] > 0 ? number_format($value['pivot']['tcs'],2) : "0.00";
                
                preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$body,$matches);

                $item_str .= $this->loop($matches,$print_data_loop);
                    
            }

             /*********extra bottom space under item table*******************/
             $print_data_loop_extra = array();
             for($j=$i; $j<=6; $j++) 
             {   
                 $print_data_loop_extra['[SLNO]']='&nbsp;';
                 $print_data_loop_extra['[DESCRIPTION]']='';
                 $print_data_loop_extra['[AMOUNT]']='';
                 $print_data_loop_extra['[DTAX]']='';
                 $print_data_loop_extra['[CTAX]'] = '';
                 
                 $item_str .= $this->loop($matches,$print_data_loop_extra);
             }
             /*********extra bottom space under item table*******************/
             if(count($matches) > 0 && isset($matches[0][0]))
                 $invoice_body =str_replace($matches[0][0], $item_str,$body);
             else
                 $invoice_body = $body;

            return ['data'=>$data,'body'=>$invoice_body];    
        }
    }
     /**
     * This Function is Used To Replace All [VARIABLE] to HTML Body Passed in Parameter
     *
     * @param  $replaced_body,$variable_array,$original_body
     * @return @raw html
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function replace_variable($replaced_body,$variable_array,$original_body)
    {
        preg_match_all('~{[A-Z_]+}([^{]*){\/[A-Z_]+}~',$replaced_body,$matches);

                
        if(count($matches)>0)
        {
            $str=array();
            $replaces=array();

            foreach($matches[1] as $key=>$value)
            {
                
                $str[$key] = "";
                preg_match('~\[[A-Z_]+\]~',$value,$matches1);
                
                if(count($matches1) > 0)
                    {
                    if(array_key_exists($matches1[0], $variable_array) && !($variable_array[$matches1[0]]=="" || $variable_array[$matches1[0]]=="false"))
                        $str[$key] =str_replace(array_keys( $variable_array), $variable_array ,$value);
                    
                    $replaces[$key]= '~{'.$matches1[0].'+}([^{]*){\/'.$matches1[0].'+}~';
                    }
                else
                    {
                        //echo htmlentities($matches[0][$key]);
                        preg_match('~\{[A-Z_]+\}~',$matches[0][$key],$matches1);
                        //print_r($matches1); echo "<br>";
                        if(count($matches1) > 0)
                            {
                            $matches1[0] = str_replace("{","[",$matches1[0]);
                            $matches1[0] = str_replace("}","]",$matches1[0]);
                            
                            if(array_key_exists($matches1[0], $variable_array))
                                {
                                    $str[$key] = str_replace(array_keys( $variable_array), $variable_array ,$value);
                                    $replaces[$key]= '~{'.$matches1[0].'+}'. $str[$key] . '{\/'.$matches1[0].'+}~';
                                }
                            else
                                    $replaces[$key]= '~{'.$matches1[0].'+}([^{]*){\/'.$matches1[0].'+}~';
                            }
                            
                    }
                    
            }

            if($replaced_body!="")  
                $replaced_body=preg_replace($replaces,$str,$replaced_body,1);
            else
                $replaced_body=preg_replace($replaces,$str,$original_body,1);
        }
        
        $replaced_body = str_replace(array_keys($variable_array), $variable_array, $replaced_body);

        return $replaced_body;
    }
     /**
     * This Function is Used To Save Raw HTML Data to PDF File in Path passed in parameters
     *
     * @param  $invoice,$html,$path
     * @return @file path
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function save_pdf($invoice,$html,$path)
    {
        $newFile = $path."/".$invoice['id'].".pdf";
        $newPath = $path;
        $newFile_Org = $invoice['id'].".pdf";
        // $newFile = "uploads/saved_invoice/".$request->pdf_type."_pdf/".$invoice['id'].".pdf";
        // $newPath = "uploads/saved_invoice/".$request->pdf_type."_pdf";
        if(file_exists($newFile)) 
        {
        
            $extension = pathinfo($newFile,PATHINFO_EXTENSION);
            $filename = pathinfo($newFile, PATHINFO_FILENAME);

            $duplicateCounter = 1;
        
            while(file_exists($iterativeFileName =
                $newPath ."/". $filename ."_". $duplicateCounter .".". $extension)) {
                $duplicateCounter++;
            }
            $newFile_Org = $filename ."_". $duplicateCounter .".". $extension;
            $newFile = $iterativeFileName;
        }

        PDF::loadHTML($html)->setWarnings(false)->save($newFile);
        return $newFile_Org;
    }

    /**
     * This Function is Used To Save Raw HTML Data to HTML File for Print in Path passed in parameters
     *
     * @param  $invoice,$html,$path
     * @return @file path
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function save_print($invoice,$html,$path)
    {
        $newFile = $path."/".$invoice['id'].".html";
        $newPath = $path;
        $newFile_Org = $invoice['id'].".html";
        // $newFile = "uploads/saved_invoice/".$request->pdf_type."_pdf/".$invoice['id'].".pdf";
        // $newPath = "uploads/saved_invoice/".$request->pdf_type."_pdf";
        if(file_exists($newFile)) 
        {
        
            $extension = pathinfo($newFile,PATHINFO_EXTENSION);
            $filename = pathinfo($newFile, PATHINFO_FILENAME);

            $duplicateCounter = 1;
        
            while(file_exists($iterativeFileName =
                $newPath ."/". $filename ."_". $duplicateCounter .".". $extension)) {
                $duplicateCounter++;
            }
            $newFile_Org = $filename ."_". $duplicateCounter .".". $extension;
            $newFile = $iterativeFileName;
        }

        $file = $newFile;;
        $fp = fopen($file, 'w');  //open file for writing
        fwrite($fp, $html); //write contents of the output buffer in Cache file
        fclose($fp);

        return $newFile_Org;
    }
    /**
     * This Function is Used For Converting Number to Words(eg 100 = one hundred)
     *
     * @param  $number
     * @return @string
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    function convertNumberToWord($number = false)
    {
        $number = str_replace(array(',', ' '), '' , trim($number));
        if(! $number) {
            return false;
        }
        $no = (int)floor($number);
        $point = (int)round(($number - $no) * 100);
        $hundred = null;
        $digits_1 = strlen($no);
        $i = 0;
        $str = array();
        $words = array('0' => '', '1' => 'one', '2' => 'two',
            '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
            '7' => 'seven', '8' => 'eight', '9' => 'nine',
            '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
            '13' => 'thirteen', '14' => 'fourteen',
            '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
            '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
            '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
            '60' => 'sixty', '70' => 'seventy',
            '80' => 'eighty', '90' => 'ninety');
        $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
        while ($i < $digits_1) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($no % $divider);
            $no = floor($no / $divider);
            $i += ($divider == 10) ? 1 : 2;


            if ($number) {
                $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                $str [] = ($number < 21) ? $words[$number] .
                    " " . $digits[$counter] . $plural . " " . $hundred
                    :
                    $words[floor($number / 10) * 10]
                    . " " . $words[$number % 10] . " "
                    . $digits[$counter] . $plural . " " . $hundred;
            } else $str[] = null;
        }
        $str = array_reverse($str);
        $result = implode('', $str);


        $points = ($point) ?
            "" . $words[floor($point / 10) * 10] . " " . 
                $words[$point = $point % 10] : ''; 

        if($points != ''){        
            $final = $result . "Rupees  " . $points . " Paise";
        } else {

            $final = $result . "Rupees";
        }

        return $final;
		
    }

    /**
     * It Creates a Loop from HTML template using in Invoice Section Prints
     *
     * @param  $matches,$print_data_loop
     * @return @string
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function loop($matches,$print_data_loop)
    {
        $item_str = "";
        if(count($matches)>0)
        {
          
          
          if(isset($matches[1][0]) && $matches[1][0]!="")
          {
            
            preg_match_all('~{[A-Z_]+}([^{]*){\/[A-Z_]+}~',$matches[1][0],$matchess);
            if(count($matchess)>0)
            {
                  $message ="";
                  $str=array();
                  $replaces=array();

                  foreach($matchess[1] as $key =>$value1)
                  {
                       
                        $str[$key] = "";
                        preg_match('~\[[A-Z_]+\]~',$value1,$matches1);
                       
                        if(count($matches1) > 0)
                          {

                            if(array_key_exists($matches1[0], $print_data_loop) && !($print_data_loop[$matches1[0]]=="" || $print_data_loop[$matches1[0]]=="false"))
                               $str[$key] =str_replace(array_keys($print_data_loop), $print_data_loop ,$value1);
                           else
                               {
                                    $str[$key]="";
                               }
                            
                            $replaces[$key]= '~{'.$matches1[0].'+}([^{]*){\/'.$matches1[0].'+}~';
                          }
                        
                          
                  }
               
                  $item_str .= preg_replace($replaces,$str,$matches[1][0]);
              
            }
            
          }  

        }
       
        return $item_str;
    }

    /**
     * It Creates Directory Recursively
     *
     * @param  $path
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    function createPath($path) {
        if (is_dir($path)) return true;
        $prev_path = substr($path, 0, strrpos($path, '/', -2) + 1 );
        $return = $this->createPath($prev_path);
        return ($return && is_writable($prev_path)) ? mkdir($path) : false;
    }

    /**
     * This Function Generates All Items Combined
     *
     * @param  
     * @return array
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */

    function getTotalItems()
    {
        $data['customers']=Customer::where('status',1)->get();
        $data['items']=Item::where('status',1)->when(env('PARTICULAR_GROUP_ID') > 0, function($query) {
            return $query->whereNull('item_group_id');
        })->get();
        $data['tds_sections'] = TdsSection::where('status',1)->get();
        $data['tcs_sections'] = TcsSection::where('status',1)->get();   

        $total_items = array();

        foreach ( $data['customers'] as $key => $value) 
        {
            array_push( $total_items ,array('id'=>'customer_'.$value->id,'name'=>$value->full_name,'group'=>$value->category));
        }

        foreach ( $data['items'] as $key => $value) 
        {
            array_push( $total_items ,array('id'=>'item_'.$value->id,'name'=>$value->name,'group'=>'Item'));
        }

        array_push( $total_items , array('id'=>'gst_1','name'=>'GST Payable','group'=>'GST'));
        array_push( $total_items , array('id'=>'cgst_1','name'=>'CGST Payable','group'=>'GST'));
        array_push( $total_items , array('id'=>'sgst_1','name'=>'SGST Payable','group'=>'GST'));
        array_push( $total_items , array('id'=>'igst_1','name'=>'IGST Payable','group'=>'GST'));

        array_push( $total_items , array('id'=>'gst_2','name'=>'GST Receivable','group'=>'GST'));
        array_push( $total_items , array('id'=>'cgst_2','name'=>'CGST Receivable','group'=>'GST'));
        array_push( $total_items , array('id'=>'sgst_2','name'=>'SGST Receivable','group'=>'GST'));
        array_push( $total_items , array('id'=>'igst_2','name'=>'IGST Receivable','group'=>'GST'));

        array_push( $total_items , array('id'=>'tds_1','name'=>'TDS Payable','group'=>'TDS'));
        array_push( $total_items ,  array('id'=>'tds_2','name'=>'TDS Receivable','group'=>'TDS'));

        array_push( $total_items , array('id'=>'tcs_1','name'=>'TCS Payable','group'=>'TCS'));

        foreach ( $data['tds_sections'] as $key => $value) 
        {
            array_push( $total_items ,array('id'=>'tds-section_'.$value->id,'name'=>$value->name,'group'=>'TDS Section'));
        }
        foreach ( $data['tcs_sections'] as $key => $value) 
        {
            array_push( $total_items ,array('id'=>'tcs-section_'.$value->id,'name'=>$value->name,'group'=>'TCS Section'));
        }
       
       
       return  $total_items; 
    } 
    
}
