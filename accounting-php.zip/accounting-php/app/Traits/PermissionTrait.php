<?php

namespace App\Traits;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

trait PermissionTrait
{

    /**
     * This Trait Will Be Used for Custom Permission Checking
     * access->1
     * insert->2
     * update->3
     * view->4
     * list->5
     * delete->6
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */

    public $access_types = array(
        array('name'=>'None','id'=>0),
        array('name'=>'Self','id'=>1),
        array('name'=>'Hierchy','id'=>2),
        array('name'=>'My Branch','id'=>3),
       // array('name'=>'My Department','id'=>4),
        array('name'=>'All','id'=>5)
    );

    public function checkGlobalAccess()
    {
       
        $res = DB::table('users')->select(DB::raw('MAX(role_permission.access) as access,role_permission.permission_id,role_permission.page_id,users.id as user_id,pages.url as page_url'))->leftJoin('role_user','role_user.user_id','=','users.id')->leftJoin('role_permission','role_permission.role_id','=','role_user.role_id')->leftJoin('pages','pages.id','=','role_permission.page_id')->where('users.id',Auth::user()->id)->where('role_user.master_id',request()->master_id)->where('role_permission.master_id',request()->master_id)->where('pages.master_id',request()->master_id)->whereNull('role_permission.deleted_at')->whereNull('role_user.deleted_at')->whereNull('pages.deleted_at')->groupBy('role_permission.permission_id')->groupBy('role_permission.page_id')->get();
        
        return $res;
    }
    public function checkAccessType($permission_id)
    {
       // $res = $this->permissionResult;
        
        //dd($res);
      
        $res = DB::table('users')->select(DB::raw('MAX(role_permission.access) as access,role_permission.permission_id,role_permission.page_id,users.id as user_id'))->leftJoin('role_user','role_user.user_id','=','users.id')->leftJoin('role_permission','role_permission.role_id','=','role_user.role_id')->leftJoin('pages','pages.id','=','role_permission.page_id')->where('pages.name',request()->page_url)->where('role_permission.permission_id',$permission_id)->where('users.id',Auth::user()->id)->where('role_user.master_id',request()->master_id)->where('role_permission.master_id',request()->master_id)->where('pages.master_id',request()->master_id)->whereNull('role_permission.deleted_at')->whereNull('role_user.deleted_at')->whereNull('pages.deleted_at')->groupBy('role_permission.permission_id')->groupBy('role_permission.page_id')->get();
        
        return $res;
    }
    /**
     * This function check query with added_by or emp_id column where ever this scope is appended
     * Only If Used In Query like $query->checkPermission()
     * @param $query, $column (should be passed from controller index function)
     * @return $query
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */ 
    public function scopecheckPermission($query,$column)
    {
        
       // echo $column; exit;
        //print_r($this->checkAccessType(5));exit;

        $user = Auth::user();
    
        if($user->is_superadmin == 0)
        {
            
            $res = $this->checkAccessType(5);
           // $this->result  = $res;
            if(count($res) > 0)
            {
                
                if($res[0]->access == 0) /*No Access*/
                    $query->whereRaw('1=2');
                elseif($res[0]->access == 1) /*Self Access*/
                    $query->where($column,$user->id);
                elseif($res[0]->access == 5) /*All Access*/
                    $query->whereRaw('1=1');
                else
                    $query->whereRaw('1=2');    
            }
            else
                $query->whereRaw('1=2');

       }

        return $query;
    }
     /**
     * This is a mutator function it returns is_delete column true or false based on conditions
     * (It will only append column if $appends used in Respective Model)
     * @return $attribute
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */ 
    public function getIsDeleteAttribute()
    {
         $is_delete = false;
         $user= Auth::user();

         if($user->is_superadmin == 0)
         {
            $res = $this->checkAccessType(6);

            if(count($res) > 0)
            {
                if($res[0]->access == 0) /*No Access*/
                    $is_delete = false;
                elseif($res[0]->access == 1) /*Self Access*/
                    $is_delete = $this->attributes['created_by'] == $user->id ? true:false;
                elseif($res[0]->access == 5) /*All Access*/ 
                    $is_delete = true;
                else
                    $is_delete = false;    

            }   
            else
                $is_delete = false;
         }
         else
            $is_delete = true;
         

         return $this->attributes['is_delete'] = $is_delete;
    }

    /**
     * This is a mutator function it returns is_edit column true or false based on conditions
     * (It will only append column if $appends used in Respective Model)
     * @return $attribute
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */ 
    

    public function getIsEditAttribute()
    {
         $is_edit = false;
         
         $user = Auth::user();

         if($user->is_superadmin == 0)
         {
         
            $res = $this->checkAccessType(3);

            if(count($res) > 0)
            {
                if($res[0]->access == 0) /*No Access*/
                    $is_edit = false;
                elseif($res[0]->access == 1)/*Self Access*/
                    $is_edit = $this->attributes['created_by'] == $user->id ? true:false;
                elseif($res[0]->access == 5) /*All Access*/   
                    $is_edit = true;
                else
                    $is_edit = false;    
            }   
            else
                $is_edit = false;    
         }
         else
            $is_edit = true;
         

         return $this->attributes['is_edit'] = $is_edit;
    }

    /**
     * This function it returns check if user can create or not based on condition. If added in controller
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */ 
    public function checkStoreAccess()
    {   
        $user = Auth::user();
        if($user->is_superadmin  == 0)
        {
            $res = $this->checkAccessType(2);

            if(count($res) > 0)
            {
                if($res[0]->access == 1)
                    return true;
                else
                    return false;    
            }
            else
                return false;
        }
        else
            return true;
    }
    
    /**
     * This function it returns check if user can make update or not based on condition. If added in controller
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */ 
    public function checkUpdateAccess($object)
    {
        $user = Auth::user();
        if($user->is_superadmin  == 0)
        {
            $res = $this->checkAccessType(3);

            if(count($res) > 0)
            {
                if($res[0]->access == 0) /*No Access*/
                    return false;
                elseif($res[0]->access == 1) /*Self Access*/
                {
                    if($object->created_by == $user->id)
                        return true;
                    else 
                        return false;   
                }
                elseif($res[0]->access == 5) /*All Access*/   
                    return true;
                else
                    return false;    
            }
            else
                return false;
        }
        else
            return true;
    }
   
    /**
     * This function it returns check if user can delete or not based on condition. If added in controller
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */ 
    public function checkDeleteAccess($object)
    {
        $user = Auth::user();
        if($user->is_superadmin  == 0)
        {
            $res = $this->checkAccessType(6);

            if(count($res) > 0)
            {
                if($res[0]->access == 0) /*No Access*/
                    return false;
                elseif($res[0]->access == 1) /*Self Access*/
                {
                    if($object->created_by == $user->id)
                        return true;
                    else 
                        return false;   
                }
                elseif($res[0]->access == 5) /*All Access*/   
                    return true;
                else
                    return false;    
            }
            else
                return false;
        }
        else
            return true;
    }

    public function checkBulkAcess($permission_id)
    {
        $user = Auth::user();
        if($user->is_superadmin == 0)
         {
            $res = $this->checkAccessType($permission_id);
            if(count($res) > 0)
            {
                if($res[0]->access == 5)
                    return true;
                else
                    return false;     
            }
            else
                return false;
         }
         else
            return true;
    }

    /**
     * This is a mutator function it returns creator information if created_by column added in table
     * (It will only append column if $appends used in Respective Model)
     * @return $attribute
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */ 
    public function getCreatorAttribute()
    {
        return User::find($this->attributes['created_by']);
    }

     /**
     * This is a mutator function it returns editor information if updated_by column added in table
     * (It will only append column if $appends used in Respective Model)
     * @return $attribute
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function getEditorAttribute()
    {
        return User::find($this->attributes['updated_by']);
    }

     /**
     * This is a mutator function it returns destroyer information if deleted_by column added in table (It will be used in rare cases)
     * (It will only append column if $appends used in Respective Model)
     * @return $attribute
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function getDestroyerAttribute()
    {
        return User::find($this->attributes['deleted_by']);
    }

    /**
     * This is a mutator function it returns status in boolean value (0/1)
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function getStatusAttribute()
    {
        return intval($this->attributes['status']);
    }

    /**
     * This is a function that retruns report edit button show or not. (Need improvisation in this function currently it will work on yes/no)
     * @return boolean
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function checkReportEditAccess()
    {
        
        $user = Auth::user();
        if($user->is_superadmin  == 0)
        {
            $res = $this->checkAccessType(3);

            if(count($res) > 0)
            {
                if($res[0]->access == 0) /*No Access*/
                    return false;
                elseif($res[0]->access == 1) /*Self Access*/
                {
                    return true;  
                }
                elseif($res[0]->access == 5) /*All Access*/   
                    return true;
                else
                    return false;    
            }
            else
                return false;
        }
        else
            return true;
    }
}

?>
