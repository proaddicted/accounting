<?php

namespace App\Traits;

use Exception;
use Illuminate\Support\Facades\Storage;

trait CommonTrait
{
    /**
     * Trait for All Common Functions Which Can Be Used In Multiple Modules
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */


    /**
     * This is a public function which converts base64 data to file data and save to storage folder
     * @param $base64_data Base 64 Data
     * @param $target_folder Folder where image will be uploaded
     * @return string or boolean  
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function base64_upload($base64_data,$target_folder)
    {
        try{
            $extension = explode('/', explode(':', substr($base64_data, 0, strpos($base64_data, ';')))[1])[1];   // .jpg .png .pdf
      
            $replace = substr($base64_data, 0, strpos($base64_data, ',')+1); 
        
            // find substring fro replace here eg: data:image/png;base64,
            
            $image = str_replace($replace, '', $base64_data); 
            
            $image = str_replace(' ', '+', $image); 
            
            $imageName = time().'.'.$extension;

            $file_path = $target_folder.'/'.$imageName;

            Storage::disk('public')->put($file_path, base64_decode($image));

            return $file_path;
        }
        catch(Exception $ex){
            return false;
        }
        
    }
   


}
