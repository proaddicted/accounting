<?php

namespace App\Http\Controllers;

use App\Http\Resources\UserResource;
use App\Models\Module;
use App\Models\Role;
use Illuminate\Http\Request;
use App\Models\User;
use App\Traits\CommonTrait;
use App\Traits\PermissionTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class UserController extends Controller
{
    use PermissionTrait,CommonTrait;
    
    public function headers()
    {
        $headers = array(
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'email','display_name'=>'Email','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'roles','display_name'=>'Roles','is_display'=>1,'is_default'=>1,'is_sortable'=>0)          
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * This Controller used for User Resources Methods
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function getlist()
    {
        $data['roles']=Role::where('status',1)->get();
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $query = QueryBuilder::for(User::class)->allowedFilters(['name',AllowedFilter::exact('email')->ignore(null),AllowedFilter::exact('id')->ignore(null)])->defaultSort('-created_at')->allowedSorts('name','email');

        $query->search(!empty($request->search)?$request->search:"");

        $users = $query->with('roles')->checkPermission('id')->paginate($request->per_page);

        return response(['data' => $users,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
        
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'password' => 'required',
            'email' => 'required|email|unique:users,email',

        ]);

        if ($validator->fails()) {
            //
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {

            $user = new User();
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->is_superadmin = $request->is_superadmin==true?1:0;

            if($profile = $this->base64_upload($request->input('image'),'users'))
                $user->profile = $profile;

            $user->save();

            $user->roles()->attach($request->role_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 


            DB::commit();

            return response(['data' => new UserResource($user),'success'=>true,'message' => 'User Created successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        return response(['data' =>new UserResource($user),'success'=>true,'message' => 'User Retrived Successfully'], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        // echo $profile = $this->base64_upload($request->input('image'),'users');exit;
        if(!$this->checkUpdateAccess($user))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'password' => 'required',
            'email' => 'required|email|unique:users,email,'.$user->id,

        ]);

        if ($validator->fails()) {
            //
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {


            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->is_superadmin = $request->is_superadmin==true?1:0;

            if($profile = $this->base64_upload($request->input('image'),'users'))
                $user->profile = $profile;

            $user->save();

            $user->roles()->detach();
            $user->roles()->attach($request->role_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]);

            DB::commit();

            return response(['data' => new UserResource($user),'success'=>true,'message' => 'User Updated successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' => $ex->getMessage()], 500);

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        if(!$this->checkDeleteAccess($user))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {
            $user->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'User Deleted successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    User::whereIn('id',request()->ids)->get()->each(function($user) 
                    {
                        $user->delete();
                    });
                }
            elseif($access == 3)  
                User::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }

    public function createMenu()
    {
        $user = Auth::user();
        $user_roles = array_column($user->roles->toArray(),'id');
        
        if( Auth::user()->is_superadmin == 0)
        {
            
            $modules = Module::with(['pages'=> function($q) use ($user_roles){ $q->whereHas('role_permission', function($q2) use ($user_roles){$q2->whereIn('role_id',$user_roles)->where('permission_id',1)->where('access','>',0);
                });
            }])->whereHas('role_permission', function($q) use ($user_roles){
                $q->whereIn('role_id',$user_roles)->where('access','>',0);
            })->where('status',1)->orderBy('order_no','asc')->get();
        }
        else
        {
            $modules = Module::with('pages')->where('status',1)->orderBy('order_no','asc')->get();
        }        
       
        return response(['data' => $modules,'permissions'=>$this->checkGlobalAccess(),'success'=>true,'message' => 'Data Retrived successfully'], 200);
    }

    public function checkUserPageAccess()
    {
        
        $res = $this->checkAccessType(request()->access_type);
        
        return response(['data' => $res,'success'=>true,'message' => 'User Access Fetched'], 200);


    }
}
