<?php

namespace App\Http\Controllers;

use App\Models\TempFile;
use Illuminate\Http\Request;

class FileUploadController extends Controller
{
    public function fileupload(Request $request)
    {
        if(!$request->hasFile('files')) {
            return response(['data' => array(),'success'=>false,'message' => "No files found"], 500);
        }
        $file_arr = array();
        $files = $request->file('files');
        
         if(count($files) > 0)
         {
            
            foreach ($files as $key => $file) 
            {
                // sleep(1);
                $file_name_org_arr = explode('.'.$file->getClientOriginalExtension(), $file->getClientOriginalName());
                
                if(count($file_name_org_arr) > 0)
                    $file_name_formated = str_replace(' ', '_',strtolower($file_name_org_arr[0]));
                else
                    $file_name_formated = md5(microtime());

                $extenstion=$file->getClientOriginalExtension();
                $size=$file->getSize() ;

                $fileName = $file_name_formated."_".time().'.'.$extenstion; 
                
                $path = $file->move(storage_path().'/app/public/uploads/', $fileName); 
                $original_file_name = $file->getClientOriginalName(); 

                $temp_file = TempFile::create(['file_path' => '/app/public/uploads/'.$fileName,'file_size'=>$size,'file_extension'=> $extenstion,'file_name'=> $original_file_name,'identifier'=>request()->identifier]);

                $file_arr[$key] = $temp_file ;
            }
        }

        return response(['data' =>$file_arr,'success'=>true,'message' => 'Files Uploaded Successfully'], 200);
    }

    public function filedownload(Request $request)
    {
        if(file_exists(storage_path().$request->file_path))
        {
            $file = storage_path().$request->file_path;
            //$headers = array('Content-Type: application/pdf');
            return  response()->file($file);
        }
        else
            return response(['data' => array(),'success'=>false,'message' => "Invalid File Path"], 500);
    }
}
