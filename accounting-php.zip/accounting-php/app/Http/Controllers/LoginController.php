<?php

namespace App\Http\Controllers;

use App\Http\Resources\UserResource;
use App\Models\Test;
use App\Models\User;
use Illuminate\Validation\ValidationException;

use Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    /**
     * This Controller used for Authentication Services
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */


    /**
     * Used for login authentication. (Auth Provider is Passport)
     *
     * @return \Illuminate\Http\Response
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */ 
    public function login(Request $request)
    {
        $request->validate([
            'email' => ['required','email'],
            'password' =>['required']
        ]);


         if(Auth::attempt(['email' => $request->email, 'password' => $request->password])){
            $user = Auth::user();
            $success['access_token'] =  $user->createToken('Auth Token')->accessToken;
            $success['return_data'] = new UserResource($user);

            return $this->sendResponse($success, 'User login successfully.');
        }
        else{
            $messages = "Invalid Login Credentails";
            return $this->sendError('Invalid Credentials', $messages);
        }


    }

    /**
     * Used for logout
     *
     * @return \Illuminate\Http\Response
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */ 
    public function logout() {

        DB::table('oauth_access_tokens')
        ->where('user_id', Auth::user()->id)
        ->update([
            'revoked' => true
        ]);

        return $this->sendResponse(null, 'You have been successfully logged out!');
    }

    public function testing(Request $request)
    {

        // $test = new Test();
        // $test->title = "Aaa";
        // $test->save();
        return $this->sendResponse(Test::all()->toArray(), 'Record Instered successfully.');
    }

    /**
     * Used for change password after login
     *
     * @return \Illuminate\Http\Response
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */ 
    public function change_password(Request $request)
    {
       
        //echo Auth::user()->id; exit;
           
        $validator = Validator::make($request->all(), [
            'old_password' => 'required',
            'new_password' => 'required|min:6',
            'confirm_password' => 'required|same:new_password',

        ]);
        
        if ($validator->fails()) {
            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        } else {

            DB::beginTransaction();
            
            try {
                
                if ((Hash::check($request->old_password, Auth::user()->password)) == false) 
                {
                    DB::commit();
                    return response(['data' => array(),'success'=>false,'message' => ["Check your old password, Not matched"]], 200);
                } 
                else if ((Hash::check($request->new_password, Auth::user()->password)) == true) {
                    DB::commit();
                    return response(['data' => array(),'success'=>false,'message' => ["Please enter a password which is not similar then current password"]], 200);

                } 
                else 
                {
                    
                    User::where('id', Auth::user()->id)->update(['password' => Hash::make($request->new_password)]);
                    
                    DB::commit();
                    return response(['data' => array(),'success'=>true,'message' => "Password updated successfully"], 200);
                
                }
            } catch (Exception $ex) {
                DB::rollBack();
                return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
            }
        }
       
    }
}
