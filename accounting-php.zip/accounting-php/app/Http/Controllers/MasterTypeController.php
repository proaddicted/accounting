<?php

namespace App\Http\Controllers;

use App\Http\Resources\MasterTypeResource;
use App\Models\MasterType;
use App\Traits\PermissionTrait;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class MasterTypeController extends Controller
{
    use PermissionTrait;
   
    public function headers()
    {
        $headers = array(
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>1,'is_default'=>1,'is_sortable'=>1)      
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(MasterType::class)->allowedFilters(['name','updated_at',AllowedFilter::exact('identifier')->ignore(null)])->defaultSort('-updated_at')->allowedSorts('name','updated_at','identifier');

        $query->search(!empty($request->search)?$request->search:"");

        $master_types = $query->checkPermission('created_by')->paginate($request->per_page);
      
        return response(['data' => $master_types,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'name' => 'required'
        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $master_type = MasterType::create($request->all());
            DB::commit();
            return response(['data' => new MasterTypeResource($master_type),'success'=>true,'message' => 'Entity Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        return response(['data' =>new MasterTypeResource(MasterType::findOrFail($id)),'success'=>true,'message' => 'Entity Retrived Successfully'], 200);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $master_type=MasterType::find($id);
        
        if(!$this->checkUpdateAccess($master_type))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
             
            
            $master_type->update($request->all());
            
            DB::commit();

            return response(['data' => new MasterTypeResource($master_type),'success'=>true,'message' => 'Entity Updated successfully'], 200);

        } catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' => $ex->getMessage()], 500);

        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $master_type=MasterType::find($id);
        
        if(!$this->checkDeleteAccess($master_type))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {
            
            $master_type->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Entity Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    MasterType::whereIn('id',request()->ids)->get()->each(function($master_type) 
                    {
                        $master_type->delete();
                    });
                }
            elseif($access == 3)  
                MasterType::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
