<?php

namespace App\Http\Controllers;

use App\Http\Resources\BranchResource;
use App\Models\BankAccount;
use App\Models\Branch;
use App\Traits\PermissionTrait;
use Illuminate\Http\Request;
use Spatie\QueryBuilder\QueryBuilder;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class BranchController extends Controller
{
    use PermissionTrait;

    public function headers()
    {
        $headers = array(
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'code','display_name'=>'Code','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'address_line1','display_name'=>'Address Line 1','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'address_line2','display_name'=>'Address Line 2','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'country','display_name'=>'Country','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'state','display_name'=>'State','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'city','display_name'=>'City','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'pincode','display_name'=>'Pincode','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'pan_no','display_name'=>'Pan No','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'gstin_no','display_name'=>'GSTIN','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'bank_accounts','display_name'=>'Accounts','is_display'=>1,'is_default'=>1,'is_sortable'=>0)            
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function getlist(Request $request)
    {
        $data['bank_accounts'] = BankAccount::where('status',1)->checkPermission('created_by')->get();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Branch::class)->allowedFilters(['name','code'])->defaultSort('-created_at')->allowedSorts('name','code','country','state','city','pincode','pan_no','gstin_no');

        $query->search(!empty($request->search)?$request->search:"");

        $branchs = $query->with('bank_accounts')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $branchs,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $branch = Branch::create($request->except(['bank_account_id']));
            
            $branch->bank_accounts()->attach($request->bank_account_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 

            DB::commit();
            return response(['data' => new BranchResource($branch),'success'=>true,'message' => 'Branch Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return response(['data' =>new BranchResource(Branch::findOrFail($id)),'success'=>true,'message' => 'Branch Retrived Successfully'], 200);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $branch=Branch::find($id);
        
        if(!$this->checkUpdateAccess($branch))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'name' => 'required'
        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $branch->update($request->except(['bank_account_id']));
            
            $branch->bank_accounts()->detach();
            
            $branch->bank_accounts()->attach($request->bank_account_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 

            DB::commit();
            
            return response(['data' => new BranchResource($branch),'success'=>true,'message' => 'Module Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $branch=Branch::find($id);
        
        if(!$this->checkDeleteAccess($branch))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $branch->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Branch Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    Branch::whereIn('id',request()->ids)->get()->each(function($branch) 
                    {
                        $branch->delete();
                    });
                }
            elseif($access == 3)  
                Branch::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
