<?php

namespace App\Http\Middleware;

use App\Models\FiscalYear;
use Closure;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class MasterAuthenticate
{
    
    /**
     * This Middleware is used to check master token for all url header
     * Handle an incoming request.
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function handle(Request $request, Closure $next)
    {

        
        if($request->header('X-MASTER-CODE') && !empty($request->header('X-MASTER-CODE')))
        {
            try
            {
                $master = DB::table('master')->where('code',$request->header('X-MASTER-CODE'))->first();

                if(!empty($master))
                {
                    $request->master_id = $master->id;
                    $request->user_id = Auth::user()->id;
                    $fiscal_year = FiscalYear::whereRaw('? BETWEEN start_date and end_date',[date('Y-m-d')])->first();

                    if(empty($fiscal_year))
                    {
                        
                        FiscalYear::where('status',1)->update(['status'=>0]);

                        $newfiscal =  new FiscalYear;
                        $newfiscal->name=date('y')."-".date('y', strtotime('+1 year'));
                        $newfiscal->start_date=date(env('FISCAL_YEAR_START'));
                        $newfiscal->end_date=date(env('FISCAL_YEAR_END'), strtotime('+1 year'));
                        $newfiscal->status=1;
                        $newfiscal->save();
                    }
                    return $next($request);
                }
                else
                    return response(['data' => array(),'success'=>false,'message' => 'Your Master Code Is Not Registered'], 403);

            }catch(Exception $e)
            {
                return response(['data' => array(),'success'=>false,'message' => $e->getMessage()], 500);
            }

        }
        else
            return response(['data' => array(),'success'=>false,'message' => 'Invalid Master Code'], 403);
    }
}
