<?php

namespace Modules\Purchase\Entities;

use App\Models\BankAccount;
use App\Models\File;
use App\Models\FiscalYear;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Illuminate\Support\Facades\DB;
use Modules\Customer\Entities\Customer;
use Spatie\QueryBuilder\QueryBuilder;
use Illuminate\Database\Eloquent\Builder;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Invoice\Entities\Item;

class PurchasePayment extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;

    protected $fillable = ['number','invoice_account_id','fiscal_year_id','customer_id','date','payment_type','bank_account_id','remarks','amount','tcs','tds','ods','transaction_type','transaction_id','transaction_date','type','is_realization','realization_date','realization_remarks'];

    protected $searchableColumns = ['number','payment_type','date','remarks'];

    protected $appends = ['is_delete','is_edit','creator','editor'];
    
    public function customer()
    {
        return $this->belongsTo(Customer::class,'customer_id');
    }
    public function account()
    {
        return $this->belongsTo(InvoiceAccount::class,'invoice_account_id');
    }
    public function fiscal_year()
    {
        return $this->belongsTo(FiscalYear::class,'fiscal_year_id');
    }
    public function bank_account()
    {
        return $this->belongsTo(BankAccount::class,'bank_account_id');
    }
    public function purchases()
    {
    	
    	return $this->belongsToMany(Purchase::class,"purchase_payment_rel","purchase_payment_id","purchase_id")->whereNull('purchase_payment_rel.deleted_at')->withTimestamps()->withPivot("due_amount","amount","tcs","tds","ods","tds_section_id","tds_type","tds_percent","pay_amount"); 
    }
    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','purchase-payment');
    }
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function scopeDateBetween(Builder $query, ...$date): Builder
    {
      return $query->whereBetween('date', [$date[0], $date[1]]);
    }

    protected static function boot() 
    {

        parent::boot();
        
        self::creating(function($model){
           
           
        });

        self::created(function($model){
            //echo "workes"; exit;
           

            // if($model->purchases && count($model->purchases) > 0)
            // {
                
            //    foreach ($model->purchases as $key => $value) 
            //    {
            //        if($value['due_amount'] == ($value['amount'] + $value['tcs'] + $value['tds'] + $value['ods'] ))
            //        {
            //             $purchase = Purchase::find($value['purchase_id']);
            //             $purchase->status = 2;
            //             $purchase->save();

            //        }
            //    }
            // }
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
          
        });

        self::deleting(function($model){
            //$model->invoices()->detach();
        });

        self::deleted(function($model){
            $model->purchases()->detach();
            $model->files()->delete();
        });


    }
}
