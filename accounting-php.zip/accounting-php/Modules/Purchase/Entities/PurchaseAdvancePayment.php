<?php

namespace Modules\Purchase\Entities;

use App\Models\File;
use App\Models\FiscalYear;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Modules\Customer\Entities\Customer;
use Illuminate\Database\Eloquent\Builder;
use Modules\Invoice\Entities\InvoiceAccount;
use App\Models\BankAccount;
use App\Traits\InvoiceModuleTrait;

class PurchaseAdvancePayment extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes,InvoiceModuleTrait;

    protected $fillable = ['number','invoice_account_id','fiscal_year_id','customer_id','date','payment_type','bank_account_id','remarks','amount','transaction_type','transaction_id','transaction_date','type','is_realization','realization_date','realization_remarks','main_id','identifier','section','auto_entry'];

    protected $searchableColumns = ['type','number','payment_type','date','remarks'];

    protected $appends = ['is_delete','is_edit','creator','editor','item_name'];
    
    public $total_items; 

    public function __construct(array $attributes = array())
    {
        parent::__construct($attributes);

        $this->total_items = $this->getTotalItems();
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class,'customer_id');
    }
    public function account()
    {
        return $this->belongsTo(InvoiceAccount::class,'invoice_account_id');
    }

    public function bank_account()
    {
        return $this->belongsTo(BankAccount::class,'bank_account_id');
    }

    public function fiscal_year()
    {
        return $this->belongsTo(FiscalYear::class,'fiscal_year_id');
    }
    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','purchase-advance-payment');
    }
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function getItemNameAttribute()
    {
        if($this->attributes['main_id'] > 0  && !empty($this->attributes['identifier']))
        {
            $items = array_column($this->total_items,'name', 'id');
            $item_name=$items[$this->attributes['identifier']."_".$this->attributes['main_id']];
            $this->attributes['item_name']=$item_name ;
            return $this->attributes['item_name'];
        }
       
    }

    public function scopeDateBetween(Builder $query, ...$date): Builder
    {
      return $query->whereBetween('date', [$date[0], $date[1]]);
    }

    protected static function boot() 
    {

        parent::boot();
        
        self::creating(function($model){
           
            if(!empty(request()->date))
            {
                if($fiscal_year=FiscalYear::whereRaw('? BETWEEN start_date and end_date',[request()->date])->first())
                    $model->fiscal_year_id = $fiscal_year->id; 
            }
        });

        self::created(function($model){
            
        });

        self::updating(function($model){
            if(!empty(request()->date))
            {
                if($fiscal_year=FiscalYear::whereRaw('? BETWEEN start_date and end_date',[request()->date])->first())
                    $model->fiscal_year_id = $fiscal_year->id; 
            }
        });

        self::updated(function($model){
          
        });

        self::deleting(function($model){
            //$model->invoices()->detach();
        });

        self::deleted(function($model){
            
            $model->files()->delete();
        });
    }
}
