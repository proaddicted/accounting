<?php

namespace Modules\Purchase\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class PurchaseFile extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;


    protected $fillable = ['purchase_id','print_link','pdf_original_link','pdf_duplicate_link','status'];
    
    protected $searchableColumns = [];

    protected $appends = ['is_delete','is_edit','creator','editor'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    
    
}
