<?php

namespace Modules\Purchase\Entities;

use App\Models\File;
use App\Models\FiscalYear;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Illuminate\Support\Facades\DB;
use Modules\Customer\Entities\Customer;
use Spatie\QueryBuilder\QueryBuilder;
use Illuminate\Database\Eloquent\Builder;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Invoice\Entities\Item;

class Purchase extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;

    protected $fillable = ['number','invoice_account_id','fiscal_year_id','customer_id','before_total','cgst','sgst','igst','after_total','remarks','status','date','place_of_supply','billing_address','notes','type','user_id','is_taxable','is_item_applicable','is_payment','payment_type','bank_account_id','transaction_type','transaction_id','transaction_date','tds_section_id','is_realization','realization_date','realization_remarks','tds_type','tds_percent','basic','no_of_days','month'];
    
    protected $searchableColumns = ['number','date'];

    protected $appends = ['is_delete','is_edit','creator','editor','status_name','paid_amount','due_amount','total_amount','total_tds','month_name'];


    public $invoice_status = array(
        array('id'=>0,'name'=>'Pending'),
        array('id'=>1,'name'=>'Canceled'),
        array('id'=>2,'name'=>'Paid')
    );
    
    public $months = array(
        array('id'=>1,'name'=>'January'),
        array('id'=>2,'name'=>'February'),
        array('id'=>3,'name'=>'March'),
        array('id'=>4,'name'=>'April'),
        array('id'=>5,'name'=>'May'),
        array('id'=>6,'name'=>'June'),
        array('id'=>7,'name'=>'July'),
        array('id'=>8,'name'=>'August'),
        array('id'=>9,'name'=>'September'),
        array('id'=>10,'name'=>'October'),
        array('id'=>11,'name'=>'November'),
        array('id'=>12,'name'=>'December')
    );

    public function customer()
    {
        return $this->belongsTo(Customer::class,'customer_id');
    }
    public function user()
    {
        return $this->belongsTo(User::class,'user_id');
    }
    public function account()
    {
        return $this->belongsTo(InvoiceAccount::class,'invoice_account_id');
    }
    public function fiscal_year()
    {
        return $this->belongsTo(FiscalYear::class,'fiscal_year_id');
    }

    public function items()
    {
    	
    	return $this->belongsToMany(Item::class,"purchase_items","purchase_id","item_id")->whereNull('purchase_items.deleted_at')->withTimestamps()->withPivot('rate','quantity','before_total','after_total','cgst','sgst','igst','discount_amount','discount','discount_type','tax','is_taxable','operator','description')->withTrashed(); 
    }

    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','purchase');
    }
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function setIsTaxableAttribute($value)
    {
        $this->attributes['is_taxable'] = (int) $value;
    }
    public function setIsItemApplicableAttribute($value)
    {
        $this->attributes['is_item_applicable'] = (int) $value;
    }
    public function setIsPaymentAttribute($value)
    {
        $this->attributes['is_payment'] = (int) $value;
    }
    
    public function getPaidAmountAttribute()
    {
      $result = DB::table('purchase_payment_rel')->selectRaw('sum(IFNULL(amount,0) + IFNULL(tcs,0) + IFNULL(tds,0) + IFNULL(ods,0)) as total_paid')->where('purchase_id',$this->attributes['id'])->whereNull('deleted_at')->get();
      return $this->attributes['paid_amount'] = $result[0]->total_paid ;
    }


    public function getTotalAmountAttribute()
    {
      $result = DB::table('purchase_payment_rel')->selectRaw('sum(IFNULL(amount,0)) as total_amount')->where('purchase_id',$this->attributes['id'])->whereNull('deleted_at')->get();
      return $this->attributes['total_amount'] = $result[0]->total_amount ;
    }
    public function getTotalTdsAttribute()
    {
      $result = DB::table('purchase_payment_rel')->selectRaw('sum(IFNULL(tds,0)) as total_tds')->where('purchase_id',$this->attributes['id'])->whereNull('deleted_at')->get();
      return $this->attributes['total_tds'] = $result[0]->total_tds ;
    }
    
    public function getDueAmountAttribute()
    {
      if(isset($this->attributes['paid_amount']))
        return $this->attributes['due_amount'] = ($this->attributes['after_total'] - $this->attributes['paid_amount']);
      else
        return $this->attributes['due_amount'] = $this->attributes['after_total'];
    }
    public function getStatusNameAttribute()
    {
        if(isset($this->attributes['status']))
        {
            $statuses=array_column($this->invoice_status,'name', 'id'); 
            $status_name=$statuses[$this->attributes['status']];
            $this->attributes['status_name']=$status_name ;
            return $this->attributes['status_name'];	
        }
    }

    public function getMonthNameAttribute()
    {
        if(isset($this->attributes['month']))
        {
            $months=array_column($this->months,'name', 'id'); 
            $month_name=$months[$this->attributes['month']];
            $this->attributes['month_name']=$month_name ;
            return $this->attributes['month_name'];	
        }
    }

    public function scopeDateBetween(Builder $query, ...$date): Builder
    {
      return $query->whereBetween('date', [$date[0], $date[1]]);
        
    }

    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
           
            
        });

        self::created(function($model){
            
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
            $model->items()->detach();
            $model->files()->delete();
        });

       
    }
}
