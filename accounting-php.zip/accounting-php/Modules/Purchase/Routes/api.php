<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::middleware(['auth:api','masterauth'])->group(function () {

    Route::resource('purchase', PurchaseController::class);
    Route::any('purchase_getlist',[Modules\Purchase\Http\Controllers\PurchaseController::class,'getlist']);
    Route::any('purchase_headers',[Modules\Purchase\Http\Controllers\PurchaseController::class,'headers']);
    Route::any('purchase_actionall',[Modules\Purchase\Http\Controllers\PurchaseController::class,'actionall']);
    Route::any('purchase_by_customer',[Modules\Purchase\Http\Controllers\PurchaseController::class,'getPurchaseByCustomer']);
    Route::any('salary_headers',[Modules\Purchase\Http\Controllers\PurchaseController::class,'salary_headers']);
    Route::any('purchase_print/{id}/',[Modules\Purchase\Http\Controllers\PurchaseController::class,'purchase_print']);
    
    
    Route::resource('purchase_payment', PurchasePaymentController::class);
    Route::any('purchase_payment_getlist',[Modules\Purchase\Http\Controllers\PurchasePaymentController::class,'getlist']);
    Route::any('purchase_payment_headers',[Modules\Purchase\Http\Controllers\PurchasePaymentController::class,'headers']);
    Route::any('purchase_payment_actionall',[Modules\Purchase\Http\Controllers\PurchasePaymentController::class,'actionall']);
    Route::any('purchase_payment_print/{id}/',[Modules\Purchase\Http\Controllers\PurchasePaymentController::class,'purchase_payment_print']);
    
    Route::resource('purchase_advance_payment', PurchaseAdvancePaymentController::class);
    Route::any('purchase_advance_payment_getlist',[Modules\Purchase\Http\Controllers\PurchaseAdvancePaymentController::class,'getlist']);
    Route::any('purchase_advance_payment_headers',[Modules\Purchase\Http\Controllers\PurchaseAdvancePaymentController::class,'headers']);
    Route::any('purchase_advance_payment_actionall',[Modules\Purchase\Http\Controllers\PurchaseAdvancePaymentController::class,'actionall']);
});
