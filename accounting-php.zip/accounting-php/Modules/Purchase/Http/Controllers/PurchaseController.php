<?php

namespace Modules\Purchase\Http\Controllers;

use App\Models\BankAccount;
use App\Models\File;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

use App\Models\FiscalYear;
use App\Models\State;
use App\Models\TempFile;
use App\Models\User;
use App\Traits\InvoiceModuleTrait;
use App\Traits\PermissionTrait;
use Carbon\Carbon;
use Modules\Customer\Entities\Customer;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Invoice\Entities\Item;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Modules\Invoice\Entities\ItemGroup;
use Modules\Invoice\Entities\TdsSection;
use Modules\Invoice\Transformers\ItemGroupResource;
use Modules\Purchase\Entities\Purchase;
use Modules\Purchase\Entities\PurchaseFile;
use Modules\Purchase\Entities\PurchasePayment;
use Modules\Purchase\Rules\PurchasePaymentRule;
use Modules\Purchase\Transformers\PurchaseResource;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class PurchaseController extends Controller
{
    use PermissionTrait,InvoiceModuleTrait;

    public function getlist()
    {
        
        $data['states']=State::where('status',1)->get();
        $data['customers']=Customer::where('status',1)->where('category','Creditor')->get();
        $data['items']=Item::where('status',1)->when(env('PARTICULAR_GROUP_ID') > 0, function($query) {
            return $query->where('item_group_id',env('PARTICULAR_GROUP_ID'));
        })->get();
        $data['accounts']=InvoiceAccount::where('status',1)->get();
        $data['fiscal_years']=FiscalYear::orderBy('status','desc')->get();
        $data['bank_accounts']=BankAccount::where('status',1)->get();
        $data['payment_types']=array(
            array('name'=>'cash','display_name'=>"Cash"),
            array('name'=>'bank','display_name'=>"Bank A/C")
        );
        $data['transaction_types']=array(
            array('name'=>'online','display_name'=>"Online"),
            array('name'=>'cheque','display_name'=>"Cheque")
        );
        $data['salary_group']=new ItemGroupResource(ItemGroup::find(2));

        $data['users']=User::orderBy('name','asc')->checkPermission('id')->get();

        $data['tds_sections'] = TdsSection::where('status',1)->get();
	
        $data['status'] = array(
                array('id'=>0,'name'=>'Pending'),
            array('id'=>1,'name'=>'Canceled'),
            array('id'=>2,'name'=>'Paid')
        );

        $data['months'] = array(
            array('id'=>1,'name'=>'January','days'=>31),
            array('id'=>2,'name'=>'February','days'=>Carbon::now()->isLeapYear() ? 29 : 28),
            array('id'=>3,'name'=>'March','days'=>31),
            array('id'=>4,'name'=>'April','days'=>30),
            array('id'=>5,'name'=>'May','days'=>31),
            array('id'=>6,'name'=>'June','days'=>30),
            array('id'=>7,'name'=>'July','days'=>31),
            array('id'=>8,'name'=>'August','days'=>31),
            array('id'=>9,'name'=>'September','days'=>30),
            array('id'=>10,'name'=>'October','days'=>31),
            array('id'=>11,'name'=>'November','days'=>30),
            array('id'=>12,'name'=>'December','days'=>31)
        );

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
    public function headers()
    {
        $headers = array(
            
            array('column_name'=>'account','display_name'=>'A/C Name','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'number','display_name'=>'Reference No.','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'customer','display_name'=>'Party','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),

            array('column_name'=>'before_total','display_name'=>'Amount','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'cgst','display_name'=>'CGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'sgst','display_name'=>'SGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'igst','display_name'=>'IGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'after_total','display_name'=>'Billable Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'paid_amount','display_name'=>'Paid Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'due_amount','display_name'=>'Due Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'items','display_name'=>'Items','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>0,'is_default'=>0,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    public function salary_headers()
    {
        $headers = array(
            
            array('column_name'=>'account','display_name'=>'A/C Name','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'number','display_name'=>'Reference No.','is_display'=>0,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'customer','display_name'=>'Employee','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),

            array('column_name'=>'before_total','display_name'=>'Amount','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'cgst','display_name'=>'CGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'sgst','display_name'=>'SGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'igst','display_name'=>'IGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'after_total','display_name'=>'Payable Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'paid_amount','display_name'=>'Paid Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'due_amount','display_name'=>'Due Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'items','display_name'=>'Items','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>0,'is_default'=>0,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Purchase::class)->allowedFilters(['number','date','after_total', AllowedFilter::scope('date_between'),AllowedFilter::exact('customer_id')->ignore(null),AllowedFilter::exact('invoice_account_id')->ignore(null),AllowedFilter::exact('fiscal_year_id')->ignore(null),AllowedFilter::exact('type')->ignore(null),AllowedFilter::exact('created_by')->ignore(null),AllowedFilter::exact('status')->default('0')])->defaultSort('-created_at')->allowedSorts('number','date','after_total','before_total','cgst','sgst','igst');

        
        $query->search(!empty($request->search)?$request->search:"");

        $purchases = $query->with('account','fiscal_year','customer','items','files')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $purchases,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        
        $validator = Validator::make($request->all(), [
            //'number' => ['required|unique:purchases,number,NULL,id,deleted_at,NULL'],
            'date'=>['required'],
            'customer_id'=>['required'],
            'invoice_account_id'=>['required'],
            'fiscal_year_id'=>['required'],
            'amount'=>[new PurchasePaymentRule],
            'tds'=>[new PurchasePaymentRule],
        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $purchase = Purchase::create($request->except(['items','files']));
        
            $purchase->items()->attach($request->items,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
        
            $purchase->files()->delete();
            
            foreach ($request->input('files') as $data) 
            {
                
                $data['identifier']=isset($data['identifier'])?$data['identifier']:"purchase";
                if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                {
                    if($object = File::withTrashed()->find($data['id']))
                    {
                        $object->restore();
                        $object->fill($data);
                    }
                    else
                    {
                        if($tempobject = TempFile::find($data['temp_id']))
                        {
                            
                            $object = new File($data);
                        }
                    }
                        
                    $purchase->files()->save($object);
                }
            }

            if($request->is_payment == 1 && $request->amount > 0)
            {
                $purchase_payment = PurchasePayment::create($request->except(['items','files','number','remarks']));
                
                $attach['purchase_payment'][0] = ['purchase_id'=>$purchase->id,'amount'=>$request->amount,'tds_section_id'=>$request->tds_section_id,'tds_type'=>$request->tds_type,'tds_percent'=>$request->tds_percent,'tds'=>$request->tds > 0?$request->tds:0,'ods'=>$request->ods > 0?$request->ods:0,'tcs'=>$request->tcs > 0?$request->tcs:0,'due_amount'=>$request->after_total];

                $purchase_payment->purchases()->attach($attach['purchase_payment'],['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);

                if($request->after_total == ($request->amount + $request->tds + $request->tcs + $request->ods))
                    $purchase->status = 2;
            
                $purchase->save();

            }

            $this->generate_payslip_file($purchase);

            DB::commit();
            return response(['data' =>new PurchaseResource($purchase),'success'=>true,'message' => 'Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $purchase = Purchase::findOrFail($id);
        return response(['data' => new PurchaseResource($purchase),'success'=>true,'message' => 'Purchase Retrived Successfully'], 200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $purchase=Purchase::find($id);
        
        if(!$this->checkUpdateAccess($purchase))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'customer_id'=>['required'],
            'invoice_account_id'=>['required'],
            'fiscal_year_id'=>['required'],
            'payment_amount'=>[new PurchasePaymentRule]

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $purchase->update($request->except(['items','date','invoice_account_id','fiscal_year_id','invoice_id']));
            
            if(isset($request->items) && count($request->items) > 0)
            {
                $purchase->items()->detach();
                $purchase->items()->attach($request->items,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            }
            $purchase->files()->delete();
            
            foreach ($request->input('files') as $data) 
            {
                
                $data['identifier']=isset($data['identifier'])?$data['identifier']:"purchase";
                if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                {
                    if($object = File::withTrashed()->find($data['id']))
                    {
                        $object->restore();
                        $object->fill($data);
                    }
                    else
                    {
                        if($tempobject = TempFile::find($data['temp_id']))
                        {
                            
                            $object = new File($data);
                        }
                    }
                        
                    $purchase->files()->save($object);
                }
            }
            if($request->is_payment == 1)
            {
                if(DB::table('purchase_payment_rel')->where('purchase_id',$purchase->id)->count() == 0)
                {
                    $purchase_payment = PurchasePayment::create($request->except(['items','files','number','remarks']));
                
                    $attach['purchase_payment'][0] = ['purchase_id'=>$purchase->id,'amount'=>$request->amount,'tds_section_id'=>$request->tds_section_id,'tds_type'=>$request->tds_type,'tds_percent'=>$request->tds_percent,'tds'=>$request->tds > 0?$request->tds:0,'ods'=>$request->ods > 0?$request->ods:0,'tcs'=>$request->tcs > 0?$request->tcs:0,'due_amount'=>$request->after_total];

                    $purchase_payment->purchases()->attach($attach['purchase_payment'],['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);

                    if($request->after_total == ($request->amount + $request->tds + $request->tcs + $request->ods))
                        $purchase->status = 2;
                
                    $purchase->save();
                }
            }

            $this->generate_payslip_file($purchase);

            DB::commit();
            return response(['data' => new PurchaseResource($purchase),'success'=>true,'message' => 'Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $purchase=Purchase::find($id);
        
        if(!$this->checkDeleteAccess($purchase))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $purchase->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Purchase Deleted Successfully'], 200);
    }

     /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
               {
                    Purchase::whereIn('id',request()->ids)->get()->each(function($purchase) 
                    {
                        $purchase->delete();
                    });
               }
            elseif($access == 3)  
                Purchase::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }

    /**
     * Get Purchases by customer/vendor id.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Renderable
     */
    public function getPurchaseByCustomer()
    {
        

        if(request()->customer_id && request()->customer_id)
           $query=Purchase::with('items')->where('customer_id',request()->customer_id);

        if(request()->action == 'edit')
           $query->whereIn('status',[0,2]);
        else
           $query->where('status',0);      

        $invoices = $query->get();
        
        return response(['data' => $invoices,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }

    /**
     * Get Purchases by customer/vendor id.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Renderable
     */
    public function purchase_print(Request $request,$id)
    {
        $data=array();
        $file=null;
        
        if($purchase_file = PurchaseFile::where('purchase_id',$id)->where('status',1)->orderBy('created_at','desc')->first())
        {
           
            if($request->type == 'print')
            {
                return response(['data' => file_get_contents(storage_path().$purchase_file->print_link),'success'=>true,'message' => 'Updated Successfully'], 200);
            }
            else
            {
                $file = storage_path().$purchase_file->pdf_original_link;
                $headers = array('Content-Type: application/pdf');
                return  response()->file($file, $headers);
            }
            
            
        }
        else
        {
            
            $update_data=array('status'=>0);
            PurchaseFile::where('purchase_id',$id)->update($update_data);
            
            $purchase = Purchase::find($id);
            
            $return = $this->generate_payslip_file($purchase);

            if($request->type == 'print')
            {
                return response(['data' => file_get_contents(storage_path().$return['print_path']),'success'=>true,'message' => 'Updated Successfully'], 200);
            }
            else
            {
                $file = storage_path().$return['pdf_path'];
                $headers = array('Content-Type: application/pdf');
                return  response()->file($file, $headers);
            }
            

        }
    		
    }

    public function generate_payslip_file(Purchase $purchase)
    {
        if($purchase)
        {
            try {
                
                if($purchase->account && $purchase->account->payslip_body)
                {
                    $print_data = array();

                    //Set Account Data Variables
                    $print_data = array_merge($print_data,$this->set_account_data($purchase->account,'payslip'));

                    //Set Customer Data Variables
                    $print_data = array_merge($print_data,$this->set_customer_data($purchase->customer,'payslip'));

                    //Set Invoice Data Variables
                    $print_data = array_merge($print_data,$this->set_payslip_data($purchase,'payslip'));

                    //Set and Replace Multi Item Data In Invoice Body
                    $return = $this->set_item_data($purchase->items,$purchase->account->payslip_body);
                    $payslip_body = $return['body'];
                    $print_data = array_merge($print_data,$return['data']);

                    //Replace Print Data Variables and Conditional Variables in Invoice Body
                    $payslip_body = $this->replace_variable($payslip_body,$print_data,$purchase->account->payslip_body);
                    
                    //Save The Final HTML to PDF
                    $path = storage_path()."/payslip/original_pdf";
                    $path_Org = "/payslip/original_pdf";
                    if (!file_exists($path)) {
                        $this->createPath($path);
                    }
                    $link = $this->save_pdf($purchase,$payslip_body,$path);

                    $html_path = storage_path()."/payslip/print";
                    $html_path_Org = "/payslip/print";
                    if (!file_exists($html_path)) {
                        $this->createPath($html_path);
                    }
                    $html_link = $this->save_print($purchase,$payslip_body,$html_path);
                    
                    $update_data=array('status'=>0);
                    PurchaseFile::where('purchase_id',$purchase->id)->update($update_data);

                    $purchase_file=new PurchaseFile;
                    $purchase_file->purchase_id = $purchase->id;
                    $purchase_file->pdf_original_link = $path_Org."/".$link;
                    $purchase_file->print_link = $html_path_Org."/".$html_link;
                    $purchase_file->status = 1;
                    $purchase_file->save();
                    
                    return ['pdf_path'=>$purchase_file->pdf_original_link,'print_path'=>$purchase_file->print_link];

                }
                else
                    return ['data' => array(),'success'=>false,'message'=>"No Print Template Found In Invoice Account"];
                
            } catch (Exception $ex) {
    
                return ['data' => array(),'success'=>false,'message'=>$ex->getMessage()];
            }
        }
    }

}
