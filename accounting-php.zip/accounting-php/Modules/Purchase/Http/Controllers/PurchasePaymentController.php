<?php

namespace Modules\Purchase\Http\Controllers;

use App\Models\BankAccount;
use App\Models\File;
use App\Models\FiscalYear;
use App\Models\TempFile;
use App\Models\User;
use App\Traits\InvoiceModuleTrait;
use App\Traits\PermissionTrait;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Modules\Customer\Entities\Customer;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Invoice\Entities\TdsSection;
use Modules\Purchase\Entities\Purchase;
use Modules\Purchase\Entities\PurchasePayment;
use Modules\Purchase\Entities\PurchasePaymentFile;
use Modules\Purchase\Transformers\PurchasePaymentResource;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class PurchasePaymentController extends Controller
{
    use PermissionTrait,InvoiceModuleTrait;

    public function getlist()
    {
        $data['customers']=Customer::where('status',1)->get();
        $data['accounts']=InvoiceAccount::where('status',1)->get();
        $data['fiscal_years']=FiscalYear::orderBy('status','desc')->get();
        $data['bank_accounts']=BankAccount::where('status',1)->get();
        $data['payment_types']=array(
            array('name'=>'cash','display_name'=>"Cash"),
            array('name'=>'bank','display_name'=>"Bank A/C")
        );

        $data['transaction_types']=array(
            array('name'=>'online','display_name'=>"Online"),
            array('name'=>'cheque','display_name'=>"Cheque")
        );

        $data['users']=User::orderBy('name','asc')->checkPermission('id')->get();

        $data['tds_sections'] = TdsSection::where('status',1)->get();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
    public function headers()
    {
        $headers = array(
            
            array('column_name'=>'account','display_name'=>'A/C Name','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'formatted_number','display_name'=>'Payment No.','is_display'=>0,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'customer','display_name'=>'Party','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),

            array('column_name'=>'amount','display_name'=>'Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'tds','display_name'=>'TDS','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'ods','display_name'=>'ODS','is_display'=>0,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'tcs','display_name'=>'TCS','is_display'=>0,'is_default'=>0,'is_sortable'=>1),
            
            array('column_name'=>'invoices','display_name'=>'Purchases','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>0,'is_default'=>0,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Renderable
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(PurchasePayment::class)->allowedFilters(['number','date', AllowedFilter::exact('payment_type')->ignore(null),AllowedFilter::scope('date_between'),AllowedFilter::exact('customer_id')->ignore(null),AllowedFilter::exact('invoice_account_id')->ignore(null),AllowedFilter::exact('bank_account_id')->ignore(null),AllowedFilter::exact('fiscal_year_id')->ignore(null),AllowedFilter::exact('created_by')->ignore(null)])->defaultSort('-created_at')->allowedSorts('number','date','payment_type','amount','tds','updated_at');

        $query->search(!empty($request->search)?$request->search:"");

        $payments = $query->with('account','fiscal_year','customer','purchases','files')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $payments,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {   
        
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

    
        $validator = Validator::make($request->all(), [
            'date'=>['required'],
            'customer_id'=>['required'],
            'invoice_account_id'=>['required'],
            'fiscal_year_id'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $payment = PurchasePayment::create($request->except(['purchase']));

            if(isset($request->purchase) && count($request->purchase) > 0 )
            {
                $purchases = [];
                foreach ($request->purchase as $key => $value) 
                {
                  if($value['amount'] > 0)
                    $purchases[$key] = $value; 
                }
                
                if(count($purchases) > 0)
                    $payment->purchases()->attach($purchases,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);

                if($purchases && count($purchases) > 0)
                {
                    
                   foreach ($purchases as $key => $value) 
                   {
                        if($value['due_amount'] == ($value['amount'] + $value['tcs'] + $value['tds'] + $value['ods'] ))
                        {
                           
                            $purchase = Purchase::find($value['purchase_id']);
                            $purchase->status = 2;
                            $purchase->save();

                        }
                   }
                } 
            }
           
            foreach ($request->input('files') as $data) 
            {
                $data['identifier']=isset($data['identifier'])?$data['identifier']:"purchase-payment";
                if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                {
                    if($object = File::withTrashed()->find($data['id']))
                    {
                        $object->restore();
                        $object->fill($data);
                    }
                    else
                    {
                        if($tempobject = TempFile::find($data['temp_id']))
                        {
                            
                            $object = new File($data);
                        }
                    }
                        
                    $payment->files()->save($object);
                }
            }

            $this->generate_purchase_payment_file($payment);

            DB::commit();
            
            return response(['data' =>new PurchasePaymentResource($payment),'success'=>true,'message' => 'Purchase Payment Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $payment = PurchasePayment::findOrFail($id);
        
        return response(['data' => new PurchasePaymentResource($payment),'success'=>true,'message' => 'Purchase Payment Retrived Successfully'], 200);
    }

    /**
     * Update the specified resource in storage.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $payment=PurchasePayment::find($id);
        
        if(!$this->checkUpdateAccess($payment))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'date'=>['required'],
            'customer_id'=>['required'],
            'invoice_account_id'=>['required'],
            'fiscal_year_id'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $payment->update($request->except(['purchase','number','date','invoice_account_id','fiscal_year_id']));
            
            if(isset($request->purchase) && count($request->purchase) > 0)
            {
                $payment->purchases()->detach();
                $payment->purchases()->attach($request->purchase,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            }
            if($request->purchases && count($request->purchases) > 0)
            {
                
                foreach ($request->purchases as $key => $value) 
                {
                    if($value['due_amount'] == ($value['amount'] + $value['tcs'] + $value['tds'] + $value['ods'] ))
                    {
                        
                        $purchase = Purchase::find($value['purchase_id']);
                        $purchase->status = 2;
                        $purchase->save();

                    }
                    else
                    {
                        $purchase = Purchase::find($value['purchase_id']);
                        $purchase->status = 0;
                        $purchase->save();
                    }
                }
            }

            $payment->files()->delete();
            foreach ($request->input('files') as $data) 
            {
                
                $data['identifier']=isset($data['identifier'])?$data['identifier']:"purchase-payment";
                if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                {
                    if($object = File::withTrashed()->find($data['id']))
                    {
                        $object->restore();
                        $object->fill($data);
                    }
                    else
                    {
                        if($tempobject = TempFile::find($data['temp_id']))
                        {
                            
                            $object = new File($data);
                        }
                    }
                        
                    $payment->files()->save($object);
                }
            }

            $this->generate_purchase_payment_file($payment);

            DB::commit();
            
            return response(['data' => new PurchasePaymentResource($payment),'success'=>true,'message' => 'Payment Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $payment=PurchasePayment::find($id);
        
        if(!$this->checkDeleteAccess($payment))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $payment->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Payment Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    PurchasePayment::whereIn('id',request()->ids)->get()->each(function($payment) 
                    {
                        $payment->delete();
                    });
                }
            elseif($access == 3)  
                PurchasePayment::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }

     /**
     * Return Generated Print/Pdf File In Response For Purchase Payment
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Response
     */
    public function purchase_payment_print(Request $request,$id)
    {
        $data=array();
        $file=null;
        
        if($purchase_payment_file = PurchasePaymentFile::where('purchase_payment_id',$id)->where('status',1)->orderBy('created_at','desc')->first())
        {
           
            if($request->type == 'print')
            {
                return response(['data' => file_get_contents(storage_path().$purchase_payment_file->print_link),'success'=>true,'message' => 'Updated Successfully'], 200);
            }
            else
            {
                $file = storage_path().$purchase_payment_file->pdf_original_link;
                $headers = array('Content-Type: application/pdf');
                return  response()->file($file, $headers);
            }
            
            
        }
        else
        {
            
            $update_data=array('status'=>0);
            PurchasePaymentFile::where('purchase_payment_id',$id)->update($update_data);
            
            $purchase_payment = PurchasePayment::find($id);
            
            $return = $this->generate_purchase_payment_file($purchase_payment);
           
            if($request->type == 'print')
            {
                return response(['data' => file_get_contents(storage_path().$return['print_path']),'success'=>true,'message' => 'Updated Successfully'], 200);
            }
            else
            {
                $file = storage_path().$return['pdf_path'];
                $headers = array('Content-Type: application/pdf');
                return  response()->file($file, $headers);
            }
            

        }
    }
    /**
     * Generate Print & Pdf File For Purchase Payment
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Response
     */
    public function generate_purchase_payment_file(PurchasePayment $purchase_payment)
    {
        if($purchase_payment)
        {
            try {
                if($purchase_payment->account && $purchase_payment->account->purchase_payment_body)
                {
                    $print_data = array();

                    //Set Account Data Variables
                    $print_data = array_merge($print_data,$this->set_account_data($purchase_payment->account,'purchase_payment'));

                    //Set Customer Data Variables
                    $print_data = array_merge($print_data,$this->set_customer_data($purchase_payment->customer,'purchase_payment'));

                    //Set Payment Data Variables
                    $print_data = array_merge($print_data,$this->set_payment_data($purchase_payment,'purchase_payment'));

                   
                    //Set and Replace Multi Item Data In Invoice Body
                    $return = $this->set_payments_item_data($purchase_payment,$purchase_payment->purchases,$purchase_payment->account->purchase_payment_body);
                    $purchase_payment_body = $return['body'];

                    //Replace Print Data Variables and Conditional Variables in Invoice Body
                    $purchase_payment_body = $this->replace_variable($purchase_payment_body,$print_data,$purchase_payment->account->purchase_payment_body);

                    //Save The Final HTML to PDF
                    $path = storage_path()."/purchase_payment/original_pdf";
                    $path_Org = "/purchase_payment/original_pdf";
                    if (!file_exists($path)) {
                        $this->createPath($path);
                    }
                    $link = $this->save_pdf($purchase_payment,$purchase_payment_body,$path);

                    $html_path = storage_path()."/purchase_payment/print";
                    $html_path_Org = "/purchase_payment/print";
                    if (!file_exists($html_path)) {
                        $this->createPath($html_path);
                    }
                    $html_link = $this->save_print($purchase_payment,$purchase_payment_body,$html_path);

                    $update_data=array('status'=>0);
                    PurchasePaymentFile::where('purchase_payment_id',$purchase_payment->id)->update($update_data);

                    $purchase_payment_file=new PurchasePaymentFile;
                    $purchase_payment_file->purchase_payment_id = $purchase_payment->id;
                    $purchase_payment_file->pdf_original_link = $path_Org."/".$link;
                    $purchase_payment_file->print_link = $html_path_Org."/".$html_link;
                    $purchase_payment_file->status = 1;
                    $purchase_payment_file->save();
                    
                    return ['pdf_path'=>$purchase_payment_file->pdf_original_link,'print_path'=>$purchase_payment_file->print_link];
                }
                else
                    return ['data' => array(),'success'=>false,'message'=>"No Print Template Found In Invoice Account"];
            } catch (Exception $ex) {
    
                return ['data' => array(),'success'=>false,'message'=>$ex->getMessage()];
            }    
        }
    }

}
