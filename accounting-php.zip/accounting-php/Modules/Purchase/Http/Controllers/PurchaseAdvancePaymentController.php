<?php

namespace Modules\Purchase\Http\Controllers;

use App\Models\File;
use App\Models\TempFile;
use App\Models\BankAccount;
use App\Models\FiscalYear;
use App\Models\User;
use App\Traits\InvoiceModuleTrait;
use App\Traits\PermissionTrait;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Modules\Customer\Entities\Customer;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Purchase\Entities\PurchaseAdvancePayment;
use Modules\Purchase\Http\Requests\PurchaseAdvanceRequest;
use Modules\Purchase\Transformers\PurchaseAdvancePaymentResource;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class PurchaseAdvancePaymentController extends Controller
{
    use PermissionTrait,InvoiceModuleTrait;
    
    public function getlist()
    {
        $data['customers']=Customer::where('status',1)->get();
        $data['accounts']=InvoiceAccount::where('status',1)->get();
        $data['fiscal_years']=FiscalYear::orderBy('status','desc')->get();
        $data['bank_accounts']=BankAccount::where('status',1)->get();
        $data['payment_types']=array(
            array('name'=>'cash','display_name'=>"Cash"),
            array('name'=>'bank','display_name'=>"Bank A/C")
        );

        $data['transaction_types']=array(
            array('name'=>'online','display_name'=>"Online"),
            array('name'=>'cheque','display_name'=>"Cheque")
        );

        $data['types']=array(
            array('name'=>'debit','display_name'=>"Debit"),
            array('name'=>'credit','display_name'=>"Credit")
        );

        $data['entry_types']=array(
            array('name'=>0,'display_name'=>"Manual Entry"),
            array('name'=>1,'display_name'=>"Auto Entry")
        );

        $data['users']=User::orderBy('name','asc')->checkPermission('id')->get();
        
        $data['total_items'] = $this->getTotalItems();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
    public function headers()
    {
        $headers = array(
            
            array('column_name'=>'account','display_name'=>'A/C Name','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'type','display_name'=>'Type','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'item_name','display_name'=>'Item','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),

            array('column_name'=>'amount','display_name'=>'Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>0,'is_default'=>0,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(PurchaseAdvancePayment::class)->allowedFilters(['date', AllowedFilter::exact('payment_type')->ignore(null),AllowedFilter::scope('date_between'),AllowedFilter::exact('customer_id')->ignore(null),AllowedFilter::exact('invoice_account_id')->ignore(null),AllowedFilter::exact('bank_account_id')->ignore(null),AllowedFilter::exact('fiscal_year_id')->ignore(null),AllowedFilter::exact('type')->ignore(null),AllowedFilter::exact('created_by')->ignore(null),AllowedFilter::exact('section')->ignore(null),AllowedFilter::exact('auto_entry')->ignore(null)])->defaultSort('-created_at')->allowedSorts('number','date','payment_type','type','updated_at','amount');

        $query->search(!empty($request->search)?$request->search:"");

        $payments = $query->with('account','fiscal_year','customer','files')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $payments,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(PurchaseAdvanceRequest $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

    
        DB::beginTransaction();
        try {
            $payment = PurchaseAdvancePayment::create($request->all());
           
            foreach ($request->input('files') as $data) 
            {
                $data['identifier']=isset($data['identifier'])?$data['identifier']:"purchase-advance-payment";
                if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                {
                    if($object = File::withTrashed()->find($data['id']))
                    {
                        $object->restore();
                        $object->fill($data);
                    }
                    else
                    {
                        if($tempobject = TempFile::find($data['temp_id']))
                        {
                            
                            $object = new File($data);
                        }
                    }
                        
                    $payment->files()->save($object);
                }
            }
            DB::commit();
            
            return response(['data' =>new PurchaseAdvancePaymentResource($payment),'success'=>true,'message' => 'Entity Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $payment = PurchaseAdvancePayment::findOrFail($id);
        
        return response(['data' => new PurchaseAdvancePaymentResource($payment),'success'=>true,'message' => 'Purchase Advance Payment Retrived Successfully'], 200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(PurchaseAdvanceRequest $request, $id)
    {
        $payment=PurchaseAdvancePayment::find($id);
        
        if(!$this->checkUpdateAccess($payment))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        

        DB::beginTransaction();
        try {
            
            $payment->update($request->except(['date','invoice_account_id','fiscal_year_id']));
            
            $payment->files()->delete();
            foreach ($request->input('files') as $data) 
            {
                
                $data['identifier']=isset($data['identifier'])?$data['identifier']:"purchase-payment";
                if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                {
                    if($object = File::withTrashed()->find($data['id']))
                    {
                        $object->restore();
                        $object->fill($data);
                    }
                    else
                    {
                        if($tempobject = TempFile::find($data['temp_id']))
                        {
                            
                            $object = new File($data);
                        }
                    }
                        
                    $payment->files()->save($object);
                }
            }
            DB::commit();
            
            return response(['data' => new PurchaseAdvancePaymentResource($payment),'success'=>true,'message' => 'Entity Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $payment=PurchaseAdvancePayment::find($id);
        
        if(!$this->checkDeleteAccess($payment))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $payment->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Payment Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    PurchaseAdvancePayment::whereIn('id',request()->ids)->get()->each(function($payment) 
                    {
                        $payment->delete();
                    });
                }
            elseif($access == 3)  
                PurchaseAdvancePayment::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
