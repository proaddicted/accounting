<?php

namespace Modules\Invoice\Http\Controllers;

use App\Models\FiscalYear;
use App\Models\NotificationTemplate;
use App\Models\State;
use App\Models\User;
use App\Traits\InvoiceModuleTrait;
use App\Traits\PermissionTrait;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Customer\Entities\Customer;
use Modules\Invoice\Entities\Invoice;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Invoice\Entities\Item;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Modules\Invoice\Entities\InvoiceFile;
use Modules\Invoice\Entities\InvoiceSeries;
use Modules\Invoice\Entities\Payment;
use Modules\Invoice\Entities\TcsSection;
use Modules\Invoice\Entities\TdsSection;
use Modules\Invoice\Http\Requests\InvoiceApiRequest;
use Modules\Invoice\Http\Requests\InvoiceCommissionApiRequest;
use Modules\Invoice\Notifications\InvoiceCreatedNotification;
use Modules\Invoice\Rules\InvoiceDateRule;
use Modules\Invoice\Rules\InvoiceNumberRule;
use Modules\Invoice\Transformers\InvoiceResource;
use Modules\Purchase\Entities\PurchaseAdvancePayment;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use PDF;

class InvoiceController extends Controller
{
    use PermissionTrait,InvoiceModuleTrait;

    public function getlist()
    {
       
        $data['states']=State::where('status',1)->get();
        $data['customers']=Customer::where('status',1)->get();
        $data['items']=Item::where('status',1)->get();
        $data['accounts']=InvoiceAccount::where('status',1)->get()->toArray();
        $data['fiscal_years']=FiscalYear::orderBy('status','desc')->get();
        $data['invoice_series']=InvoiceSeries::with('items')->where('status',1)->get();

        $data['users']=User::orderBy('name','asc')->checkPermission('id')->get();
        $data['statuses'] = array(
            array('id'=>0,'name'=>'Pending'),
            array('id'=>1,'name'=>'Canceled'),
            array('id'=>2,'name'=>'Received'),
            array('id'=>'0,1,2','name'=>'All')
        ); 
        foreach($data['accounts'] as $key => $account)
	        {
				$data['accounts'][$key]['default_max_no'] = sprintf(env('DEFAULT_NUMBER_FORMAT'),(001));
				
				foreach($data['fiscal_years'] as $key1 => $fiscal)
					{
                        $data['accounts'][$key]['fiscal_years'][$key1]['default_max_no'] = sprintf(env('DEFAULT_NUMBER_FORMAT'),(001));
                        $data['accounts'][$key]['fiscal_years'][$key1]['fiscal_year_id'] = $fiscal->id;

                        $i = 0;
				        $t = array();
                        foreach($data['invoice_series'] as $key2 => $series)
					    {
                            $t[$i]['account_id'] = $account['id'];
                            $t[$i]['id'] = $fiscal->id;
                            $t[$i]['series_id'] = $series->id;
                            $t[$i]['max_no'] = sprintf(env('DEFAULT_NUMBER_FORMAT'),(001));
                            $invoice=Invoice::where('invoice_account_id',$account['id'])->where('fiscal_year_id',$fiscal->id)->where('invoice_series_id',$series->id)->max('number');
                            if(intval($invoice) > 0)
                                $t[$i]['max_no'] = sprintf(env('DEFAULT_NUMBER_FORMAT'), intval($invoice) + 1);
                            $i++;
                        }
                        $data['accounts'][$key]['fiscal_years'][$key1]['invoice_max_no'] = $t;
					}
				
	        }
        $data['invoice_number'] = sprintf(env('DEFAULT_NUMBER_FORMAT'),(001));


        $data['tds_sections']=TdsSection::where('status',1)->get();
        $data['tcs_sections']=TcsSection::where('status',1)->get();
    

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
    public function headers()
    {
        $headers = array(
            
            array('column_name'=>'account','display_name'=>'A/C Name','is_display'=>1,'is_default'=>0,'is_sortable'=>0),array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),

            array('column_name'=>'formatted_number','display_name'=>'Invoice No.','is_display'=>1,'is_default'=>1,'is_sortable'=>0),

            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'customer','display_name'=>'Customer','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
           

            array('column_name'=>'before_total','display_name'=>'Amount','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'cgst','display_name'=>'CGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'sgst','display_name'=>'SGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'igst','display_name'=>'IGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'after_total','display_name'=>'Total Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'due_amount','display_name'=>'Due Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'due_age','display_name'=>'Due Age','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'items','display_name'=>'Items','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'remarks','display_name'=>'Remarks','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'note','display_name'=>'Notes','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'proforma_invoice','display_name'=>'Proforma Invoice','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'creator','display_name'=>'Creator','is_display'=>1,'is_default'=>0,'is_sortable'=>0)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        
        $query = QueryBuilder::for(Invoice::class)->allowedFilters(['number','date','after_total', AllowedFilter::scope('date_between'),AllowedFilter::exact('customer_id')->ignore(null),AllowedFilter::exact('invoice_account_id')->ignore(null),AllowedFilter::exact('fiscal_year_id')->ignore(null),AllowedFilter::exact('created_by')->ignore(null),AllowedFilter::exact('status')->default('0')])->defaultSort('-created_at')->allowedSorts('number','date','after_total','before_total','cgst','sgst','igst','remarks','note');

        
        $query->search(!empty($request->search)?$request->search:"");

        $invoices = $query->with('account','fiscal_year','customer','items','proforma_invoice')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $invoices,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        
        $validator = Validator::make($request->all(), [
            'number' => ['required',new InvoiceNumberRule],
            'date'=>['required',new InvoiceDateRule],
            'customer_id'=>['required'],
            'invoice_account_id'=>['required'],
            'invoice_series_id'=>['required'],
            'fiscal_year_id'=>['required'],
            'after_total' => ['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $invoice = Invoice::create($request->except(['invoice']));
        
            $invoice->items()->attach($request->invoice,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            
            $this->generate_file($invoice);

            DB::commit();
            return response(['data' => $invoice,'success'=>true,'message' => 'Invoice Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
       
        $invoice = Invoice::findOrFail($id);
        // return $this->generate_file($invoice); exit;
        return response(['data' => new InvoiceResource($invoice),'success'=>true,'message' => 'Invoice Retrived Successfully'], 200);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
       
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $invoice=Invoice::find($id);
        
        if(!$this->checkUpdateAccess($invoice))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'customer_id'=>['required'],
            'invoice_account_id'=>['required'],
            'invoice_series_id'=>['required'],
            'fiscal_year_id'=>['required'],
            'after_total' => [
                'required',
                function ($attribute, $value, $fail) use ($id){
                    $model = Invoice::find($id); 
                    if ($value < $model->paid_amount) {
                        $fail("Total amount can't be less than paid amount = ".$model->paid_amount." , Please adjust rates");
                    }
                },
            ],
        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $invoice->update($request->except(['invoice','number','date','invoice_account_id','fiscal_year_id']));
            
            if(isset($request->invoice) && count($request->invoice) > 0)
            {
                $invoice->items()->detach();
                $invoice->items()->attach($request->invoice,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            }
            
            $this->generate_file($invoice);
            
            DB::commit();
            return response(['data' => new InvoiceResource($invoice),'success'=>true,'message' => 'Invoice Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $invoice=Invoice::find($id);
        
        if(!$this->checkDeleteAccess($invoice))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $invoice->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Invoice Deleted Successfully'], 200);
    }

     /**
     * Get Invoices by customer id.
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Renderable
     */
     public function getInvoiceByCustomer()
     {
         

         if(request()->customer_id && request()->customer_id)
            $query=Invoice::with('items')->where('customer_id',request()->customer_id);

        if(request()->action == 'edit')
            $query->whereIn('status',[0,2]);
        else
            $query->where('status',0);      

         $invoices = $query->get();
         
         return response(['data' => $invoices,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
 
     }

     /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
               {
                    Invoice::whereIn('id',request()->ids)->get()->each(function($invoice) 
                    {
                        $invoice->delete();
                    });
               }
            elseif($access == 3)  
                Invoice::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }

    public function invoice_print($id)
    {
        $data=array();
        $file=null;
        
        if($invoice_file = InvoiceFile::where('invoice_id',$id)->where('status',1)->orderBy('created_at','desc')->first())
        {
           
            $file = storage_path().$invoice_file->pdf_original_link;
            $headers = array('Content-Type: application/pdf');
            return  response()->file($file, $headers);
            
        }
        else
        {
            
            $update_data=array('status'=>0);
            InvoiceFile::where('invoice_id',$id)->update($update_data);
            
            $invoice = Invoice::find($id);
            
            $link = $this->generate_file($invoice);
            $file = storage_path().$link;
            $headers = array('Content-Type: application/pdf');
            return  response()->file($file, $headers);

        }
    		
    }
    
    public function generate_file(Invoice $invoice)
    {
        if($invoice)
        {
            try {
                
                if($invoice->account && $invoice->account->invoice_body)
                {
                    $print_data = array();

                    //Set Account Data Variables
                    $print_data = array_merge($print_data,$this->set_account_data($invoice->account,'invoice'));

                    //Set Customer Data Variables
                    $print_data = array_merge($print_data,$this->set_customer_data($invoice->customer,'invoice'));

                    //Set Invoice Data Variables
                    $print_data = array_merge($print_data,$this->set_invoice_data($invoice,'invoice'));

                    //Set and Replace Multi Item Data In Invoice Body
                    $return = $this->set_item_data($invoice->items,$invoice->account->invoice_body);
                    $invoice_body = $return['body'];
                    $print_data = array_merge($print_data,$return['data']);

                    //Replace Print Data Variables and Conditional Variables in Invoice Body
                    $invoice_body = $this->replace_variable($invoice_body,$print_data,$invoice->account->invoice_body);
                    
                    //Save The Final HTML to PDF
                    $path = storage_path()."/invoice/original_pdf";
                    $path_Org = "/invoice/original_pdf";
                    if (!file_exists($path)) {
                        $this->createPath($path);
                    }
                    $link = $this->save_pdf($invoice,$invoice_body,$path);
                    
                    $update_data=array('status'=>0);
                    InvoiceFile::where('invoice_id',$invoice->id)->update($update_data);

                    $invoice_file=new InvoiceFile;
                    $invoice_file->invoice_id = $invoice->id;
                    $invoice_file->pdf_original_link = $path_Org."/".$link;
                    $invoice_file->status = 1;
                    $invoice_file->save();
                    
                    return $invoice_file->pdf_original_link;

                }
                else
                    return ['data' => array(),'success'=>false,'message'=>"No Print Template Found In Invoice Account"];
                
            } catch (Exception $ex) {
    
                return ['data' => array(),'success'=>false,'message'=>$ex->getMessage()];
            }
        }
    }

    public function send_invoice_mail_customer($id)
    {
        $invoice = Invoice::findOrFail($id);
        if($invoice_file = InvoiceFile::where('invoice_id',$id)->where('status',1)->orderBy('created_at','desc')->first())
        {
            if($template = NotificationTemplate::where('name','invoice-created-notification-customer')->where('status',1)->first())
            {
                    try{
                
                        $file = storage_path().$invoice_file->pdf_original_link;
                        $data['attachments'] = [
                            $file => [
                                'as' => $invoice->formatted_number.'.pdf',
                                'mime' => 'application/pdf',
                            ]
                        ];
                        $data['invoice'] = new InvoiceResource($invoice);
                        $data['template'] = $template;
                        $data['section'] = "invoice";
                        $invoice->customer->notify(new InvoiceCreatedNotification($data));
        
                        return response(['data' => array(),'success'=>true,'message' => 'Notification Send'], 200);
                    }
                    catch (Exception $ex) {
                        return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
                    } 
            }
            else
            {
                return response(['data' => array(),'success'=>true,'message' => 'Notification Is Disabled'], 500);  
            }
            
        }
        else
             return response(['data' => array(),'success'=>true,'message' => 'Notification Failure'], 500);
        
    }

    public function storeInvoiceApi(InvoiceApiRequest $request)
    {
        
        DB::beginTransaction();
        
        try {
            
            /* Generate Invoice */
            $invoice = Invoice::create($request->except(['items','transaction_id','transaction_type','transaction_date','transaction_bank']));
            
            $invoice->items()->attach($request->items['invoice'],['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            
            
            /* Payment Invoice */
            /* Below Code Is Disabled As Per Instruction on 05/09/2021*/
            /*
            $payment = Payment::create(['invoice_account_id'=>$request->invoice_account_id,'fiscal_year_id'=>$request->fiscal_year_id,'date'=>date('Y-m-d'),'customer_id'=>$request->customer_id,'payment_type'=>'bank','transaction_id'=>$request->transaction_id,'transaction_type'=>$request->transaction_type,'transaction_date'=>$request->transaction_date,'transaction_bank'=>$request->transaction_bank,'amount'=>$request->after_total]);

            $attach['invoice'][0] = ['invoice_id'=>$invoice->id,'pay_amount'=>$request->after_total,'amount'=>$request->after_total,'tds'=>0,'ods'=>0,'tcs'=>0,'due_amount'=>$request->after_total];
            
            $payment->invoices()->attach($attach['invoice'],['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);

            // Update Invoice Status
            $invoice->status = 2;
            $invoice->save();
            */
            $this->generate_file($invoice);


            DB::commit();

            return response(['data' => $invoice,'success'=>true,'message' => 'Invoice & Payment Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }    
    }

    public function storeCommissionApi(InvoiceCommissionApiRequest $request)
    {
       
        DB::beginTransaction();

        try {

            /*Generate Advance Received*/
            if($request->base_amount > 0)
            {
                $advance_payment = PurchaseAdvancePayment::create([
                    'amount'=>($request->base_amount + $request->base_gst),
                    'customer_id'=>$request->customer_id,
                    'main_id'=>$request->customer_id,
                    'identifier'=>'customer',
                    'type'=>'credit',
                    'section'=>'advance',
                    'remarks'=>'Payment Received for Appoinment/Package (With GST)',
                    'invoice_account_id'=>$request->invoice_account_id,
                    'fiscal_year_id'=>$request->fiscal_year_id,
                    'transaction_id'=>$request->transaction_id,'transaction_type'=>$request->transaction_type,'transaction_date'=>$request->transaction_date,'transaction_bank'=>$request->transaction_bank,
                    'date'=>date('Y-m-d'),
                    'payment_type'=>'bank',
                    'auto_entry'=>1
                ]);
            }


            /* Generate Invoice */
            $invoice = Invoice::create($request->except(['items','transaction_id','transaction_type','transaction_date','transaction_bank']));
            
            $invoice->items()->attach($request->items['invoice'],['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            
            
            /* Payment Invoice */
            /* Below Code Is Disabled As Per Instruction on 05/09/2021*/
            /*
            $payment = Payment::create(['invoice_account_id'=>$request->invoice_account_id,'fiscal_year_id'=>$request->fiscal_year_id,'date'=>date('Y-m-d'),'customer_id'=>$request->customer_id,'payment_type'=>'bank','transaction_id'=>$request->transaction_id,'transaction_type'=>$request->transaction_type,'transaction_date'=>$request->transaction_date,'transaction_bank'=>$request->transaction_bank,'amount'=>$request->after_total]);

            $attach['invoice'][0] = ['invoice_id'=>$invoice->id,'pay_amount'=>$request->after_total,'amount'=>$request->after_total,'tds'=>0,'ods'=>0,'tcs'=>0,'due_amount'=>$request->after_total];
            
            $payment->invoices()->attach($attach['invoice'],['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);


            $advance_refund = PurchaseAdvancePayment::create([
                'amount'=>($request->after_total),
                'customer_id'=>$request->customer_id,
                'type'=>'debit',
                'remarks'=>'Commission Adjusted from Advance',
                'invoice_account_id'=>$request->invoice_account_id,
                'fiscal_year_id'=>$request->fiscal_year_id,
                'transaction_id'=>$request->transaction_id,'transaction_type'=>$request->transaction_type,'transaction_date'=>$request->transaction_date,'transaction_bank'=>$request->transaction_bank,
                'date'=>date('Y-m-d'),
                'payment_type'=>'bank'
            ]);

            // Update Invoice Status 
            $invoice->status = 2;
            $invoice->save();
            */
            $this->generate_file($invoice);

            DB::commit();

            return response(['data' => $invoice,'success'=>true,'message' => 'Invoice & Payment Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }    
    }

}
