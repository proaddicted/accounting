<?php

namespace Modules\Invoice\Http\Controllers;

use App\Traits\PermissionTrait;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Invoice\Entities\Item;
use Spatie\QueryBuilder\QueryBuilder;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Modules\Invoice\Entities\Category;
use Modules\Invoice\Entities\ItemGroup;
use Modules\Invoice\Transformers\ItemResource;
use Spatie\QueryBuilder\AllowedFilter;

class ItemController extends Controller
{
    use PermissionTrait;

    public function getlist()
    {
      $data['item_groups']=ItemGroup::where('status',1)->get();
      $data['categories']=Category::where('status',1)->get();
      $data['items']=Item::where('status',1)->where('is_child_allowed',1)->get();

      return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }

    public function headers()
    {
        $headers = array(
            array('column_name'=>'group','display_name'=>'Group','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'categories','display_name'=>'Category','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'description','display_name'=>'Description','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'hsn_code','display_name'=>'HSN Code','is_display'=>0,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'sac_code','display_name'=>'SAC Code','is_display'=>0,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'hsn_sac_code','display_name'=>'HSN/SAC Code','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'cgst','display_name'=>'CGST','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'sgst','display_name'=>'SGST','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'igst','display_name'=>'IGST','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>1,'is_default'=>1,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Item::class)->allowedFilters(['name','sac_code','hsn_code',AllowedFilter::exact('item_group_id')->ignore(null)])->defaultSort('-created_at')->allowedSorts('name','sac_code','hsn_code','description','cgst','sgst','igst');

        $query->search(!empty($request->search)?$request->search:"");

        $items = $query->with('group','categories')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $items,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
    
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

            
        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $item = Item::create($request->except('category_id'));
            
            $item->categories()->attach($request->category_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 

            DB::commit();
            return response(['data' => new ItemResource($item),'success'=>true,'message' => 'Item Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $item = Item::findOrFail($id);
        
        return response(['data' => new ItemResource($item),'success'=>true,'message' => 'Item Retrived Successfully'], 200);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
       
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $item=Item::find($id);
        
        if(!$this->checkUpdateAccess($item))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
            
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'parent_id' => [
                function ($attribute, $value, $fail) use ($id){
                    if ($value == $id) {
                        $fail('Parent Item Cant Be Same Item.');
                    }
                },
            ]

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $item->update($request->except('category_id'));

            $item->categories()->detach();
            
            $item->categories()->attach($request->category_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 

            DB::commit();
            
            return response(['data' => new ItemResource($item),'success'=>true,'message' => 'Item Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
           
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $item=Item::find($id);
        
        if(!$this->checkDeleteAccess($item))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $item->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Item Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @param int $id
     * @return Renderable
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                Item::whereIn('id',request()->ids)->delete();
            elseif($access == 3)  
                Item::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
