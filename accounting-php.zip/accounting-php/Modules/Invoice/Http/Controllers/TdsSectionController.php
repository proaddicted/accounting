<?php

namespace Modules\Invoice\Http\Controllers;

use App\Traits\PermissionTrait;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Spatie\QueryBuilder\QueryBuilder;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Modules\Invoice\Entities\TdsSection;
use Modules\Invoice\Transformers\TdsSectionResource;

class TdsSectionController extends Controller
{
    use PermissionTrait;

    public function headers()
    {
        $headers = array(
           
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'description','display_name'=>'Description','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>1,'is_default'=>1,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(TdsSection::class)->allowedFilters(['name'])->defaultSort('-created_at')->allowedSorts('name','description');

        $query->search(!empty($request->search)?$request->search:"");

        $items = $query->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $items,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
    
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

            
        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $item = TdsSection::create($request->all());
            
            
            DB::commit();
            return response(['data' => new TdsSectionResource($item),'success'=>true,'message' => 'TDS Section Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $item = TdsSection::findOrFail($id);
        
        return response(['data' => new TdsSectionResource($item),'success'=>true,'message' => 'TDS Section Retrived Successfully'], 200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $item=TdsSection::find($id);
        
        if(!$this->checkUpdateAccess($item))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
            
        $validator = Validator::make($request->all(), [
            'name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $item->update($request->all());

            DB::commit();
            
            return response(['data' => new TdsSectionResource($item),'success'=>true,'message' => 'TDS Section Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
           
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }


    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $item=TdsSection::find($id);
        
        if(!$this->checkDeleteAccess($item))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $item->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'TDS Section Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @param int $id
     * @return Renderable
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
            {
                TdsSection::whereIn('id',request()->ids)->get()->each(function($tds_section) 
                {
                    $tds_section->delete();
                });
            }
            elseif($access == 3)  
                TdsSection::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
