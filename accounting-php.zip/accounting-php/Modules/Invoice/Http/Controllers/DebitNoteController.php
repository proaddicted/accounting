<?php

namespace Modules\Invoice\Http\Controllers;

use App\Models\FiscalYear;
use App\Models\NotificationTemplate;
use App\Models\State;
use App\Models\User;
use App\Traits\InvoiceModuleTrait;
use App\Traits\PermissionTrait;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Customer\Entities\Customer;
use Modules\Invoice\Entities\DebitNote;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Invoice\Entities\Item;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Modules\Invoice\Entities\DebitNoteFile;
use Modules\Invoice\Rules\DebitNoteDateRule;
use Modules\Invoice\Rules\DebitNoteNumberRule;
use Modules\Invoice\Transformers\DebitNoteResource;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\Invoice\Notifications\InvoiceCreatedNotification;


class DebitNoteController extends Controller
{
    use PermissionTrait,InvoiceModuleTrait;
    
    public function getlist()
    {
       
        $data['states']=State::where('status',1)->get();
        $data['customers']=Customer::where('status',1)->get();
        $data['items']=Item::where('status',1)->get();
        $data['accounts']=InvoiceAccount::where('status',1)->get();
        $data['fiscal_years']=FiscalYear::orderBy('status','desc')->get();

        $data['users']=User::orderBy('name','asc')->checkPermission('id')->get();

        foreach($data['accounts'] as $key => $account)
	        {
				$data['accounts'][$key]['default_max_no'] = sprintf(env('DEFAULT_NUMBER_FORMAT'),(001));
				$i = 0;
				$t = array();
				foreach($data['fiscal_years'] as $key1 => $fiscal)
					{
			            $t[$i]['account_id'] = $account['id'];
			            $t[$i]['id'] = $fiscal->id;
			            $t[$i]['max_no'] = sprintf(env('DEFAULT_NUMBER_FORMAT'),(001));
						$debitnote=DebitNote::where('invoice_account_id',$account['id'])->where('fiscal_year_id',$fiscal->id)->max('number');
						if(intval($debitnote) > 0)
				            $t[$i]['max_no'] = sprintf(env('DEFAULT_NUMBER_FORMAT'), intval($debitnote) + 1);
						$i++;
					}
				$data['accounts'][$key]['debit_note_max_no'] = $t;
	        }
        $data['debit_note_number'] = sprintf(env('DEFAULT_NUMBER_FORMAT'),(001));

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
    public function headers()
    {
        $headers = array(
            array('column_name'=>'invoice','display_name'=>'Invoice No.','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'account','display_name'=>'A/C Name','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'formatted_number','display_name'=>'Debit Note No.','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'customer','display_name'=>'Customer','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),

            array('column_name'=>'before_total','display_name'=>'Amount','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'cgst','display_name'=>'CGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'sgst','display_name'=>'SGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'igst','display_name'=>'IGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'after_total','display_name'=>'Taxable Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'items','display_name'=>'Items','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>0,'is_default'=>0,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(DebitNote::class)->allowedFilters(['number','date','after_total',AllowedFilter::scope('date_between'),AllowedFilter::exact('invoice_id')->ignore(null),AllowedFilter::exact('customer_id')->ignore(null),AllowedFilter::exact('invoice_account_id')->ignore(null),AllowedFilter::exact('fiscal_year_id')->ignore(null),AllowedFilter::exact('created_by')->ignore(null),AllowedFilter::exact('status')->ignore(null)])->defaultSort('-created_at')->allowedSorts('number','date','after_total','before_total','cgst','sgst','igst','updated_at');

        $query->search(!empty($request->search)?$request->search:"");

        $debit_notes = $query->with('account','fiscal_year','customer','items','invoice')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $debit_notes,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
        return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

    
        $validator = Validator::make($request->all(), [
            'number' => ['required',new DebitNoteNumberRule],
            'date'=>['required',new DebitNoteDateRule],
            'customer_id'=>['required'],
            'invoice_account_id'=>['required'],
            'fiscal_year_id'=>['required'],
            'invoice_id'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $debitnote = DebitNote::create($request->except(['invoice']));
        
            $debitnote->items()->attach($request->invoice,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            
            $this->generate_file($debitnote);
            DB::commit();
            return response(['data' =>new DebitNoteResource($debitnote),'success'=>true,'message' => 'Debit Note Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $debitnote = DebitNote::findOrFail($id);
        // return $this->send_debitnote_mail_customer($id); exit;
        return response(['data' => new DebitNoteResource($debitnote),'success'=>true,'message' => 'Debit Note Retrived Successfully'], 200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $debitnote=DebitNote::find($id);
        
        if(!$this->checkUpdateAccess($debitnote))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'customer_id'=>['required'],
            'invoice_account_id'=>['required'],
            'fiscal_year_id'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $debitnote->update($request->except(['invoice','number','date','invoice_account_id','fiscal_year_id']));
            
            if(isset($request->invoice) && count($request->invoice) > 0)
            {
                $debitnote->items()->detach();
                $debitnote->items()->attach($request->invoice,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            }
            
            $this->generate_file($debitnote);
            
            DB::commit();
            return response(['data' => new DebitNoteResource($debitnote),'success'=>true,'message' => 'Debit Note Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $debitnote=DebitNote::find($id);
        
        if(!$this->checkDeleteAccess($debitnote))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $debitnote->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Debit Note Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
               {
                    DebitNote::whereIn('id',request()->ids)->get()->each(function($debitnote) 
                    {
                        $debitnote->delete();
                    });
               }
            elseif($access == 3)  
                DebitNote::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }

    public function debitnote_print($id)
    {
        $data=array();
        $file=null;
        
        if($invoice_file = DebitNoteFile::where('debit_note_id',$id)->where('status',1)->orderBy('created_at','desc')->first())
        {
           
            $file = storage_path().$invoice_file->pdf_original_link;
            $headers = array('Content-Type: application/pdf');
            return  response()->file($file, $headers);
            
        }
        else
        {
            
            $update_data=array('status'=>0);
            DebitNoteFile::where('debit_note_id',$id)->update($update_data);
            
            $debit_note = DebitNote::find($id);
            
            $link = $this->generate_file($debit_note);
            $file = storage_path().$link;
            $headers = array('Content-Type: application/pdf');
            return  response()->file($file, $headers);

        }
    		
    }
    
    public function generate_file(DebitNote $debit_note)
    {
        if($debit_note)
        {
            try {
                
                if($debit_note->account && $debit_note->account->debit_note_body)
                {
                    $print_data = array();

                    //Set Account Data Variables
                    $print_data = array_merge($print_data,$this->set_account_data($debit_note->account,'debit_note'));

                    //Set Customer Data Variables
                    $print_data = array_merge($print_data,$this->set_customer_data($debit_note->customer,'debit_note'));

                    //Set Invoice Data Variables
                    $print_data = array_merge($print_data,$this->set_invoice_data($debit_note,'debit_note'));

                    //Set and Replace Multi Item Data In Invoice Body
                    $return = $this->set_item_data($debit_note->items,$debit_note->account->debit_note_body);
                    $debit_note_body = $return['body'];
                    $print_data = array_merge($print_data,$return['data']);

                    //Replace Print Data Variables and Conditional Variables in Invoice Body
                    $debit_note_body = $this->replace_variable($debit_note_body,$print_data,$debit_note->account->debit_note_body);
                    
                    //Save The Final HTML to PDF
                    $path = storage_path()."/debit-note/original_pdf";
                    $path_Org = "/debit-note/original_pdf";
                    if (!file_exists($path)) {
                        $this->createPath($path);
                    }
                    $link = $this->save_pdf($debit_note,$debit_note_body,$path);
                    
                    $update_data=array('status'=>0);
                    DebitNoteFile::where('debit_note_id',$debit_note->id)->update($update_data);

                    $invoice_file=new DebitNoteFile;
                    $invoice_file->debit_note_id = $debit_note->id;
                    $invoice_file->pdf_original_link = $path_Org."/".$link;
                    $invoice_file->status = 1;
                    $invoice_file->save();
                    
                    return $invoice_file->pdf_original_link;

                }
                else
                    return ['data' => array(),'success'=>false,'message'=>"No Print Template Found In Invoice Account"];
                
            } catch (Exception $ex) {
    
                return ['data' => array(),'success'=>false,'message'=>$ex->getMessage()];
            }
        }
    }

    public function send_debitnote_mail_customer($id)
    {
        $debit_note = DebitNote::findOrFail($id);
        if($invoice_file = DebitNoteFile::where('debit_note_id',$id)->where('status',1)->orderBy('created_at','desc')->first())
        {
            
            if($template = NotificationTemplate::where('name','debitnote-created-notification-customer')->where('status',1)->first())
            {
                    try{
                
                        $file = storage_path().$invoice_file->pdf_original_link;
                        $data['attachments'] = [
                            $file => [
                                'as' => $debit_note->formatted_number.'.pdf',
                                'mime' => 'application/pdf',
                            ]
                        ];
                        $data['invoice'] = new DebitNoteResource($debit_note);
                        $data['template'] = $template;
                        $data['section'] = "debit_note";
                        $debit_note->customer->notify(new InvoiceCreatedNotification($data));
        
                        return response(['data' => array(),'success'=>true,'message' => 'Notification Sent'], 200);
                    }
                    catch (Exception $ex) {
                        return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
                    } 
            }
            else
            {
                return response(['data' => array(),'success'=>true,'message' => 'Notification Is Disabled'], 500);  
            }
            
        }
        else
             return response(['data' => array(),'success'=>true,'message' => 'Notification Failure'], 500);
        
    }
}
