<?php

namespace Modules\Invoice\Http\Controllers;

use App\Models\BankAccount;
use App\Models\File;
use App\Models\FiscalYear;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

use Carbon\Carbon;

use App\Models\TempFile;
use App\Models\User;
use App\Traits\InvoiceModuleTrait;
use App\Traits\PermissionTrait;
use Modules\Customer\Entities\Customer;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Invoice\Entities\Item;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Modules\Invoice\Entities\Journal;
use Modules\Invoice\Entities\JournalFile;
use Modules\Invoice\Entities\JournalMain;
use Modules\Invoice\Entities\TcsSection;
use Modules\Invoice\Entities\TdsSection;
use Modules\Invoice\Http\Requests\JournalRequest;
use Modules\Invoice\Transformers\JournalMainResource;
use Modules\Invoice\Transformers\JournalResource;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class JournalController extends Controller
{
    use PermissionTrait,InvoiceModuleTrait;

    public function getlist()
    {
       
        $data['fiscal_years']=FiscalYear::orderBy('status','desc')->orderBy('start_date','desc')->get();
        $data['accounts']=InvoiceAccount::where('status',1)->get();
        $data['bank_accounts']=BankAccount::where('status',1)->get();
        $data['payment_types']=array(
            array('name'=>'cash','display_name'=>"Cash"),
            array('name'=>'bank','display_name'=>"Bank A/C")
        );

        $data['transaction_types']=array(
            array('name'=>'online','display_name'=>"Online"),
            array('name'=>'cheque','display_name'=>"Cheque")
        );

        $data['types']=array(
            array('name'=>'debit','display_name'=>"Debit"),
            array('name'=>'credit','display_name'=>"Credit")
        ); 

        $data['voucher_types']=array(
            array('name'=>'debit','display_name'=>"Payment"),
            array('name'=>'credit','display_name'=>"Receive")
        ); 

        $data['users']=User::orderBy('name','asc')->checkPermission('id')->get();

        
       
       
        $data['total_items'] = $this->getTotalItems();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }

    public function headers()
    {
        $headers = array(
            
            array('column_name'=>'account','display_name'=>'A/C Name','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'journals','display_name'=>'Item','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),

            array('column_name'=>'amount','display_name'=>'Total Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'remarks','display_name'=>'Remarks','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>0,'is_default'=>0,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function voucher_headers()
    {
        $headers = array(
            
            array('column_name'=>'account','display_name'=>'A/C Name','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
           
            array('column_name'=>'journals','display_name'=>'Item','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'voucher_type','display_name'=>'Type','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'amount','display_name'=>'Total Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'payment_type','display_name'=>'Payment Type','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'transaction_type','display_name'=>'Transaction Type','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'bank_account','display_name'=>'Bank','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'transaction_date','display_name'=>'Transaction Date','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'remarks','display_name'=>'Remarks','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>0,'is_default'=>0,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function index(Request $request)
    {
        $query = QueryBuilder::for(JournalMain::class)->allowedFilters(['number','date','amount',AllowedFilter::scope('item_in'),AllowedFilter::scope('date_between'),AllowedFilter::exact('invoice_account_id')->ignore(null),AllowedFilter::exact('fiscal_year_id')->ignore(null),AllowedFilter::exact('type')->ignore(null),AllowedFilter::exact('created_by')->ignore(null),AllowedFilter::exact('bank_account_id')->ignore(null),AllowedFilter::exact('payment_type')->ignore(null)])->defaultSort('-created_at')->allowedSorts('date','amount');

        
        $query->search(!empty($request->search)?$request->search:"");

        $journals = $query->with('account','fiscal_year','files','journals','bank_account')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $journals,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function store(JournalRequest $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);


        DB::beginTransaction();

        try {
            
            $journal = JournalMain::create($request->except(['items','journals']));
                    
            if($request->input('files') && count($request->input('files')) > 0)
            {
                foreach ($request->input('files') as $data) 
                {
                    
                    $data['identifier']=isset($data['identifier'])?$data['identifier']:"journal";
                    if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                    {
                        if($object = File::withTrashed()->find($data['id']))
                        {
                            $object->restore();
                            $object->fill($data);
                        }
                        else
                        {
                            if($tempobject = TempFile::find($data['temp_id']))
                            {
                                
                                $object = new File($data);
                            }
                        }
                            
                        $journal->files()->save($object);
                    }
                }
            }
            if($request->input('journals') && count($request->input('journals')) > 0)
            {
                foreach ($request->input('journals') as $journaldata) 
                {
                    
                    
                    if(intval($journaldata['id']) > 0)
                    {
                        if($object = Journal::withTrashed()->find($journaldata['id']))
                        {
                            $object->restore();
                            $object->fill($journaldata);
                        }
                       
                            
                        $journal->journals()->save($object);
                    }
                    else
                    {
                        $object = new Journal($journaldata);
                        $journal->journals()->save($object);
                    }

                }
            }
            
            if($request->type == 'journal')
                $this->generate_journal_file($journal);
            elseif($request->type == 'voucher')    
                $this->generate_voucher_file($journal);

            DB::commit();

            return response(['data' =>new JournalMainResource($journal),'success'=>true,'message' => 'Journal Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    public function show($id)
    {
        $journal = JournalMain::findOrFail($id);
        
        return response(['data' => new JournalMainResource($journal),'success'=>true,'message' => 'Journal Retrived Successfully'], 200);
    }

    public function update(JournalRequest $request, $id)
    {
        $journal=JournalMain::find($id);
        
        if(!$this->checkUpdateAccess($journal))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {
            
            $journal->update($request->except(['items','date','invoice_account_id','fiscal_year_id','invoice_id']));
            
            $journal->files()->delete();
            
            foreach ($request->input('files') as $data) 
            {
                
                $data['identifier']=isset($data['identifier'])?$data['identifier']:"journal";
                if(intval($data['id']) > 0 || intval($data['temp_id']) > 0)
                {
                    if($object = File::withTrashed()->find($data['id']))
                    {
                        $object->restore();
                        $object->fill($data);
                    }
                    else
                    {
                        if($tempobject = TempFile::find($data['temp_id']))
                        {
                            
                            $object = new File($data);
                        }
                    }
                        
                    $journal->files()->save($object);
                }
            }

            $journal->journals()->delete();

            if($request->input('journals') && count($request->input('journals')) > 0)
            {
                foreach ($request->input('journals') as $journaldata) 
                {
                    
                    
                    if(intval($journaldata['id']) > 0)
                    {
                        if($object = Journal::withTrashed()->find($journaldata['id']))
                        {
                            $object->restore();
                            $object->fill($journaldata);
                        }
                       
                            
                        $journal->journals()->save($object);
                    }
                    else
                    {
                        $object = new Journal($journaldata);
                        $journal->journals()->save($object);
                    }

                }
            }

            if($request->type == 'journal')
                $this->generate_journal_file($journal);
            elseif($request->type == 'voucher')    
                $this->generate_voucher_file($journal);

            DB::commit();

            return response(['data' => new JournalMainResource($journal),'success'=>true,'message' => 'Journal Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    public function destroy($id)
    {
        $journal=JournalMain::find($id);
        
        if(!$this->checkDeleteAccess($journal))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $journal->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Journal Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
               {
                JournalMain::whereIn('id',request()->ids)->get()->each(function($journal) 
                    {
                        $journal->delete();
                    });
               }
            elseif($access == 3)  
                JournalMain::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }

    /**
     * Return Generated Print/Pdf File In Response For Journal/Voucher
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Response
     */
    public function journal_print(Request $request,$id)
    {
        $data=array();
        $file=null;
        
        if($journal_file = JournalFile::where('journal_id',$id)->where('status',1)->orderBy('created_at','desc')->first())
        {
           
            if($request->type == 'print')
            {
                return response(['data' => file_get_contents(storage_path().$journal_file->print_link),'success'=>true,'message' => 'Updated Successfully'], 200);
            }
            else
            {
                $file = storage_path().$journal_file->pdf_original_link;
                $headers = array('Content-Type: application/pdf');
                return  response()->file($file, $headers);
            }
            
            
        }
        else
        {
            
            $update_data=array('status'=>0);
            JournalFile::where('journal_id',$id)->update($update_data);
            
            $journal = JournalMain::find($id);
            
            if($journal->type == 'journal')
                $return = $this->generate_journal_file($journal);
            elseif($journal->type == 'voucher')    
                $return =  $this->generate_voucher_file($journal);
           
           
            if($request->type == 'print')
            {
                return response(['data' => file_get_contents(storage_path().$return['print_path']),'success'=>true,'message' => 'Updated Successfully'], 200);
            }
            else
            {
                $file = storage_path().$return['pdf_path'];
                $headers = array('Content-Type: application/pdf');
                return  response()->file($file, $headers);
            }
            

        }
    		
    }

    /**
     * Generate Print & Pdf File For Journal
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Response
     */
    public function generate_journal_file(JournalMain $journal)
    {
        if($journal)
        {
            try {
                if($journal->account && $journal->account->journal_body)
                {
                    $print_data = array();

                    //Set Account Data Variables
                    $print_data = array_merge($print_data,$this->set_account_data($journal->account,'journal'));

                    
                    $print_data['[DATE]'] = Carbon::parse($journal->date)->format('d/m/Y'); 
                    $print_data['[REMARKS]'] = $journal->remarks;
                    //Set and Replace Multi Item Data In Journal Body
                    if(count($journal->journals) > 0)
                    {
                        $print_data_loop=array();
                        $i=0;
                        $item_str="";
                        $total_debit = 0;
                        $total_credit = 0;
        
                        foreach ($journal->journals as $value) 
                        {   
                            
                            $i++;
        
                            $print_data_loop['[ITEM]']=$value['item_name'];
                           
                            if($value['type'] == 'debit')
                            {
                                $print_data_loop['[DEBIT]']=number_format(floatval($value['after_total']),2);
                                $print_data_loop['[CREDIT]']="";
                                $total_debit=$total_debit+floatval($value['after_total']);
                            }
                            elseif($value['type'] == 'credit')
                            {
                                $print_data_loop['[DEBIT]']="";
                                $print_data_loop['[CREDIT]'] = number_format(floatval($value['after_total']),2);
                                $total_credit=$total_credit+floatval($value['after_total']);
                            }
                           
                            
                            preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$journal->account->journal_body,$matches);
        
                            $item_str .= $this->loop($matches,$print_data_loop);
                                
                           
                            
                        }
        
                        if(count($matches) > 0 && isset($matches[0][0]))
                            $journal_body =str_replace($matches[0][0], $item_str,$journal->account->journal_body);
                        else
                            $journal_body = $journal->account->journal_body;
        
                        $print_data['[TOTAL_CREDIT]'] = number_format($total_credit,2);
                        $print_data['[TOTAL_DEBIT]'] = number_format($total_debit,2);
        
                        
                        if(($total_credit - $total_debit) >= 0)
                        {
                            $print_data['[CLOSING_BALANCE_DEBIT]'] = number_format(abs($total_credit - $total_debit),2);
                            $print_data['[CLOSING_BALANCE_CREDIT]'] = "";
        
                            $print_data['[GRAND_DEBIT]'] = number_format($total_debit + abs($total_credit - $total_debit),2);
                            $print_data['[GRAND_CREDIT]'] = number_format($total_credit,2);
                        }
                        if(($total_credit - $total_debit) < 0)
                        {
                            $print_data['[CLOSING_BALANCE_CREDIT]'] = number_format(abs($total_credit - $total_debit),2);
                            $print_data['[CLOSING_BALANCE_DEBIT]'] = "";
        
                            $print_data['[GRAND_CREDIT]'] = number_format($total_credit + abs($total_credit - $total_debit),2);
                            $print_data['[GRAND_DEBIT]'] = number_format($total_debit,2);
                        }                             
        
                    }

                    //Replace Print Data Variables and Conditional Variables in Invoice Body
                    $journal_body = $this->replace_variable($journal_body,$print_data,$journal->account->journal_body);

                    //Save The Final HTML to PDF
                    $path = storage_path()."/journal/original_pdf";
                    $path_Org = "/journal/original_pdf";
                    if (!file_exists($path)) {
                        $this->createPath($path);
                    }
                    $link = $this->save_pdf($journal,$journal_body,$path);

                    $html_path = storage_path()."/journal/print";
                    $html_path_Org = "/journal/print";
                    if (!file_exists($html_path)) {
                        $this->createPath($html_path);
                    }
                    $html_link = $this->save_print($journal,$journal_body,$html_path);

                    $update_data=array('status'=>0);
                    JournalFile::where('journal_id',$journal->id)->update($update_data);

                    $journal_file=new JournalFile;
                    $journal_file->journal_id = $journal->id;
                    $journal_file->pdf_original_link = $path_Org."/".$link;
                    $journal_file->print_link = $html_path_Org."/".$html_link;
                    $journal_file->status = 1;
                    $journal_file->save();
                    
                    return ['pdf_path'=>$journal_file->pdf_original_link,'print_path'=>$journal_file->print_link];
                }
                else
                    return ['data' => array(),'success'=>false,'message'=>"No Print Template Found In Invoice Account"];
            } catch (Exception $ex) {
    
                return ['data' => array(),'success'=>false,'message'=>$ex->getMessage()];
            }    
        }
    }

    /**
     * Generate Print & Pdf File For Voucher
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Response
     */
    public function generate_voucher_file(JournalMain $journal)
    {
        if($journal)
        {
            try {
                if($journal->account && $journal->account->voucher_body)
                {
                    $print_data = array();

                    //Set Account Data Variables
                    $print_data = array_merge($print_data,$this->set_account_data($journal->account,'journal'));

                    
                    $print_data['[DATE]'] = Carbon::parse($journal->date)->format('d/m/Y'); 
                    $print_data['[REMARKS]'] = $journal->remarks;

                    $print_data['[TOTAL_AMOUNT]']=number_format($journal->amount, 2);
                    $print_data['[TOTAL_IN_WORDS_DECIMAL]']=ucwords($this->convertNumberToWord(number_format($journal->amount, 2)));
                    $print_data['[TYPE]']=ucwords($journal->voucher_type);
                    $print_data['[PAYMENT_TYPE]']=ucwords($journal->payment_type);
                    $print_data['[TRANSACTION_TYPE]']=ucwords($journal->transaction_type);

                    if(!empty($journal->bank_account))
                    {
                        $print_data['[BANK_NAME]']=ucwords($journal->bank_account->display_name);
                    }
                    if($journal->transaction_type == 'online')
                    {
                        $print_data['[TRANSACTION_ID]']=$journal->transaction_id;
                        $print_data['[TRANSACTION_DATE]']=Carbon::parse($journal->transaction_date)->format('d/m/Y');
                    }   
                    elseif($journal->transaction_type == 'cheque')
                    {
                        $print_data['[CHEQUE_ID]']=$journal->transaction_id;
                        $print_data['[CHEQUE_DATE]']=Carbon::parse($journal->transaction_date)->format('d/m/Y');
                    }    
                    //Set and Replace Multi Item Data In Journal Body
                    if(count($journal->journals) > 0)
                    {
                        $print_data_loop=array();
                        $i=0;
                        $item_str="";
                        $total_amount = 0;

                        foreach ($journal->journals as $value) 
                        {   
                            
                            $i++;
        
                            $print_data_loop['[ITEM]']=$value['item_name'];
                            $print_data_loop['[AMOUNT]']=number_format(floatval($value['after_total']),2);
                            $total_amount=$total_amount+floatval($value['after_total']);
                           
                            
                            preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$journal->account->voucher_body,$matches);
        
                            $item_str .= $this->loop($matches,$print_data_loop);
                                
                           
                            
                        }
        
                        if(count($matches) > 0 && isset($matches[0][0]))
                            $voucher_body =str_replace($matches[0][0], $item_str,$journal->account->voucher_body);
                        else
                            $voucher_body = $journal->account->voucher_body;
        
                                                   
        
                    }

                    //Replace Print Data Variables and Conditional Variables in Invoice Body
                    $voucher_body = $this->replace_variable($voucher_body,$print_data,$journal->account->voucher_body);

                    //Save The Final HTML to PDF
                    $path = storage_path()."/journal/original_pdf";
                    $path_Org = "/journal/original_pdf";
                    if (!file_exists($path)) {
                        $this->createPath($path);
                    }
                    $link = $this->save_pdf($journal,$voucher_body,$path);

                    $html_path = storage_path()."/journal/print";
                    $html_path_Org = "/journal/print";
                    if (!file_exists($html_path)) {
                        $this->createPath($html_path);
                    }
                    $html_link = $this->save_print($journal,$voucher_body,$html_path);

                    $update_data=array('status'=>0);
                    JournalFile::where('journal_id',$journal->id)->update($update_data);

                    $journal_file=new JournalFile;
                    $journal_file->journal_id = $journal->id;
                    $journal_file->pdf_original_link = $path_Org."/".$link;
                    $journal_file->print_link = $html_path_Org."/".$html_link;
                    $journal_file->status = 1;
                    $journal_file->save();
                    
                    return ['pdf_path'=>$journal_file->pdf_original_link,'print_path'=>$journal_file->print_link];
                }
                else
                    return ['data' => array(),'success'=>false,'message'=>"No Print Template Found In Invoice Account"];
            } catch (Exception $ex) {
    
                return ['data' => array(),'success'=>false,'message'=>$ex->getMessage()];
            }    
        }
    }
}
