<?php

namespace Modules\Invoice\Http\Controllers;

use App\Models\FiscalYear;
use App\Models\NotificationTemplate;
use App\Models\State;
use App\Models\User;
use App\Traits\InvoiceModuleTrait;
use App\Traits\PermissionTrait;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Customer\Entities\Customer;
use Modules\Invoice\Entities\ProformaInvoice;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Invoice\Entities\Item;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Modules\Invoice\Entities\ProformaInvoiceFile;
use Modules\Invoice\Notifications\InvoiceCreatedNotification;
use Modules\Invoice\Rules\ProformaInvoiceDateRule;
use Modules\Invoice\Rules\ProformaInvoiceNumberRule;
use Modules\Invoice\Transformers\ProformaInvoiceResource;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Modules\Invoice\Entities\TcsSection;
use Modules\Invoice\Entities\TdsSection;

class ProformaInvoiceController extends Controller
{
    use PermissionTrait,InvoiceModuleTrait;

    public function getlist()
    {
       
        $data['states']=State::where('status',1)->get();
        $data['customers']=Customer::where('status',1)->get();
        $data['items']=Item::where('status',1)->get();
        $data['accounts']=InvoiceAccount::where('status',1)->get();
        $data['fiscal_years']=FiscalYear::orderBy('status','desc')->get();

        $data['users']=User::orderBy('name','asc')->checkPermission('id')->get();
        $data['statuses'] = array(
            array('id'=>0,'name'=>'Pending'),
            array('id'=>1,'name'=>'Canceled'),
            array('id'=>2,'name'=>'Invoice Created')
        );

        foreach($data['accounts'] as $key => $account)
	        {
				$data['accounts'][$key]['default_max_no'] = sprintf(env('DEFAULT_NUMBER_FORMAT'),(001));
				$i = 0;
				$t = array();
				foreach($data['fiscal_years'] as $key1 => $fiscal)
					{
			            $t[$i]['account_id'] = $account['id'];
			            $t[$i]['id'] = $fiscal->id;
			            $t[$i]['max_no'] = sprintf(env('DEFAULT_NUMBER_FORMAT'),(001));
						$invoice=ProformaInvoice::where('invoice_account_id',$account['id'])->where('fiscal_year_id',$fiscal->id)->max('number');
						if(intval($invoice) > 0)
				            $t[$i]['max_no'] = sprintf(env('DEFAULT_NUMBER_FORMAT'), intval($invoice) + 1);
						$i++;
					}
				$data['accounts'][$key]['invoice_max_no'] = $t;
	        }
        $data['invoice_number'] = sprintf(env('DEFAULT_NUMBER_FORMAT'),(001));
        
        $data['tds_sections']=TdsSection::where('status',1)->get();
        $data['tcs_sections']=TcsSection::where('status',1)->get();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
    public function headers()
    {
        $headers = array(
            
            array('column_name'=>'account','display_name'=>'A/C Name','is_display'=>1,'is_default'=>0,'is_sortable'=>0),array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),

            array('column_name'=>'formatted_number','display_name'=>'Invoice No.','is_display'=>1,'is_default'=>1,'is_sortable'=>0),

            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'customer','display_name'=>'Customer','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
           

            array('column_name'=>'before_total','display_name'=>'Amount','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'cgst','display_name'=>'CGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'sgst','display_name'=>'SGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'igst','display_name'=>'IGST','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'after_total','display_name'=>'Total Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'items','display_name'=>'Items','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'status_name','display_name'=>'Status','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'remarks','display_name'=>'Remarks','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'note','display_name'=>'Notes','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'creator','display_name'=>'Creator','is_display'=>1,'is_default'=>0,'is_sortable'=>0)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        
        $query = QueryBuilder::for(ProformaInvoice::class)->allowedFilters(['number','date','after_total', AllowedFilter::scope('date_between'),AllowedFilter::exact('customer_id')->ignore(null),AllowedFilter::exact('invoice_account_id')->ignore(null),AllowedFilter::exact('fiscal_year_id')->ignore(null),AllowedFilter::exact('created_by')->ignore(null),AllowedFilter::exact('status')->ignore(null)])->defaultSort('-created_at')->allowedSorts('number','date')->defaultSort('-created_at')->allowedSorts('number','date','after_total','before_total','cgst','sgst','igst','remarks','note');

        $query->search(!empty($request->search)?$request->search:"");

        $invoices = $query->with('account','fiscal_year','customer','items')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $invoices,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        
        $validator = Validator::make($request->all(), [
            'number' => ['required',new ProformaInvoiceNumberRule],
            'date'=>['required',new ProformaInvoiceDateRule],
            'customer_id'=>['required'],
            'invoice_account_id'=>['required'],
            'fiscal_year_id'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $invoice = ProformaInvoice::create($request->except(['invoice']));
        
            $invoice->items()->attach($request->invoice,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            
            $this->generate_file($invoice);

            DB::commit();
            return response(['data' => new ProformaInvoiceResource($invoice),'success'=>true,'message' => 'Invoice Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        
        $invoice = ProformaInvoice::findOrFail($id);
        return response(['data' => new ProformaInvoiceResource($invoice),'success'=>true,'message' => 'Invoice Retrived Successfully'], 200);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
       
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $invoice=ProformaInvoice::find($id);
        
        if(!$this->checkUpdateAccess($invoice))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        $validator = Validator::make($request->all(), [
            'customer_id'=>['required'],
            'invoice_account_id'=>['required'],
            'fiscal_year_id'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $invoice->update($request->except(['invoice','number','date','invoice_account_id','fiscal_year_id']));
            
            if(isset($request->invoice) && count($request->invoice) > 0)
            {
                $invoice->items()->detach();
                $invoice->items()->attach($request->invoice,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s')]);
            }
            
            $this->generate_file($invoice);
            
            DB::commit();
            return response(['data' => new ProformaInvoiceResource($invoice),'success'=>true,'message' => 'Invoice Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $invoice=ProformaInvoice::find($id);
        
        if(!$this->checkDeleteAccess($invoice))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $invoice->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Invoice Deleted Successfully'], 200);
    }
    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     * @return Response
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                {
                    ProformaInvoice::whereIn('id',request()->ids)->get()->each(function($invoice) 
                    {
                        $invoice->delete();
                    });
                }
            elseif($access == 3)  
                ProformaInvoice::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }

    public function invoice_print($id)
    {
        $data=array();
        $file=null;
        
        if($invoice_file = ProformaInvoiceFile::where('invoice_id',$id)->where('status',1)->orderBy('created_at','desc')->first())
        {
           
            $file = storage_path().$invoice_file->pdf_original_link; 
            $headers = array('Content-Type: application/pdf');
            return  response()->file($file, $headers);
            
        }
        else
        {
            
            $update_data=array('status'=>0);
            ProformaInvoiceFile::where('invoice_id',$id)->update($update_data);
            
            $invoice = ProformaInvoice::find($id);
            
            $link = $this->generate_file($invoice);
            $file = storage_path().$link;
            $headers = array('Content-Type: application/pdf');
            return  response()->file($file, $headers);

        }
    		
    }
    
    public function generate_file(ProformaInvoice $invoice)
    {
        if($invoice)
        {
            try {
                
                if($invoice->account && $invoice->account->proforma_invoice_body)
                {
                    $print_data = array();

                    //Set Account Data Variables
                    $print_data = array_merge($print_data,$this->set_account_data($invoice->account,'proforma_invoice'));

                    //Set Customer Data Variables
                    $print_data = array_merge($print_data,$this->set_customer_data($invoice->customer,'proforma_invoice'));

                    //Set Invoice Data Variables
                    $print_data = array_merge($print_data,$this->set_invoice_data($invoice,'proforma_invoice'));

                    //Set and Replace Multi Item Data In Invoice Body
                    $return = $this->set_item_data($invoice->items,$invoice->account->proforma_invoice_body);
                    $invoice_body = $return['body'];
                    $print_data = array_merge($print_data,$return['data']);

                    //Replace Print Data Variables and Conditional Variables in Invoice Body
                    $invoice_body = $this->replace_variable($invoice_body,$print_data,$invoice->account->invoice_body);
                    
                    //Save The Final HTML to PDF
                    $path = storage_path()."/proforma-invoice/original_pdf";
                    $path_Org = "/proforma-invoice/original_pdf";
                    if (!file_exists($path)) {
                        $this->createPath($path);
                    }
                    $link = $this->save_pdf($invoice,$invoice_body,$path);
                    
                    $update_data=array('status'=>0);
                    ProformaInvoiceFile::where('invoice_id',$invoice->id)->update($update_data);

                    $invoice_file=new ProformaInvoiceFile;
                    $invoice_file->invoice_id = $invoice->id;
                    $invoice_file->pdf_original_link = $path_Org."/".$link;
                    $invoice_file->status = 1;
                    $invoice_file->save();
                    
                    return $invoice_file->pdf_original_link;

                }
                else
                    return ['data' => array(),'success'=>false,'message'=>"No Print Template Found In Invoice Account"];
                
            } catch (Exception $ex) {
    
                return ['data' => array(),'success'=>false,'message'=>$ex->getMessage()];
            }
        }
    }

    public function send_invoice_mail_customer($id)
    {
        $invoice = ProformaInvoice::findOrFail($id);
        if($invoice_file = ProformaInvoiceFile::where('invoice_id',$id)->where('status',1)->orderBy('created_at','desc')->first())
        {
            
            if($template = NotificationTemplate::where('name','proforma-invoice-created-notification-customer')->where('status',1)->first())
            {
                try{
                
                        $file = storage_path().$invoice_file->pdf_original_link;
                        $data['attachments'] = [
                            $file => [
                                'as' => $invoice->formatted_number.'.pdf',
                                'mime' => 'application/pdf',
                            ]
                        ];
                        $data['invoice'] = new ProformaInvoiceResource($invoice);
                        $data['template'] = $template;
                        $data['section'] = "proforma_invoice";
                        $invoice->customer->notify(new InvoiceCreatedNotification($data));
        
                        return response(['data' => array(),'success'=>true,'message' => 'Notification Send'], 200);
                    }
                    catch (Exception $ex) {
                        return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
                    } 
            }
            else
            {
                return response(['data' => array(),'success'=>true,'message' => 'Notification Is Disabled'], 500);  
            }
            
        }
        else
             return response(['data' => array(),'success'=>true,'message' => 'Notification Failure'], 500);
        
    }
}
