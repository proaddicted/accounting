<?php

namespace Modules\Invoice\Http\Controllers;

use App\Traits\PermissionTrait;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Invoice\Entities\Item;
use Spatie\QueryBuilder\QueryBuilder;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Modules\Invoice\Entities\InvoiceSeries;
use Modules\Invoice\Transformers\InvoiceSeriesResource;

class InvoiceSeriesController extends Controller
{
    use PermissionTrait;

    public function getlist()
    {
      
      $data['items']=Item::where('status',1)->get();

      return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }

    public function headers()
    {
        $headers = array(
          
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'description','display_name'=>'Description','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'display_name','display_name'=>'Display Name','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>1,'is_default'=>1,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(InvoiceSeries::class)->allowedFilters(['name','description','display_name'])->defaultSort('-created_at')->allowedSorts('name','description','display_name');

        $query->search(!empty($request->search)?$request->search:"");

        $items = $query->with('items')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $items,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
    
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

            
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'display_name' => 'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            $invoice_series = InvoiceSeries::create($request->except('item_id'));
            
            $invoice_series->items()->attach($request->item_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 

            DB::commit();
            return response(['data' => new InvoiceSeriesResource($invoice_series),'success'=>true,'message' => 'Invoice Series Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $invoice_series = InvoiceSeries::findOrFail($id);
        
        return response(['data' => new InvoiceSeriesResource($invoice_series),'success'=>true,'message' => 'Invoice Series Retrived Successfully'], 200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $invoice_series=InvoiceSeries::find($id);
        
        if(!$this->checkUpdateAccess($invoice_series))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
            
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'display_name'=>'required'

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $invoice_series->update($request->except('item_id'));

            $invoice_series->items()->detach();
            
            $invoice_series->items()->attach($request->item_id,['master_id'=>$request->master_id,'created_by'=>Auth::user()->id,'updated_by'=>Auth::user()->id]); 

            DB::commit();
            
            return response(['data' => new InvoiceSeriesResource($invoice_series),'success'=>true,'message' => 'Invoice Series Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
           
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $invoice_series=InvoiceSeries::find($id);
        
        if(!$this->checkDeleteAccess($invoice_series))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $invoice_series->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Item Deleted Successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @param int $id
     * @return Renderable
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                InvoiceSeries::whereIn('id',request()->ids)->delete();
            elseif($access == 3)  
                InvoiceSeries::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
