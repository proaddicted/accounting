<?php

namespace Modules\Invoice\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\JsonResponse;

class JournalRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'invoice_account_id' => 'required',
            'date' => 'required',
            'amount' => 'required',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation()
    {
        $journals = array();
        if(count($this->journals) > 0)
        {
            foreach($this->journals as $key => $journal)
            {
                $main = explode('_',$journal['main']);
                $journals[$key]['id'] = isset($journal['id']) ? $journal['id']: 0 ;
                $journals[$key]['main_id'] =$main[1];
                $journals[$key]['identifier'] =$main[0];
                $journals[$key]['before_total'] = $journal['amount'];
                $journals[$key]['after_total'] = $journal['amount'];
                $journals[$key]['cgst'] = 0;
                $journals[$key]['sgst'] = 0;
                $journals[$key]['igst'] = 0;
                $journals[$key]['type'] = $journal['type'];
                $journals[$key]['date'] = $this->date;
                $journals[$key]['invoice_account_id'] = $this->invoice_account_id;
                $journals[$key]['remarks'] = $this->remarks;
            }

            $this->merge([
                'journals'=>$journals,
                
            ]);
        }
    }

    protected function failedValidation(\Illuminate\Contracts\Validation\Validator $validator)
    {
        
        $response = new JsonResponse(['data' => array(),'success'=>false,'message' => $validator->errors()], 422);

        throw new \Illuminate\Validation\ValidationException($validator, $response);
    
    }
}
