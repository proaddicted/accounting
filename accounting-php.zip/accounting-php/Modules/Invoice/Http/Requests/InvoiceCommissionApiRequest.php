<?php

namespace Modules\Invoice\Http\Requests;

use App\Models\FiscalYear;
use Illuminate\Foundation\Http\FormRequest;
use Modules\Invoice\Entities\Invoice;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Invoice\Entities\InvoiceSeries;
use Modules\Invoice\Entities\Item;
use Modules\Invoice\Entities\TcsSection;
use Modules\Invoice\Entities\TdsSection;

class InvoiceCommissionApiRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'customer_id' => 'required',
            'after_total' => 'required',
            'base_amount' => 'required',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation()
    {

        
        if($this->commission_value > 0)
        {
            $item = Item::when($this->hsn_sac, function($q){
                $q->where('hsn_sac_code',$this->hsn_sac);
            })->when($this->item_id, function($q){
                $q->where('id',$this->item_id);
            })->first();

            $invoice_series = InvoiceSeries::whereHas('items', function($q) use ($item){
                $q->where('item_id',$item->id);
             })->first();
            $commission_amount = 0;

            if($this->commission_type == 'percent')
            {
                $commission_amount = round((($this->commission_value / 100) * $this->base_amount), 2);
                
            }
            elseif($this->commission_type == 'fixed')
            {
                $commission_amount = $this->commission_value;
            }

            if($item)
            {
                $account = InvoiceAccount::find(1);

                $cgst = 0 ; 
                $sgst = 0 ;
                $igst = 0 ;
                $tax = 0;

                $tds = 0;
                $tcs = 0;

                $after_total = 0 ;
                $tds_section_id = 0;
                $tcs_section_id = 0;

                if($account)
                {
                    if($account->state == $this->place_of_supply)
                    {
                        //CGST & SGST
                        $cgst = round((($item->cgst / 100) * $commission_amount), 2);
                        $sgst = round((($item->sgst / 100) * $commission_amount), 2);

                        $tax = $cgst + $sgst ; 
                    }
                    else
                    {
                        //IGST
                        $igst = round((($item->igst / 100) * $commission_amount), 2);
                        
                        $tax = $igst;

                    }

                }

                if(!empty($this->tds_percent))
                {
                    $tds = round((($this->tds_percent / 100) * $this->base_amount), 2);
                    $tds_section = TdsSection::find($this->tds_section_id);
                    $tds_section_id = $tds_section->id;
                }
                if(!empty($this->tcs_percent))
                {
                    $tcs = round((($this->tcs_percent / 100) * $this->base_amount), 2);
                    $tcs_section = TcsSection::find($this->tcs_section_id);
                    $tcs_section_id = $tcs_section->id;
                }

                $item_arr['invoice'][0] = [
                    'item_id'=>$item->id,
                    'description'=>$item->description,
                    'cgst'=>$item->cgst,
                    'sgst'=>$item->sgst,
                    'igst'=>$item->igst,
                    'quantity'=>1,
                    'rate'=>$commission_amount,
                    'discount_type'=>1,
                    'discount'=>0,
                    'discount_amount'=>0,
                    'before_total'=>$commission_amount,
                    'tax'=>$tax,
                    'after_total'=>( $commission_amount + $tax )
                ];


                $fiscal_year=FiscalYear::whereRaw('? BETWEEN start_date and end_date',[date('Y-m-d')])->first();

                $invoice=Invoice::where('invoice_account_id',1)->where('fiscal_year_id',$fiscal_year->id)->where('invoice_series_id',$invoice_series->id)->max('number');

                $this->merge([
                    'page_url'=> 'invoice',
                    'master_id'=> 1,
                    'invoice_account_id'=> 1,
                    'fiscal_year_id'=>$fiscal_year->id,
                    'invoice_series_id'=>$invoice_series->id,
                    'date'=>date('Y-m-d'),
                    'number'=>sprintf(env('DEFAULT_NUMBER_FORMAT'), intval($invoice) + 1),
                    'customer_id' => $this->customer_id,
                    'place_of_supply'=>$this->place_of_supply,
                    'before_total' => $commission_amount,
                    'cgst' => $cgst,
                    'sgst' => $sgst,
                    'igst' => $igst,
                    'tds' => $tds,
                    'tcs' => $tcs, 
                    'after_total' => ( $commission_amount + $tax + $tds + $tcs),
                    'items'=>$item_arr,
                    'transaction_id'=>$this->transaction_id,
                    'transaction_type'=>'online',
                    'transaction_date'=>date('Y-m-d'),
                    'transaction_bank'=>$this->transaction_bank,
                    'base_amount'=>$this->base_amount,
                    'base_gst'=>$this->base_gst,
                    'tds_section_id'=> $tds_section_id,
                    'tcs_section_id'=> $tcs_section_id,
                    'note'=>"Commission charges on amount Rs. ".$this->base_amount
                ]);
            }
    
        }
    }
}
