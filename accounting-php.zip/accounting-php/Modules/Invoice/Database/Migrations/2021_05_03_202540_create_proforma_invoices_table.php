<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProformaInvoicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('proforma_invoices', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('master_id')->nullable();

            $table->unsignedBigInteger('number')->nullable();
            $table->unsignedBigInteger('invoice_account_id')->nullable();
            $table->unsignedBigInteger('fiscal_year_id')->nullable();
            
            $table->unsignedBigInteger('customer_id')->nullable();
            
            $table->date('date')->nullable();
            $table->string('place_of_supply')->nullable();
            $table->string('billing_address')->nullable();

            $table->string('before_total')->nullable();
            $table->string('cgst')->nullable();
            $table->string('sgst')->nullable();
            $table->string('igst')->nullable();
            $table->string('after_total')->nullable();

            $table->text('remarks')->nullable();
            $table->softDeletes();
            $table->timestamps();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();
            $table->tinyInteger('status')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('proforma_invoices');
    }
}
