<?php

namespace Modules\Invoice\Notifications;

use App\Mail\SendGrid;
use App\Traits\InvoiceModuleTrait;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\DB;

class InvoiceCreatedNotification extends Notification
{
    use Queueable,InvoiceModuleTrait;

    public $data;
    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($data)
    {
        $this->data = $data;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database','mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        
        $dd = DB::table('notifications')->latest()->first();
        $this->data['variables'] = array();
        //Set Customer Data Variables
        $this->data['variables'] = array_merge($this->data['variables'],$this->set_customer_data($this->data['invoice']['customer'],$this->data['section']));

        //Set Invoice Data Variables
        $this->data['variables'] = array_merge($this->data['variables'],$this->set_invoice_data($this->data['invoice'],$this->data['section']));
        
        $headerData = ['unique_args' => ['notification_id' => $dd->id]];
        $this->data['header'] = $headerData;
        $this->data['notification_id'] = $dd->id;

        return (new SendGrid($this->data))->to($notifiable->email);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'to'=>$notifiable->email
        ];
    }
}
