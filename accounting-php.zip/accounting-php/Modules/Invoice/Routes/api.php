<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api','masterauth')->get('/invoice', function (Request $request) {
//     return $request->user();
// });
Route::middleware(['auth:api','masterauth'])->group(function () {

    Route::resource('invoice', InvoiceController::class);
    Route::any('invoice_getlist',[Modules\Invoice\Http\Controllers\InvoiceController::class,'getlist']);
    Route::any('invoice_headers',[Modules\Invoice\Http\Controllers\InvoiceController::class,'headers']);
    Route::any('invoice_by_customer',[Modules\Invoice\Http\Controllers\InvoiceController::class,'getInvoiceByCustomer']);
    Route::any('invoice_actionall',[Modules\Invoice\Http\Controllers\InvoiceController::class,'actionall']);
    Route::any('invoice_print/{id}/',[Modules\Invoice\Http\Controllers\InvoiceController::class,'invoice_print']);
    Route::any('invoice_send_mail_customer/{id}/',[Modules\Invoice\Http\Controllers\InvoiceController::class,'send_invoice_mail_customer']);
    
    Route::post('invoice_create_api',[Modules\Invoice\Http\Controllers\InvoiceController::class,'storeInvoiceApi']);
    Route::post('invoice_commission_create_api',[Modules\Invoice\Http\Controllers\InvoiceController::class,'storeCommissionApi']);

    Route::resource('item', ItemController::class);
    Route::any('item_getlist',[Modules\Invoice\Http\Controllers\ItemController::class,'getlist']);
    Route::any('item_headers',[Modules\Invoice\Http\Controllers\ItemController::class,'headers']);
    Route::any('item_actionall',[Modules\Invoice\Http\Controllers\ItemController::class,'actionall']);

    Route::resource('category', CategoryController::class);
    Route::any('category_getlist',[Modules\Invoice\Http\Controllers\CategoryController::class,'getlist']);
    Route::any('category_headers',[Modules\Invoice\Http\Controllers\CategoryController::class,'headers']);
    Route::any('category_actionall',[Modules\Invoice\Http\Controllers\CategoryController::class,'actionall']);

    Route::resource('item_group', ItemGroupController::class);
    Route::any('item_group_headers',[Modules\Invoice\Http\Controllers\ItemGroupController::class,'headers']);
    Route::any('item_group_actionall',[Modules\Invoice\Http\Controllers\ItemGroupController::class,'actionall']);
    Route::any('item_group_getlist',[Modules\Invoice\Http\Controllers\ItemGroupController::class,'getlist']);

    Route::resource('payment', PaymentController::class);
    Route::any('payment_getlist',[Modules\Invoice\Http\Controllers\PaymentController::class,'getlist']);
    Route::any('payment_headers',[Modules\Invoice\Http\Controllers\PaymentController::class,'headers']);
    Route::any('payment_actionall',[Modules\Invoice\Http\Controllers\PaymentController::class,'actionall']);

    Route::resource('proforma_invoice', ProformaInvoiceController::class);
    Route::any('proforma_invoice_getlist',[Modules\Invoice\Http\Controllers\ProformaInvoiceController::class,'getlist']);
    Route::any('proforma_invoice_headers',[Modules\Invoice\Http\Controllers\ProformaInvoiceController::class,'headers']);
    Route::any('proforma_invoice_actionall',[Modules\Invoice\Http\Controllers\ProformaInvoiceController::class,'actionall']);
    Route::any('proforma_invoice_print/{id}/',[Modules\Invoice\Http\Controllers\ProformaInvoiceController::class,'invoice_print']);
    Route::any('proforma_invoice_send_mail_customer/{id}/',[Modules\Invoice\Http\Controllers\ProformaInvoiceController::class,'send_invoice_mail_customer']);

    Route::resource('creditnote', CreditNoteController::class);
    Route::any('creditnote_getlist',[Modules\Invoice\Http\Controllers\CreditNoteController::class,'getlist']);
    Route::any('creditnote_headers',[Modules\Invoice\Http\Controllers\CreditNoteController::class,'headers']);
    Route::any('creditnote_actionall',[Modules\Invoice\Http\Controllers\CreditNoteController::class,'actionall']);
    Route::any('creditnote_print/{id}/',[Modules\Invoice\Http\Controllers\CreditNoteController::class,'creditnote_print']);
    Route::any('creditnote_send_mail_customer/{id}/',[Modules\Invoice\Http\Controllers\CreditNoteController::class,'send_creditnote_mail_customer']);
    
    Route::resource('debitnote', DebitNoteController::class);
    Route::any('debitnote_getlist',[Modules\Invoice\Http\Controllers\DebitNoteController::class,'getlist']);
    Route::any('debitnote_headers',[Modules\Invoice\Http\Controllers\DebitNoteController::class,'headers']);
    Route::any('debitnote_actionall',[Modules\Invoice\Http\Controllers\DebitNoteController::class,'actionall']);
    Route::any('debitnote_print/{id}/',[Modules\Invoice\Http\Controllers\DebitNoteController::class,'debitnote_print']);
    Route::any('debitnote_send_mail_customer/{id}/',[Modules\Invoice\Http\Controllers\DebitNoteController::class,'send_debitnote_mail_customer']);


    Route::resource('tds_section', TdsSectionController::class);
    Route::any('tds_section_headers',[Modules\Invoice\Http\Controllers\TdsSectionController::class,'headers']);
    Route::any('tds_section_actionall',[Modules\Invoice\Http\Controllers\TdsSectionController::class,'actionall']);

    Route::resource('tcs_section', TcsSectionController::class);
    Route::any('tcs_section_headers',[Modules\Invoice\Http\Controllers\TcsSectionController::class,'headers']);
    Route::any('tcs_section_actionall',[Modules\Invoice\Http\Controllers\TcsSectionController::class,'actionall']);


    Route::resource('journal', JournalController::class);
    Route::any('journal_getlist',[Modules\Invoice\Http\Controllers\JournalController::class,'getlist']);
    Route::any('journal_headers',[Modules\Invoice\Http\Controllers\JournalController::class,'headers']);
    Route::any('voucher_headers',[Modules\Invoice\Http\Controllers\JournalController::class,'voucher_headers']);
    Route::any('journal_actionall',[Modules\Invoice\Http\Controllers\JournalController::class,'actionall']);
    Route::any('journal_print/{id}/',[Modules\Invoice\Http\Controllers\JournalController::class,'journal_print']);

    Route::resource('invoice_series', InvoiceSeriesController::class);
    Route::any('invoice_series_getlist',[Modules\Invoice\Http\Controllers\InvoiceSeriesController::class,'getlist']);
    Route::any('invoice_series_headers',[Modules\Invoice\Http\Controllers\InvoiceSeriesController::class,'headers']);
    Route::any('invoice_series_actionall',[Modules\Invoice\Http\Controllers\InvoiceSeriesController::class,'actionall']);
});
