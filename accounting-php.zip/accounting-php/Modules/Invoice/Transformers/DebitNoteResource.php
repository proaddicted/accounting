<?php

namespace Modules\Invoice\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class DebitNoteResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        return array_merge($main,['items'=>ItemResource::collection($this->items),'fiscal_year'=>$this->fiscal_year,'account'=>$this->account,'customer'=>$this->customer,'invoice'=>$this->invoice]);
    }
}
