<?php

namespace Modules\Invoice\Transformers;

use App\Http\Resources\FiscalYearResource;
use Illuminate\Http\Resources\Json\JsonResource;

class InvoiceResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        return array_merge($main,['items'=>ItemResource::collection($this->items),'fiscal_year'=>$this->fiscal_year,'account'=>$this->account,'customer'=>$this->customer,'credit_note'=>$this->credit_note,'debit_note'=>$this->debit_note,'payment'=>$this->payment,'proforma_invoice'=>$this->proforma_invoice,'tds_section'=>$this->tds_section,'tcs_section'=>$this->tcs_section,'invoice_series'=>$this->invoice_series]);
    }
}
