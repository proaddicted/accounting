<?php

namespace Modules\Invoice\Rules;

use Illuminate\Contracts\Validation\Rule;
use Modules\Invoice\Entities\Invoice;

class InvoiceNumberRule implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        

        if(Invoice::where('invoice_account_id',request()->invoice_account_id)->where('fiscal_year_id',request()->fiscal_year_id)->where('invoice_series_id',request()->invoice_series_id)->where('number','=',intval(ltrim(request()->number)))->count() > 0)
            return false;
        else
            return true;    
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'The :attribute already exists with this account and fiscal year';
    }
}
