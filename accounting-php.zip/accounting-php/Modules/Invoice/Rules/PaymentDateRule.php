<?php

namespace Modules\Invoice\Rules;

use App\Models\FiscalYear;
use Illuminate\Contracts\Validation\Rule;

class PaymentDateRule implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $fiscal_year=FiscalYear::whereRaw('? BETWEEN start_date and end_date',[request()->date])->first();
        
        if($fiscal_year && $fiscal_year->id == request()->fiscal_year_id)
            return true;
        else
            return false;

    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
       return 'The :attribute must be in selected fiscal year';
    }
}
