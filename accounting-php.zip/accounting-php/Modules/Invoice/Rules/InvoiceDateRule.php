<?php

namespace Modules\Invoice\Rules;

use App\Models\FiscalYear;
use Illuminate\Contracts\Validation\Rule;
use Modules\Invoice\Entities\Invoice;

class InvoiceDateRule implements Rule
{
    public $message = '';
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->message = '';
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $fiscal_year=FiscalYear::whereRaw('? BETWEEN start_date and end_date',[request()->date])->first();
        
        if($fiscal_year && $fiscal_year->id == request()->fiscal_year_id)
        {
            $date1=Invoice::where('invoice_account_id',request()->invoice_account_id)->where('fiscal_year_id',request()->fiscal_year_id)->where('invoice_series_id',request()->invoice_series_id)->where('number','<',intval(request()->number))->orderBy('number','desc')->first(); //end limit

            $date2=Invoice::where('invoice_account_id',request()->invoice_account_id)->where('fiscal_year_id',request()->fiscal_year_id)->where('invoice_series_id',request()->invoice_series_id)->where('number','>',intval(request()->number))->orderBy('number','asc')->first(); //nearest low

            if($date1 && !$date2 && request()->date  <   $date1->date)
            {
                    
                $this->message = "Invoice Number " . sprintf(env('DEFAULT_NUMBER_FORMAT'),$date1->number) . " is already created on " . date('d-m-Y',strtotime($date1->date));
                return false;
            }
            elseif($date2 && !$date1 && request()->date > $date2->date)
            {
                $this->message = "Invoice Number " . sprintf(env('DEFAULT_NUMBER_FORMAT'),$date2->number) . " is already created on " . date('d-m-Y',strtotime($date2->date));
                return false;
            }
            elseif($date2 && $date1 && (request()->date >  $date2->date || request()->date < $date1->date))
            {

                $this->message="Invoice date is wrong, please do check Invoice Number" . sprintf(env('DEFAULT_NUMBER_FORMAT'),$date1->number) . " and " . sprintf(env('DEFAULT_NUMBER_FORMAT'),$date2->number);
                return false;
            }
            else
                return true;
        }
        else
        {
            $this->message = 'Selected Date Must Be Between Selected Fiscal Year';
            return false;
        }
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return $this->message;
    }
}
