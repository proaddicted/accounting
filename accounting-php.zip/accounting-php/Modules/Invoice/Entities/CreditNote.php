<?php

namespace Modules\Invoice\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Illuminate\Support\Facades\DB;
use Modules\Customer\Entities\Customer;
use App\Models\FiscalYear;
use Illuminate\Database\Eloquent\Builder;

class CreditNote extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;
    
    protected $fillable = ['number','invoice_account_id','fiscal_year_id','customer_id','before_total','cgst','sgst','igst','after_total','remarks','status','date','place_of_supply','billing_address','note','invoice_id'];
    
    protected $searchableColumns = ['number','place_of_supply','date'];

    protected $appends = ['is_delete','is_edit','creator','editor','formatted_number'];
    

    public function customer()
    {
        return $this->belongsTo(Customer::class,'customer_id');
    }
    public function account()
    {
        return $this->belongsTo(InvoiceAccount::class,'invoice_account_id');
    }
    public function fiscal_year()
    {
        return $this->belongsTo(FiscalYear::class,'fiscal_year_id');
    }
    public function invoice()
    {
        return $this->belongsTo(Invoice::class,'invoice_id');
    }
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function setNumberAttribute($value)
    {
        $this->attributes['number'] = intval($value);
    }
    public function getNumberAttribute($value)
    {
        return sprintf(env('DEFAULT_NUMBER_FORMAT'), intval($value));
    }

    public function items()
    {
    	
    	return $this->belongsToMany(Item::class,"credit_note_items","credit_note_id","item_id")->whereNull('credit_note_items.deleted_at')->withTimestamps()->withPivot('rate','quantity','before_total','after_total','cgst','sgst','igst','discount_amount','discount','discount_type','tax','description')->withTrashed(); 
    }
    public function getFormattedNumberAttribute()
    {

        $this->attributes['formatted_number'] = strtoupper($this->account->code)."/CR/".$this->fiscal_year->name."/".$this->number;
        
        return $this->attributes['formatted_number'];
    }
    public function scopeDateBetween(Builder $query, ...$date): Builder
    {
      return $query->whereBetween('date', [$date[0], $date[1]]);
        
    }
    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
           
            $max = CreditNote::where('invoice_account_id',request()->invoice_account_id)->where('fiscal_year_id',request()->fiscal_year_id)->orderBy('number', 'desc')->first();
            
            $max_number = 1;
            
            if($max)
                $max_number = $max['number'] + 1;

            $model->number = $max_number;   
	    
	         		            
		
        });

        self::created(function($model){
            if(request()->invoice_id && intval(request()->invoice_id) > 0)
            {
                
                if(request()->available_amount == $model->after_total)
                {
                    $invoice = Invoice::find(request()->invoice_id);
                    $invoice->status = 2;
                    $invoice->save();
                }
            }
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            if(request()->invoice_id && intval(request()->invoice_id) > 0)
            {
                if(request()->available_amount == $model->after_total)
                {
                    $invoice = Invoice::find(request()->invoice_id);
                    $invoice->status = 2;
                    $invoice->save();
                }
                else
                {
                    $invoice = Invoice::find(request()->invoice_id);
                    $invoice->status = 0;
                    $invoice->save();
                }
            }
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
            $model->items()->detach();
        });

       
    }
    
}
