<?php

namespace Modules\Invoice\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class Item extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;

    protected $fillable = ['name','description','rate','hsn_code','sac_code','cgst','sgst','igst','status','item_group_id','is_taxable','type','hsn_sac_code','is_child_allowed','parent_id'];
    
    protected $searchableColumns = ['name','hsn_code','sac_code','cgst','sgst','igst','type'];

    protected $appends = ['is_delete','is_edit','creator','editor'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    
    public function setIsTaxableAttribute($value)
    {
        $this->attributes['is_taxable'] = (int) $value;
    }

    public function setParentIdAttribute($value)
    {
        $this->attributes['parent_id'] = intval($value) > 0 ? $value : 0;
    }
    
    public function getIsTaxableAttribute()
    {
        return intval($this->attributes['is_taxable']);
    }

    public function group()
    {
        return $this->belongsTo(ItemGroup::class,'item_group_id');
    }

    public function categories()
    {
        return $this->belongsToMany(Category::class,'item_categories','item_id','category_id')->wherePivot('deleted_at',NULL)->withTimestamps();
    }

    public function invoices()
    {
    	
    	return $this->belongsToMany(Invoice::class,"invoice_items","item_id","invoice_id")->whereNull('invoice_items.deleted_at')->withTimestamps()->withPivot('rate','quantity','before_total','after_total','cgst','sgst','igst','discount_amount','discount','discount_type','tax','description')->withTrashed(); 
    }
    
}
