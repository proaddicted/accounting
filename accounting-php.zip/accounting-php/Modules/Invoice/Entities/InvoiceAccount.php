<?php

namespace Modules\Invoice\Entities;

use App\Models\BankAccount;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class InvoiceAccount extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;

    protected $fillable = ['name','city','state','address','city','pincode','gstin','pan_no','cin_no'];
    
    protected $searchableColumns = ['name','state','gstin','pan_no','cin_no'];

    protected $appends = ['is_delete','is_edit','creator','editor'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function banks()
    {
    	
    	return $this->belongsToMany(BankAccount::class,"invoice_account_banks","invoice_account_id","bank_account_id")->whereNull('invoice_account_banks.deleted_at')->withTimestamps()->withPivot('is_default')->orderBy('invoice_account_banks.is_default','desc')->withTrashed(); 
    }
    
}
