<?php

namespace Modules\Invoice\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
class ItemGroup extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;

    protected $fillable = ['name','description','status','is_item'];
    
    protected $searchableColumns = ['name','description'];

    protected $appends = ['is_delete','is_edit','creator','editor'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function setIsItemAttribute($value)
    {
        $this->attributes['is_item'] = (int) $value;
    }
    public function items()
    {
    	
    	return $this->belongsToMany(Item::class,"item_group_items","item_group_id","item_id")->whereNull('item_group_items.deleted_at')->orderBy('item_group_items.order_no')->withTimestamps()->withPivot("order_no","operator","auto_calculate","calculation_type","calculation_rate","calculate_item_id"); 
    }
    
    protected static function boot() 
    {

        parent::boot();
        
        self::creating(function($model){

        });

        self::created(function($model){
           
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
           
        });

        self::deleting(function($model){
            //$model->invoices()->detach();
        });

        self::deleted(function($model){
            $model->items()->detach();
        });


    }
}
