<?php

namespace Modules\Invoice\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class InvoiceSeries extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;

    protected $fillable = ['name','description','display_name','status'];
    
    protected $searchableColumns = ['name','description','display_name'];

    protected $appends = ['is_delete','is_edit','creator','editor'];

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function items()
    {
        return $this->belongsToMany(Item::class,'invoice_series_items','invoice_series_id','item_id')->wherePivot('deleted_at',NULL)->withTimestamps();
    }

    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
           
            
        });

        self::created(function($model){
            
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
            $model->items()->detach();
        });

       
    }
}
