<?php

namespace Modules\Invoice\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

class Category extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;

    protected $fillable = ['name','description','type','parent_id','status'];
    
    protected $searchableColumns = ['name','description','type'];

    protected $appends = ['is_delete','is_edit','creator','editor','type_name'];

    public $category_types = array(
        
        array('id'=>1,'name'=>'Profit & Loss (P&L)'),
        array('id'=>2,'name'=>'Balance Sheet (BSC)')
    );

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function setParentIdAttribute($value)
    {
        $this->attributes['parent_id'] = (int) $value > 0 ? (int) $value : 0 ;
    }
    public function getTypeNameAttribute()
    {
        if(isset($this->attributes['type']) && !empty($this->attributes['type']))
        {
            $types=array_column($this->category_types,'name', 'id'); 
            $type_name=$types[$this->attributes['type']];
            $this->attributes['type_name']=$type_name ;
            return $this->attributes['type_name'];	
        }
    }

    /*
    //No Need According To Me
    
    public function categories()
    {
        return $this->hasMany(Category::class, 'parent_id');
    }
    */
    public function children()
    {
        return $this->hasMany(Category::class, 'parent_id')->with('children');
    }
   
}
