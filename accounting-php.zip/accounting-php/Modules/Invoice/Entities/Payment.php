<?php

namespace Modules\Invoice\Entities;

use App\Models\BankAccount;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;

use Modules\Customer\Entities\Customer;
use App\Models\FiscalYear;
use Illuminate\Database\Eloquent\Builder;
use App\Models\File;

class Payment extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;

    protected $fillable = ['number','invoice_account_id','fiscal_year_id','customer_id','date','payment_type','bank_account_id','remarks','amount','tcs','tds','ods','transaction_type','transaction_date','transaction_id','transaction_bank','transaction_branch','is_realization','realization_date','realization_remarks'];

    protected $searchableColumns = ['number','payment_type','date','remarks'];

    protected $appends = ['is_delete','is_edit','creator','editor','formatted_number'];

    public function customer()
    {
        return $this->belongsTo(Customer::class,'customer_id');
    }
    public function account()
    {
        return $this->belongsTo(InvoiceAccount::class,'invoice_account_id');
    }
    public function fiscal_year()
    {
        return $this->belongsTo(FiscalYear::class,'fiscal_year_id');
    }

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }

    public function setIsRealizationAttribute($value)
    {
        $this->attributes['is_realization'] = (int) $value;
    }

    public function setNumberAttribute($value)
    {
        $this->attributes['number'] = intval($value);
    }
    public function getNumberAttribute($value)
    {
        return sprintf(env('DEFAULT_NUMBER_FORMAT'), intval($value));
    }

    public function invoices()
    {
    	
    	return $this->belongsToMany(Invoice::class,"invoice_payments","payment_id","invoice_id")->whereNull('invoice_payments.deleted_at')->withTimestamps()->withPivot("due_amount","amount","tcs","tds","ods","tds_section_id","tcs_section_id","tds_type","tds_percent","pay_amount"); 
    }
    public function getFormattedNumberAttribute()
    {

        $this->attributes['formatted_number'] = strtoupper($this->account->code)."/PRC/".$this->fiscal_year->name."/".$this->number;
        
        return $this->attributes['formatted_number'];
    }
    public function bank_account()
    {
        return $this->belongsTo(BankAccount::class,'bank_account_id');
    }
    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','payment');
    }

    public function scopeDateBetween(Builder $query, ...$date): Builder
    {
      return $query->whereBetween('date', [$date[0], $date[1]]);
    }

    protected static function boot() 
    {

        parent::boot();
        
        self::creating(function($model){
           
            $max = Payment::where('invoice_account_id',request()->invoice_account_id)->where('fiscal_year_id',request()->fiscal_year_id)->orderBy('number', 'desc')->first();
            
            $max_number = 1;
            
            if($max)
                $max_number = $max['number'] + 1;

            $model->number = $max_number;    
        });

        self::created(function($model){

        
           if(request()->invoice && count(request()->invoice) > 0)
           {
               foreach (request()->invoice as $key => $value) 
               {
                   
                   if($value['due_amount'] == ($value['amount'] + $value['tcs'] + $value['tds'] + $value['ods'] ))
                   {
                       

                       Invoice::where('id',$value['invoice_id'])->update(['status'=>2]);

                   }
               }
           }
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            if(request()->invoice && count(request()->invoice) > 0)
            {
                foreach (request()->invoice as $key => $value) 
                {
                    if($value['due_amount'] == ($value['amount'] + $value['tcs'] + $value['tds'] + $value['ods'] ))
                    {
                        Invoice::where('id',$value['invoice_id'])->update(['status'=>2]);

                    }
                    else
                    {
                        Invoice::where('id',$value['invoice_id'])->update(['status'=>0]);
                    }
                }
            }
        });

        self::deleting(function($model){
            //$model->invoices()->detach();
        });

        self::deleted(function($model){
            if($model->invoices && count($model->invoices) > 0)
            {
                foreach ($model->invoices as $key => $value) 
                {
                    Invoice::where('id',$value['id'])->update(['status'=>0]);
                }
            }    
            $model->invoices()->detach();
        });


    }
}
