<?php

namespace Modules\Invoice\Entities;

use App\Models\FiscalYear;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Illuminate\Support\Facades\DB;
use Modules\Customer\Entities\Customer;
use Illuminate\Database\Eloquent\Builder;

class ProformaInvoice extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;
    
    protected $fillable = ['number','invoice_account_id','fiscal_year_id','customer_id','before_total','cgst','sgst','igst','after_total','remarks','status','date','place_of_supply','billing_address','note','tds','tcs','tds_section_id','tcs_section_id','tds_tcs_applicable','tds_tcs_type'];
    
    protected $searchableColumns = ['number','place_of_supply','date'];

    protected $appends = ['is_delete','is_edit','creator','editor','status_name','formatted_number'];

    public $invoice_status = array(
        array('id'=>0,'name'=>'Pending'),
        array('id'=>1,'name'=>'Canceled'),
        array('id'=>2,'name'=>'Invoice Created')
    );

    public function customer()
    {
        return $this->belongsTo(Customer::class,'customer_id');
    }
    public function account()
    {
        return $this->belongsTo(InvoiceAccount::class,'invoice_account_id');
    }
    public function fiscal_year()
    {
        return $this->belongsTo(FiscalYear::class,'fiscal_year_id');
    }


    public function items()
    {
    	
    	return $this->belongsToMany(Item::class,"proforma_invoice_items","invoice_id","item_id")->whereNull('proforma_invoice_items.deleted_at')->withTimestamps()->withPivot('rate','quantity','before_total','after_total','cgst','sgst','igst','discount_amount','discount','discount_type','tax','description')->withTrashed(); 
    }
    public function tds_section()
    {
        return $this->belongsTo(TdsSection::class,'tds_section_id');
    }
    public function tcs_section()
    {
        return $this->belongsTo(TcsSection::class,'tcs_section_id');
    }

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function setTdsTcsApplicableAttribute($value)
    {
        $this->attributes['tds_tcs_applicable'] = (int) $value;
    }
    public function setNumberAttribute($value)
    {
        $this->attributes['number'] = intval($value);
    }
    public function getNumberAttribute($value)
    {
        return sprintf(env('DEFAULT_NUMBER_FORMAT'), intval($value));
    }
    public function getFormattedNumberAttribute()
    {

        $this->attributes['formatted_number'] = strtoupper($this->account->code)."/PR/".$this->fiscal_year->name."/".$this->number;
        
        return $this->attributes['formatted_number'];
    }
    public function getStatusNameAttribute()
    {
        if(isset($this->attributes['status']))
        {
            $statuses=array_column($this->invoice_status,'name', 'id'); 
            $status_name=$statuses[$this->attributes['status']];
            $this->attributes['status_name']=$status_name ;
            return $this->attributes['status_name'];
        }
    }
    public function scopeDateBetween(Builder $query, ...$date): Builder
    {
      return $query->whereBetween('date', [$date[0], $date[1]]);
        
    }
    protected static function boot() 
    {

        parent::boot();
        
        self::creating(function($model){  
        });

        self::created(function($model){
           
        });

        self::updating(function($model){
            // ... code here
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
            // ... code here
        });

        self::deleted(function($model){
            $model->items()->detach();
        });


    }
    
}
