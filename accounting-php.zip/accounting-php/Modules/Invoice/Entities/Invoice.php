<?php

namespace Modules\Invoice\Entities;

use App\Models\FiscalYear;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Modules\Customer\Entities\Customer;
use Spatie\QueryBuilder\QueryBuilder;
use Illuminate\Database\Eloquent\Builder;

class Invoice extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;
    
    protected $fillable = ['number','invoice_account_id','fiscal_year_id','customer_id','before_total','cgst','sgst','igst','after_total','remarks','status','date','place_of_supply','billing_address','note','proforma_invoice_id','tds_tcs_applicable','tds_tcs_type','tds_section_id','tcs_section_id','tds','tcs','invoice_series_id'];
    
    protected $searchableColumns = ['number','place_of_supply','date'];

    protected $appends = ['is_delete','is_edit','creator','editor','due_amount','status_name','formatted_number','due_age','paid_amount'];


    public $invoice_status = array(
        array('id'=>0,'name'=>'Pending'),
        array('id'=>1,'name'=>'Canceled'),
        array('id'=>2,'name'=>'Received')
    );

    public function customer()
    {
        return $this->belongsTo(Customer::class,'customer_id');
    }
    public function account()
    {
        return $this->belongsTo(InvoiceAccount::class,'invoice_account_id');
    }
    public function fiscal_year()
    {
        return $this->belongsTo(FiscalYear::class,'fiscal_year_id');
    }

    public function invoice_series()
    {
        return $this->belongsTo(InvoiceSeries::class,'invoice_series_id');
    }

    public function proforma_invoice()
    {
        return $this->belongsTo(ProformaInvoice::class,'proforma_invoice_id');
    }


    public function items()
    {
    	
    	return $this->belongsToMany(Item::class,"invoice_items","invoice_id","item_id")->whereNull('invoice_items.deleted_at')->withTimestamps()->withPivot('rate','quantity','before_total','after_total','cgst','sgst','igst','discount_amount','discount','discount_type','tax','description')->withTrashed(); 
    }

    public function credit_note()
    {
        return $this->hasMany(CreditNote::class,'invoice_id','id');
    }
    public function debit_note()
    {
        return $this->hasMany(DebitNote::class,'invoice_id','id');
    }
    public function payment()
    {
        return $this->belongsToMany(Payment::class,"invoice_payments","invoice_id","payment_id")->whereNull('invoice_payments.deleted_at')->withTimestamps()->withPivot("due_amount","amount","tcs","tds","ods"); 
    }

    public function tds_section()
    {
        return $this->belongsTo(TdsSection::class,'tds_section_id');
    }
    public function tcs_section()
    {
        return $this->belongsTo(TcsSection::class,'tcs_section_id');
    }
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function setTdsTcsApplicableAttribute($value)
    {
        $this->attributes['tds_tcs_applicable'] = (int) $value;
    }
    public function setNumberAttribute($value)
    {
        $this->attributes['number'] = intval($value);
    }
    public function getNumberAttribute($value)
    {
        return sprintf(env('DEFAULT_NUMBER_FORMAT'), intval($value));
    }

    public function getDueAmountAttribute()
    {
      
       $result = DB::table('invoice_payments')->selectRaw('sum(amount + tcs + tds + ods) as total_paid')->where('invoice_id',$this->attributes['id'])->whereNull('deleted_at')->get();

       $credit_note = DB::table('credit_notes')->selectRaw('sum(after_total) as total_credit_note')->where('invoice_id',$this->attributes['id'])->whereNull('deleted_at')->get();

       $debit_note = DB::table('debit_notes')->selectRaw('sum(after_total) as total_debit_note')->where('invoice_id',$this->attributes['id'])->whereNull('deleted_at')->get();
       
       return $this->attributes['due_amount'] = round(($this->attributes['after_total'] + $debit_note[0]->total_debit_note )  - ($result[0]->total_paid + $credit_note[0]->total_credit_note),2);
    

    }
    public function getPaidAmountAttribute()
    {
      
       $result = DB::table('invoice_payments')->selectRaw('sum(amount + tcs + tds + ods) as total_paid')->where('invoice_id',$this->attributes['id'])->whereNull('deleted_at')->get();

       $credit_note = DB::table('credit_notes')->selectRaw('sum(after_total) as total_credit_note')->where('invoice_id',$this->attributes['id'])->whereNull('deleted_at')->get();
       
       return $this->attributes['paid_amount'] = round(($result[0]->total_paid + $credit_note[0]->total_credit_note),2);
    

    }
    public function getStatusNameAttribute()
    {
        if(isset($this->attributes['status']))
        {
            $statuses=array_column($this->invoice_status,'name', 'id'); 
            $status_name=$statuses[$this->attributes['status']];
            $this->attributes['status_name']=$status_name ;
            return $this->attributes['status_name'];	
        }
    }

    public function getFormattedNumberAttribute()
    {

        $this->attributes['formatted_number'] = strtoupper($this->account->code)."/IN/".$this->fiscal_year->name."/".$this->invoice_series->display_name.$this->number;
        
        return $this->attributes['formatted_number'];
    }
    public function getDueAgeAttribute()
    {
        
        $date = Carbon::parse($this->attributes['date']);
        $today = Carbon::now();
        $this->attributes['due_age'] = $date->diffForHumans($today);
        return $this->attributes['due_age'];
    }
    public function scopeDateBetween(Builder $query, ...$date): Builder
    {
      return $query->whereBetween('date', [$date[0], $date[1]]);
        
    }
    protected static function boot() 
    {
        parent::boot();
        
        self::creating(function($model){
           
            
        });

        self::created(function($model){
            if(request()->proforma_invoice_id && request()->proforma_invoice_id > 0)
            {
                $proforma_invoice = ProformaInvoice::find(request()->proforma_invoice_id);
                $proforma_invoice->status = 2;
                $proforma_invoice->invoice_id = $model->id;
                $proforma_invoice->save();
            }
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            if($model->due_amount && $model->due_amount > 0)
            {
                $invoice = Invoice::find($model->id);
                $invoice->status = 0;
                $invoice->save();
            }
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
            $model->items()->detach();
        });

       
    }
}
