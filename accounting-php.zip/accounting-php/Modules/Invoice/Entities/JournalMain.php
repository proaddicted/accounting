<?php

namespace Modules\Invoice\Entities;

use App\Models\File;
use App\Models\FiscalYear;
use App\Traits\InvoiceModuleTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Modules\Customer\Entities\Customer;
use Illuminate\Database\Eloquent\Builder;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Invoice\Entities\Item;
use Modules\Invoice\Entities\TdsSection;
use Modules\Invoice\Entities\TcsSection;
use App\Models\BankAccount;

class JournalMain extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes,InvoiceModuleTrait;

    protected $fillable = ['invoice_account_id','fiscal_year_id','type','date','amount','remarks','status','voucher_type','payment_type','bank_account_id','transaction_type','transaction_id','transaction_date','is_realization','realization_date','realization_remarks'];
    
    protected $searchableColumns = ['date','remarks','type'];

    protected $appends = ['is_delete','is_edit','creator','editor'];

    public function account()
    {
        return $this->belongsTo(InvoiceAccount::class,'invoice_account_id');
    }
    public function setIsRealizationAttribute($value)
    {
        $this->attributes['is_realization'] = (int) $value;
    }
    public function fiscal_year()
    {
        return $this->belongsTo(FiscalYear::class,'fiscal_year_id');
    }

    public function files()
    {
        return $this->hasMany(File::class,"main_id","id")->where('identifier','journal');
    }
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function bank_account()
    {
        return $this->belongsTo(BankAccount::class,'bank_account_id');
    }
    public function journals()
    {
        return $this->hasMany(Journal::class,"journal_id","id");
    }
    public function scopeItemIn(Builder $query, ...$item): Builder
    {
        $search_params = explode('_',$item[0]);

        return $query->whereHas('journals', function($q) use ($search_params){
             $q->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
        });
        
    }
    public function scopeDateBetween(Builder $query, ...$date): Builder
    {
      return $query->whereBetween('date', [$date[0], $date[1]]);
        
    }

    protected static function boot() 
    {
        
        parent::boot();
        
        self::creating(function($model){
           
            if(!empty(request()->date))
            {
                if($fiscal_year=FiscalYear::whereRaw('? BETWEEN start_date and end_date',[request()->date])->first())
                    $model->fiscal_year_id = $fiscal_year->id; 
            }
        });

        self::created(function($model){
            
        });

        self::updating(function($model){
            if(!empty(request()->date))
            {
                if($fiscal_year=FiscalYear::whereRaw('? BETWEEN start_date and end_date',[request()->date])->first())
                    $model->fiscal_year_id = $fiscal_year->id; 
            }
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
            
            $model->files()->delete();
            $model->journals()->delete();
        });

       
    }
}
