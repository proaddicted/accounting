<?php

return [
    'name' => 'Cashbook'
];
