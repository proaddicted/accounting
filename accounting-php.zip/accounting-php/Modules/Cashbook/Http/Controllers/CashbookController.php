<?php

namespace Modules\Cashbook\Http\Controllers;

use App\Models\BankAccount;
use App\Models\User;
use App\Traits\PermissionTrait;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Modules\Cashbook\Entities\CashbookTransaction;
use Modules\Cashbook\Transformers\CashbookResource;
use Modules\Customer\Entities\Customer;
use Modules\Invoice\Entities\InvoiceAccount;

use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class CashbookController extends Controller
{
    use PermissionTrait;

    public function getlist(Request $request)
    {   
        
        $data['customers']=Customer::where('status',1)->get();
        $data['accounts']=InvoiceAccount::where('status',1)->get();
        $data['bank_accounts']=BankAccount::where('status',1)->get();

        $data['transaction_types']=array(
            array('name'=>'credit','display_name'=>"Cash Received"),
            array('name'=>'debit','display_name'=>"Cash Payment")
        );
        $data['contra_transaction_types']=array(
            array('name'=>'credit','display_name'=>"Bank Deposit"),
            array('name'=>'debit','display_name'=>"Bank Withdrawal")
        );
        $data['bank_transaction_types']=array(
            array('name'=>'cash','display_name'=>"Cash"),
            array('name'=>'online','display_name'=>"Online"),
            array('name'=>'cheque','display_name'=>"Cheque")
        );
        $data['users']=User::orderBy('name','asc')->checkPermission('id')->get();

        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
    public function headers()
    {
        $headers = array(
            
            array('column_name'=>'account','display_name'=>'A/C Name','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'type','display_name'=>'Transaction Type','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'main','display_name'=>'Customer','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),

            array('column_name'=>'amount','display_name'=>'Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>0,'is_default'=>0,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function contra_headers()
    {
        $headers = array(
            
            array('column_name'=>'account','display_name'=>'A/C Name','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'type','display_name'=>'Method','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'main','display_name'=>'Bank Account','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'date','display_name'=>'Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),

            array('column_name'=>'amount','display_name'=>'Amount','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'transaction_type','display_name'=>'Transaction Type','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'transaction_id','display_name'=>'Transaction Id','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'transaction_date','display_name'=>'Transaction Date','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>0,'is_default'=>0,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(CashbookTransaction::class)->allowedFilters(['date',AllowedFilter::exact('identifier')->ignore(null), AllowedFilter::exact('type')->ignore(null),AllowedFilter::scope('date_between'),AllowedFilter::exact('main_id')->ignore(null),AllowedFilter::exact('invoice_account_id')->ignore(null),AllowedFilter::exact('fiscal_year_id')->ignore(null)])->defaultSort('-created_at')->allowedSorts('date','type','amount','transaction_type','transaction_id','transaction_date','updated_at');

        $query->search(!empty($request->search)?$request->search:"");

        $transactions = $query->with('account','fiscal_year','main')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $transactions,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
        return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);


        $validator = Validator::make($request->all(), [
            'date'=>['required'],
            'main_id'=>['required'],
            'type'=>['required'],
            'invoice_account_id'=>['required'],
            'amount'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $transaction = CashbookTransaction::create($request->all());
            
            if($transaction->identifier == 'bank')
            {
                if($transaction->to_bank_account_id > 0)
                {
                        $type = $transaction->type == 'credit'?'debit':'credit';

                        $reverse_transaction = new CashbookTransaction;
                        
                        $reverse_transaction->main_id = $transaction->to_bank_account_id;
                        $reverse_transaction->type = $type;
                        $reverse_transaction->to_bank_account_id = $transaction->main_id;
                        $reverse_transaction->remarks = $transaction->remarks;
                        $reverse_transaction->transaction_id = $transaction->transaction_id;
                        $reverse_transaction->transaction_date = $transaction->transaction_date;
                        $reverse_transaction->transaction_type = $transaction->transaction_type;
                        $reverse_transaction->date = $transaction->date;
                        $reverse_transaction->identifier = $transaction->identifier;
                        $reverse_transaction->invoice_account_id = $transaction->invoice_account_id;
                        $reverse_transaction->amount = $transaction->amount;

                        $reverse_transaction->save();
                        // $transaction = CashbookTransaction::create(['main_id'=>$model->to_bank_account_id,'type'=>$type,'to_bank_account_id'=>$model->main_id,'amount'=>$model->amount,'remarks'=>$model->remarks,'transaction_type'=>$model->transaction_type,'transaction_id'=>$model->transaction_id,'transaction_date'=>$model->transaction_date,'date'=>$model->date,'identifier'=>$model->identifier,'invoice_account_id'=>$model->invoice_account_id]);
                    
                }
                elseif($transaction->transaction_type == 'cash')
                {
                    $type = $transaction->type == 'credit'?'debit':'credit';

                    $reverse_transaction = new CashbookTransaction;
                    
                    $reverse_transaction->main_id = 0;
                    $reverse_transaction->type = $type;
                    $reverse_transaction->to_bank_account_id = $transaction->main_id;
                    $reverse_transaction->remarks = $transaction->remarks;
                    $reverse_transaction->transaction_type = $transaction->transaction_type;
                    $reverse_transaction->date = $transaction->date;
                    $reverse_transaction->identifier = 'cash';
                    $reverse_transaction->invoice_account_id = $transaction->invoice_account_id;
                    $reverse_transaction->amount = $transaction->amount;

                    $reverse_transaction->save();
                }
            }
            
             

            DB::commit();
            
            return response(['data' =>new CashbookResource($transaction),'success'=>true,'message' => 'Transaction Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $transaction = CashbookTransaction::findOrFail($id);
        
        return response(['data' => new CashbookResource($transaction),'success'=>true,'message' => 'Transaction Retrived Successfully'], 200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $transaction=CashbookTransaction::find($id);
        
        if(!$this->checkUpdateAccess($transaction))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
            
        $validator = Validator::make($request->all(), [
            'date'=>['required'],
            'main_id'=>['required'],
            'type'=>['required'],
            'invoice_account_id'=>['required'],
            'amount'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }

        DB::beginTransaction();
        try {
            
            $transaction->update($request->all());

            DB::commit();
            
            return response(['data' => new CashbookResource($transaction),'success'=>true,'message' => 'Transaction Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
           
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $transaction=CashbookTransaction::find($id);
        
        if(!$this->checkDeleteAccess($transaction))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $transaction->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Transaction Deleted Successfully'], 200);
    }
    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @param int $id
     * @return Renderable
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess($access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
              {
                CashbookTransaction::whereIn('id',request()->ids)->get()->each(function($transaction) 
                {
                    $transaction->delete();
                });
              } 
            elseif($access == 3)  
                CashbookTransaction::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
