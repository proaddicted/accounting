<?php

namespace Modules\Cashbook\Entities;

use App\Models\BankAccount;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Modules\Customer\Entities\Customer;
use App\Models\FiscalYear;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\Relation;
use Modules\Invoice\Entities\InvoiceAccount;

class CashbookTransaction extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes;
    
    protected $table = 'cashbook_contra_transactions';

    protected $fillable = ['invoice_account_id','main_id','identifier','type','amount','date','remarks','transaction_type','transaction_id','transaction_date','to_bank_account_id','is_realization','realization_date','realization_remarks'];
    
    protected $searchableColumns = ['date','type'];

    protected $appends = ['is_delete','is_edit','creator','editor'];
    
    public function main()
    {
        return $this->morphTo(null, 'identifier', 'main_id');
    }

    
    public function account()
    {
        return $this->belongsTo(InvoiceAccount::class,'invoice_account_id');
    }
    public function fiscal_year()
    {
        return $this->belongsTo(FiscalYear::class,'fiscal_year_id');
    }
    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function bank_account()
    {
        return $this->belongsTo(BankAccount::class,'to_bank_account_id');
    }
    public function scopeDateBetween(Builder $query, ...$date): Builder
    {
      return $query->whereBetween('date', [$date[0], $date[1]]);
    }

    protected static function boot() 
    {
        parent::boot();
    
        Relation::morphMap([
            'cash' => Customer::class,
            'bank' => BankAccount::class,
        ]);
        
        self::creating(function($model){
            
                
               if(!empty(request()->date))
               {
                    if($fiscal_year=FiscalYear::whereRaw('? BETWEEN start_date and end_date',[request()->date])->first())
                        $model->fiscal_year_id = $fiscal_year->id; 
               } 
              
                     
        });

        self::created(function($model){
           
        });

        self::updating(function($model){
            if(!empty(request()->date))
            {
                if($fiscal_year=FiscalYear::whereRaw('? BETWEEN start_date and end_date',[request()->date])->first())
                    $model->fiscal_year_id = $fiscal_year->id; 
            }
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
        });

       
    }
}
