<?php

namespace Modules\Cashbook\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class CashbookResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $main = parent::toArray($request);
        return array_merge($main,['fiscal_year'=>$this->fiscal_year,'account'=>$this->account,'main'=>$this->main]);
    }
}
