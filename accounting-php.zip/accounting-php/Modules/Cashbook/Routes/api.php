<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::middleware(['auth:api','masterauth'])->group(function () {

    Route::resource('cashbook', CashbookController::class);
    Route::any('cashbook_getlist',[Modules\Cashbook\Http\Controllers\CashbookController::class,'getlist']);
    Route::any('cashbook_headers',[Modules\Cashbook\Http\Controllers\CashbookController::class,'headers']);
    Route::any('cashbook_actionall',[Modules\Cashbook\Http\Controllers\CashbookController::class,'actionall']);
    Route::any('cashbook_contra_headers',[Modules\Cashbook\Http\Controllers\CashbookController::class,'contra_headers']);
   
});