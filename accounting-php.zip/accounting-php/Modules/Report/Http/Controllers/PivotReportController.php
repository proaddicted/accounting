<?php

namespace Modules\Report\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Invoice\Entities\Invoice;
use Modules\Purchase\Entities\Purchase;

class PivotReportController extends Controller
{
    public function invoice_summary_report(Request $request)
    {
        $format_data = array();

        
        $invoices = Invoice::with('customer','account','items','fiscal_year')->when($request->start_date, function($query) use ($request) {
            return $query->whereBetween('date',[$request->start_date,$request->end_date]);
          })->where('status','<>',1)->get();

        foreach ($invoices as $key => $value) 
        {
            $format_data[$key]['number']=$value->formatted_number;
            $format_data[$key]['account']=$value->account->name;
            $format_data[$key]['customer']=$value->customer->full_name;
            $format_data[$key]['pan_no']=$value->customer->pan_no;
            $format_data[$key]['fiscalyear']=$value->fiscal_year->name;
            $format_data[$key]['items']=implode(',',array_column($value->items->toArray(),'name'));

            $date=Carbon::createFromFormat('Y-m-d', $value->date);
            $format_data[$key]['month'] = $date->format('F');
	          $format_data[$key]['before_amount'] = floatval($value->before_total);
            $format_data[$key]['cgst'] = floatval($value->cgst);
            $format_data[$key]['sgst'] = floatval($value->sgst);
            $format_data[$key]['igst'] = floatval($value->igst);
            $format_data[$key]['tds'] = floatval($value->tds);
            $format_data[$key]['tcs'] = floatval($value->tcs);
            $format_data[$key]['amount'] = floatval($value->after_total);
            $format_data[$key]['paid_amount'] = floatval($value->paid_amount);
            $format_data[$key]['due_amount'] = floatval($value->due_amount);
	   
        }

        return response(['data' => $format_data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function purchase_summary_report(Request $request)
    {
        $format_data = array();

        $purchases = Purchase::where('type','vendor')->with('customer','items','account','fiscal_year')->when($request->start_date, function($query) use ($request) {
            return $query->whereBetween('date',[$request->start_date,$request->end_date]);
          })->where('status','<>',1)->get();  
          
        foreach ($purchases as $key => $value) 
        {
              $format_data[$key]['number']=!empty($value->number)?$value->number:"ID-".$value->id;
              $format_data[$key]['account']=$value->account->name;
              $format_data[$key]['customer']=!empty($value->customer)?$value->customer->full_name:"N/A";
              $format_data[$key]['pan_no']=$value->customer->pan_no;
              $format_data[$key]['fiscalyear']=$value->fiscal_year->name;
              $format_data[$key]['items']=implode(',',array_column($value->items->toArray(),'name'));
              $date=Carbon::createFromFormat('Y-m-d', $value->date);
              $format_data[$key]['month'] = $date->format('F');

              $format_data[$key]['date'] = $date->format('Y-m-d');

              if($value->is_taxable > 0)
              {
                $format_data[$key]['before_amount'] = floatval($value->before_total);
                $format_data[$key]['cgst'] = floatval($value->cgst);
                $format_data[$key]['sgst'] = floatval($value->sgst);
                $format_data[$key]['igst'] = floatval($value->igst);
                $format_data[$key]['amount'] = floatval($value->after_total);
              }
              else
              {
                $format_data[$key]['before_amount'] = floatval($value->after_total);
                $format_data[$key]['cgst'] = floatval($value->cgst);
                $format_data[$key]['sgst'] = floatval($value->sgst);
                $format_data[$key]['igst'] = floatval($value->igst);
                $format_data[$key]['amount'] = floatval($value->after_total);
              }
             
              $format_data[$key]['paid_amount'] = floatval($value->paid_amount);
              $format_data[$key]['due_amount'] = floatval($value->due_amount);
         
        }
  
        return response(['data' => $format_data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);  
    }


    public function debtors_report(Request $request)
    {
        $format_data = array();

        
        $invoices = Invoice::with('customer','account','fiscal_year')->when($request->start_date, function($query) use ($request) {
            return $query->whereBetween('date',[$request->start_date,$request->end_date]);
          })->where('status',0)->get();

        $i = 0;  
        foreach ($invoices as $key => $value) 
        {
          
            if(floatval($value->due_amount) > 0)
            {
                $format_data[$i]['number']=$value->formatted_number;
                $format_data[$i]['account']=$value->account->name;
                $format_data[$i]['customer']=$value->customer->full_name;
        
                $format_data[$i]['fiscalyear']=$value->fiscal_year->name;

                $date=Carbon::createFromFormat('Y-m-d', $value->date);
                $format_data[$i]['month'] = $date->format('F');
                $format_data[$i]['due_amount'] = floatval($value->due_amount);
                $i++;
             }
            
	   
        }

        return response(['data' => $format_data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function creditors_report(Request $request)
    {
        $format_data = array();

        $purchases = Purchase::with('customer','account','fiscal_year')->where('type','vendor')->when($request->start_date, function($query) use ($request) {
            return $query->whereBetween('date',[$request->start_date,$request->end_date]);
          })->where('status',0)->get();  
          
        $i = 0;    
        foreach ($purchases as $key => $value) 
        {
              if($value->due_amount > 0)
              {
                $format_data[$i]['number']=!empty($value->number)?$value->number:"ID-".$value->id;
                $format_data[$i]['account']=$value->account->name;
                $format_data[$i]['customer']=!empty($value->customer)?$value->customer->full_name:"N/A";
            
                $format_data[$i]['fiscalyear']=$value->fiscal_year->name;
    
                $date=Carbon::createFromFormat('Y-m-d', $value->date);
                $format_data[$i]['month'] = $date->format('F');

                $format_data[$i]['date'] = $date->format('Y-m-d');
                $format_data[$i]['due_amount'] = floatval($value->due_amount);
                $i++;
              }
              
         
        }
  
        return response(['data' => $format_data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);  
    }
}
