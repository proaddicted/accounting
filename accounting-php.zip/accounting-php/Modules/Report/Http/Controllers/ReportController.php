<?php

namespace Modules\Report\Http\Controllers;

use App\Models\BankAccount;
use App\Models\FiscalYear;
use App\Models\State;
use App\Traits\InvoiceModuleTrait;
use App\Traits\PermissionTrait;
use Carbon\Carbon;
use Exception;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Modules\Cashbook\Entities\CashbookTransaction;
use Modules\Customer\Entities\Customer;
use Modules\Invoice\Entities\CreditNote;
use Modules\Invoice\Entities\DebitNote;
use Modules\Invoice\Entities\Invoice;
use Modules\Invoice\Entities\Payment;
use Modules\Purchase\Entities\PurchaseAdvancePayment;
use Illuminate\Support\Facades\Validator;
use Modules\Cashbook\Transformers\CashbookResource;
use Modules\Customer\Entities\OpeningBalance;
use Modules\Invoice\Entities\InvoiceAccount;
use Modules\Invoice\Entities\Item;
use Modules\Invoice\Entities\Journal;
use Modules\Invoice\Entities\JournalMain;
use Modules\Invoice\Entities\TcsSection;
use Modules\Invoice\Entities\TdsSection;
use Modules\Invoice\Transformers\JournalMainResource;
use Modules\Invoice\Transformers\PaymentResource;
use Modules\Purchase\Entities\Purchase;
use Modules\Purchase\Entities\PurchasePayment;
use Modules\Purchase\Transformers\PurchaseAdvancePaymentResource;
use Modules\Purchase\Transformers\PurchasePaymentResource;
use PDF;

class ReportController extends Controller
{
    use PermissionTrait,InvoiceModuleTrait;

    public function getlist()
    {
       
        $data['fiscal_years']=FiscalYear::orderBy('status','desc')->orderBy('start_date','desc')->get();
        $data['bank_accounts']=BankAccount::where('status',1)->get();
    
        $data['total_items'] = $this->getTotalItems();

        $data['json_report_types']=array(
            array('id'=>'gstr-3b','name'=>'GSTR-3B'),
            array('id'=>'gstr-1','name'=>'GSTR-1')

        );
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
    
    public function customer_ledger_report(Request $request)
    {
        $validator = Validator::make($request->all(), [
            
            'customer_id'=>['required'],
            'start_date'=>['required'],
            'end_date'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            $invoices = Invoice::where('customer_id',$request->customer_id)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            $payments = Payment::where('customer_id',$request->customer_id)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            $debit_notes = DebitNote::where('customer_id',$request->customer_id)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            $credit_notes = CreditNote::where('customer_id',$request->customer_id)->whereBetween('date',[$request->start_date,$request->end_date])->get();


            $cash_entries = CashbookTransaction::where('main_id',$request->customer_id)->where('identifier','cash')->whereBetween('date',[$request->start_date,$request->end_date])->get();


            $advances = PurchaseAdvancePayment::where('customer_id',$request->customer_id)->where('auto_entry',0)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            
            $from = Carbon::parse($request->start_date);
            $to = Carbon::parse($request->end_date);

            $i = 0;
            $report_array = array();

            for($d = $from; $d->lte($to); $d->addDay()) 
            {
                foreach ($invoices as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $report_array[$i]['reference'] = "Invoice Created Ref.-".$value->formatted_number;
                        $report_array[$i]['against'] = $value->formatted_number;
                        $report_array[$i]['description'] = $value->note;
                        $report_array[$i]['debit'] = $value->after_total;
                        $report_array[$i]['credit'] = "";
                        $report_array[$i]['type'] = "journal";

                        $report_array[$i]['section'] = "invoice";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $i++;
                    }
                }

                foreach ($payments as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $report_array[$i]['reference'] = "Payment Received Ref.-".$value->formatted_number." For Invoice Reference (".implode(',',array_column($value->invoices->toArray(),'formatted_number')).")";
                        $report_array[$i]['against'] = array_column($value->invoices->toArray(),'formatted_number');
                        $report_array[$i]['description'] = $value->remarks;
                        $report_array[$i]['credit'] = $value->amount;
                        $report_array[$i]['debit'] = "";
                        $report_array[$i]['type'] = "receipt";
                        
                        $report_array[$i]['section'] = "payment";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/payment/add-edit-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $i++;
                    }
                }

                foreach ($debit_notes as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $report_array[$i]['reference'] ="Debit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number;
                        $report_array[$i]['against'] = $value->invoice->formatted_number;
                        $report_array[$i]['description'] = $value->note;
                        $report_array[$i]['debit'] = $value->after_total;
                        $report_array[$i]['credit'] = "";
                        $report_array[$i]['type'] = "journal";
                        
                        $report_array[$i]['section'] = "debitnote";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $i++;
                    }
                }

                foreach ($credit_notes as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                    // var_dump($value->invoice->formatted_number); exit;
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $report_array[$i]['reference'] ="Credit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number;
                        $report_array[$i]['against'] = $value->invoice->formatted_number;
                        $report_array[$i]['description'] = $value->note;
                        $report_array[$i]['credit'] = $value->after_total;
                        $report_array[$i]['debit'] = "";
                        $report_array[$i]['type'] = "receipt";
                        
                        $report_array[$i]['section'] = "creditnote";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $i++;
                    }
                }

                foreach ($cash_entries as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        if($value->type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Cash Payment On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "journal";
                        }
                        elseif($value->type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Cash Received On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "receipt";
                        }

                        $report_array[$i]['section'] = "cashbook";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/cashbook/add-edit-cashbook/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);
                        $i++;
                        
                    }
                }

                foreach ($advances as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        if($value->type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "journal";
                        }
                        elseif($value->type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "receipt";
                        }

                        $report_array[$i]['section'] = "purchase_advance";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);
                        $i++;
                        
                    }
                }
            }

            return response(['data' => $report_array,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        }
        
    }

    public function vendor_ledger_report(Request $request)
    {
        $validator = Validator::make($request->all(), [
            
            'customer_id'=>['required'],
            'start_date'=>['required'],
            'end_date'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            $purchases = Purchase::where('type','vendor')->where('customer_id',$request->customer_id)->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Credit Asset = Credit

            $purchase_payments = PurchasePayment::where('type','vendor')->where('customer_id',$request->customer_id)->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Payment = Debit

            $cash_entries = CashbookTransaction::where('main_id',$request->customer_id)->where('identifier','cash')->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Payment = Debit


            $advances = PurchaseAdvancePayment::where('customer_id',$request->customer_id)->where('auto_entry',0)->whereBetween('date',[$request->start_date,$request->end_date])->get();


            $from = Carbon::parse($request->start_date);
            $to = Carbon::parse($request->end_date);

            $i = 0;
            $report_array = array();

            for($d = $from; $d->lte($to); $d->addDay()) 
            {
                foreach ($purchases as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $report_array[$i]['reference'] = "Purchase Done Ref.-".$value->number;
                        $report_array[$i]['against'] = $value->number;
                        $report_array[$i]['description'] = $value->remarks;
                        $report_array[$i]['debit'] = "";
                        $report_array[$i]['credit'] = $value->after_total;
                        $report_array[$i]['type'] = "journal";
                        
                        $report_array[$i]['section'] = "purchase";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $i++;
                    }
                }

                foreach ($purchase_payments as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $report_array[$i]['reference'] = "Purchase Payment Given Ref.-".$value->formatted_number." For Purchase Dated (".implode(',',array_column($value->purchases->toArray(),'date')).",Reference No. = ".implode(',',array_column($value->purchases->toArray(),'number')).")";
                        $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                        $report_array[$i]['description'] = $value->remarks;
                        $report_array[$i]['debit'] = $value->amount;
                        $report_array[$i]['credit'] = "";
                        $report_array[$i]['type'] = "receipt";
                        
                        $report_array[$i]['section'] = "purchase_payment";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $i++;
                    }
                }

                foreach ($cash_entries as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        if($value->type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Cash Payment On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "journal";
                        }
                        elseif($value->type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Cash Received On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "receipt";
                        }

                        $report_array[$i]['section'] = "cashbook";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/cashbook/add-edit-cashbook/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);

                        $i++;
                        
                    }
                }

                foreach ($advances as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        if($value->type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Advance Payment On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "journal";
                        }
                        elseif($value->type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "receipt";
                        }

                        $report_array[$i]['section'] = "purchase_advance";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);

                        $i++;
                        
                    }
                }


            }

            return response(['data' => $report_array,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

        }
    }
    public function calculate_opening_balance(Request $request)
    {

        $opening_balance = 0;
        $credit = 0 ; 
        $debit = 0;
        $pay_total = 0;

        $data['invoice_debit'] = Invoice::select(DB::raw('SUM(after_total) as total_after,SUM(before_total) as total_before,SUM(case when igst > 0 then igst else cgst+sgst end) as total_tax, SUM(cgst) as total_cgst, SUM(sgst) as total_sgst, SUM(igst) as total_igst, SUM(tds) as total_tds, SUM(tcs) as total_tcs'))->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->when($request->tds_section_id, function($query) use ($request) {
            return $query->where('invoices.tds_section_id',$request->tds_section_id);
        })->when($request->tcs_section_id, function($query) use ($request) {
            return $query->where('invoices.tcs_section_id',$request->tds_section_id);
        })->where('date','<',$request->start_date)->get();

        $invoices_back = Invoice::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->where('date','<',$request->start_date)->get();

        $data['payment_credit'] = Payment::select(DB::raw('SUM(amount) as total_amount,SUM(tds) as total_tds,SUM(tcs) as total_tcs,SUM(ods) as total_ods'))->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($invoices_back) {
            return $query->whereHas('invoices', function($q) use ($invoices_back){
                $q->whereIn('invoice_id',array_column($invoices_back->toArray(),'id'));
            });
        })->where('date','<',$request->start_date)->get();

        //echo "<pre>"; print_r($payments->toArray()); echo "</pre>"; exit;

        $data['debit_note_debit'] = DebitNote::select(

            DB::raw('SUM(after_total) as total_after,SUM(before_total) as total_before,SUM(case when igst > 0 then igst else cgst+sgst end) as total_tax, SUM(cgst) as total_cgst, SUM(sgst) as total_sgst, SUM(igst) as total_igst')

        )->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->where('date','<',$request->start_date)->get();

        $data['credit_note_credit'] = CreditNote::select(

            DB::raw('SUM(after_total) as total_after,SUM(before_total) as total_before,SUM(case when igst > 0 then igst else cgst+sgst end) as total_tax, SUM(cgst) as total_cgst, SUM(sgst) as total_sgst, SUM(igst) as total_igst')

        )->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->where('date','<',$request->start_date)->get();


        $data['cash_entrie_credit'] = CashbookTransaction::when($request->customer_id, function($query) use ($request) {
            return $query->where('main_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereRaw('1=2');
        })->where('identifier','cash')->where('type','credit')->where('date','<',$request->start_date)->sum('amount');

        $data['cash_entrie_debit'] = CashbookTransaction::when($request->customer_id, function($query) use ($request) {
            return $query->where('main_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereRaw('1=2');
        })->where('identifier','cash')->where('type','debit')->where('date','<',$request->start_date)->sum('amount');


        

        $data['purchase_credit'] = Purchase::select(

            DB::raw('SUM(after_total) as total_after,SUM(before_total) as total_before,SUM(case when igst > 0 then igst else cgst+sgst end) as total_tax, SUM(cgst) as total_cgst, SUM(sgst) as total_sgst, SUM(igst) as total_igst')

        )->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->where('date','<',$request->start_date)->get(); //Credit Asset = Credit
        $purchases_back = Purchase::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->where('date','<',$request->start_date)->get(); 

        $data['purchase_payment_debit'] = PurchasePayment::select(

            DB::raw('SUM(amount) as total_amount,SUM(tds) as total_tds,SUM(tcs) as total_tcs,SUM(ods) as total_ods')

        )->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($purchases_back) {
            return $query->whereHas('purchases', function($q) use ($purchases_back){
                $q->whereIn('purchase_id',array_column($purchases_back->toArray(),'id'));
            });
        })->when($request->tds_section_id, function($query) use ($request) {

            $query->whereRaw('id in ( select purchase_payment_id from purchase_payment_rel where tds_section_id = ? and deleted_at is null)',[$request->tds_section_id]);
            
        })->where('date','<',$request->start_date)->get();

        if(!empty($request->all_search))
        {
            $search_params = explode('_',$request->all_search);
            if(count($search_params) == 2)
            {

                $data['advance_credit'] = PurchaseAdvancePayment::when(count($search_params) > 0 , function($query) use ($search_params) {

                    $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                    
                })->where('auto_entry',0)->where('type','credit')->where('date','<',$request->start_date)->sum('amount');
        
                $data['advance_debit'] = PurchaseAdvancePayment::when(count($search_params) > 0 , function($query) use ($search_params) {
        
                    $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                    
                })->where('auto_entry',0)->where('type','debit')->where('date','<',$request->start_date)->sum('amount');

                $data['journal_credit'] = Journal::when(count($search_params) > 0 , function($query) use ($search_params) {

                    $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                    
                })->where('type','credit')->where('date','<',$request->start_date)->sum('after_total');
        
                $data['journal_debit'] = Journal::when(count($search_params) > 0 , function($query) use ($search_params) {

                    $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                    
                })->where('type','debit')->where('date','<',$request->start_date)->sum('after_total');
            }

            $opening = OpeningBalance::when(count($search_params) > 0 , function($query) use ($search_params) {

                $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                
            })->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();
        }    
       
        if(($request->input_gst == 1 || $request->output_gst == 1 || $request->gst == 1 || $request->input_tds == 1 || $request->output_tds || $request->tds == 1 || $request->tcs == 1 || $request->input_tcs == 1 || $request->output_tcs == 1 || $request->input_cgst == 1 || $request->input_sgst == 1 || $request->input_igst == 1 || $request->output_cgst == 1 || $request->output_sgst == 1 || $request->output_igst == 1))
        {
            if($request->input_gst == 1)
            {
                $debit = ($data['credit_note_credit'][0]['total_tax'] + $data['journal_debit'] +  $data['advance_debit']);
                $credit = ($data['invoice_debit'][0]['total_tax'] + $data['debit_note_debit'][0]['total_tax'] + $data['journal_credit'] +  $data['advance_credit']);
                $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->input_cgst == 1)
            {
                $debit = ($data['credit_note_credit'][0]['total_cgst'] + $data['journal_debit'] +  $data['advance_debit']);
                $credit = ($data['invoice_debit'][0]['total_cgst'] + $data['debit_note_debit'][0]['total_cgst'] + $data['journal_credit'] +  $data['advance_credit']);
                $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->input_sgst == 1)
            {
                $debit = ( $data['credit_note_credit'][0]['total_sgst'] + $data['journal_debit'] +  $data['advance_debit']);
                $credit = ($data['invoice_debit'][0]['total_sgst'] + $data['debit_note_debit'][0]['total_cgst'] + $data['journal_credit'] +  $data['advance_credit']);
                $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->input_igst == 1)
            {
               
                
                $debit = ($data['credit_note_credit'][0]['total_igst'] + $data['journal_debit'] + $data['advance_debit']);
                $credit = ($data['invoice_debit'][0]['total_igst'] + $data['debit_note_debit'][0]['total_igst'] + $data['journal_credit'] + $data['advance_credit']);
                
                $opening_balance = bcsub($credit, $debit,2);

                
            }
            if($request->output_gst == 1)
            {
               $debit = $data['purchase_credit'][0]['total_tax'] + $data['journal_debit'] +  $data['advance_debit'];
               $credit =  $data['journal_credit'] +  $data['advance_credit'];
               $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->output_cgst == 1)
            {
               $debit = $data['purchase_credit'][0]['total_cgst'] + $data['journal_debit'] +  $data['advance_debit'];
               $credit =  $data['journal_credit'] +  $data['advance_credit'];
               $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->output_sgst == 1)
            {
               $debit = $data['purchase_credit'][0]['total_sgst'] + $data['journal_debit'] +  $data['advance_debit'];
               $credit =  $data['journal_credit'] +  $data['advance_credit'];
               $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->output_igst == 1)
            {
               $debit = $data['purchase_credit'][0]['total_igst'] + $data['journal_debit'] +  $data['advance_debit'];
               $credit =  $data['journal_credit'] +  $data['advance_credit'];
              
               $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->input_tds == 1)
            {
               
                $opening_balance = bcsub(($data['invoice_debit'][0]['total_tds'] +  $data['advance_debit']),($data['journal_debit']+  $data['advance_credit']),2);
            }
            elseif($request->output_tds == 1)
            {
                $opening_balance = bcsub(($data['journal_credit'] +  $data['advance_credit']),$data['purchase_payment_debit'][0]['total_tds'],2);
            }
            if($request->input_tcs == 1)
            {
                $opening_balance = bcsub($data['invoice_debit'][0]['total_tcs'],$data['journal_debit'] +  $data['advance_debit'],2);
            }
            
        }
        else
        {
            if(count($request->item_id) > 0)
            {
                $pay_total = $data['payment_credit'][0]['total_amount'] > 0 ?  bcsub($data['payment_credit'][0]['total_amount'],bcsub($data['payment_credit'][0]['total_amount'],$data['invoice_debit'][0]['total_before'],2),2):0;

                $debit = ( $data['credit_note_credit'][0]['total_tax'] + $data['purchase_credit'][0]['total_before'] + $data['journal_credit'] +  $data['advance_credit']);

                $credit = bcsub(( $data['invoice_debit'][0]['total_before'] + $data['debit_note_debit'][0]['total_before'] + $data['journal_debit'] +  $data['advance_debit']),0,2);

                $opening_balance = bcsub($credit, $debit,2);
            }
            else
            {
                $credit = bcsub(($data['purchase_credit'][0]['total_after'] + $data['payment_credit'][0]['total_amount'] + $data['advance_credit'] +  $data['cash_entrie_credit'] + $data['journal_credit']),0,2);
                $debit = bcsub(($data['purchase_payment_debit'][0]['total_amount'] + $data['invoice_debit'][0]['total_after'] + $data['debit_note_debit'][0]['total_after'] + $data['advance_debit'] + $data['cash_entrie_debit'] + $data['journal_debit']),0,2);
                $opening_balance = bcsub($credit, $debit,2);
                
                
            }
        }
        

        if(isset($opening) && !empty($opening))
        {
            $opening_balance = $opening->type == 'debit' ? ((0 - $opening->amount) + $opening_balance) : ($opening->amount + $opening_balance);
        }
        
          
       return $opening_balance;
    }
    public function full_ledger_report(Request $request)
    {
        $validator = Validator::make($request->all(), [
            
            'start_date'=>['required'],
            'end_date'=>['required'],
            'all_search'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            
            if(!empty($request->all_search))
            {
                $search_params = explode('_',$request->all_search);

                $request->item_id = array();
                if(count($search_params) == 2)
                {
                    if($search_params[0] == 'customer')
                        $request->customer_id = $search_params[1];
                    if($search_params[0] == 'item')
                        $request->item_id = array($search_params[1]);

                    if($search_params[0] == 'gst')
                    {
                        if($search_params[1] == 1)
                         $request->input_gst = 1;
                        elseif($search_params[1] == 2)
                         $request->output_gst = 1; 

                    }
                    if($search_params[0] == 'cgst')
                    {
                        if($search_params[1] == 1)
                         $request->input_cgst = 1;
                        elseif($search_params[1] == 2)
                         $request->output_cgst = 1; 
                    }
                    if($search_params[0] == 'sgst')
                    {
                        if($search_params[1] == 1)
                         $request->input_sgst = 1;
                        elseif($search_params[1] == 2)
                         $request->output_sgst = 1; 
                    }
                    if($search_params[0] == 'igst')
                    {
                        if($search_params[1] == 1)
                         $request->input_igst = 1;
                        elseif($search_params[1] == 2)
                         $request->output_igst = 1; 
                    }
                    if($search_params[0] == 'tds')
                    {
                        if($search_params[1] == 1)
                         $request->input_tds = 1;
                        elseif($search_params[1] == 2)
                         $request->output_tds = 1; 

                    }
                    if($search_params[0] == 'tcs')
                    {
                        if($search_params[1] == 1)
                         $request->input_tcs = 1;
                        elseif($search_params[1] == 2)
                         $request->output_tcs = 1; 

                    }
                    if($search_params[0] == 'tds-section')
                    {
                        $request->input_tcs = 1;
                        $request->tds_section_id = $search_params[1];
                    }
                    if($search_params[0] == 'tcs-section')
                    {
                        $request->input_tcs = 1;
                        $request->tcs_section_id = $search_params[1];
                    }           
                }
                else
                    return response(['data' => array(),'success'=>false,'message' =>"Selector Error"], 200);
            }
            //For Opening Balance Checking
           
            $opening_balance = $this->calculate_opening_balance($request);

            //Date Range Data
            $invoices = Invoice::when($request->customer_id, function($query) use ($request) {
                return $query->where('customer_id',$request->customer_id);
            })->when($request->item_id, function($query) use ($request) {
                return $query->whereHas('items', function($q) use ($request){
                    $q->whereIn('item_id',$request->item_id);
                });
            })->when($request->tds_section_id, function($query) use ($request) {
                return $query->where('tds_section_id',$request->tds_section_id);
            })->when($request->tcs_section_id, function($query) use ($request) {
                return $query->where('tcs_section_id',$request->tcs_section_id);
               
            })->whereBetween('date',[$request->start_date,$request->end_date])->get();

            
            $payments = Payment::with('bank_account')->when($request->customer_id, function($query) use ($request) {
                return $query->where('customer_id',$request->customer_id);
            })->when($request->item_id, function($query) use ($invoices) {
                return $query->whereHas('invoices', function($q) use ($invoices){
                    $q->whereIn('invoice_id',array_column($invoices->toArray(),'id'));
                });
            })->whereBetween('date',[$request->start_date,$request->end_date])->get();


            $debit_notes = DebitNote::when($request->customer_id, function($query) use ($request) {
                return $query->where('customer_id',$request->customer_id);
            })->when($request->item_id, function($query) use ($request) {
                return $query->whereHas('items', function($q) use ($request){
                    $q->whereIn('item_id',$request->item_id);
                });
            })->whereBetween('date',[$request->start_date,$request->end_date])->get();

            $credit_notes = CreditNote::when($request->customer_id, function($query) use ($request) {
                return $query->where('customer_id',$request->customer_id);
            })->when($request->item_id, function($query) use ($request) {
                return $query->whereHas('items', function($q) use ($request){
                    $q->whereIn('item_id',$request->item_id);
                });
            })->whereBetween('date',[$request->start_date,$request->end_date])->get();


            $cash_entries = CashbookTransaction::when($request->customer_id, function($query) use ($request) {
                return $query->where('main_id',$request->customer_id);
            })->when($request->item_id, function($query) use ($request) {
                return $query->whereRaw('1=2');
            })->where('identifier','cash')->whereBetween('date',[$request->start_date,$request->end_date])->get();


            $advances = PurchaseAdvancePayment::with('bank_account')->when(count($search_params) > 0 , function($query) use ($search_params) {

                $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                
            })->where('auto_entry',0)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            $purchases = Purchase::when($request->customer_id, function($query) use ($request) {
                return $query->where('customer_id',$request->customer_id);
            })->when($request->item_id, function($query) use ($request) {
                return $query->whereHas('items', function($q) use ($request){
                    $q->whereIn('item_id',$request->item_id);
                });
            })->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Credit Asset = Credit
            
            $purchase_payments = PurchasePayment::with('bank_account')->when($request->customer_id, function($query) use ($request) {
                return $query->where('customer_id',$request->customer_id);
            })->when($request->item_id, function($query) use ($purchases) {
                return $query->whereHas('purchases', function($q) use ($purchases){
                    $q->whereIn('purchase_id',array_column($purchases->toArray(),'id'));
                });
            })->when($request->tds_section_id, function($query) use ($request) {

                $query->whereRaw('id in ( select purchase_payment_id from purchase_payment_rel where tds_section_id = ? and deleted_at is null)',[$request->tds_section_id]);
                
            })->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Payment = Debit


            $journals = Journal::with('journal_main')->when(count($search_params) > 0 , function($query) use ($search_params) {

                $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                
            })->whereBetween('date',[$request->start_date,$request->end_date])->get();

           
            $from = Carbon::parse($request->start_date);
            $to = Carbon::parse($request->end_date);

            $i = 0;
            $report_array = array();

            
            
            $report_array[$i]['date'] = $from->format('Y-m-d');
            $report_array[$i]['reference'] = "Opening Balance On ".$from->format('d/m/Y');

            if($opening_balance >= 0)
            {
                $report_array[$i]['debit'] = "";
                $report_array[$i]['credit'] = abs($opening_balance);
                $report_array[$i]['type'] = "credit";
            }
            elseif($opening_balance < 0)
            {
                $report_array[$i]['debit'] = abs($opening_balance);
                $report_array[$i]['credit'] = "";
                $report_array[$i]['type'] = "debit";
            }
            
            
            
            $i++;
            
            $edit_access =  $this->checkReportEditAccess();
            for($d = $from; $d->lte($to); $d->addDay()) 
            {
                if(($request->input_gst == 1 || $request->output_gst == 1 || $request->gst == 1 || $request->input_tds == 1 || $request->output_tds || $request->tds == 1 || $request->tcs == 1 || $request->input_tcs == 1 || $request->output_tcs == 1 || $request->input_cgst == 1 || $request->input_sgst == 1 || $request->input_igst == 1 || $request->output_cgst == 1 || $request->output_sgst == 1 || $request->output_igst == 1))
                {
                    if($request->input_gst == 1)
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($invoices as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output GST (Invoice No. ".$value->formatted_number."): - Rs.".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "invoice";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
				                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                        foreach ($debit_notes as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Output GST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "debitnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
				                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        foreach ($credit_notes as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = $value->igst > 0 ? "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- IGST : Rs. " .$value->igst: "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- CGST - Rs. ".$value['cgst']." , SGST - Rs. ".$value['sgst'];
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "creditnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
				                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                        } 
                    }
                    if($request->input_cgst == 1)
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($invoices as $key => $value) 
                        {
                            if($value->cgst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Output CGST (Invoice No. ".$value->formatted_number."): - Rs.".$value->cgst;
                                    $report_array[$i]['against'] = $value->formatted_number;
                                    $report_array[$i]['description'] = $value->note;
                                    $report_array[$i]['credit'] = $value->cgst;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['type'] = "invoice";

                                    $report_array[$i]['section'] = "invoice";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                            }
                            
                        }
                        
                        foreach ($debit_notes as $key => $value) 
                        {
                            if($value->cgst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] ="Output CGST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".$value->cgst;
                                    $report_array[$i]['against'] = $value->invoice->formatted_number;
                                    $report_array[$i]['description'] = $value->note;
                                    $report_array[$i]['credit'] =  $value->cgst;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "debitnote";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = "";
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                            }
                            
                        }
                        foreach ($credit_notes as $key => $value) 
                        {
                            if($value->cgst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Output CGST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- CGST - Rs. ".$value['cgst'];
                                    $report_array[$i]['against'] = $value->invoice->formatted_number;
                                    $report_array[$i]['description'] = $value->note;
                                    $report_array[$i]['debit'] =  $value->cgst;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "creditnote";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = "";
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                            }    
                        }
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                        } 
                    }
                    if($request->input_sgst == 1)
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($invoices as $key => $value) 
                        {
                            if($value->sgst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Output SGST (Invoice No. ".$value->formatted_number."): - Rs.".$value->sgst;
                                    $report_array[$i]['against'] = $value->formatted_number;
                                    $report_array[$i]['description'] = $value->note;
                                    $report_array[$i]['credit'] = $value->sgst;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['type'] = "invoice";

                                    $report_array[$i]['section'] = "invoice";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                            }
                            
                        }
                        
                        foreach ($debit_notes as $key => $value) 
                        {
                            if($value->sgst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] ="Output SGST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".$value->sgst;
                                    $report_array[$i]['against'] = $value->invoice->formatted_number;
                                    $report_array[$i]['description'] = $value->note;
                                    $report_array[$i]['credit'] =  $value->sgst;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "debitnote";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = "";
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                            }
                            
                        }
                        foreach ($credit_notes as $key => $value) 
                        {
                            if($value->sgst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Output SGST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- SGST - Rs. ".$value['sgst'];
                                    $report_array[$i]['against'] = $value->invoice->formatted_number;
                                    $report_array[$i]['description'] = $value->note;
                                    $report_array[$i]['debit'] =  $value->sgst;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "creditnote";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = "";
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                            }    
                        }
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                        } 
                    }
                    if($request->input_igst == 1)
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($invoices as $key => $value) 
                        {
                            if($value->igst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Output IGST (Invoice No. ".$value->formatted_number."): - Rs.".$value->igst;
                                    $report_array[$i]['against'] = $value->formatted_number;
                                    $report_array[$i]['description'] = $value->note;
                                    $report_array[$i]['credit'] = $value->igst;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['type'] = "invoice";

                                    $report_array[$i]['section'] = "invoice";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                            }
                            
                        }
                        
                        foreach ($debit_notes as $key => $value) 
                        {
                            if($value->igst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] ="Output IGST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".$value->igst;
                                    $report_array[$i]['against'] = $value->invoice->formatted_number;
                                    $report_array[$i]['description'] = $value->note;
                                    $report_array[$i]['credit'] =  $value->igst;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "debitnote";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = "";
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                            }
                            
                        }
                        foreach ($credit_notes as $key => $value) 
                        {
                            if($value->igst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Output IGST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- IGST - Rs. ".$value['igst'];
                                    $report_array[$i]['against'] = $value->invoice->formatted_number;
                                    $report_array[$i]['description'] = $value->note;
                                    $report_array[$i]['debit'] =  $value->igst;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "creditnote";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = "";
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                            }
                           
                        }
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                        } 
                    }
                    if($request->output_gst == 1)
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($purchases as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->is_taxable == 1)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = ($value->igst > 0 ? ("Input GST :-  IGST Rs.- " .$value->igst): ("Input GST :- CGST Rs.- ".$value['cgst']." , SGST Rs.- ".$value['sgst']));
                                    $report_array[$i]['against'] = $value->number;
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "purchase";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
				                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['edit_access'] = $edit_access;	
                                    $i++;
                                }
                                
                            }
                        }
                        
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type ;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                        } 
                        
                    }
                    if($request->output_cgst == 1)
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($purchases as $key => $value) 
                        {
                            if($value->cgst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    if($value->is_taxable == 1)
                                    {
                                        $report_array[$i]['date'] = $d->format('Y-m-d');
                                        $report_array[$i]['reference'] = "Input CGST Rs.- " .$value->cgst;
                                        $report_array[$i]['against'] = $value->number;
                                        $report_array[$i]['description'] = $value->remarks;
                                        $report_array[$i]['credit'] = "";
                                        $report_array[$i]['debit'] = $value->cgst;
                                        $report_array[$i]['type'] = "receipt";
                                        
                                        $report_array[$i]['section'] = "purchase";
                                        $report_array[$i]['section_id'] = $value->id;
                                        $report_array[$i]['section_type'] = "";
                                        $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                        $report_array[$i]['param'] = array();
                                        $report_array[$i]['status'] = $value->status;
                                        $report_array[$i]['edit_access'] = $edit_access;	
                                        $i++;
                                    }
                                    
                                }
                            }
                            
                        }
                        
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                        } 
                        
                    }
                    if($request->output_sgst == 1)
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($purchases as $key => $value) 
                        {
                            if($value->sgst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    if($value->is_taxable == 1)
                                    {
                                        $report_array[$i]['date'] = $d->format('Y-m-d');
                                        $report_array[$i]['reference'] = "Input SGST Rs.- " .$value->cgst;
                                        $report_array[$i]['against'] = $value->number;
                                        $report_array[$i]['description'] = $value->remarks;
                                        $report_array[$i]['credit'] = "";
                                        $report_array[$i]['debit'] = $value->sgst;
                                        $report_array[$i]['type'] = "receipt";
                                        
                                        $report_array[$i]['section'] = "purchase";
                                        $report_array[$i]['section_id'] = $value->id;
                                        $report_array[$i]['section_type'] = "";
                                        $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                        $report_array[$i]['param'] = array();
                                        $report_array[$i]['status'] = $value->status;
                                        $report_array[$i]['edit_access'] = $edit_access;	
                                        $i++;
                                    }
                                    
                                }
                            }
                            
                        }
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                        } 
                        
                    }
                    if($request->output_igst == 1)
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($purchases as $key => $value) 
                        {
                            if($value->igst > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    if($value->is_taxable == 1)
                                    {
                                        $report_array[$i]['date'] = $d->format('Y-m-d');
                                        $report_array[$i]['reference'] = "Input IGST Rs.- " .$value->cgst;
                                        $report_array[$i]['against'] = $value->number;
                                        $report_array[$i]['description'] = $value->remarks;
                                        $report_array[$i]['credit'] = "";
                                        $report_array[$i]['debit'] = $value->igst;
                                        $report_array[$i]['type'] = "invoice";
                                        
                                        $report_array[$i]['section'] = "purchase";
                                        $report_array[$i]['section_id'] = $value->id;
                                        $report_array[$i]['section_type'] = "";
                                        $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                        $report_array[$i]['param'] = array();
                                        $report_array[$i]['status'] = $value->status;
                                        $report_array[$i]['edit_access'] = $edit_access;	
                                        $i++;
                                    }
                                    
                                }
                            }
                            
                        }
                        
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Journal Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = "journal";
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                        } 
                        
                    }
                    if($request->gst == 1)
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($invoices as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Input GST (Invoice No. ".$value->formatted_number."): - Rs.".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "journal";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
				                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        foreach ($purchases as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->is_taxable == 1)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = ($value->igst > 0 ? ("Output GST :-  IGST Rs.- " .$value->igst): ("Output GST :- CGST Rs.- ".$value['cgst']." , SGST Rs.- ".$value['sgst']));
                                    $report_array[$i]['against'] = $value->number;
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                    $report_array[$i]['type'] = "journal";
                                    
                                    $report_array[$i]['section'] = "purchase";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
				                    $report_array[$i]['status'] = "";
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                                
                            }
                        }
                        foreach ($debit_notes as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Input GST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "journal";
                                
                                $report_array[$i]['section'] = "debitnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
				                $report_array[$i]['status'] = "";
                                $i++;
                            }
                        }
                        foreach ($credit_notes as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                            // var_dump($value->invoice->formatted_number); exit;
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = $value->igst > 0 ? "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- IGST : Rs. " .$value->igst: "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- CGST - Rs. ".$value['cgst']." , SGST - Rs. ".$value['sgst'];
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "creditnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
				                $report_array[$i]['status'] = "";
                                $i++;
                            }
                        }
                    }
                    if($request->input_tds == 1)
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($invoices as $key => $value) 
                        {
                            if($value->tds > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Output TDS (Invoice No. ".$value->formatted_number."): - Rs.".$value->tds;
                                    $report_array[$i]['against'] = $value->formatted_number;
                                    $report_array[$i]['description'] = $value->note;
                                    $report_array[$i]['credit'] = $value->tds;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['type'] = "invoice";

                                    $report_array[$i]['section'] = "invoice";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                            }
                            
                        }
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                        } 
                    }
                    if($request->output_tds == 1)
                    {                 
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($purchase_payments as $key => $value) 
                        {
                            if($value->tds > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Input TDS -".$value->formatted_number." For Purchase (Dated ".implode(',',array_column($value->purchases->toArray(),'date')).",Reference No. = ".implode(',',array_column($value->purchases->toArray(),'number')).")";
                                    $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "purchase_payment";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                                    $report_array[$i]['status'] = "";
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['edit_access'] = $edit_access;

                                    if($request->tds_section_id)
                                    {
                                        $tds = 0;

                                        foreach ($value->purchases->toArray() as $key => $inv) 
                                        {
                                        if($inv['pivot']['tds_section_id'] == $request->tds_section_id)
                                        {
                                            $tds = $tds + $inv['pivot']['tds'];
                                        }
                                        }

                                        $report_array[$i]['debit'] = $tds;
                                    }
                                    else
                                        $report_array[$i]['debit'] = $value->tds;
                                    $i++;
                                }
                            }
                            
                        }
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                        } 
                    }
                    if($request->input_tcs == 1)
                    {
                       
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($invoices as $key => $value) 
                        {
                            if($value->tcs > 0)
                            {
                                if($d->format('Y-m-d') == $value->date)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Output TCS (Invoice No. ".$value->formatted_number."): - Rs.".$value->tcs;
                                    $report_array[$i]['against'] = $value->formatted_number;
                                    $report_array[$i]['description'] = $value->note;
                                    $report_array[$i]['credit'] = $value->tcs;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['type'] = "receipt";

                                    $report_array[$i]['section'] = "invoice";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['edit_access'] = $edit_access;
                                    $i++;
                                }
                            }
                            
                        }
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    

                        } 
                    }
                }
                else
                {
                    if(count($request->item_id) > 0)
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($invoices as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Invoice Created.-".$value->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->before_total;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "invoice";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;	
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        /*foreach ($payments as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Payment Received Ref.-".$value->formatted_number." For Invoice Reference (".implode(',',array_column($value->invoices->toArray(),'formatted_number')).")";
                                $report_array[$i]['against'] = array_column($value->invoices->toArray(),'formatted_number');
                                $report_array[$i]['description'] = $value->remarks;
                                
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "payment";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/payment/add-edit-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;

                                $gst = 0;

                                foreach ($value->invoices->toArray() as $key => $inv) 
                                {
                                    $gst = $gst + $inv['igst'] > 0 ? $inv['igst'] : ($inv['cgst'] + $inv['sgst']);
                                }

                                $report_array[$i]['debit'] = $value->amount - $gst;
                                $i++;
                            }
                        }*/
                        foreach ($purchases as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Purchase Done Ref.-".$value->number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                                $report_array[$i]['against'] = $value->number;
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = !empty($value->before_total) ? $value->before_total: $value->before_total;
                                $report_array[$i]['type'] = "purchase";
                                
                                $report_array[$i]['section'] = "purchase";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        /*foreach ($purchase_payments as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Purchase Payment Given Ref.-".$value->formatted_number." For Purchase (Dated ".implode(',',array_column($value->purchases->toArray(),'date')).",Reference No. = ".implode(',',array_column($value->purchases->toArray(),'number')).")";
                                $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                                $report_array[$i]['description'] = $value->remarks;
                               
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "purchase_payment";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;

                                $gst = 0;

                                foreach ($value->purchases->toArray() as $key => $inv) 
                                {
                                    $gst = $gst + $inv['igst'] > 0 ? $inv['igst'] : ($inv['cgst'] + $inv['sgst']);
                                }
                                $report_array[$i]['credit'] = $value->amount - $gst;
                                $i++;
                            }
                        }*/

                        foreach ($debit_notes as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Debit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->before_total;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "debitnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }

                        foreach ($credit_notes as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                            // var_dump($value->invoice->formatted_number); exit;
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Credit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] = $value->before_total;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "creditnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                            
                        } 
                        
                    }
                    else
                    {
                        foreach ($advances as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $bank_name = !empty($value->bank_account) ? $value->bank_account->display_name : "";
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Amount Debited From ".$bank_name."  On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Amount Debited To ".$bank_name."  On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "purchase_advance";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach ($invoices as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Invoice Created.-".$value->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "invoice";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;	
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        foreach ($payments as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Payment Received Ref.-".$value->formatted_number." For Invoice Reference (".implode(',',array_column($value->invoices->toArray(),'formatted_number')).")";
                                $report_array[$i]['against'] = array_column($value->invoices->toArray(),'formatted_number');
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "payment";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/payment/add-edit-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        foreach ($purchases as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Purchase Done Ref.-".$value->number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                                $report_array[$i]['against'] = $value->number;
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = !empty($value->after_total) ? $value->after_total: $value->before_total;
                                $report_array[$i]['type'] = "purchase";
                                
                                $report_array[$i]['section'] = "purchase";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        foreach ($purchase_payments as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Purchase Payment Given From  Ref.-".$value->formatted_number." For Purchase (Dated ".implode(',',array_column($value->purchases->toArray(),'date')).",Reference No. = ".implode(',',array_column($value->purchases->toArray(),'number')).")";
                                $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "purchase_payment";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }

                        foreach ($debit_notes as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Debit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "debitnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }

                        foreach ($credit_notes as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                            // var_dump($value->invoice->formatted_number); exit;
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Credit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "creditnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }

                        foreach ($cash_entries as $key => $value) 
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->type == 'debit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Cash Payment On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->amount;
                                    $report_array[$i]['type'] = "debit";
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Cash Received On - ".$d->format('d/m/Y');
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->amount;
                                    $report_array[$i]['type'] = "credit";
                                }

                                $report_array[$i]['section'] = "cashbook";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/cashbook/add-edit-cashbook/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                                
                            }
                        }
                        foreach($journals as $key => $value)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                                if($value->type == 'debit')
                                {
                                    
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->after_total;
                                    $report_array[$i]['type'] =  $type;
                                }
                                elseif($value->type == 'credit')
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                    $report_array[$i]['against'] = "";
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['debit'] = "";
                                    $report_array[$i]['credit'] = $value->after_total;
                                    $report_array[$i]['type'] = $type;
                                }

                                $report_array[$i]['section'] = "journal";
                                $report_array[$i]['section_id'] = $value->journal_id;
                                $report_array[$i]['section_type'] = $value->type;
                                $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                                $report_array[$i]['param'] = array('type'=>$value->type);
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }    
                            
                        } 

                    }

                    
                }
                
            }

            if($request->return_type == 'array')
                return $report_array;
            else
                return response(['data' => $report_array,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        }
        
    }

    public function full_ledger_report_pdf(Request $request)
    {
        $request->return_type = 'array';

        $return_array  = $this->full_ledger_report($request);
        $print_data = array();

        if($invoice_account =InvoiceAccount::find(1))
        {

            //Ledger Item Name
            $print_data['[ITEM_NAME]'] = $request->item_name;
            //Set Account Data Variables
            $print_data = array_merge($print_data,$this->set_account_data($invoice_account,'invoice'));

            if($customer = Customer::find($request->customer_id))
            {
                //Set Customer Data Variables
                $print_data = array_merge($print_data,$this->set_customer_data($customer,'invoice'));
            }    

            if(count($return_array) > 0)
            {
                $print_data_loop=array();
                $i=0;
                $item_str="";
                $total_debit = 0;
                $total_credit = 0;

                foreach ($return_array as  $value) 
                {   
                    
                    $i++;

                    $print_data_loop['[SLNO]']=$i;
                    
                    $print_data_loop['[REFERENCE]']=$value['reference'];
                    $print_data_loop['[DATE]']=Carbon::parse($value['date'])->format('d/m/Y');
                    $print_data_loop['[TYPE]']=ucfirst($value['type']);
                    $print_data_loop['[DEBIT]']=number_format(floatval($value['debit']),2);
                    $print_data_loop['[CREDIT]'] = number_format(floatval($value['credit']),2);
                    
                    preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$invoice_account->ledger_body,$matches);

                    $item_str .= $this->loop($matches,$print_data_loop);
                        
                    $total_debit=$total_debit+floatval($value['debit']);
                    $total_credit=$total_credit+floatval($value['credit']);
                }

                if(count($matches) > 0 && isset($matches[0][0]))
                    $ledger_body =str_replace($matches[0][0], $item_str,$invoice_account->ledger_body);
                else
                    $ledger_body = $invoice_account->ledger_body;

                $print_data['[TOTAL_CREDIT]'] = number_format($total_credit,2);
                $print_data['[TOTAL_DEBIT]'] = number_format($total_debit,2);

                
                if(($total_credit - $total_debit) >= 0)
                {
                    $print_data['[CLOSING_BALANCE_DEBIT]'] = number_format(abs($total_credit - $total_debit),2);
                    $print_data['[CLOSING_BALANCE_CREDIT]'] = "";

                    $print_data['[GRAND_DEBIT]'] = number_format($total_debit + abs($total_credit - $total_debit),2);
                    $print_data['[GRAND_CREDIT]'] = number_format($total_credit,2);
                }
                if(($total_credit - $total_debit) < 0)
                {
                    $print_data['[CLOSING_BALANCE_CREDIT]'] = number_format(abs($total_credit - $total_debit),2);
                    $print_data['[CLOSING_BALANCE_DEBIT]'] = "";

                    $print_data['[GRAND_CREDIT]'] = number_format($total_credit + abs($total_credit - $total_debit),2);
                    $print_data['[GRAND_DEBIT]'] = number_format($total_debit,2);
                }     

                $from = Carbon::parse($request->start_date);
                $to = Carbon::parse($request->end_date);

                $print_data['[START_DATE]'] = $from->format('d/m/Y');
                $print_data['[END_DATE]'] = $to->format('d/m/Y');

                $ledger_body = $this->replace_variable($ledger_body,$print_data,$invoice_account->ledger_body);

                //Save The Final HTML to PDF
                $path = storage_path()."/report/ledger";
                if (!file_exists($path)) {
                    $this->createPath($path);
                }
                $fileName =  $path."/".$request->item_name."-Leader-Report-".time().".pdf";

                PDF::loadHTML($ledger_body)->setPaper('a4', 'portrait')->setWarnings(false)->save($fileName);

                return  response()->file($fileName);

            }
        }
        
    }
    
    public function cashbook_report(Request $request)
    {
        $validator = Validator::make($request->all(), [

            'start_date'=>['required'],
            'end_date'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {

            $payment_credit = Payment::where('payment_type','cash')->where('date','<',$request->start_date)->sum('amount'); //Credit

            $purchase_payment_debit = PurchasePayment::where('payment_type','cash')->where('date','<',$request->start_date)->sum('amount'); // Debit

            $contra_entry_credit = CashbookTransaction::where('identifier','cash')->where('date','<',$request->start_date)->where('type','credit')->sum('amount'); // Credit

            $contra_entry_debit = CashbookTransaction::where('identifier','cash')->where('type','debit')->where('date','<',$request->start_date)->sum('amount'); // Debit

            $advance_credit = PurchaseAdvancePayment::where('payment_type','cash')->where('date','<',$request->start_date)->where('auto_entry',0)->where('type','credit')->sum('amount'); //Credit

            $advance_debit = PurchaseAdvancePayment::where('payment_type','cash')->where('date','<',$request->start_date)->where('auto_entry',0)->where('type','debit')->sum('amount'); //Debit

            $voucher_debit = JournalMain::where('type','voucher')->where('payment_type','cash')->where('date','<',$request->start_date)->where('voucher_type','debit')->sum('amount'); //Debit

            $voucher_credit = JournalMain::where('type','voucher')->where('payment_type','cash')->where('date','<',$request->start_date)->where('voucher_type','credit')->sum('amount'); //Credit

            $payments = Payment::with('customer')->where('payment_type','cash')->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Credit


            $cash_entries = CashbookTransaction::with('main')->where('identifier','cash')->whereBetween('date',[$request->start_date,$request->end_date])->get();


            $advances = PurchaseAdvancePayment::where('payment_type','cash')->where('auto_entry',0)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            $purchase_payments = PurchasePayment::with('customer')->where('payment_type','cash')->whereBetween('date',[$request->start_date,$request->end_date])->get(); // Debit

            $vouchers =  JournalMain::with('journals')->where('type','voucher')->where('payment_type','cash')->whereBetween('date',[$request->start_date,$request->end_date])->get();

            $opening = OpeningBalance::where('main_id',0)->where('identifier','cash')->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();

            $from = Carbon::parse($request->start_date);
            $to = Carbon::parse($request->end_date);

            $i = 0;
            $report_array = array();

            $opening_balance = (( floatval($payment_credit) + floatval($advance_credit) + floatval($contra_entry_credit) + floatval($voucher_credit) ) - (floatval($purchase_payment_debit) + floatval($advance_debit) + floatval($contra_entry_debit) + floatval($voucher_debit)));

            if(isset($opening) && !empty($opening))
            {
                $opening_balance = $opening->type == 'debit' ? ((0 - $opening->amount) + $opening_balance) : ($opening->amount + $opening_balance);
            }

            $report_array = array();
            $report_array[$i]['date'] = $from->format('Y-m-d');
            $report_array[$i]['reference'] = "Opening Balance On ".$from->format('d/m/Y');


            if($opening_balance >= 0)
            {
                $report_array[$i]['debit'] = "";
                $report_array[$i]['credit'] = abs($opening_balance);
                $report_array[$i]['type'] = "credit";
            }
            elseif($opening_balance < 0)
            {
                $report_array[$i]['debit'] = abs($opening_balance);
                $report_array[$i]['credit'] = "";
                $report_array[$i]['type'] = "debit";
            }

            
            $i++;

            $edit_access =  $this->checkReportEditAccess();

            for($d = $from; $d->lte($to); $d->addDay()) 
            {
                foreach ($payments as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $report_array[$i]['reference'] = "Payment Received From ".$value->customer->full_name." Ref.-".$value->formatted_number." For Invoice Reference (".implode(',',array_column($value->invoices->toArray(),'formatted_number')).")";
                        $report_array[$i]['against'] = array_column($value->invoices->toArray(),'formatted_number');
                        $report_array[$i]['description'] = $value->remarks;
                        $report_array[$i]['credit'] = $value->amount;
                        $report_array[$i]['debit'] = "";
                        $report_array[$i]['type'] = "credit";
                        
                        $report_array[$i]['section'] = "payment";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/payment/add-edit-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                    }
                }
                
                foreach ($purchase_payments as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $type = $value->type == "vendor" ? "Purchase":"Salary";
                        
                        if($value->type == 'vendor')
                             $report_array[$i]['reference'] = $type." Payment Given To ".$value->customer->full_name." Ref.-".$value->formatted_number." For Purchase (Dated ".implode(',',array_column($value->purchases->toArray(),'date')).",Reference No. = ".implode(',',array_column($value->purchases->toArray(),'number')).")";
                        else
                            $report_array[$i]['reference'] = $type." Payment Given To ".$value->customer->full_name;

                        $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                        $report_array[$i]['description'] = $value->remarks;
                        $report_array[$i]['debit'] = $value->amount;
                        $report_array[$i]['credit'] = "";
                        $report_array[$i]['type'] = "debit";
                        
                        $report_array[$i]['section'] = "purchase_payment";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                    }
                }

                foreach ($cash_entries as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        if($value->type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Cash Debited - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "debit";
                        }
                        elseif($value->type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Cash Credited".$value->main->full_name." On ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "credit";
                        }

                        $report_array[$i]['section'] = "cashbook";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/cashbook/add-edit-cashbook/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                        
                    }
                }

                foreach ($advances as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        if($value->type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Amount Refund To ".$value->item_name." - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "debit";
                        }
                        elseif($value->type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "credit";
                        }

                        $report_array[$i]['section'] = "purchase_advance";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                        
                    }
                }

                foreach ($vouchers as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        if($value->voucher_type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Account Voucher Debited For ".implode(',',array_column($value->journals->toArray(),'item_name') ) ."- ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "debit";
                        }
                        elseif($value->voucher_type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Account Voucher Credited For ".implode(',',array_column($value->journals->toArray(),'item_name') ) ."- ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "credit";
                        }

                        $report_array[$i]['section'] = "account-voucher";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/account-voucher/add-edit-account-voucher/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                        
                    }
                }
            }


            if($request->return_type == 'array')
                return $report_array;
            else
                return response(['data' => $report_array,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        } 
    }

    public function cashbook_report_pdf(Request $request)
    {
        $request->return_type = 'array';

        $return_array  = $this->cashbook_report($request);
        $print_data = array();

        if($invoice_account =InvoiceAccount::find(1))
        {

            //Ledger Item Name
            $print_data['[ITEM_NAME]'] = $request->item_name;
            //Set Account Data Variables
            $print_data = array_merge($print_data,$this->set_account_data($invoice_account,'invoice'));  

            if(count($return_array) > 0)
            {
                $print_data_loop=array();
                $i=0;
                $item_str="";
                $total_debit = 0;
                $total_credit = 0;

                foreach ($return_array as  $value) 
                {   
                    
                    $i++;

                    $print_data_loop['[SLNO]']=$i;
                    
                    $print_data_loop['[REFERENCE]']=$value['reference'];
                    $print_data_loop['[DATE]']=Carbon::parse($value['date'])->format('d/m/Y');
                    $print_data_loop['[TYPE]']=ucfirst($value['type']);
                    $print_data_loop['[DEBIT]']=number_format(floatval($value['debit']),2);
                    $print_data_loop['[CREDIT]'] = number_format(floatval($value['credit']),2);
                    
                    preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$invoice_account->cashbook_body,$matches);

                    $item_str .= $this->loop($matches,$print_data_loop);
                        
                    $total_debit=$total_debit+floatval($value['debit']);
                    $total_credit=$total_credit+floatval($value['credit']);
                }

                if(count($matches) > 0 && isset($matches[0][0]))
                    $cashbook_body =str_replace($matches[0][0], $item_str,$invoice_account->cashbook_body);
                else
                    $cashbook_body = $invoice_account->cashbook_body;

                $print_data['[TOTAL_CREDIT]'] = number_format($total_credit,2);
                $print_data['[TOTAL_DEBIT]'] = number_format($total_debit,2);

                
                if(($total_credit - $total_debit) >= 0)
                {
                    $print_data['[CLOSING_BALANCE_DEBIT]'] = number_format(abs($total_credit - $total_debit),2);
                    $print_data['[CLOSING_BALANCE_CREDIT]'] = "";

                    $print_data['[GRAND_DEBIT]'] = number_format($total_debit + abs($total_credit - $total_debit),2);
                    $print_data['[GRAND_CREDIT]'] = number_format($total_credit,2);
                }
                if(($total_credit - $total_debit) < 0)
                {
                    $print_data['[CLOSING_BALANCE_CREDIT]'] = number_format(abs($total_credit - $total_debit),2);
                    $print_data['[CLOSING_BALANCE_DEBIT]'] = "";

                    $print_data['[GRAND_CREDIT]'] = number_format($total_credit + abs($total_credit - $total_debit),2);
                    $print_data['[GRAND_DEBIT]'] = number_format($total_debit,2);
                }     

                $from = Carbon::parse($request->start_date);
                $to = Carbon::parse($request->end_date);

                $print_data['[START_DATE]'] = $from->format('d/m/Y');
                $print_data['[END_DATE]'] = $to->format('d/m/Y');

                $cashbook_body = $this->replace_variable($cashbook_body,$print_data,$invoice_account->cashbook_body);

                //Save The Final HTML to PDF
                $path = storage_path()."/report/cashbook";
                if (!file_exists($path)) {
                    $this->createPath($path);
                }
                $fileName =  $path."/"."Cashbook-Report-".time().".pdf";

                PDF::loadHTML($cashbook_body)->setPaper('a4', 'portrait')->setWarnings(false)->save($fileName);

                return  response()->file($fileName);

            }
        }
    }
    public function bank_reconciliation(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date'=>['required'],
            'end_date'=>['required']

        ]);
        
        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            /*Calculation of Amount Before Start Date*/

            $payment_credit = Payment::where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->sum('amount'); //Credit

            $purchase_payment_debit = PurchasePayment::where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->sum('amount'); // Debit

            $contra_entry_credit = CashbookTransaction::where('identifier','bank')->where('main_id',$request->bank_account_id)->where('date','<',$request->start_date)->where('type','credit')->sum('amount'); // Credit

            $contra_entry_debit = CashbookTransaction::where('identifier','bank')->where('main_id',$request->bank_account_id)->where('type','debit')->where('date','<',$request->start_date)->sum('amount'); // Debit


            $advance_credit = PurchaseAdvancePayment::where('payment_type','bank')->where('auto_entry',0)->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->where('type','credit')->sum('amount'); //Credit

            $advance_debit = PurchaseAdvancePayment::where('payment_type','bank')->where('auto_entry',0)->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->where('type','debit')->sum('amount'); //Debit

            $voucher_debit = JournalMain::where('type','voucher')->where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->where('voucher_type','debit')->sum('amount'); //Debit

            $voucher_credit = JournalMain::where('type','voucher')->where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->where('voucher_type','credit')->sum('amount'); //Credit

            /*Bank Transactions Between Start Date and End Date */

            $payments = Payment::where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Credit

            $purchase_payments = PurchasePayment::where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->whereBetween('date',[$request->start_date,$request->end_date])->get(); // Debit


            $contra_entry = CashbookTransaction::with('main','bank_account')->where('identifier','bank')->where('main_id',$request->bank_account_id)->whereBetween('date',[$request->start_date,$request->end_date])->get();


            $advances = PurchaseAdvancePayment::where('payment_type','bank')->where('auto_entry',0)->where('bank_account_id',$request->bank_account_id)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            $vouchers =  JournalMain::where('type','voucher')->where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            $from = Carbon::parse($request->start_date);
            $to = Carbon::parse($request->end_date);

            $opening = OpeningBalance::where('main_id',$request->bank_account_id)->where('identifier','bank')->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();

            $i = 0;
            $report_array = array();

            $from = Carbon::parse($request->start_date);
            $to = Carbon::parse($request->end_date);

            $opening_balance = (( floatval($payment_credit) + floatval($advance_credit) + floatval($contra_entry_credit) + floatval($voucher_credit) ) - (floatval($purchase_payment_debit) + floatval($advance_debit) + floatval($contra_entry_debit) + floatval($voucher_debit)));

            if(isset($opening) && !empty($opening))
            {
                $opening_balance = $opening->type == 'debit' ? ((0 - $opening->amount) + $opening_balance) : ($opening->amount + $opening_balance);
            }

            $report_array = array();
            $report_array[$i]['date'] = $from->format('Y-m-d');
            $report_array[$i]['reference'] = "Opening Balance On ".$from->format('d/m/Y');


            if($opening_balance >= 0)
            {
                $report_array[$i]['debit'] = "";
                $report_array[$i]['is_realization'] = 1;
                $report_array[$i]['credit'] = abs($opening_balance);
                $report_array[$i]['type'] = "credit";
            }
            elseif($opening_balance < 0)
            {
                $report_array[$i]['debit'] = abs($opening_balance);
                $report_array[$i]['credit'] = "";
                $report_array[$i]['is_realization'] = 0;
                $report_array[$i]['type'] = "debit";
            }
            $i++;
            $edit_access =  $this->checkReportEditAccess();
           
            $total_debit = 0;
            $total_credit = 0;


            for($d = $from; $d->lte($to); $d->addDay()) 
            {

                foreach ($payments as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                       
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $report_array[$i]['reference'] = "Invoice Payment Received From ".$value->customer->full_name." Ref.-".$value->formatted_number." For Invoice Reference (".implode(',',array_column($value->invoices->toArray(),'formatted_number')).")";
                        $report_array[$i]['against'] = array_column($value->invoices->toArray(),'formatted_number');
                        $report_array[$i]['description'] = $value->remarks;
                        $report_array[$i]['credit'] = $value->amount;
                        $report_array[$i]['debit'] = "";
                        $report_array[$i]['type'] = "credit";
                        $report_array[$i]['amount'] = $value->amount;
                        $report_array[$i]['is_realization'] = $value->is_realization;
                        $report_array[$i]['section'] = "payment";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/payment/add-edit-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                       
                        $total_credit = $total_credit + $value->amount;
                    }
                }

                foreach ($purchase_payments as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $type = $value->type == "vendor" ? "Purchase":"Salary";
                        
                        if($value->type == 'vendor')
                            $report_array[$i]['reference'] = $type." Payment Given To ".$value->customer->full_name;
                        else
                            $report_array[$i]['reference'] = $type." Payment Given To ".$value->customer->full_name;

                        $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                        $report_array[$i]['description'] = $value->remarks;
                        $report_array[$i]['debit'] = $value->amount;
                        $report_array[$i]['credit'] = "";
                        $report_array[$i]['type'] = "debit";
                        
                        $report_array[$i]['amount'] = $value->amount;
                        $report_array[$i]['is_realization'] = $value->is_realization;
                        $report_array[$i]['section'] = "purchase_payment";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                        
                        
                    }

                    $total_debit = $total_debit + $value->amount;
                }

                foreach ($contra_entry as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        
                        if(!empty($value->bank_account))
                            $bank_or_cash = $value->bank_account->display_name;
                        else
                            $bank_or_cash = "Cash";
                        if($value->type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Amount Transfered To ". $bank_or_cash." On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "debit";
                        }
                        elseif($value->type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Amount Received From ". $bank_or_cash." - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "credit";
                        }
                    
                    

                        $report_array[$i]['amount'] = $value->amount;
                        $report_array[$i]['is_realization'] = $value->is_realization;
                        $report_array[$i]['section'] = "contra-entry";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/contra-entry/add-edit-contra-entry/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                       

                        if($value->type == 'debit')
                            $total_debit = $total_debit + $value->amount;
                        elseif($value->type == 'credit') 
                            $total_credit = $total_credit + $value->amount;
                        
                    }
                }

                foreach ($advances as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                       
                        if($value->type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Amount Given To ".$value->item_name." On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "debit";
                        }
                        elseif($value->type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Amount Received From To ".$value->item_name." On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "credit";
                        }

                        $report_array[$i]['amount'] = $value->amount;
                        $report_array[$i]['is_realization'] = $value->is_realization;
                        $report_array[$i]['section'] = "purchase_advance";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                       
                        
                        if($value->type == 'debit')
                            $total_debit = $total_debit + $value->amount;
                        elseif($value->type == 'credit') 
                            $total_credit = $total_credit + $value->amount;
                        
                    }
                }

                foreach ($vouchers as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                       
                        if($value->voucher_type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Account Voucher Debited For ".implode(',',array_column($value->journals->toArray(),'item_name') ) ." - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "debit";
                        }
                        elseif($value->voucher_type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Account Voucher Credited For ".implode(',',array_column($value->journals->toArray(),'item_name') ) ." - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "credit";
                        }
                        $report_array[$i]['is_realization'] = $value->is_realization;
                        $report_array[$i]['section'] = "account-voucher";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/account-voucher/add-edit-account-voucher/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                       
                        
                        if($value->voucher_type == 'debit')
                            $total_debit = $total_debit + $value->amount;
                        elseif($value->voucher_type == 'credit') 
                            $total_credit = $total_credit + $value->amount;
                        
                    }
                }
            }

            if($request->return_type == 'array')
                return ['data'=>$report_array,'total_balance'=>$total_credit - $total_debit];
            else
                return response(['data' => $report_array,'total_balance'=>$total_credit - $total_debit,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        }
        
    }
    public function bank_reconciliation_pdf(Request $request)
    {
        $request->return_type = 'array';

        $data = $this->bank_reconciliation($request);
        $return_array  =  $data['data'];
        $print_data = array();
       
        if($invoice_account =InvoiceAccount::find(1))
        {

            //Ledger Item Name
            $print_data['[BANK_NAME]'] = $request->bank_name;
            //Set Account Data Variables
            $print_data = array_merge($print_data,$this->set_account_data($invoice_account,'invoice'));  

            if(count($return_array) > 0)
            {
                $print_data_loop=array();
                $i=0;
                $item_str="";
                $total_debit = 0;
                $total_credit = 0;
                $total_realized_debit = 0;
                $total_realized_credit = 0;
                $total_company_credit = 0;
                $total_company_debit = 0;

                foreach ($return_array as  $value) 
                {   
                    
                    $i++;

                    $print_data_loop['[SLNO]']=$i;
                    
                    $print_data_loop['[REFERENCE]']=$value['reference'];
                    $print_data_loop['[DATE]']=Carbon::parse($value['date'])->format('d/m/Y');
                    $print_data_loop['[TYPE]']=ucfirst($value['type']);
                    $print_data_loop['[DEBIT]']=number_format(floatval($value['debit']),2);
                    $print_data_loop['[CREDIT]'] = number_format(floatval($value['credit']),2);
                    
                    preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$invoice_account->bank_reconciliation_body,$matches);

                    $item_str .= $this->loop($matches,$print_data_loop);
                    

                    $total_company_debit=$total_company_debit+floatval($value['debit']);
                    $total_company_credit=$total_company_credit+floatval($value['credit']);

                    if($value['is_realization'] == 0)
                    {
                        $total_debit=$total_debit+floatval($value['debit']);
                        $total_credit=$total_credit+floatval($value['credit']);
                    }
                    else if($value['is_realization'] == 1)
                    {
                        $total_realized_debit=$total_realized_debit+floatval($value['debit']);
                        $total_realized_credit=$total_realized_credit+floatval($value['credit']);
                    }
                   
                }

                if(count($matches) > 0 && isset($matches[0][0]))
                    $bank_reconciliation_body =str_replace($matches[0][0], $item_str,$invoice_account->bank_reconciliation_body);
                else
                    $bank_reconciliation_body = $invoice_account->bank_reconciliation_body;

                $print_data['[TOTAL_CREDIT]'] = number_format($total_credit,2);
                $print_data['[TOTAL_DEBIT]'] = number_format($total_debit,2);

                if($total_company_credit - $total_company_debit > 0)
                {
                    $print_data['[CLOSING_BALANCE_CREDIT]'] = number_format(abs( $total_company_credit - $total_company_debit),2);
                    $print_data['[CLOSING_BALANCE_DEBIT]'] = "";
                }  
                if($total_company_credit - $total_company_debit < 0)
                {
                    $print_data['[CLOSING_BALANCE_DEBIT]'] = number_format(abs($total_company_credit - $total_company_debit),2);
                    $print_data['[CLOSING_BALANCE_CREDIT]'] = "";
                }
                
                $bank_balance =  $total_realized_credit -  $total_realized_debit;

                if( $bank_balance >= 0)
                {
                    $print_data['[GRAND_CREDIT]'] = number_format(abs($bank_balance),2);
                    $print_data['[GRAND_DEBIT]'] = "";
                }
                if($bank_balance < 0)
                {
                    $print_data['[GRAND_CREDIT]'] = "";
                    $print_data['[GRAND_DEBIT]'] =  number_format(abs($bank_balance),2);
                }

                $from = Carbon::parse($request->start_date);
                $to = Carbon::parse($request->end_date);

                $print_data['[START_DATE]'] = $from->format('d/m/Y');
                $print_data['[END_DATE]'] = $to->format('d/m/Y');

                $bank_reconciliation_body = $this->replace_variable($bank_reconciliation_body,$print_data,$invoice_account->bank_reconciliation_body);

                //Save The Final HTML to PDF
                $path = storage_path()."/report/bank-reconciliation";
                if (!file_exists($path)) {
                    $this->createPath($path);
                }
                $fileName =  $path."/".$request->bank_name."-Bank-Reconciliation-Report-".time().".pdf";

                PDF::loadHTML($bank_reconciliation_body)->setPaper('a4', 'portrait')->setWarnings(false)->save($fileName);

                return  response()->file($fileName);

            }
        }
    }
    public function trial_balance_old(Request $request)
    {
       
        $validator = Validator::make($request->all(), [

            'start_date'=>['required'],
            'end_date'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
           $report_array = array();
           
           $fiscal_year = FiscalYear::whereRaw('((start_date between ? and ? ) or (end_date between ? and ? ))',[$request->start_date,$request->end_date,$request->start_date,$request->end_date])->first();
           
           /* Current Liablities */
           $purchases = Purchase::with('customer','fiscal_year')->whereBetween('date',[$request->start_date,$request->end_date])->get();
           $i = 0; 
           foreach($purchases as $value)
           {
                if($value->after_total > 0 || $value->before_total)
                {
                    $report_array[$i]['reference'] = "Sundry Creditors";
                    $report_array[$i]['item'] = "Purchase From ".$value->customer->full_name." Dated -".$value->date;
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = !empty($value->after_total) ? floatval($value->after_total): floatval($value->before_total);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $value->date;
                    $report_array[$i]['fiscal_year'] = $value->fiscal_year->name;
                    $i++;
                }
                if(($value->cgst + $value->sgst) > 0 || $value->igst > 0)
                {
                    $report_array[$i]['reference'] = "GST Input & Output";
                    $report_array[$i]['item'] = "Purchase GST Input Invoice No".$value->formatted_number." Dated -".$value->date;
                    $report_array[$i]['debit'] =  $value->igst > 0 ? floatval($value->igst) : floatval($value->cgst + $value->sgst);
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $value->date;
                    $report_array[$i]['fiscal_year'] = $value->fiscal_year->name;
                    $i++;
                }
                
           }

           $creditors = Customer::where('category','Creditor')->where('status',1)->get();

           foreach($creditors as $creditor){
           
                $creditors_openings = OpeningBalance::where('identifier','customer')->where('main_id',$creditor->id)->whereBetween('date',[$request->start_date,$request->end_date])->get();

                foreach($creditors_openings as $opening)
                {
                    $type = "Opening Balance";
                    if($opening->type == 'debit')
                    {
                        $report_array[$i]['reference'] = 'Sundry Creditors';
                        $report_array[$i]['item'] = $type."-". $opening->date;
                        $report_array[$i]['debit'] = floatval($opening->amount );
                        $report_array[$i]['credit'] = floatval(0);
                        $report_array[$i]['type'] = "A. Current Liablities";
                        $report_array[$i]['date'] = $opening->date;
                        $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                        $i++;
                    }
                    elseif($opening->type == 'credit')
                    {
                        $report_array[$i]['reference'] ='Sundry Creditors';
                        $report_array[$i]['item'] = $type."-".$opening->date;
                        $report_array[$i]['debit'] = floatval(0);
                        $report_array[$i]['credit'] = floatval($opening->amount);
                        $report_array[$i]['type'] = "A. Current Liablities";
                        $report_array[$i]['date'] = $opening->date;
                        $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                        $i++;
                    }
                }
                $journal_sum = Journal::whereHas('journal_main', function($q) use ($request){
                    $q->where('type','journal');
                })->with('journal_main')->where('identifier','customer')->where('main_id',$creditor->id)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

                $voucher_sum = Journal::whereHas('journal_main', function($q) use ($request){
                    $q->where('type','voucher');
                })->with('journal_main')->where('identifier','customer')->where('main_id',$creditor->id)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

                if($journal_sum >  $voucher_sum)
                {
                    $journals = Journal::whereHas('journal_main', function($q) use ($request){
                        $q->where('type','journal');
                    })->with('journal_main')->where('identifier','customer')->where('main_id',$creditor->id)->whereBetween('date',[$request->start_date,$request->end_date])->get();
                }
                else
                {
                    $journals = Journal::whereHas('journal_main', function($q) use ($request){
                        $q->where('type','voucher');
                    })->with('journal_main')->where('identifier','customer')->where('main_id',$creditor->id)->whereBetween('date',[$request->start_date,$request->end_date])->get(); 
                }
            

                foreach($journals as $journal)
                {
                    $type = $journal->journal_main->type == 'journal'?"Journal":"Account Voucher";
                    if($journal->type == 'debit')
                    {
                        $report_array[$i]['reference'] = 'Sundry Creditors';
                        $report_array[$i]['item'] = $type."-". $journal->date;
                        $report_array[$i]['debit'] = floatval($journal->after_total);
                        $report_array[$i]['credit'] = floatval(0);
                        $report_array[$i]['type'] = "A. Current Liablities";
                        $report_array[$i]['date'] = $journal->date;
                        $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                        $i++;
                    }
                    elseif($journal->type == 'credit')
                    {
                        $report_array[$i]['reference'] = 'Sundry Creditors';
                        $report_array[$i]['item'] = $type."-".$journal->date;
                        $report_array[$i]['debit'] = floatval(0);
                        $report_array[$i]['credit'] = floatval($journal->after_total);
                        $report_array[$i]['type'] = "A. Current Liablities";
                        $report_array[$i]['date'] = $journal->date;
                        $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                        $i++;
                    }
                }
           }

            $liablity_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',9);
            })->where('status',1)->get();

            if(count($liablity_items) > 0)
            {
                foreach($liablity_items as $item)
                {
                    $liablity_items_openings = OpeningBalance::where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->get();

                    foreach($liablity_items_openings as $opening)
                    {
                        $type = "Opening Balance";
                        if($opening->type == 'debit')
                        {
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] = $type."-". $opening->date;
                            $report_array[$i]['debit'] = floatval($opening->amount );
                            $report_array[$i]['credit'] = floatval(0);
                            $report_array[$i]['type'] = "A. Current Liablities";
                            $report_array[$i]['date'] = $opening->date;
                            $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                            $i++;
                        }
                        elseif($opening->type == 'credit')
                        {
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] = $type."-".$opening->date;
                            $report_array[$i]['debit'] = floatval(0);
                            $report_array[$i]['credit'] = floatval($opening->amount);
                            $report_array[$i]['type'] = "A. Current Liablities";
                            $report_array[$i]['date'] = $opening->date;
                            $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                            $i++;
                        }
                    }
                    $journal_sum = Journal::whereHas('journal_main', function($q) use ($request){
                        $q->where('type','journal');
                    })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

                    $voucher_sum = Journal::whereHas('journal_main', function($q) use ($request){
                        $q->where('type','voucher');
                    })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

                    if($journal_sum >  $voucher_sum)
                    {
                        $journals = Journal::whereHas('journal_main', function($q) use ($request){
                            $q->where('type','journal');
                        })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->get();
                    }
                    else
                    {
                        $journals = Journal::whereHas('journal_main', function($q) use ($request){
                            $q->where('type','voucher');
                        })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->get(); 
                    }
                   

                    foreach($journals as $journal)
                    {
                        $type = $journal->journal_main->type == 'journal'?"Journal":"Account Voucher";
                        if($journal->type == 'debit')
                        {
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] = $type."-". $journal->date;
                            $report_array[$i]['debit'] = floatval($journal->after_total);
                            $report_array[$i]['credit'] = floatval(0);
                            $report_array[$i]['type'] = "A. Current Liablities";
                            $report_array[$i]['date'] = $journal->date;
                            $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                            $i++;
                        }
                        elseif($journal->type == 'credit')
                        {
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] = $type."-".$journal->date;
                            $report_array[$i]['debit'] = floatval(0);
                            $report_array[$i]['credit'] = floatval($journal->after_total);
                            $report_array[$i]['type'] = "A. Current Liablities";
                            $report_array[$i]['date'] = $journal->date;
                            $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                            $i++;
                        }
                    }
                }
            }

            $invoices = Invoice::with('fiscal_year','customer')->whereBetween('date',[$request->start_date,$request->end_date])->get();
            foreach ($invoices as $key => $value) 
            {
                if($value->tds > 0)
                {
                   
                        $report_array[$i]['date'] = $value->date;
                        $report_array[$i]['item'] = "Invoice TDS Payable Invoice No ".$value->formatted_number." Dated -".$value->date;
                        $report_array[$i]['credit'] = floatval($value->tds);
                        $report_array[$i]['debit'] = floatval(0);
                        $report_array[$i]['type'] = "A. Current Liablities";
                        $report_array[$i]['fiscal_year'] = $value->fiscal_year->name;
                        $report_array[$i]['reference'] = "TDS Payable";
                     
                        $i++;
                   
                }
            }    
            foreach ($invoices as $key => $value) 
            {     
                if($value->tcs > 0)
                {
                   
                        $report_array[$i]['date'] = $value->date;
                        $report_array[$i]['item'] = "Invoice TCS Payable Invoice No ".$value->formatted_number." Dated -".$value->date;
                        $report_array[$i]['credit'] = floatval($value->tcs);
                        $report_array[$i]['debit'] = floatval(0);
                        $report_array[$i]['type'] = "A. Current Liablities";
                        $report_array[$i]['fiscal_year'] = $value->fiscal_year->name;
                        $report_array[$i]['reference'] = "TCS Payable";
                     
                        $i++;
                   
                }
            }
            foreach ($invoices as $key => $value) 
            {    
                if(($value->cgst + $value->sgst) > 0 || $value->igst > 0)
                {
                    $report_array[$i]['reference'] = "GST Input & Output";
                    $report_array[$i]['item'] = "Invoice GST Output Invoice No ".$value->formatted_number." Dated -".$value->date;
                    $report_array[$i]['debit'] =  floatval(0);
                    $report_array[$i]['credit'] = $value->igst > 0 ? floatval($value->igst) : floatval($value->cgst + $value->sgst);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $value->date;
                    $report_array[$i]['fiscal_year'] = $value->fiscal_year->name;
                    $i++;
                }  
            }

            //TCS PAY
            $tcs_pay_openings = OpeningBalance::where('identifier','tcs')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            foreach($tcs_pay_openings as $opening)
            {
                $type = "Opening Balance";
                if($opening->type == 'debit')
                {
                    $report_array[$i]['reference'] = 'TCS Payable';
                    $report_array[$i]['item'] = $type."-". $opening->date;
                    $report_array[$i]['debit'] = floatval($opening->amount );
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $opening->date;
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
                elseif($opening->type == 'credit')
                {
                    $report_array[$i]['reference'] ='TCS Payable';
                    $report_array[$i]['item'] = $type."-".$opening->date;
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval($opening->amount);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $opening->date;
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
            }
            $journal_sum = Journal::whereHas('journal_main', function($q) use ($request){
                $q->where('type','journal');
            })->with('journal_main')->where('identifier','tcs')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

            $voucher_sum = Journal::whereHas('journal_main', function($q) use ($request){
                $q->where('type','voucher');
            })->with('journal_main')->where('identifier','tcs')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

            if($journal_sum >  $voucher_sum)
            {
                $journals = Journal::whereHas('journal_main', function($q) use ($request){
                    $q->where('type','journal');
                })->with('journal_main')->where('identifier','tcs')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->get();
            }
            else
            {
                $journals = Journal::whereHas('journal_main', function($q) use ($request){
                    $q->where('type','voucher');
                })->with('journal_main')->where('identifier','tcs')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->get(); 
            }
        

            foreach($journals as $journal)
            {
                $type = $journal->journal_main->type == 'journal'?"Journal":"Account Voucher";
                if($journal->type == 'debit')
                {
                    $report_array[$i]['reference'] = 'TCS Payable';
                    $report_array[$i]['item'] = $type."-". $journal->date;
                    $report_array[$i]['debit'] = floatval($journal->after_total);
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $journal->date;
                    $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                    $i++;
                }
                elseif($journal->type == 'credit')
                {
                    $report_array[$i]['reference'] = 'TCS Payable';
                    $report_array[$i]['item'] = $type."-".$journal->date;
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval($journal->after_total);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $journal->date;
                    $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                    $i++;
                }
            }

            //TDS PAY

            $tds_pay_openings = OpeningBalance::where('identifier','tds')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            foreach($tds_pay_openings as $opening)
            {
                $type = "Opening Balance";
                if($opening->type == 'debit')
                {
                    $report_array[$i]['reference'] = 'TDS Payable';
                    $report_array[$i]['item'] = $type."-". $opening->date;
                    $report_array[$i]['debit'] = floatval($opening->amount );
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $opening->date;
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
                elseif($opening->type == 'credit')
                {
                    $report_array[$i]['reference'] ='TDS Payable';
                    $report_array[$i]['item'] = $type."-".$opening->date;
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval($opening->amount);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $opening->date;
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
            }
            $journal_sum = Journal::whereHas('journal_main', function($q) use ($request){
                $q->where('type','journal');
            })->with('journal_main')->where('identifier','tds')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

            $voucher_sum = Journal::whereHas('journal_main', function($q) use ($request){
                $q->where('type','voucher');
            })->with('journal_main')->where('identifier','tds')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

            if($journal_sum >  $voucher_sum)
            {
                $journals = Journal::whereHas('journal_main', function($q) use ($request){
                    $q->where('type','journal');
                })->with('journal_main')->where('identifier','tds')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->get();
            }
            else
            {
                $journals = Journal::whereHas('journal_main', function($q) use ($request){
                    $q->where('type','voucher');
                })->with('journal_main')->where('identifier','tds')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->get(); 
            }
        

            foreach($journals as $journal)
            {
                $type = $journal->journal_main->type == 'journal'?"Journal":"Account Voucher";
                if($journal->type == 'debit')
                {
                    $report_array[$i]['reference'] = 'TDS Payable';
                    $report_array[$i]['item'] = $type."-". $journal->date;
                    $report_array[$i]['debit'] = floatval($journal->after_total);
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $journal->date;
                    $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                    $i++;
                }
                elseif($journal->type == 'credit')
                {
                    $report_array[$i]['reference'] = 'TDS Payable';
                    $report_array[$i]['item'] = $type."-".$journal->date;
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval($journal->after_total);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $journal->date;
                    $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                    $i++;
                }
            }

            //GST PAY

            $gst_pay_openings = OpeningBalance::where('identifier','gst')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            foreach($gst_pay_openings as $opening)
            {
                $type = "Opening Balance";
                if($opening->type == 'debit')
                {
                    $report_array[$i]['reference'] = 'GST Payable';
                    $report_array[$i]['item'] = $type."-". $opening->date;
                    $report_array[$i]['debit'] = floatval($opening->amount );
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $opening->date;
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
                elseif($opening->type == 'credit')
                {
                    $report_array[$i]['reference'] ='GST Payable';
                    $report_array[$i]['item'] = $type."-".$opening->date;
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval($opening->amount);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $opening->date;
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
            }
            $journal_sum = Journal::whereHas('journal_main', function($q) use ($request){
                $q->where('type','journal');
            })->with('journal_main')->where('identifier','gst')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

            $voucher_sum = Journal::whereHas('journal_main', function($q) use ($request){
                $q->where('type','voucher');
            })->with('journal_main')->where('identifier','gst')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

            if($journal_sum >  $voucher_sum)
            {
                $journals = Journal::whereHas('journal_main', function($q) use ($request){
                    $q->where('type','journal');
                })->with('journal_main')->where('identifier','gst')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->get();
            }
            else
            {
                $journals = Journal::whereHas('journal_main', function($q) use ($request){
                    $q->where('type','voucher');
                })->with('journal_main')->where('identifier','gst')->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->get(); 
            }
        

            foreach($journals as $journal)
            {
                $type = $journal->journal_main->type == 'journal'?"Journal":"Account Voucher";
                if($journal->type == 'debit')
                {
                    $report_array[$i]['reference'] = 'GST Payable';
                    $report_array[$i]['item'] = $type."-". $journal->date;
                    $report_array[$i]['debit'] = floatval($journal->after_total);
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $journal->date;
                    $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                    $i++;
                }
                elseif($journal->type == 'credit')
                {
                    $report_array[$i]['reference'] = 'GST Payable';
                    $report_array[$i]['item'] = $type."-".$journal->date;
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval($journal->after_total);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['date'] = $journal->date;
                    $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                    $i++;
                }
            }

            // $tds_tcs_journals = Journal::whereHas('journal_main', function($q) use ($request){
            //     $q->where('type','voucher');
            // })->with('fiscal_year','journal_main')->whereIn('identifier',['tds','tcs'])->where('main_id',1)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            // foreach($tds_tcs_journals as $value)
            // {
            //     $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

            //     if($value->type == 'debit')
            //     {
            //         $report_array[$i]['reference'] = $value->item_name;
            //         $report_array[$i]['item'] = $type."-".$value->date;
            //         $report_array[$i]['debit'] = floatval($value->after_total);
            //         $report_array[$i]['credit'] = floatval(0);
            //         $report_array[$i]['type'] = "A. Current Liablities";
            //         $report_array[$i]['date'] = $value->date;
            //         $report_array[$i]['fiscal_year'] = $value->fiscal_year->name;
            //         $i++;
            //     }
            //     elseif($value->type == 'credit')
            //     {
            //         $report_array[$i]['reference'] = $value->item_name;
            //         $report_array[$i]['item'] = $type."-".$value->date;
            //         $report_array[$i]['debit'] = floatval(0);
            //         $report_array[$i]['credit'] = floatval($value->after_total);
            //         $report_array[$i]['type'] = "A. Current Liablities";
            //         $report_array[$i]['date'] = $value->date;
            //         $report_array[$i]['fiscal_year'] = $value->fiscal_year->name;
            //         $i++;
            //     }
            // }

            /*Current Asset*/
            /*foreach ($invoices as $key => $value) 
            {
                if($value->before_total > 0)
                {
                
                    $report_array[$i]['date'] = $value->date;
                    $report_array[$i]['reference'] = "Sudry Debtors";
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['debit'] = floatval($value->before_total);
                    $report_array[$i]['type'] = "B. Current Assets";
                    $report_array[$i]['fiscal_year'] = $value->fiscal_year->name;
                    $report_array[$i]['item'] = "Invoice No ".$value->formatted_number." For ".$value->customer->full_name." Dated - ".$value->date;
                    
                    $i++;
                
                }
            }*/   
            $request->return_type = 'array';

            $bank_accounts = BankAccount::where('status',1)->get();

            foreach($bank_accounts as $bank)
            {
               

                $total_bankbook_credit = 0;
                $total_bankbook_debit = 0;

                $request->merge(['bank_account_id' => $bank->id]);
                $bank_book_data = $this->bankbook_report($request);
               
                foreach ($bank_book_data as $key => $value) {
                    if($value['type'] == 'credit')
                        $total_bankbook_credit = $total_bankbook_credit + $value['credit'];
                    elseif($value['type'] == 'debit')
                        $total_bankbook_debit = $total_bankbook_debit + $value['debit'];    
                }
                if(($total_bankbook_credit - $total_bankbook_debit) >= 0)
                {
                    $report_array[$i]['reference'] = "Bank Accounts";
                    $report_array[$i]['item'] = $bank->display_name;
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['debit'] = floatval($total_bankbook_credit - $total_bankbook_debit);
                    $report_array[$i]['type'] = "B. Current Assets";
                    $report_array[$i]['date'] = "";
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
                else
                {
                    $report_array[$i]['reference'] = "Bank Accounts";
                    $report_array[$i]['item'] = $bank->display_name;
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval($total_bankbook_credit - $total_bankbook_debit);
                    $report_array[$i]['type'] = "B. Current Assets";
                    $report_array[$i]['date'] = "";
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }

            }
            
            $cash_book_data = $this->cashbook_report($request);

            $total_cashbook_credit = 0;
            $total_cashbook_debit = 0;

            foreach ($cash_book_data as $key => $value) {
                if($value['type'] == 'credit')
                    $total_cashbook_credit = $total_cashbook_credit + $value['credit'];
                elseif($value['type'] == 'debit')
                    $total_cashbook_debit = $total_cashbook_debit + $value['debit'];    
            }
            if(($total_cashbook_credit - $total_cashbook_debit) >= 0)
            {
                $report_array[$i]['reference'] = "Cash-In-Hand";
                $report_array[$i]['item'] = "Cash-In-Hand";
                $report_array[$i]['credit'] = 0;
                $report_array[$i]['debit'] = floatval($total_cashbook_credit - $total_cashbook_debit);
                $report_array[$i]['type'] = "B. Current Assets";
                $report_array[$i]['date'] = "";
                $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                $i++;
            }
            else
            {
                $report_array[$i]['reference'] = "Cash-In-Hand";
                $report_array[$i]['item'] = "Cash-In-Hand";
                $report_array[$i]['debit'] = 0;
                $report_array[$i]['credit'] = floatval(abs($total_cashbook_credit - $total_cashbook_debit));
                $report_array[$i]['type'] = "B. Current Assets";
                $report_array[$i]['date'] = "";
                $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                $i++;
            }
           
            /*Sales Account*/
            $sales_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',19);
            })->where('status',1)->get(); 
            
            if(count($sales_items) > 0)
            {
                foreach($sales_items as $item)
                {
                    $sales_invoices = Invoice::with('fiscal_year','customer')->whereHas('items', function($q) use ($item){
                        $q->where('items.id',$item->id);
                    })->whereBetween('date',[$request->start_date,$request->end_date])->get();

                    foreach($sales_invoices as $invoice)
                    {
                        $report_array[$i]['reference'] = $item->name."-".$item->hsn_sac_code;
                        $report_array[$i]['item'] = "Invoice No ".$invoice->formatted_number." For ".$invoice->customer->full_name." Dated-".$invoice->date;
                        $report_array[$i]['debit'] = floatval(0);
                        $report_array[$i]['credit'] = floatval($invoice->before_total);
                        $report_array[$i]['type'] = "C. Sales Accounts";
                        $report_array[$i]['date'] = $invoice->date;
                        $report_array[$i]['fiscal_year'] = $invoice->fiscal_year->name;
                        $i++;
                    }

                }
            }

            /*Indirect Income*/
            $indirect_income_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',20);
            })->where('status',1)->get();

            if(count($indirect_income_items) > 0)
            {
                foreach($indirect_income_items as $item)
                {
                    $indirect_income_items_openings = OpeningBalance::where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->get();

                    foreach($indirect_income_items_openings as $opening)
                    {
                        $type = "Opening Balance";
                        if($opening->type == 'debit')
                        {
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] = $type."-". $opening->date;
                            $report_array[$i]['debit'] = floatval($opening->amount );
                            $report_array[$i]['credit'] = floatval(0);
                            $report_array[$i]['type'] = "D. Indirect Income";
                            $report_array[$i]['date'] = $opening->date;
                            $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                            $i++;
                        }
                        elseif($opening->type == 'credit')
                        {
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] = $type."-".$opening->date;
                            $report_array[$i]['debit'] = floatval(0);
                            $report_array[$i]['credit'] = floatval($opening->amount);
                            $report_array[$i]['type'] = "D. Indirect Income";
                            $report_array[$i]['date'] = $opening->date;
                            $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                            $i++;
                        }
                    }
                    $journal_sum = Journal::whereHas('journal_main', function($q) use ($request){
                        $q->where('type','journal');
                    })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

                    $voucher_sum = Journal::whereHas('journal_main', function($q) use ($request){
                        $q->where('type','voucher');
                    })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

                    if($journal_sum >  $voucher_sum)
                    {
                        $journals = Journal::whereHas('journal_main', function($q) use ($request){
                            $q->where('type','journal');
                        })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->get();
                    }
                    else
                    {
                        $journals = Journal::whereHas('journal_main', function($q) use ($request){
                            $q->where('type','voucher');
                        })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->get(); 
                    }
                   

                    foreach($journals as $journal)
                    {
                        $type = $journal->journal_main->type == 'journal'?"Journal":"Account Voucher";

                        if($journal->type == 'debit')
                        {
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] = $type."-".$journal->date;
                            $report_array[$i]['debit'] = floatval($journal->after_total);
                            $report_array[$i]['credit'] = floatval(0);
                            $report_array[$i]['type'] = "D. Indirect Income";
                            $report_array[$i]['date'] = $journal->date;
                            $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                            $i++;
                        }
                        elseif($journal->type == 'credit')
                        {
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] = $type."-".$journal->date;
                            $report_array[$i]['debit'] = floatval(0);
                            $report_array[$i]['credit'] = floatval($journal->after_total);
                            $report_array[$i]['type'] = "D. Indirect Income";
                            $report_array[$i]['date'] = $journal->date;
                            $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                            $i++;
                        }
                    }
                }
            }

            /*Indirect Expense*/
            $indirect_expense_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',14);
            })->where('status',1)->get();

            if(count($indirect_expense_items) > 0)
            {
                foreach($indirect_expense_items as $item)
                {
                    $indirect_expense_items_openings = OpeningBalance::where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->get();

                    foreach($indirect_expense_items_openings as $opening)
                    {
                        $type = "Opening Balance";
                        if($opening->type == 'debit')
                        {
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] = $type."-". $opening->date;
                            $report_array[$i]['debit'] = floatval($opening->amount );
                            $report_array[$i]['credit'] = floatval(0);
                            $report_array[$i]['type'] = "E. Indirect Expense";
                            $report_array[$i]['date'] = $opening->date;
                            $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                            $i++;
                        }
                        elseif($opening->type == 'credit')
                        {
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] = $type."-".$opening->date;
                            $report_array[$i]['debit'] = floatval(0);
                            $report_array[$i]['credit'] = floatval($opening->amount);
                            $report_array[$i]['type'] = "E. Indirect Expense";
                            $report_array[$i]['date'] = $opening->date;
                            $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                            $i++;
                        }
                    }
                    $journal_sum = Journal::whereHas('journal_main', function($q) use ($request){
                        $q->where('type','journal');
                    })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

                    $voucher_sum = Journal::whereHas('journal_main', function($q) use ($request){
                        $q->where('type','voucher');
                    })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->sum('after_total');

                    if($journal_sum >  $voucher_sum)
                    {
                        $journals = Journal::whereHas('journal_main', function($q) use ($request){
                            $q->where('type','journal');
                        })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->get();
                    }
                    else
                    {
                        $journals = Journal::whereHas('journal_main', function($q) use ($request){
                            $q->where('type','voucher');
                        })->with('journal_main')->where('identifier','item')->where('main_id',$item->id)->whereBetween('date',[$request->start_date,$request->end_date])->get(); 
                    }
                   

                    foreach($journals as $journal)
                    {
                        $type = $journal->journal_main->type == 'journal'?"Journal":"Account Voucher";

                        if($journal->type == 'debit')
                        {
                            
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] =$type."-".$journal->date;
                            $report_array[$i]['debit'] = floatval($journal->after_total);
                            $report_array[$i]['credit'] = floatval(0);
                            $report_array[$i]['type'] = "E. Indirect Expense";
                            $report_array[$i]['date'] = $journal->date;
                            $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                            $i++;
                        }
                        elseif($journal->type == 'credit')
                        {
                            $report_array[$i]['reference'] = $item->name;
                            $report_array[$i]['item'] = $type."-".$journal->date;
                            $report_array[$i]['debit'] = floatval(0);
                            $report_array[$i]['credit'] = floatval($journal->after_total);
                            $report_array[$i]['type'] = "E. Indirect Expense";
                            $report_array[$i]['date'] = $journal->date;
                            $report_array[$i]['fiscal_year'] = $journal->fiscal_year->name;
                            $i++;
                        }
                    }
                }
            }
            
            /*Profit/Loss A/C*/
           
            $last_fiscal_year = FiscalYear::where('start_date',date('Y-04-01', strtotime($request->start_date . " -1 year") ))->first();
            $request->start_date = $last_fiscal_year->start_date;
            $request->end_date = $last_fiscal_year->end_date;
            $request->type = "array";

            $return_pl = $this->profit_loss_report($request);
            $report_array[$i]['reference'] = "Profit & Loss A/C";
            $report_array[$i]['item'] = "Profit & Loss A/C";
            if($return_pl['nett_profit'] == 0)
            {
                $opening_balance=OpeningBalance::where('main_id',0)->where('identifier','profit')->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();

                if(!empty($opening_balance))
                {
                    if($opening_balance->type == 'credit')
                    {
                        $report_array[$i]['debit'] = floatval(0);
                        $report_array[$i]['credit'] = floatval($opening_balance->amount);
                    }
                    elseif($opening_balance->type == 'debit')
                    {
                        $report_array[$i]['credit'] = floatval(0);
                        $report_array[$i]['debit'] = floatval($opening_balance->amount);
                    }
                }
                else
                {
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval(0);
                }
            }
            else
            {
                if($return_pl['nett_profit'] > 0)
                {
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = abs($return_pl['nett_profit']);
                }
                else
                {
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['debit'] = abs($return_pl['nett_profit']);
                }
            }
            
            
            $report_array[$i]['type'] = "F. Profit & Loss A/C";
            $report_array[$i]['date'] = "";
            $report_array[$i]['fiscal_year'] = $fiscal_year->name;
            $i++;

            return response(['data' => $report_array,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        } 
    }
    public function trial_balance(Request $request)
    {
        $validator = Validator::make($request->all(), [

            'start_date'=>['required'],
            'end_date'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            $report_array = array();
            $i = 0;
            $fiscal_year = FiscalYear::whereRaw('((? between start_date and end_date ) or ( ? between start_date and end_date ))',[$request->start_date,$request->end_date])->first();

            
             
            /*Sales Account*/
            $sales_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',19);
            })->where('status',1)->get(); 
            
            if(count($sales_items) > 0)
            {
                foreach($sales_items as $sitem)
                {
                   
                    $sales_ret = $this->gst_ledger($request,'item_'.$sitem->id);
                    
                   
                    if( $sales_ret < 0)
                    {
                        $report_array[$i]['reference'] =$sitem->name."-".$sitem->hsn_sac_code;
                        $report_array[$i]['debit'] = abs(floatval($sales_ret));
                        $report_array[$i]['credit'] = floatval(0);
                        $report_array[$i]['type'] = "C. Sales Accounts";
                        $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                        $i++;
                        
                    }
                    elseif( $sales_ret > 0)
                    {
    
                        $report_array[$i]['reference'] =$sitem->name."-".$sitem->hsn_sac_code;
                        $report_array[$i]['debit'] = floatval(0);
                        $report_array[$i]['credit'] = floatval($sales_ret);
                        $report_array[$i]['type'] = "C. Sales Accounts";
                        $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                        $i++;
                    }
                   
                }
            }

            /*GST Input & Output */

           $igst_rec = abs($this->gst_ledger($request,'igst_2'));
           $cgst_rec = abs($this->gst_ledger($request,'cgst_2'));
           $sgst_rec = abs($this->gst_ledger($request,'sgst_2'));

           $sgst_pay = abs($this->gst_ledger($request,'sgst_1'));
           $cgst_pay = abs($this->gst_ledger($request,'cgst_1'));
           $igst_pay = abs($this->gst_ledger($request,'igst_1')); 
           if(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec) < 0)
           {
               $report_array[$i]['reference'] ="GST Input & Output";
               $report_array[$i]['debit'] = abs(floatval(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec)));
               $report_array[$i]['credit'] = floatval(0);
               $report_array[$i]['type'] = "A. Current Liablities";
               $report_array[$i]['fiscal_year'] = $fiscal_year->name;
               $i++;
           }
           elseif(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec) > 0)
           {

                $report_array[$i]['reference'] ="GST Input & Output";
                $report_array[$i]['credit'] = abs(floatval(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec)));
                $report_array[$i]['debit'] = floatval(0);
                $report_array[$i]['type'] = "A. Current Liablities";
                $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                $i++;
           }

            /* TCS Payable */ 
            $tcs_payables_ret =$this->gst_ledger($request,'tcs_1');
            
            if($tcs_payables_ret < 0)
            {
                $report_array[$i]['reference'] ="TCS Payable";
                $report_array[$i]['debit'] = floatval(sprintf('%0.2f',abs(floatval($tcs_payables_ret))));
                $report_array[$i]['credit'] = floatval(0);
                $report_array[$i]['type'] = "A. Current Liablities";
                $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                $i++;
            }
            elseif($tcs_payables_ret > 0)
            {

                $report_array[$i]['reference'] ="TCS Payable";
                $report_array[$i]['debit'] = floatval(0);
                $report_array[$i]['credit'] = floatval(sprintf('%0.2f',floatval($tcs_payables_ret)));
                $report_array[$i]['type'] = "A. Current Liablities";
                $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                $i++;
            }
            /* TDS Payable */ 
            $tds_pay = $this->gst_ledger($request,'tds_1');
			if($tds_pay < 0)
            {
                $report_array[$i]['reference'] ="TDS Payable";
                $report_array[$i]['debit'] =abs(floatval($tds_pay));
                $report_array[$i]['credit'] = floatval(0);
                $report_array[$i]['type'] = "A. Current Liablities";
                $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                $i++;
            }
            elseif($tds_pay > 0)
            {

                $report_array[$i]['reference'] ="TDS Payable";
                $report_array[$i]['debit'] = floatval(0);
                $report_array[$i]['credit'] = floatval($tds_pay);
                $report_array[$i]['type'] = "A. Current Liablities";
                $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                $i++;
            }
            
             
            $sens_hotel = Customer::find(26);
            $sens_hotels_ret = $this->gst_ledger($request,'customer_'.$sens_hotel->id);
           
            if($sens_hotels_ret < 0)
            {
                $report_array[$i]['reference'] =$sens_hotel->full_name;
                $report_array[$i]['debit'] = floatval(sprintf('%0.2f',abs(floatval($sens_hotels_ret))));
                $report_array[$i]['credit'] = floatval(0);
                $report_array[$i]['type'] = "B. Current Assets";
                $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                $i++;
            }
            elseif($sens_hotels_ret > 0)
            {

                $report_array[$i]['reference'] =$sens_hotel->full_name;
                $report_array[$i]['debit'] = floatval(0);
                $report_array[$i]['credit'] = floatval(sprintf('%0.2f',floatval($sens_hotels_ret)));
                $report_array[$i]['type'] = "B. Current Assets";
                $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                $i++;
            }

            $asset_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',10);
            })->where('status',1)->get();

            foreach($asset_items as $lkey => $aitem)
            {
               
                $assets_rel = $this->gst_ledger($request,'item_'.$aitem->id);
               
               
                if($assets_rel < 0)
                {
                    $report_array[$i]['reference'] =$aitem->name;
                    $report_array[$i]['debit'] = abs(floatval($assets_rel));
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['type'] = "B. Current Assets";
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
                elseif($assets_rel > 0)
                {

                    $report_array[$i]['reference'] =$aitem->name;
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval($assets_rel);
                    $report_array[$i]['type'] = "B. Current Assets";
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }

                $liability_total_debit = 0;
                $liability_total_credit = 0;
               
            }
            
            $all_liability_items = array();
            $liablity_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',9);
            })->where('status',1)->get();

            if(count($liablity_items) > 0)
            {
                foreach($liablity_items as $key => $llitem)
                {
                    $all_liability_items[$key]['all_search'] = 'item_'.$llitem->id;
                    $all_liability_items[$key]['reference'] = $llitem->name;
                }
            } 
            
            
          //  array_push( $all_liability_items , array('all_search'=>'tcs_1','reference'=>'TDS Payable'));
            
          
           
            foreach($all_liability_items as $lkey => $litem)
            {
               
                $liabilities_ret = $this->gst_ledger($request,$litem['all_search']);
               
               
                if($liabilities_ret < 0)
                {
                    $report_array[$i]['reference'] =$litem['reference'];
                    $report_array[$i]['debit'] = abs(floatval($liabilities_ret));
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
                elseif($liabilities_ret > 0)
                {

                    $report_array[$i]['reference'] =$litem['reference'];
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval($liabilities_ret);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }

                $liability_total_debit = 0;
                $liability_total_credit = 0;
               
            }

           
             /*Indirect Expense*/
             $indirect_expense_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',14);
             })->where('status',1)->get();

            if(count($indirect_expense_items) > 0)
            {
                foreach($indirect_expense_items as $exitem)
                {
                   
                    $indirect_expenses_ret =  $this->gst_ledger($request,'item_'.$exitem->id);
                    
            
                    if($indirect_expenses_ret < 0)
                    {
                        $report_array[$i]['reference'] =$exitem->name;
                        $report_array[$i]['debit'] = abs(floatval($indirect_expenses_ret));
                        $report_array[$i]['credit'] = floatval(0);
                        $report_array[$i]['type'] = "E. Indirect Expense";
                        $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                        $i++;
                    }
                    elseif($indirect_expenses_ret > 0)
                    {
    
                        $report_array[$i]['reference'] =$exitem->name;
                        $report_array[$i]['debit'] = floatval(0);
                        $report_array[$i]['credit'] = floatval($indirect_expenses_ret);
                        $report_array[$i]['type'] = "E. Indirect Expense";
                        $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                        $i++;
                    }
                }
            }
            /*Indirect Income*/
            $indirect_income_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',20);
            })->where('status',1)->get();

            if(count($indirect_income_items) > 0)
            {
                foreach($indirect_income_items as $initem)
                {
                   
                    $indirect_incomes_ret =  $this->gst_ledger($request,'item_'.$initem->id);
                
                    if( $indirect_incomes_ret < 0)
                    {
                        $report_array[$i]['reference'] =$initem->name;
                        $report_array[$i]['debit'] =  abs(floatval( $indirect_incomes_ret));
                        $report_array[$i]['credit'] = floatval(0);
                        $report_array[$i]['type'] = "D. Indirect Income";
                        $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                        $i++;
                    }
                    elseif( $indirect_incomes_ret > 0)
                    {
    
                        $report_array[$i]['reference'] =$initem->name;
                        $report_array[$i]['debit'] = floatval(0);
                        $report_array[$i]['credit'] = floatval( $indirect_incomes_ret);
                        $report_array[$i]['type'] = "D. Indirect Income";
                        $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                        $i++;
                    }
                }
            } 
           
           
            $creditors = Customer::where('category','Creditor')->where('status',1)->get();

            foreach($creditors as $creditor){
                
                $sundry_creditors_ret = $this->gst_ledger($request,"customer_".$creditor->id);
               
                if($sundry_creditors_ret < 0)
                {
                    $report_array[$i]['reference'] ='Sundry Creditors';
                    $report_array[$i]['debit'] = abs(floatval($sundry_creditors_ret));
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
                elseif($sundry_creditors_ret > 0)
                {

                    $report_array[$i]['reference'] ='Sundry Creditors';
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval($sundry_creditors_ret);
                    $report_array[$i]['type'] = "A. Current Liablities";
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
            }

           

            $request->return_type = 'array';

            $bank_accounts = BankAccount::where('status',1)->get();

            foreach($bank_accounts as $bank)
            {
               

                $total_bankbook_credit = 0;
                $total_bankbook_debit = 0;

                $request->merge(['bank_account_id' => $bank->id]);
                $bank_book_data = $this->bankbook_report($request);
               
                foreach ($bank_book_data as $key => $value) {
                    if($value['type'] == 'credit')
                        $total_bankbook_credit = $total_bankbook_credit + floatval(sprintf('%0.2f',$value['credit']));
                    elseif($value['type'] == 'debit')
                        $total_bankbook_debit = $total_bankbook_debit + floatval(sprintf('%0.2f',$value['debit']));    
                }
                if(($total_bankbook_credit - $total_bankbook_debit) >= 0)
                {
                    $report_array[$i]['reference'] = "Bank Accounts";
                    $report_array[$i]['item'] = $bank->display_name;
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['debit'] = floatval(sprintf('%0.2f',floatval($total_bankbook_credit - $total_bankbook_debit)));
                    $report_array[$i]['type'] = "B. Current Assets";
                    $report_array[$i]['date'] = "";
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }
                else
                {
                    $report_array[$i]['reference'] = "Bank Accounts";
                    $report_array[$i]['item'] = $bank->display_name;
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval(sprintf('%0.2f',abs(floatval($total_bankbook_credit - $total_bankbook_debit))));
                    $report_array[$i]['type'] = "B. Current Assets";
                    $report_array[$i]['date'] = "";
                    $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                    $i++;
                }

            }
            
            $cash_book_data = $this->cashbook_report($request);

            $total_cashbook_credit = 0;
            $total_cashbook_debit = 0;

            foreach ($cash_book_data as $key => $value) {
                if($value['type'] == 'credit')
                    $total_cashbook_credit = $total_cashbook_credit + floatval(sprintf('%0.2f',$value['credit']));
                elseif($value['type'] == 'debit')
                    $total_cashbook_debit = $total_cashbook_debit + floatval(sprintf('%0.2f',$value['debit']));    
            }
            if(($total_cashbook_credit - $total_cashbook_debit) >= 0)
            {
                $report_array[$i]['reference'] = "Cash-In-Hand";
                $report_array[$i]['item'] = "Cash-In-Hand";
                $report_array[$i]['credit'] = 0;
                $report_array[$i]['debit'] = floatval(sprintf('%0.2f',floatval($total_cashbook_credit - $total_cashbook_debit)));
                $report_array[$i]['type'] = "B. Current Assets";
                $report_array[$i]['date'] = "";
                $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                $i++;
            }
            else
            {
                $report_array[$i]['reference'] = "Cash-In-Hand";
                $report_array[$i]['item'] = "Cash-In-Hand";
                $report_array[$i]['debit'] = 0;
                $report_array[$i]['credit'] = floatval(sprintf('%0.2f',floatval(abs($total_cashbook_credit - $total_cashbook_debit))));
                $report_array[$i]['type'] = "B. Current Assets";
                $report_array[$i]['date'] = "";
                $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                $i++;
            }

           
             /*Profit/Loss A/C*/
           
             $last_fiscal_year = FiscalYear::where('start_date',date('Y-04-01', strtotime($request->start_date . " -1 year") ))->first();
             $request->start_date = $last_fiscal_year->start_date;
             $request->end_date = $last_fiscal_year->end_date;
             $request->type = "array";
 
             $return_pl = $this->profit_loss_report($request);
             $report_array[$i]['reference'] = "Profit & Loss A/C";
             $report_array[$i]['item'] = "Profit & Loss A/C";
             if($return_pl['nett_profit'] == 0)
             {
                 $opening_balance=OpeningBalance::where('main_id',0)->where('identifier','profit')->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();
 
                 if(!empty($opening_balance))
                 {
                     if($opening_balance->type == 'credit')
                     {
                         $report_array[$i]['debit'] = floatval(0);
                         $report_array[$i]['credit'] = floatval($opening_balance->amount);
                     }
                     elseif($opening_balance->type == 'debit')
                     {
                         $report_array[$i]['credit'] = floatval(0);
                         $report_array[$i]['debit'] = floatval($opening_balance->amount);
                     }
                 }
                 else
                 {
                     $report_array[$i]['debit'] = floatval(0);
                     $report_array[$i]['credit'] = floatval(0);
                 }
                 $report_array[$i]['type'] = "F. Profit & Loss A/C";
                 $report_array[$i]['date'] = "";
                 $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                 $i++;
             }
             else
             {
                 if($return_pl['nett_profit'] > 0)
                 {
                     $report_array[$i]['debit'] = floatval(0);
                     $report_array[$i]['credit'] = abs(floatval($return_pl['nett_profit']));
                 }
                 else
                 {
                     $report_array[$i]['credit'] = floatval(0);
                     $report_array[$i]['debit'] = abs(floatval($return_pl['nett_profit']));
                 }
                 $report_array[$i]['type'] = "F. Profit & Loss A/C";
                 $report_array[$i]['date'] = "";
                 $report_array[$i]['fiscal_year'] = $fiscal_year->name;
                 $i++;
             }
             
             
             return response(['data' => $report_array,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

              
        }

    }     
    public function gst_ledger(Request $request,$type)
    {
        if(!empty($type))
        {
            $search_params = explode('_',$type);

            $request->item_id = array();
            if(count($search_params) == 2)
            {
                if($search_params[0] == 'customer')
                    $request->customer_id = $search_params[1];
                if($search_params[0] == 'item')
                    $request->item_id = array($search_params[1]);

                if($search_params[0] == 'gst')
                {
                    if($search_params[1] == 1)
                     $request->input_gst = 1;
                    elseif($search_params[1] == 2)
                     $request->output_gst = 1; 

                }
                if($search_params[0] == 'cgst')
                {
                    if($search_params[1] == 1)
                     $request->input_cgst = 1;
                    elseif($search_params[1] == 2)
                     $request->output_cgst = 1; 
                }
                if($search_params[0] == 'sgst')
                {
                    if($search_params[1] == 1)
                     $request->input_sgst = 1;
                    elseif($search_params[1] == 2)
                     $request->output_sgst = 1; 
                }
                if($search_params[0] == 'igst')
                {
                    if($search_params[1] == 1)
                     $request->input_igst = 1;
                    elseif($search_params[1] == 2)
                     $request->output_igst = 1; 
                }
                if($search_params[0] == 'tds')
                {
                    if($search_params[1] == 1)
                     $request->input_tds = 1;
                    elseif($search_params[1] == 2)
                     $request->output_tds = 1; 

                }
                if($search_params[0] == 'tcs')
                {
                    if($search_params[1] == 1)
                     $request->input_tcs = 1;
                    elseif($search_params[1] == 2)
                     $request->output_tcs = 1; 

                }
                if($search_params[0] == 'tds-section')
                {
                    $request->input_tcs = 1;
                    $request->tds_section_id = $search_params[1];
                }
                if($search_params[0] == 'tcs-section')
                {
                    $request->input_tcs = 1;
                    $request->tcs_section_id = $search_params[1];
                }           
            }
            else
                return response(['data' => array(),'success'=>false,'message' =>"Selector Error"], 200);
        }
        //For Opening Balance Checking
        $opening_balance = $this->calculate_opening_balance_gst($request,$type);

        //Date Range Data
        $invoices = Invoice::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->when($request->tds_section_id, function($query) use ($request) {
            return $query->where('tds_section_id',$request->tds_section_id);
        })->when($request->tcs_section_id, function($query) use ($request) {
            return $query->where('tcs_section_id',$request->tcs_section_id);
           
        })->whereBetween('date',[$request->start_date,$request->end_date])->get();

        
        $payments = Payment::with('bank_account')->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($invoices) {
            return $query->whereHas('invoices', function($q) use ($invoices){
                $q->whereIn('invoice_id',array_column($invoices->toArray(),'id'));
            });
        })->whereBetween('date',[$request->start_date,$request->end_date])->get();


        $debit_notes = DebitNote::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->whereBetween('date',[$request->start_date,$request->end_date])->get();

        $credit_notes = CreditNote::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->whereBetween('date',[$request->start_date,$request->end_date])->get();


        $cash_entries = CashbookTransaction::when($request->customer_id, function($query) use ($request) {
            return $query->where('main_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereRaw('1=2');
        })->where('identifier','cash')->whereBetween('date',[$request->start_date,$request->end_date])->get();


        $advances = PurchaseAdvancePayment::with('bank_account')->when(count($search_params) > 0 , function($query) use ($search_params) {

            $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
            
        })->where('auto_entry',0)->whereBetween('date',[$request->start_date,$request->end_date])->get();

        $purchases = Purchase::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Credit Asset = Credit
        
        $purchase_payments = PurchasePayment::with('bank_account')->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($purchases) {
            return $query->whereHas('purchases', function($q) use ($purchases){
                $q->whereIn('purchase_id',array_column($purchases->toArray(),'id'));
            });
        })->when($request->tds_section_id, function($query) use ($request) {

            $query->whereRaw('id in ( select purchase_payment_id from purchase_payment_rel where tds_section_id = ? and deleted_at is null)',[$request->tds_section_id]);
            
        })->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Payment = Debit


        $journals = Journal::with('journal_main')->when(count($search_params) > 0 , function($query) use ($search_params) {

            $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
            
        })->whereBetween('date',[$request->start_date,$request->end_date])->get();

       
        $from = Carbon::parse($request->start_date);
        $to = Carbon::parse($request->end_date);

        $i = 0;
        $report_array = array();

        
        
        $report_array[$i]['date'] = $from->format('Y-m-d');
        $report_array[$i]['reference'] = "Opening Balance On ".$from->format('d/m/Y');

        if($opening_balance >= 0)
        {
            $report_array[$i]['debit'] = "";
            $report_array[$i]['credit'] = abs($opening_balance);
            $report_array[$i]['type'] = "credit";
        }
        elseif($opening_balance < 0)
        {
            $report_array[$i]['debit'] = abs($opening_balance);
            $report_array[$i]['credit'] = "";
            $report_array[$i]['type'] = "debit";
        }
        
        
        
        $i++;
        
        $edit_access =  $this->checkReportEditAccess();
        for($d = $from; $d->lte($to); $d->addDay()) 
        {
            if(($request->input_gst == 1 || $request->output_gst == 1 || $request->gst == 1 || $request->input_tds == 1 || $request->output_tds || $request->tds == 1 || $request->tcs == 1 || $request->input_tcs == 1 || $request->output_tcs == 1 || $request->input_cgst == 1 || $request->input_sgst == 1 || $request->input_igst == 1 || $request->output_cgst == 1 || $request->output_sgst == 1 || $request->output_igst == 1))
            {
                if($request->input_gst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Output GST (Invoice No. ".$value->formatted_number."): - Rs.".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                            $report_array[$i]['against'] = $value->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "invoice";

                            $report_array[$i]['section'] = "invoice";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                            $report_array[$i]['status'] = $value->status;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    
                    foreach ($debit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Output GST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "debitnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach ($credit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = $value->igst > 0 ? "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- IGST : Rs. " .$value->igst: "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- CGST - Rs. ".$value['cgst']." , SGST - Rs. ".$value['sgst'];
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "creditnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->input_cgst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($value->cgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output CGST (Invoice No. ".$value->formatted_number."): - Rs.".$value->cgst;
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->cgst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "invoice";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    
                    foreach ($debit_notes as $key => $value) 
                    {
                        if($value->cgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Output CGST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".$value->cgst;
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] =  $value->cgst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "debitnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    foreach ($credit_notes as $key => $value) 
                    {
                        if($value->cgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                            
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output CGST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- CGST - Rs. ".$value['cgst'];
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] =  $value->cgst;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "creditnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }    
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->input_sgst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($value->sgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output SGST (Invoice No. ".$value->formatted_number."): - Rs.".$value->sgst;
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->sgst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "invoice";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    
                    foreach ($debit_notes as $key => $value) 
                    {
                        if($value->sgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Output SGST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".$value->sgst;
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] =  $value->sgst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "debitnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    foreach ($credit_notes as $key => $value) 
                    {
                        if($value->sgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                            
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output SGST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- SGST - Rs. ".$value['sgst'];
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] =  $value->sgst;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "creditnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }    
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->input_igst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($value->igst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output IGST (Invoice No. ".$value->formatted_number."): - Rs.".$value->igst;
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->igst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "invoice";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    
                    foreach ($debit_notes as $key => $value) 
                    {
                        if($value->igst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Output IGST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".$value->igst;
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] =  $value->igst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "debitnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    foreach ($credit_notes as $key => $value) 
                    {
                        if($value->igst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                            
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output IGST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- IGST - Rs. ".$value['igst'];
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] =  $value->igst;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "creditnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                       
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->output_gst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->is_taxable == 1)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = ($value->igst > 0 ? ("Input GST :-  IGST Rs.- " .$value->igst): ("Input GST :- CGST Rs.- ".$value['cgst']." , SGST Rs.- ".$value['sgst']));
                                $report_array[$i]['against'] = $value->number;
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "purchase";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['edit_access'] = $edit_access;	
                                $i++;
                            }
                            
                        }
                    }
                    
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type ;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                    
                }
                if($request->output_cgst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($value->cgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->is_taxable == 1)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Input CGST Rs.- " .$value->cgst;
                                    $report_array[$i]['against'] = $value->number;
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->cgst;
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "purchase";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['edit_access'] = $edit_access;	
                                    $i++;
                                }
                                
                            }
                        }
                        
                    }
                    
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                    
                }
                if($request->output_sgst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($value->sgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->is_taxable == 1)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Input SGST Rs.- " .$value->cgst;
                                    $report_array[$i]['against'] = $value->number;
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->sgst;
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "purchase";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['edit_access'] = $edit_access;	
                                    $i++;
                                }
                                
                            }
                        }
                        
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                    
                }
                if($request->output_igst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($value->igst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->is_taxable == 1)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Input IGST Rs.- " .$value->cgst;
                                    $report_array[$i]['against'] = $value->number;
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->igst;
                                    $report_array[$i]['type'] = "invoice";
                                    
                                    $report_array[$i]['section'] = "purchase";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['edit_access'] = $edit_access;	
                                    $i++;
                                }
                                
                            }
                        }
                        
                    }
                    
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Journal Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = "journal";
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                    
                }
                if($request->gst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Input GST (Invoice No. ".$value->formatted_number."): - Rs.".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                            $report_array[$i]['against'] = $value->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "journal";

                            $report_array[$i]['section'] = "invoice";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                            $report_array[$i]['status'] = $value->status;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->is_taxable == 1)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = ($value->igst > 0 ? ("Output GST :-  IGST Rs.- " .$value->igst): ("Output GST :- CGST Rs.- ".$value['cgst']." , SGST Rs.- ".$value['sgst']));
                                $report_array[$i]['against'] = $value->number;
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                $report_array[$i]['type'] = "journal";
                                
                                $report_array[$i]['section'] = "purchase";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                            
                        }
                    }
                    foreach ($debit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Input GST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "journal";
                            
                            $report_array[$i]['section'] = "debitnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $i++;
                        }
                    }
                    foreach ($credit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                        // var_dump($value->invoice->formatted_number); exit;
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = $value->igst > 0 ? "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- IGST : Rs. " .$value->igst: "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- CGST - Rs. ".$value['cgst']." , SGST - Rs. ".$value['sgst'];
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "creditnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $i++;
                        }
                    }
                }
                if($request->input_tds == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($value->tds > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output TDS (Invoice No. ".$value->formatted_number."): - Rs.".$value->tds;
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->tds;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "invoice";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->output_tds == 1)
                {                 
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($purchase_payments as $key => $value) 
                    {
                        if($value->tds > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Input TDS -".$value->formatted_number." For Purchase (Dated ".implode(',',array_column($value->purchases->toArray(),'date')).",Reference No. = ".implode(',',array_column($value->purchases->toArray(),'number')).")";
                                $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "purchase_payment";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;

                                if($request->tds_section_id)
                                {
                                    $tds = 0;

                                    foreach ($value->purchases->toArray() as $key => $inv) 
                                    {
                                    if($inv['pivot']['tds_section_id'] == $request->tds_section_id)
                                    {
                                        $tds = $tds + $inv['pivot']['tds'];
                                    }
                                    }

                                    $report_array[$i]['debit'] = $tds;
                                }
                                else
                                    $report_array[$i]['debit'] = $value->tds;
                                $i++;
                            }
                        }
                        
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->input_tcs == 1)
                {
                   
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($value->tcs > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output TCS (Invoice No. ".$value->formatted_number."): - Rs.".$value->tcs;
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->tcs;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    

                    } 
                }
            }
            else
            {
                if(count($request->item_id) > 0)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Invoice Created.-".$value->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] = $value->before_total;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "invoice";

                            $report_array[$i]['section'] = "invoice";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                            $report_array[$i]['status'] = $value->status;	
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    /*foreach ($payments as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Payment Received Ref.-".$value->formatted_number." For Invoice Reference (".implode(',',array_column($value->invoices->toArray(),'formatted_number')).")";
                            $report_array[$i]['against'] = array_column($value->invoices->toArray(),'formatted_number');
                            $report_array[$i]['description'] = $value->remarks;
                            
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "payment";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/payment/add-edit-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;

                            $gst = 0;

                            foreach ($value->invoices->toArray() as $key => $inv) 
                            {
                                $gst = $gst + $inv['igst'] > 0 ? $inv['igst'] : ($inv['cgst'] + $inv['sgst']);
                            }

                            $report_array[$i]['debit'] = $value->amount - $gst;
                            $i++;
                        }
                    }*/
                    foreach ($purchases as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Purchase Done Ref.-".$value->number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->number;
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = !empty($value->before_total) ? $value->before_total: $value->before_total;
                            $report_array[$i]['type'] = "purchase";
                            
                            $report_array[$i]['section'] = "purchase";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    /*foreach ($purchase_payments as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Purchase Payment Given Ref.-".$value->formatted_number." For Purchase (Dated ".implode(',',array_column($value->purchases->toArray(),'date')).",Reference No. = ".implode(',',array_column($value->purchases->toArray(),'number')).")";
                            $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                            $report_array[$i]['description'] = $value->remarks;
                           
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "purchase_payment";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;

                            $gst = 0;

                            foreach ($value->purchases->toArray() as $key => $inv) 
                            {
                                $gst = $gst + $inv['igst'] > 0 ? $inv['igst'] : ($inv['cgst'] + $inv['sgst']);
                            }
                            $report_array[$i]['credit'] = $value->amount - $gst;
                            $i++;
                        }
                    }*/

                    foreach ($debit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Debit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] = $value->before_total;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "debitnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }

                    foreach ($credit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                        // var_dump($value->invoice->formatted_number); exit;
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Credit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] = $value->before_total;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "creditnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                        
                    } 
                    
                }
                else
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $bank_name = !empty($value->bank_account) ? $value->bank_account->display_name : "";
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Amount Debited From ".$bank_name."  On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Amount Debited To ".$bank_name."  On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Invoice Created.-".$value->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] = $value->after_total;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "invoice";

                            $report_array[$i]['section'] = "invoice";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                            $report_array[$i]['status'] = $value->status;	
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach ($payments as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Payment Received Ref.-".$value->formatted_number." For Invoice Reference (".implode(',',array_column($value->invoices->toArray(),'formatted_number')).")";
                            $report_array[$i]['against'] = array_column($value->invoices->toArray(),'formatted_number');
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "payment";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/payment/add-edit-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Purchase Done Ref.-".$value->number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->number;
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = !empty($value->after_total) ? $value->after_total: $value->before_total;
                            $report_array[$i]['type'] = "purchase";
                            
                            $report_array[$i]['section'] = "purchase";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach ($purchase_payments as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Purchase Payment Given From  Ref.-".$value->formatted_number." For Purchase (Dated ".implode(',',array_column($value->purchases->toArray(),'date')).",Reference No. = ".implode(',',array_column($value->purchases->toArray(),'number')).")";
                            $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "purchase_payment";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }

                    foreach ($debit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Debit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] = $value->after_total;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "debitnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }

                    foreach ($credit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                        // var_dump($value->invoice->formatted_number); exit;
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Credit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] = $value->after_total;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "creditnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }

                    foreach ($cash_entries as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Cash Payment On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Cash Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "cashbook";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/cashbook/add-edit-cashbook/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] =  $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                        
                    } 

                }

                
            }
            
        }
        $total_credit = 0;
        $total_debit = 0;

        foreach($report_array as $report)
        {
            $total_debit = $total_debit + bcsub($report['debit'],0,2);
            $total_credit = $total_credit + bcsub($report['credit'],0,2);
        }
        $request->input_gst = "";
        $request->output_gst = "";
        $request->input_cgst = "";
        $request->output_cgst = "";
        $request->input_sgst = "";
        $request->output_sgst = "";
        $request->input_igst = "";
        $request->output_igst = "";
        $request->customer_id = "";
        $request->item_id = "";
        $request->input_tcs = "";
        $request->output_tcs = "";
        $request->input_tds = "";
        $request->output_tds = ""; 
        
        return bcsub(bcsub($total_credit,0,2),bcsub($total_debit,0,2),2);
       // return number_format(bcsub(number_format(floatval($total_credit), 2, '.', ''),number_format(floatval($total_debit), 2, '.', ''),2), 2, '.', '');
      
    }

    public function calculate_opening_balance_gst(Request $request,$type)
    {

        $opening_balance = 0;
        $credit = 0 ; 
        $debit = 0;
        $pay_total = 0;

        $data['invoice_debit'] = Invoice::select(DB::raw('SUM(after_total) as total_after,SUM(before_total) as total_before,SUM(case when igst > 0 then igst else cgst+sgst end) as total_tax, SUM(cgst) as total_cgst, SUM(sgst) as total_sgst, SUM(igst) as total_igst, SUM(tds) as total_tds, SUM(tcs) as total_tcs'))->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->when($request->tds_section_id, function($query) use ($request) {
            return $query->where('invoices.tds_section_id',$request->tds_section_id);
        })->when($request->tcs_section_id, function($query) use ($request) {
            return $query->where('invoices.tcs_section_id',$request->tds_section_id);
        })->where('date','<',$request->start_date)->get();

        $invoices_back = Invoice::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->where('date','<',$request->start_date)->get();

        $data['payment_credit'] = Payment::select(DB::raw('SUM(amount) as total_amount,SUM(tds) as total_tds,SUM(tcs) as total_tcs,SUM(ods) as total_ods'))->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($invoices_back) {
            return $query->whereHas('invoices', function($q) use ($invoices_back){
                $q->whereIn('invoice_id',array_column($invoices_back->toArray(),'id'));
            });
        })->where('date','<',$request->start_date)->get();

        //echo "<pre>"; print_r($payments->toArray()); echo "</pre>"; exit;

        $data['debit_note_debit'] = DebitNote::select(

            DB::raw('SUM(after_total) as total_after,SUM(before_total) as total_before,SUM(case when igst > 0 then igst else cgst+sgst end) as total_tax, SUM(cgst) as total_cgst, SUM(sgst) as total_sgst, SUM(igst) as total_igst')

        )->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->where('date','<',$request->start_date)->get();

        $data['credit_note_credit'] = CreditNote::select(

            DB::raw('SUM(after_total) as total_after,SUM(before_total) as total_before,SUM(case when igst > 0 then igst else cgst+sgst end) as total_tax, SUM(cgst) as total_cgst, SUM(sgst) as total_sgst, SUM(igst) as total_igst')

        )->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->where('date','<',$request->start_date)->get();


        $data['cash_entrie_credit'] = CashbookTransaction::when($request->customer_id, function($query) use ($request) {
            return $query->where('main_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereRaw('1=2');
        })->where('identifier','cash')->where('type','credit')->where('date','<',$request->start_date)->sum('amount');

        $data['cash_entrie_debit'] = CashbookTransaction::when($request->customer_id, function($query) use ($request) {
            return $query->where('main_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereRaw('1=2');
        })->where('identifier','cash')->where('type','debit')->where('date','<',$request->start_date)->sum('amount');


        

        $data['purchase_credit'] = Purchase::select(

            DB::raw('SUM(after_total) as total_after,SUM(before_total) as total_before,SUM(case when igst > 0 then igst else cgst+sgst end) as total_tax, SUM(cgst) as total_cgst, SUM(sgst) as total_sgst, SUM(igst) as total_igst')

        )->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->where('date','<',$request->start_date)->get(); //Credit Asset = Credit
        $purchases_back = Purchase::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->where('date','<',$request->start_date)->get(); 

        $data['purchase_payment_debit'] = PurchasePayment::select(

            DB::raw('SUM(amount) as total_amount,SUM(tds) as total_tds,SUM(tcs) as total_tcs,SUM(ods) as total_ods')

        )->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($purchases_back) {
            return $query->whereHas('purchases', function($q) use ($purchases_back){
                $q->whereIn('purchase_id',array_column($purchases_back->toArray(),'id'));
            });
        })->when($request->tds_section_id, function($query) use ($request) {

            $query->whereRaw('id in ( select purchase_payment_id from purchase_payment_rel where tds_section_id = ? and deleted_at is null)',[$request->tds_section_id]);
            
        })->where('date','<',$request->start_date)->get();

        if(!empty($type))
        {
            $search_params = explode('_',$type);
            if(count($search_params) == 2)
            {

                $data['advance_credit'] = PurchaseAdvancePayment::when(count($search_params) > 0 , function($query) use ($search_params) {

                    $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                    
                })->where('auto_entry',0)->where('type','credit')->where('date','<',$request->start_date)->sum('amount');
        
                $data['advance_debit'] = PurchaseAdvancePayment::when(count($search_params) > 0 , function($query) use ($search_params) {
        
                    $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                    
                })->where('auto_entry',0)->where('type','debit')->where('date','<',$request->start_date)->sum('amount');

                $data['journal_credit'] = Journal::when(count($search_params) > 0 , function($query) use ($search_params) {

                    $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                    
                })->where('type','credit')->where('date','<',$request->start_date)->sum('after_total');
        
                $data['journal_debit'] = Journal::when(count($search_params) > 0 , function($query) use ($search_params) {

                    $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                    
                })->where('type','debit')->where('date','<',$request->start_date)->sum('after_total');
            }

            $opening = OpeningBalance::when(count($search_params) > 0 , function($query) use ($search_params) {

                $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
                
            })->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();
        }    
       
        if(($request->input_gst == 1 || $request->output_gst == 1 || $request->gst == 1 || $request->input_tds == 1 || $request->output_tds || $request->tds == 1 || $request->tcs == 1 || $request->input_tcs == 1 || $request->output_tcs == 1 || $request->input_cgst == 1 || $request->input_sgst == 1 || $request->input_igst == 1 || $request->output_cgst == 1 || $request->output_sgst == 1 || $request->output_igst == 1))
        {
            if($request->input_gst == 1)
            {
                $debit = ($data['credit_note_credit'][0]['total_tax'] + $data['journal_debit'] +  $data['advance_debit']);
                $credit = ($data['invoice_debit'][0]['total_tax'] + $data['debit_note_debit'][0]['total_tax'] + $data['journal_credit'] +  $data['advance_credit']);
                $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->input_cgst == 1)
            {
                $debit = ($data['credit_note_credit'][0]['total_cgst'] + $data['journal_debit'] +  $data['advance_debit']);
                $credit = ($data['invoice_debit'][0]['total_cgst'] + $data['debit_note_debit'][0]['total_cgst'] + $data['journal_credit'] +  $data['advance_credit']);
                $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->input_sgst == 1)
            {
                $debit = ( $data['credit_note_credit'][0]['total_sgst'] + $data['journal_debit'] +  $data['advance_debit']);
                $credit = ($data['invoice_debit'][0]['total_sgst'] + $data['debit_note_debit'][0]['total_cgst'] + $data['journal_credit'] +  $data['advance_credit']);
                $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->input_igst == 1)
            {
               
                
                $debit = ($data['credit_note_credit'][0]['total_igst'] + $data['journal_debit'] + $data['advance_debit']);
                $credit = ($data['invoice_debit'][0]['total_igst'] + $data['debit_note_debit'][0]['total_igst'] + $data['journal_credit'] + $data['advance_credit']);
                
                $opening_balance = bcsub($credit, $debit,2);

                
            }
            if($request->output_gst == 1)
            {
               $debit = $data['purchase_credit'][0]['total_tax'] + $data['journal_debit'] +  $data['advance_debit'];
               $credit =  $data['journal_credit'] +  $data['advance_credit'];
               $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->output_cgst == 1)
            {
               $debit = $data['purchase_credit'][0]['total_cgst'] + $data['journal_debit'] +  $data['advance_debit'];
               $credit =  $data['journal_credit'] +  $data['advance_credit'];
               $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->output_sgst == 1)
            {
               $debit = $data['purchase_credit'][0]['total_sgst'] + $data['journal_debit'] +  $data['advance_debit'];
               $credit =  $data['journal_credit'] +  $data['advance_credit'];
               $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->output_igst == 1)
            {
               $debit = $data['purchase_credit'][0]['total_igst'] + $data['journal_debit'] +  $data['advance_debit'];
               $credit =  $data['journal_credit'] +  $data['advance_credit'];
              
               $opening_balance = bcsub($credit, $debit,2);
            }
            if($request->input_tds == 1)
            {
               
                $opening_balance = bcsub(($data['invoice_debit'][0]['total_tds'] +  $data['advance_debit']),($data['journal_debit']+  $data['advance_credit']),2);
            }
            elseif($request->output_tds == 1)
            {
                $opening_balance = bcsub(($data['journal_credit'] +  $data['advance_credit']),$data['purchase_payment_debit'][0]['total_tds'],2);
            }
            if($request->input_tcs == 1)
            {
                $opening_balance = bcsub($data['invoice_debit'][0]['total_tcs'],$data['journal_debit'] +  $data['advance_debit'],2);
            }
            
        }
        else
        {
            if(count($request->item_id) > 0)
            {
                $pay_total = $data['payment_credit'][0]['total_amount'] > 0 ?  bcsub($data['payment_credit'][0]['total_amount'],bcsub($data['payment_credit'][0]['total_amount'],$data['invoice_debit'][0]['total_before'],2),2):0;

                $debit = ( $data['credit_note_credit'][0]['total_tax'] + $data['purchase_credit'][0]['total_before'] + $data['journal_credit'] +  $data['advance_credit']);

                $credit = bcsub(( $data['invoice_debit'][0]['total_before'] + $data['debit_note_debit'][0]['total_before'] + $data['journal_debit'] +  $data['advance_debit']),0,2);

                $opening_balance = bcsub($credit, $debit,2);
            }
            else
            {
                $credit = bcsub(($data['purchase_credit'][0]['total_after'] + $data['payment_credit'][0]['total_amount'] + $data['advance_credit'] +  $data['cash_entrie_credit'] + $data['journal_credit']),0,2);
                $debit = bcsub(($data['purchase_payment_debit'][0]['total_amount'] + $data['invoice_debit'][0]['total_after'] + $data['debit_note_debit'][0]['total_after'] + $data['advance_debit'] + $data['cash_entrie_debit'] + $data['journal_debit']),0,2);
                $opening_balance = bcsub($credit, $debit,2);
                
                
            }
        }
        

        if(isset($opening) && !empty($opening))
        {
            $opening_balance = $opening->type == 'debit' ? ((0 - $opening->amount) + $opening_balance) : ($opening->amount + $opening_balance);
        }
        
          
       return $opening_balance;
    }
   
    public function trial_balance_pdf(Request $request)
    {
        $validator = Validator::make($request->all(), [

            'start_date'=>['required'],
            'end_date'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            $report_array = array();
            $i = 0;
            $fiscal_year = FiscalYear::whereRaw('((start_date between ? and ? ) or (end_date between ? and ? ))',[$request->start_date,$request->end_date,$request->start_date,$request->end_date])->first();

            
            $print_data = array();

            $from = Carbon::parse($request->start_date);
            $to = Carbon::parse($request->end_date);

            $print_data['[START_DATE]'] = $from->format('d/m/Y');
            $print_data['[END_DATE]'] = $to->format('d/m/Y');

            $all_liability_items = array();
            $liablity_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',9);
            })->where('status',1)->get();

            if(count($liablity_items) > 0)
            {
                foreach($liablity_items as $key => $llitem)
                {
                    $all_liability_items[$key]['all_search'] = 'item_'.$llitem->id;
                    $all_liability_items[$key]['reference'] = $llitem->name;
                }
            } 

            $ik = 0;
            $liabliity_total_credit = 0;
            $liabliity_total_debit = 0;
            $liability_item_arr = array();
            foreach($all_liability_items as $lkey => $litem)
            {
               
                $liabilities_ret = $this->gst_ledger($request,$litem['all_search']);
               
               
                if($liabilities_ret < 0)
                {
                    $liability_item_arr[$ik]['reference'] = $litem['reference'];
                    $liability_item_arr[$ik]['debit'] = sprintf('%0.2f',floatval(abs($liabilities_ret)));
                    $liability_item_arr[$ik]['credit'] = sprintf('%0.2f',floatval(0));
                    $liability_item_arr[$ik]['children'] = array();
                    $ik++;
                    $liabliity_total_debit = $liabliity_total_debit + floatval(abs($liabilities_ret));
                }
                elseif($liabilities_ret > 0)
                {

                    $liability_item_arr[$ik]['reference'] = $litem['reference'];
                    $liability_item_arr[$ik]['debit'] = sprintf('%0.2f',floatval(0));
                    $liability_item_arr[$ik]['credit'] = sprintf('%0.2f',floatval(abs($liabilities_ret)));
                    $liability_item_arr[$ik]['children'] = array();
                    $ik++;

                    $liabliity_total_credit = $liabliity_total_credit + floatval(abs($liabilities_ret));
                }

                
               
            }

            $creditors = Customer::where('category','Creditor')->where('status',1)->get();

            $sundry_creditor_credit = 0;
            $sundry_creditor_debit = 0;

            foreach($creditors as $creditor){
                
                $sundry_creditors_ret = $this->gst_ledger($request,"customer_".$creditor->id);
               
                if($sundry_creditors_ret < 0)
                {
                    $sundry_creditor_debit = $sundry_creditor_debit + floatval(abs($sundry_creditors_ret));
                }
                elseif($sundry_creditors_ret > 0)
                {

                    $sundry_creditor_credit = $sundry_creditor_credit + floatval(abs($sundry_creditors_ret));
                }
            }

            /*GST Input & Output */
            $output_gst = 0 ;
            $input_gst = 0;
            $igst_rec = abs($this->gst_ledger($request,'igst_2'));
            $cgst_rec = abs($this->gst_ledger($request,'cgst_2'));
            $sgst_rec = abs($this->gst_ledger($request,'sgst_2'));
 
            $sgst_pay = abs($this->gst_ledger($request,'sgst_1'));
            $cgst_pay = abs($this->gst_ledger($request,'cgst_1'));
            $igst_pay = abs($this->gst_ledger($request,'igst_1'));
             
            if(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec) < 0)
            {
                $output_gst = abs(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec));
            }
            elseif(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec) > 0)
            {
 
                $input_gst = ($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec);
            }

             /* TCS Payable */ 
             $tcs_pay_cr = 0;
             $tcs_pay_dr = 0;
             $tcs_payables_ret =$this->gst_ledger($request,'tcs_1');

             if($tcs_payables_ret < 0)
             {
                $tcs_pay_dr = sprintf('%0.2f',abs(floatval($tcs_payables_ret)));
             }
             elseif($tcs_payables_ret > 0)
             {
                $tcs_pay_cr = sprintf('%0.2f',abs(floatval($tcs_payables_ret)));
             }

             /* TDS Payable */ 
             $tds_pay_cr = 0;
             $tds_pay_dr = 0;
             $tds_pay = $this->gst_ledger($request,'tds_1');
             if($tds_pay < 0)
             {
                $tds_pay_dr = sprintf('%0.2f',abs(floatval($tds_pay)));
             }
             elseif($tds_pay > 0)
             {
 
                $tds_pay_cr = sprintf('%0.2f',abs(floatval($tds_pay)));
             }

            $liability_arr[0]['reference']="Sundry Creditor";
            $liability_arr[0]['credit']=sprintf('%0.2f',$sundry_creditor_credit);
            $liability_arr[0]['debit']=sprintf('%0.2f',$sundry_creditor_debit);
            $liability_arr[0]['children']=array();
 
            $liability_arr[1]['reference']="GST Input & Output";
            $liability_arr[1]['credit']=sprintf('%0.2f',$input_gst);
            $liability_arr[1]['debit']=sprintf('%0.2f',$output_gst);
            $liability_arr[1]['children']=array();
 
            $liability_arr[2]['reference']="TDS Payable";
            $liability_arr[2]['credit']=$tds_pay_cr;
            $liability_arr[2]['debit']= $tds_pay_dr;
            $liability_arr[2]['children']=array();
 
            $liability_arr[3]['reference']="TCS Payable";
            $liability_arr[3]['credit']=$tcs_pay_cr;
            $liability_arr[3]['debit']= $tcs_pay_dr;
            $liability_arr[3]['children']=array();
 
            $liability_cr = 0;
            $liability_dr = 0;
 
            foreach( array_merge($liability_arr,$liability_item_arr) as $lk => $lv)
            {
             $liability_cr = $liability_cr + $lv['credit'];
             $liability_dr = $liability_dr + $lv['debit'];
            }
 
            $report_array[$i]['reference'] = "A. Current Liablities";
            $report_array[$i]['children'] =  array_merge($liability_arr,$liability_item_arr);
            $report_array[$i]['debit'] = $liability_dr;
            $report_array[$i]['credit'] = $liability_cr;
            $i++;

            /*Current Asset */
            //Current Assets Section
            $request->return_type = 'array';

            $bank_accounts = BankAccount::where('status',1)->get();
           

            $bank_book_arr = array();
            foreach($bank_accounts as $bk => $bank)
            {
                $request->merge(['bank_account_id' => $bank->id]);
                $bank_book_data = $this->bankbook_report($request);
                $total_bankbook_credit = 0;
                $total_bankbook_debit = 0;
                foreach ($bank_book_data as $key => $value) {
                    if($value['type'] == 'credit')
                        $total_bankbook_credit = $total_bankbook_credit + $value['credit'];
                    elseif($value['type'] == 'debit')
                        $total_bankbook_debit = $total_bankbook_debit + $value['debit'];    
                }
               
                if( $total_bankbook_credit -  $total_bankbook_debit >= 0)
                {
                    $bank_book_arr[$bk]['bank_name'] = $bank->display_name;
                    $bank_book_arr[$bk]['debit'] = ($total_bankbook_credit -  $total_bankbook_debit);
                    $bank_book_arr[$bk]['credit'] = 0;
                }
                elseif( $total_bankbook_credit -  $total_bankbook_debit < 0)
                {
                    $bank_book_arr[$bk]['bank_name'] = $bank->display_name;
                    $bank_book_arr[$bk]['credit'] = abs($total_bankbook_credit -  $total_bankbook_debit);
                    $bank_book_arr[$bk]['debit'] = 0;
                }
                
            }
            
            $cash_book_data = $this->cashbook_report($request);

            $total_cashbook_credit = 0;
            $total_cashbook_debit = 0;

            foreach ($cash_book_data as $key => $value) {
                if($value['type'] == 'credit')
                    $total_cashbook_credit = $total_cashbook_credit + $value['credit'];
                elseif($value['type'] == 'debit')
                    $total_cashbook_debit = $total_cashbook_debit + $value['debit'];    
            }

           
            $cash_balance_debit = 0;
            $cash_balance_credit = 0;

            if(($total_cashbook_credit - $total_cashbook_debit) >= 0)
            {
                $cash_balance_debit = abs($total_cashbook_credit - $total_cashbook_debit);
            }
            else
            {
                $cash_balance_credit = abs($total_cashbook_credit - $total_cashbook_debit);
            }
            $bank_balance_credit = 0;
            $bank_balance_debit = 0;
            foreach($bank_book_arr as $bb){

                if($bb['credit'] > 0)
                    $bank_balance_credit = $bank_balance_credit + $bb['credit'];
                elseif($bb['debit'] > 0)
                    $bank_balance_debit =   $bank_balance_debit + $bb['debit'];  
            }
            
           

            $sens_hotel = Customer::find(26);
            $sens_hotels_ret = $this->gst_ledger($request,'customer_'.$sens_hotel->id);
            $sens_hotels_cr = 0;
            $sens_hotels_dr = 0;
            if($sens_hotels_ret < 0)
            {
                $sens_hotels_dr = sprintf('%0.2f',floatval($sens_hotels_ret));
            }
            elseif($sens_hotels_ret > 0)
            {
                $sens_hotels_cr = sprintf('%0.2f',floatval($sens_hotels_ret));
                
            }

            $assets_arr = array();
            $asset_cr = 0;
            $asset_dr = 0;

            $asset_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',10);
            })->where('status',1)->get();

            foreach($asset_items as $askey => $aitem)
            {
               
                $assets_rel = $this->gst_ledger($request,'item_'.$aitem->id);
               
               
                if($assets_rel < 0)
                {
                    $asset_arr[$askey]['reference'] =$aitem->name;
                    $asset_arr[$askey]['debit'] =sprintf('%0.2f',abs(floatval($assets_rel)));
                    $asset_arr[$askey]['credit'] = floatval(0);
                    $asset_arr[$askey]['childeren'] = array();

                    $asset_dr = $asset_dr + floatval($assets_rel);
                }
                elseif($assets_rel > 0)
                {
                    $asset_arr[$askey]['reference'] =$aitem->name;
                    $asset_arr[$askey]['credit'] = sprintf('%0.2f',abs(floatval($assets_rel)));
                    $asset_arr[$askey]['debit'] = floatval(0);
                    $asset_arr[$askey]['childeren'] = array();
                    $asset_cr = $asset_cr + floatval($assets_rel);
                }
               
            }
            $current_assets_arr =  array(
                array('reference'=>'Cash In Hand','credit'=>floatval($cash_balance_credit),'debit'=>floatval($cash_balance_debit)),
                array('reference'=>'Bank Accounts','credit'=>floatval($bank_balance_credit),'debit'=>floatval($bank_balance_debit)),
                array('reference'=> $sens_hotel->full_name,'credit'=>floatval($sens_hotels_cr),'debit'=>floatval($sens_hotels_dr))
            );

           
            $report_array[$i]['reference'] = "B. Current Assets";
            $report_array[$i]['children'] =  array_merge($current_assets_arr,$assets_arr);
            $report_array[$i]['debit'] = ($cash_balance_debit + $bank_balance_debit + $sens_hotels_dr + $asset_dr);
            $report_array[$i]['credit'] = ($cash_balance_credit + $bank_balance_credit + $sens_hotels_cr + $asset_cr);
            $i++;
             
            
            /*Sales Account*/
            $sales_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',19);
            })->where('status',1)->get(); 
            
            $sales_arr = array();
            $sales_cr = 0;
            $sales_dr = 0;
            if(count($sales_items) > 0)
            {
                foreach($sales_items as $skey => $sitem)
                {
                   
                    $sales_ret = $this->gst_ledger($request,'item_'.$sitem->id);
                    
                   

                    if( $sales_ret < 0)
                    {
                        $sales_arr[$skey]['reference'] = $sitem->name."-".$sitem->hsn_sac_code;
                        $sales_arr[$skey]['debit'] = sprintf('%0.2f',abs(floatval( $sales_ret)));
                        $sales_arr[$skey]['credit'] = sprintf('%0.2f',floatval(0));
                        $sales_arr[$skey]['children'] = array();
                        
                        $sales_dr = $sales_dr + abs($sales_ret);
                    }
                    elseif( $sales_ret > 0)
                    {
                        $sales_arr[$skey]['reference'] = $sitem->name."-".$sitem->hsn_sac_code;
                        $sales_arr[$skey]['credit'] = sprintf('%0.2f',abs(floatval( $sales_ret)));
                        $sales_arr[$skey]['debit'] = floatval(0);
                        $sales_arr[$skey]['children'] = array();

                        $sales_cr = $sales_cr + abs($sales_ret);
                    }
                   
                }
            }
            
           
            $report_array[$i]['reference'] = "C. Sales Account";
            $report_array[$i]['children'] =  $sales_arr; 
            $report_array[$i]['debit'] = $sales_dr;
            $report_array[$i]['credit'] = $sales_cr;
            $i++;    
          
              /*Indirect Income*/

              $indirect_income_arr = array();
              $indirect_income_debit = 0;
              $indirect_income_credit = 0;
  
              $indirect_income_items = Item::whereHas('categories', function($q) use ($request){
                  $q->where('categories.id',20);
              })->where('status',1)->get();
  
              if(count($indirect_income_items) > 0)
              {
                  foreach($indirect_income_items as $inkey => $initem)
                  {
                     
                      $indirect_incomes_ret =  $this->gst_ledger($request,'item_'.$initem->id);
                  
                      if( $indirect_incomes_ret < 0)
                      {
                          $indirect_income_arr[$inkey]['reference'] = $initem->name;
                          $indirect_income_arr[$inkey]['debit'] = sprintf('%0.2f',floatval(0));
                          $indirect_income_arr[$inkey]['credit'] = sprintf('%0.2f',abs(floatval( $indirect_incomes_ret)));
                          $indirect_income_arr[$inkey]['children'] = array();
                          
                          $indirect_income_debit = $indirect_income_debit + abs($indirect_incomes_ret);
                      }
                      elseif( $indirect_incomes_ret > 0)
                      {
      
                          $indirect_income_arr[$inkey]['reference'] = $initem->name;
                          $indirect_income_arr[$inkey]['debit'] =  sprintf('%0.2f',floatval(0));
                          $indirect_income_arr[$inkey]['credit'] = sprintf('%0.2f',abs(floatval( $indirect_incomes_ret)));
                          $indirect_income_arr[$inkey]['children'] = array();
                          
                          $indirect_income_credit = $indirect_income_credit + abs($indirect_incomes_ret);
                      }
                  }
              } 
             
              $report_array[$i]['reference'] = "D. Indirect Income";
              $report_array[$i]['children'] =  $indirect_income_arr; 
              $report_array[$i]['debit'] = $indirect_income_debit;
              $report_array[$i]['credit'] =  $indirect_income_credit;
              $i++;
             /*Indirect Expense*/
             $indirect_expense_credit = 0;
             $indirect_expense_debit = 0;
             $indirect_expense_arr = array();
             $indirect_expense_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',14);
            })->where('status',1)->get();

            if(count($indirect_expense_items) > 0)
            {
                foreach($indirect_expense_items as $exkey => $exitem)
                {
                   
                    $indirect_expenses_ret =  $this->gst_ledger($request,'item_'.$exitem->id);
                    
            
                    if($indirect_expenses_ret < 0)
                    {

                        $indirect_expense_arr[$exkey]['reference'] = $exitem->name;
                        $indirect_expense_arr[$exkey]['debit'] = sprintf('%0.2f',abs(floatval( $indirect_expenses_ret)));
                        $indirect_expense_arr[$exkey]['credit'] = sprintf('%0.2f',floatval(0));
                        $indirect_expense_arr[$exkey]['children'] = array();
                        
                        $indirect_expense_debit = $indirect_expense_debit + abs($indirect_expenses_ret);

                    }
                    elseif($indirect_expenses_ret > 0)
                    {
    
                       
                        $indirect_expense_arr[$exkey]['reference'] = $exitem->name;
                        $indirect_expense_arr[$exkey]['credit'] = sprintf('%0.2f',abs(floatval( $indirect_expenses_ret)));
                        $indirect_expense_arr[$exkey]['debit'] = sprintf('%0.2f',floatval(0));
                        $indirect_expense_arr[$exkey]['children'] = array();

                        $indirect_expense_credit = $indirect_expense_credit + abs($indirect_expenses_ret);
                    }
                }
            }

            $report_array[$i]['reference'] = "E. Indirect Expense";
            $report_array[$i]['children'] =  $indirect_expense_arr; 
            $report_array[$i]['debit'] = $indirect_expense_debit;
            $report_array[$i]['credit'] =  $indirect_expense_credit;
            $i++;

          
           
           
             /*Profit/Loss A/C*/
           
            $last_fiscal_year = FiscalYear::where('start_date',date('Y-04-01', strtotime($request->start_date . " -1 year") ))->first();
            $request->start_date = $last_fiscal_year->start_date;
            $request->end_date = $last_fiscal_year->end_date;
            $request->type = "array";

            $return_pl = $this->profit_loss_report($request);
            
            if($return_pl['nett_profit'] == 0)
            {
                $opening_balance=OpeningBalance::where('main_id',0)->where('identifier','profit')->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();

                if(!empty($opening_balance))
                {
                    if($opening_balance->type == 'credit')
                    {
                        $report_array[$i]['debit'] = floatval(0);
                        $report_array[$i]['credit'] = floatval($opening_balance->amount);
                    }
                    elseif($opening_balance->type == 'debit')
                    {
                        $report_array[$i]['credit'] = floatval(0);
                        $report_array[$i]['debit'] = floatval($opening_balance->amount);
                    }
                }
                else
                {
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = floatval(0);
                }
                $report_array[$i]['reference'] = "F. Profit & Loss A/C";
                $report_array[$i]['children'] = array();
                $i++;
            }
            else
            {
                if($return_pl['nett_profit'] > 0)
                {
                    $report_array[$i]['debit'] = floatval(0);
                    $report_array[$i]['credit'] = abs(floatval($return_pl['nett_profit']));
                }
                else
                {
                    $report_array[$i]['credit'] = floatval(0);
                    $report_array[$i]['debit'] = abs(floatval($return_pl['nett_profit']));
                }
                $report_array[$i]['reference'] = "F. Profit & Loss A/C";
                $report_array[$i]['children'] = array();
                $i++;
            }

            //return $report_array;

            if($invoice_account = InvoiceAccount::find(1))
            {
               
                if(count($report_array) > 0)
                {
                    $print_data_loop=array();
                    $item_str="";
                    $total_debit = 0;
                    $total_credit = 0;
    
                    foreach ($report_array as  $value) 
                    {   
                        
                        $print_data_loop['[REFERENCE]']="<span style='font-weight:bold;'>".$value['reference']."</span>";
                        $print_data_loop['[DEBIT]']="<span style='font-weight:bold;'>".number_format(floatval($value['debit']),2)."</span>";
                        $print_data_loop['[CREDIT]'] = "<span style='font-weight:bold;'>".number_format(floatval($value['credit']),2)."</span>";
                        preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$invoice_account->trial_balance_body,$matches);
                        $item_str .= $this->loop($matches,$print_data_loop);
                         
                        
                        $total_debit=$total_debit+floatval($value['debit']);
                        $total_credit=$total_credit+floatval($value['credit']);

                        if(count($value['children']) > 0)
                        {
                            foreach ($value['children'] as $key1 => $value1) 
                            {
                        
                                //print_r($value1);
                                $print_data_loop['[REFERENCE]']="<span style='padding-left:20px;'>".$value1['reference']."</span>";
                                $print_data_loop['[DEBIT]']=number_format(floatval($value1['debit']),2);
                                $print_data_loop['[CREDIT]'] = number_format(floatval($value1['credit']),2);
                            
                                preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$invoice_account->trial_balance_body,$matches);
            
                                $item_str .= $this->loop($matches,$print_data_loop);
                            }
                        }
                        
                    }
                }  
                
                if(count($matches) > 0 && isset($matches[0][0]))
                    $trial_balance_body =str_replace($matches[0][0], $item_str,$invoice_account->trial_balance_body);
                else
                    $trial_balance_body = $invoice_account->trial_balance_body;
                
                $print_data['[TOTAL_CREDIT]'] = number_format($total_credit,2);
                $print_data['[TOTAL_DEBIT]'] = number_format($total_debit,2);

                $trial_balance_body = $this->replace_variable($trial_balance_body,$print_data,$invoice_account->trial_balance_body);

                //Save The Final HTML to PDF
                $path = storage_path()."/report/trial-balance";
                if (!file_exists($path)) {
                    $this->createPath($path);
                }
                $fileName =  $path."/Trial-Balance-Report-".time().".pdf";

                PDF::loadHTML($trial_balance_body)->setPaper('a4', 'portrait')->setWarnings(false)->save($fileName);

                return  response()->file($fileName);
            }

        }
    }
    public function profit_loss_report(Request $request)
    {
        $validator = Validator::make($request->all(), [

            'start_date'=>['required'],
            'end_date'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            $report_array_right = array();
            $report_array_left = array();
            $i = 0;

            $gross_profit = 0;
            
            $sales_arr = array();
            $sales_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',19);
            })->where('status',1)->get(); 
            
            if(count($sales_items) > 0)
            {
                foreach($sales_items as $skey => $item)
                {
                    $sales_item_ret = $this->profit_loss_ledger($request,'item_'.$item->id);
                    $sales_total_dr = 0;
                    $sales_total_cr = 0;
                    
                    foreach ($sales_item_ret as $key => $value) {
                        $invoice_arr[$key]['reference']=$value['reference'];
                        $invoice_arr[$key]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) : sprintf('%0.2f',floatval($value['credit']));
                        $invoice_arr[$key]['children'] = array();

                        $sales_total_cr = $sales_total_cr + floatval($value['credit']);
                        $sales_total_dr = $sales_total_dr + floatval($value['debit']);
                    }

                    $sales_arr[$skey]['reference'] = $item->name."-".$item->hsn_sac_code;
                    $sales_arr[$skey]['amount'] = sprintf('%0.2f',floatval($sales_total_cr - $sales_total_dr));
                    $sales_arr[$skey]['children'] =  $invoice_arr;
                    
                    $gross_profit = $gross_profit + floatval($sales_total_cr - $sales_total_dr);
                    
                }
            }
            /*Indirect Income*/
            $indirect_profit = 0;
            $indirect_income_arr = array();
            $indirect_income_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',20);
            })->where('status',1)->get();

            if(count($indirect_income_items) > 0)
            {
                foreach($indirect_income_items as $ikey => $item)
                {
                    $indirect_income_ret = $this->profit_loss_ledger($request,'item_'.$item->id);

                    $indirect_income_total_cr = 0 ;
                    $indirect_income_total_dr = 0 ;
                    $in_journal_arr = array();

                    $jj = 0;
                    foreach ($indirect_income_ret as $key => $value) {
                      
                        $in_journal_arr[$jj]['reference'] =  $value['reference'];
                        $in_journal_arr[$jj]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) : sprintf('%0.2f',floatval($value['credit']));
                        $in_journal_arr[$jj]['children'] = array();
                       
                        $indirect_income_total_cr = $indirect_income_total_cr + floatval($value['credit']);
                        $indirect_income_total_dr = $indirect_income_total_dr + floatval($value['debit']);
                        $jj++;
                    }

                    $indirect_income_arr[$ikey]['reference'] = $item->name;
                    $indirect_income_arr[$ikey]['amount'] = sprintf('%0.2f',floatval($indirect_income_total_cr - $indirect_income_total_dr));
                    $indirect_income_arr[$ikey]['children'] = $in_journal_arr;

                    $indirect_profit =  $indirect_profit + floatval($indirect_income_total_cr - $indirect_income_total_dr);
                    
                }
            }

            $right_table_total = 0;

            $report_array_right[$i]['reference']="Sales Accounts";
            $report_array_right[$i]['amount']=sprintf('%0.2f',$gross_profit);
            $report_array_right[$i]['children']=$sales_arr;
            $i++;

            $report_array_right[$i]['reference']="Indirect Incomes";
            $report_array_right[$i]['amount']=sprintf('%0.2f',$indirect_profit);
            $report_array_right[$i]['children']=$indirect_income_arr;
            $i++;
           
            $right_table_total = $gross_profit + $indirect_profit;


            $indirect_expense = 0;
            $indirect_arr = array();
            /*Indirect Expense*/ 
            $indirect_expense_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',14);
            })->where('status',1)->get();

            if(count($indirect_expense_items) > 0)
            {
                foreach($indirect_expense_items as $ikey => $item)
                {
                    $indirect_expense_ret = $this->profit_loss_ledger($request,'item_'.$item->id);

                    $indirect_expense_total_cr = 0 ;
                    $indirect_expense_total_dr = 0 ;
                    $journal_arr = array();

                    $kk = 0;
                    foreach ($indirect_expense_ret as $key => $value) {
                      
                        $journal_arr[$kk]['reference'] =  $value['reference'];
                        $journal_arr[$kk]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) : sprintf('%0.2f',floatval($value['credit']));
                        $journal_arr[$kk]['children'] = array();
                       
                        $indirect_expense_total_cr = $indirect_expense_total_cr + floatval($value['credit']);
                        $indirect_expense_total_dr = $indirect_expense_total_dr + floatval($value['debit']);
                        $kk++;
                    }

                    $indirect_arr[$ikey]['reference'] = $item->name;
                    $indirect_arr[$ikey]['amount'] = sprintf('%0.2f',abs(floatval($indirect_expense_total_cr - $indirect_expense_total_dr)));
                    $indirect_arr[$ikey]['children'] = $journal_arr;

                    $indirect_expense =  $indirect_expense + abs(floatval($indirect_expense_total_cr - $indirect_expense_total_dr));
                    
                }
            }

            $direct_expense_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',15);
            })->where('status',1)->get();
            $direct_expense_arr = array();
            $direct_expense_total = 0;
            if(count($direct_expense_items) > 0)
            {
                foreach($direct_expense_items as $item)
                {
                    $direct_expense_ret = $this->profit_loss_ledger($request,'item_'.$item->id);

                    $direct_expense_total_cr = 0 ;
                    $direct_expense_total_dr = 0 ;
                    $direct_arr = array();

                    $kk = 0;
                    foreach ($direct_expense_ret as $key => $value) {
                      
                        $direct_arr[$kk]['reference'] =  $value['reference'];
                        $direct_arr[$kk]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) : sprintf('%0.2f',floatval($value['credit']));
                        $direct_arr[$kk]['children'] = array();
                       
                        $direct_expense_total_cr = $direct_expense_total_cr + floatval($value['credit']);
                        $direct_expense_total_dr = $direct_expense_total_dr + floatval($value['debit']);
                        $kk++;
                    }

                    $direct_expense_arr[$ikey]['reference'] = $item->name;
                    $direct_expense_arr[$ikey]['amount'] = sprintf('%0.2f',abs(floatval($direct_expense_total_cr - $direct_expense_total_dr)));
                    $direct_expense_arr[$ikey]['children'] = $journal_arr;

                    $direct_expense_total =  $direct_expense_total + abs(floatval($direct_expense_total_cr - $direct_expense_total_dr));
                }
            }

            // $purchases = Purchase::with('customer','fiscal_year')->whereBetween('date',[$request->start_date,$request->end_date])->get();

            // $purchase_arr = array();
            // $purchase_expense = 0;
 
            // foreach($purchases as $key => $value)
            // {
            //     if($value->after_total > 0 || $value->before_total)
            //     {
            //         $purchase_arr[$key]['reference'] = "Direct Expense";
            //         $purchase_arr[$key]['amount'] = !empty($value->after_total) ? floatval($value->after_total): floatval($value->before_total);
            //         $purchase_expense = $purchase_expense + $purchase_arr[$key]['amount'];
            //         $purchase_arr[$key]['children'] = array();
                   
            //     }
                   
            // }

            $j = 0;
            $left_table_total = 0;

            
            $report_array_left[$j]['reference'] = "Direct Expense";
            $report_array_left[$j]['amount'] = $direct_expense_total;
            $report_array_left[$j]['children'] = $direct_expense_arr;
            $j++;

            $report_array_left[$j]['reference'] = "Gross Profit C/F";
            $report_array_left[$j]['amount'] = floatval($gross_profit);
            $report_array_left[$j]['children'] = array();
            $j++;

            $report_array_left[$j]['reference'] = "Indirect Expense";
            $report_array_left[$j]['amount'] = $indirect_expense;
            $report_array_left[$j]['children'] =  $indirect_arr;
            $j++;

            
            if(floatval(($gross_profit + $indirect_profit) - ($direct_expense_total + $indirect_expense)) >= 0)
            {
                $report_array_left[$j]['reference'] = "Nett Profit";
                $report_array_left[$j]['amount'] = abs(floatval(($gross_profit + $indirect_profit) - ($direct_expense_total + $indirect_expense)));
                $report_array_left[$j]['children'] = array();
                $j++;
            }
            else
            {
                $report_array_left[$j]['reference'] = "Nett Loss";
                $report_array_left[$j]['amount'] = abs(floatval(($gross_profit + $indirect_profit) - ($direct_expense_total + $indirect_expense)));
                $report_array_left[$j]['children'] = array();
                $j++;
            }
            

            $left_table_total = floatval((($gross_profit + $indirect_profit) - ($direct_expense_total + $indirect_expense)) + ($direct_expense_total + $indirect_expense));
                

            if($request->type == 'array')
                return ['left'=>$report_array_left, 'right'=>$report_array_right,'right_table_total'=>$right_table_total,'left_table_total'=>$left_table_total,'nett_profit'=>floatval(($gross_profit + $indirect_profit) - ($direct_expense_total + $indirect_expense))];
            else
                return response(['data' => array('left'=>$report_array_left, 'right'=>$report_array_right,'right_table_total'=>$right_table_total,'left_table_total'=>$left_table_total),'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        }
    }

    public function profit_loss_ledger(Request $request,$type)
    {
        if(!empty($type))
        {
            $search_params = explode('_',$type);

            $request->item_id = array();
            if(count($search_params) == 2)
            {
                if($search_params[0] == 'customer')
                    $request->customer_id = $search_params[1];
                if($search_params[0] == 'item')
                    $request->item_id = array($search_params[1]);

                if($search_params[0] == 'gst')
                {
                    if($search_params[1] == 1)
                     $request->input_gst = 1;
                    elseif($search_params[1] == 2)
                     $request->output_gst = 1; 

                }
                if($search_params[0] == 'cgst')
                {
                    if($search_params[1] == 1)
                     $request->input_cgst = 1;
                    elseif($search_params[1] == 2)
                     $request->output_cgst = 1; 
                }
                if($search_params[0] == 'sgst')
                {
                    if($search_params[1] == 1)
                     $request->input_sgst = 1;
                    elseif($search_params[1] == 2)
                     $request->output_sgst = 1; 
                }
                if($search_params[0] == 'igst')
                {
                    if($search_params[1] == 1)
                     $request->input_igst = 1;
                    elseif($search_params[1] == 2)
                     $request->output_igst = 1; 
                }
                if($search_params[0] == 'tds')
                {
                    if($search_params[1] == 1)
                     $request->input_tds = 1;
                    elseif($search_params[1] == 2)
                     $request->output_tds = 1; 

                }
                if($search_params[0] == 'tcs')
                {
                    if($search_params[1] == 1)
                     $request->input_tcs = 1;
                    elseif($search_params[1] == 2)
                     $request->output_tcs = 1; 

                }
                if($search_params[0] == 'tds-section')
                {
                    $request->input_tcs = 1;
                    $request->tds_section_id = $search_params[1];
                }
                if($search_params[0] == 'tcs-section')
                {
                    $request->input_tcs = 1;
                    $request->tcs_section_id = $search_params[1];
                }           
            }
            else
                return response(['data' => array(),'success'=>false,'message' =>"Selector Error"], 200);
        }
        //For Opening Balance Checking
        $opening_balance = $this->calculate_opening_balance_gst($request,$type);

        //Date Range Data
        $invoices = Invoice::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->when($request->tds_section_id, function($query) use ($request) {
            return $query->where('tds_section_id',$request->tds_section_id);
        })->when($request->tcs_section_id, function($query) use ($request) {
            return $query->where('tcs_section_id',$request->tcs_section_id);
           
        })->whereBetween('date',[$request->start_date,$request->end_date])->get();

        
        $payments = Payment::with('bank_account')->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($invoices) {
            return $query->whereHas('invoices', function($q) use ($invoices){
                $q->whereIn('invoice_id',array_column($invoices->toArray(),'id'));
            });
        })->whereBetween('date',[$request->start_date,$request->end_date])->get();


        $debit_notes = DebitNote::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->whereBetween('date',[$request->start_date,$request->end_date])->get();

        $credit_notes = CreditNote::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->whereBetween('date',[$request->start_date,$request->end_date])->get();


        $cash_entries = CashbookTransaction::when($request->customer_id, function($query) use ($request) {
            return $query->where('main_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereRaw('1=2');
        })->where('identifier','cash')->whereBetween('date',[$request->start_date,$request->end_date])->get();


        $advances = PurchaseAdvancePayment::with('bank_account')->when(count($search_params) > 0 , function($query) use ($search_params) {

            $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
            
        })->where('auto_entry',0)->whereBetween('date',[$request->start_date,$request->end_date])->get();

        $purchases = Purchase::when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($request) {
            return $query->whereHas('items', function($q) use ($request){
                $q->whereIn('item_id',$request->item_id);
            });
        })->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Credit Asset = Credit
        
        $purchase_payments = PurchasePayment::with('bank_account')->when($request->customer_id, function($query) use ($request) {
            return $query->where('customer_id',$request->customer_id);
        })->when($request->item_id, function($query) use ($purchases) {
            return $query->whereHas('purchases', function($q) use ($purchases){
                $q->whereIn('purchase_id',array_column($purchases->toArray(),'id'));
            });
        })->when($request->tds_section_id, function($query) use ($request) {

            $query->whereRaw('id in ( select purchase_payment_id from purchase_payment_rel where tds_section_id = ? and deleted_at is null)',[$request->tds_section_id]);
            
        })->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Payment = Debit


        $journals = Journal::with('journal_main')->when(count($search_params) > 0 , function($query) use ($search_params) {

            $query->where('main_id',$search_params[1])->where('identifier',$search_params[0]);
            
        })->whereBetween('date',[$request->start_date,$request->end_date])->get();

       
        $from = Carbon::parse($request->start_date);
        $to = Carbon::parse($request->end_date);

        $i = 0;
        $report_array = array();

        
        
        $report_array[$i]['date'] = $from->format('Y-m-d');
        $report_array[$i]['reference'] = "Opening Balance On ".$from->format('d/m/Y');

        if($opening_balance >= 0)
        {
            $report_array[$i]['debit'] = "";
            $report_array[$i]['credit'] = abs($opening_balance);
            $report_array[$i]['type'] = "credit";
        }
        elseif($opening_balance < 0)
        {
            $report_array[$i]['debit'] = abs($opening_balance);
            $report_array[$i]['credit'] = "";
            $report_array[$i]['type'] = "debit";
        }
        
        
        
        $i++;
        
        $edit_access =  $this->checkReportEditAccess();
        for($d = $from; $d->lte($to); $d->addDay()) 
        {
            if(($request->input_gst == 1 || $request->output_gst == 1 || $request->gst == 1 || $request->input_tds == 1 || $request->output_tds || $request->tds == 1 || $request->tcs == 1 || $request->input_tcs == 1 || $request->output_tcs == 1 || $request->input_cgst == 1 || $request->input_sgst == 1 || $request->input_igst == 1 || $request->output_cgst == 1 || $request->output_sgst == 1 || $request->output_igst == 1))
            {
                if($request->input_gst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Output GST (Invoice No. ".$value->formatted_number."): - Rs.".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                            $report_array[$i]['against'] = $value->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "invoice";

                            $report_array[$i]['section'] = "invoice";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                            $report_array[$i]['status'] = $value->status;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    
                    foreach ($debit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Output GST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "debitnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach ($credit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = $value->igst > 0 ? "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- IGST : Rs. " .$value->igst: "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- CGST - Rs. ".$value['cgst']." , SGST - Rs. ".$value['sgst'];
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "creditnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->input_cgst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($value->cgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output CGST (Invoice No. ".$value->formatted_number."): - Rs.".$value->cgst;
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->cgst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "invoice";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    
                    foreach ($debit_notes as $key => $value) 
                    {
                        if($value->cgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Output CGST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".$value->cgst;
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] =  $value->cgst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "debitnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    foreach ($credit_notes as $key => $value) 
                    {
                        if($value->cgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                            
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output CGST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- CGST - Rs. ".$value['cgst'];
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] =  $value->cgst;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "creditnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }    
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->input_sgst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($value->sgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output SGST (Invoice No. ".$value->formatted_number."): - Rs.".$value->sgst;
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->sgst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "invoice";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    
                    foreach ($debit_notes as $key => $value) 
                    {
                        if($value->sgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Output SGST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".$value->sgst;
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] =  $value->sgst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "debitnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    foreach ($credit_notes as $key => $value) 
                    {
                        if($value->sgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                            
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output SGST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- SGST - Rs. ".$value['sgst'];
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] =  $value->sgst;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "creditnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }    
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->input_igst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($value->igst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output IGST (Invoice No. ".$value->formatted_number."): - Rs.".$value->igst;
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->igst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "invoice";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    
                    foreach ($debit_notes as $key => $value) 
                    {
                        if($value->igst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] ="Output IGST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".$value->igst;
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] =  $value->igst;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "debitnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    foreach ($credit_notes as $key => $value) 
                    {
                        if($value->igst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                            
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output IGST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- IGST - Rs. ".$value['igst'];
                                $report_array[$i]['against'] = $value->invoice->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['debit'] =  $value->igst;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "creditnote";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                       
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->output_gst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->is_taxable == 1)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = ($value->igst > 0 ? ("Input GST :-  IGST Rs.- " .$value->igst): ("Input GST :- CGST Rs.- ".$value['cgst']." , SGST Rs.- ".$value['sgst']));
                                $report_array[$i]['against'] = $value->number;
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "purchase";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['edit_access'] = $edit_access;	
                                $i++;
                            }
                            
                        }
                    }
                    
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type ;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                    
                }
                if($request->output_cgst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($value->cgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->is_taxable == 1)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Input CGST Rs.- " .$value->cgst;
                                    $report_array[$i]['against'] = $value->number;
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->cgst;
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "purchase";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['edit_access'] = $edit_access;	
                                    $i++;
                                }
                                
                            }
                        }
                        
                    }
                    
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                    
                }
                if($request->output_sgst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($value->sgst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->is_taxable == 1)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Input SGST Rs.- " .$value->cgst;
                                    $report_array[$i]['against'] = $value->number;
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->sgst;
                                    $report_array[$i]['type'] = "receipt";
                                    
                                    $report_array[$i]['section'] = "purchase";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['edit_access'] = $edit_access;	
                                    $i++;
                                }
                                
                            }
                        }
                        
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                    
                }
                if($request->output_igst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($value->igst > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                if($value->is_taxable == 1)
                                {
                                    $report_array[$i]['date'] = $d->format('Y-m-d');
                                    $report_array[$i]['reference'] = "Input IGST Rs.- " .$value->cgst;
                                    $report_array[$i]['against'] = $value->number;
                                    $report_array[$i]['description'] = $value->remarks;
                                    $report_array[$i]['credit'] = "";
                                    $report_array[$i]['debit'] = $value->igst;
                                    $report_array[$i]['type'] = "invoice";
                                    
                                    $report_array[$i]['section'] = "purchase";
                                    $report_array[$i]['section_id'] = $value->id;
                                    $report_array[$i]['section_type'] = "";
                                    $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                    $report_array[$i]['param'] = array();
                                    $report_array[$i]['status'] = $value->status;
                                    $report_array[$i]['edit_access'] = $edit_access;	
                                    $i++;
                                }
                                
                            }
                        }
                        
                    }
                    
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Journal Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = "journal";
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                    
                }
                if($request->gst == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Input GST (Invoice No. ".$value->formatted_number."): - Rs.".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                            $report_array[$i]['against'] = $value->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "journal";

                            $report_array[$i]['section'] = "invoice";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                            $report_array[$i]['status'] = $value->status;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->is_taxable == 1)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = ($value->igst > 0 ? ("Output GST :-  IGST Rs.- " .$value->igst): ("Output GST :- CGST Rs.- ".$value['cgst']." , SGST Rs.- ".$value['sgst']));
                                $report_array[$i]['against'] = $value->number;
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                                $report_array[$i]['type'] = "journal";
                                
                                $report_array[$i]['section'] = "purchase";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                            
                        }
                    }
                    foreach ($debit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Input GST (Debit Note No. ".$value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."): - Rs. ".($value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "journal";
                            
                            $report_array[$i]['section'] = "debitnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $i++;
                        }
                    }
                    foreach ($credit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                        // var_dump($value->invoice->formatted_number); exit;
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = $value->igst > 0 ? "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- IGST : Rs. " .$value->igst: "Output GST (Credit Note ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number."):- CGST - Rs. ".$value['cgst']." , SGST - Rs. ".$value['sgst'];
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] =  $value->igst > 0 ? $value->igst: ($value->cgst + $value->sgst);
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "creditnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $i++;
                        }
                    }
                }
                if($request->input_tds == 1)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($value->tds > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output TDS (Invoice No. ".$value->formatted_number."): - Rs.".$value->tds;
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->tds;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "invoice";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->output_tds == 1)
                {                 
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($purchase_payments as $key => $value) 
                    {
                        if($value->tds > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Input TDS -".$value->formatted_number." For Purchase (Dated ".implode(',',array_column($value->purchases->toArray(),'date')).",Reference No. = ".implode(',',array_column($value->purchases->toArray(),'number')).")";
                                $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['type'] = "receipt";
                                
                                $report_array[$i]['section'] = "purchase_payment";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                                $report_array[$i]['status'] = "";
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;

                                if($request->tds_section_id)
                                {
                                    $tds = 0;

                                    foreach ($value->purchases->toArray() as $key => $inv) 
                                    {
                                    if($inv['pivot']['tds_section_id'] == $request->tds_section_id)
                                    {
                                        $tds = $tds + $inv['pivot']['tds'];
                                    }
                                    }

                                    $report_array[$i]['debit'] = $tds;
                                }
                                else
                                    $report_array[$i]['debit'] = $value->tds;
                                $i++;
                            }
                        }
                        
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                    } 
                }
                if($request->input_tcs == 1)
                {
                   
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($value->tcs > 0)
                        {
                            if($d->format('Y-m-d') == $value->date)
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Output TCS (Invoice No. ".$value->formatted_number."): - Rs.".$value->tcs;
                                $report_array[$i]['against'] = $value->formatted_number;
                                $report_array[$i]['description'] = $value->note;
                                $report_array[$i]['credit'] = $value->tcs;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['type'] = "receipt";

                                $report_array[$i]['section'] = "invoice";
                                $report_array[$i]['section_id'] = $value->id;
                                $report_array[$i]['section_type'] = "";
                                $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                                $report_array[$i]['status'] = $value->status;
                                $report_array[$i]['param'] = array();
                                $report_array[$i]['edit_access'] = $edit_access;
                                $i++;
                            }
                        }
                        
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->journal_id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    

                    } 
                }
            }
            else
            {
                if(count($request->item_id) > 0)
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Refund On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Advance Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Invoice Created.-".$value->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] = $value->before_total;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "invoice";

                            $report_array[$i]['section'] = "invoice";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                            $report_array[$i]['status'] = $value->status;	
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    /*foreach ($payments as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Payment Received Ref.-".$value->formatted_number." For Invoice Reference (".implode(',',array_column($value->invoices->toArray(),'formatted_number')).")";
                            $report_array[$i]['against'] = array_column($value->invoices->toArray(),'formatted_number');
                            $report_array[$i]['description'] = $value->remarks;
                            
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "payment";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/payment/add-edit-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;

                            $gst = 0;

                            foreach ($value->invoices->toArray() as $key => $inv) 
                            {
                                $gst = $gst + $inv['igst'] > 0 ? $inv['igst'] : ($inv['cgst'] + $inv['sgst']);
                            }

                            $report_array[$i]['debit'] = $value->amount - $gst;
                            $i++;
                        }
                    }*/
                    foreach ($purchases as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Purchase Done Ref.-".$value->number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->number;
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = !empty($value->before_total) ? $value->before_total: $value->before_total;
                            $report_array[$i]['type'] = "purchase";
                            
                            $report_array[$i]['section'] = "purchase";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    /*foreach ($purchase_payments as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Purchase Payment Given Ref.-".$value->formatted_number." For Purchase (Dated ".implode(',',array_column($value->purchases->toArray(),'date')).",Reference No. = ".implode(',',array_column($value->purchases->toArray(),'number')).")";
                            $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                            $report_array[$i]['description'] = $value->remarks;
                           
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "purchase_payment";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;

                            $gst = 0;

                            foreach ($value->purchases->toArray() as $key => $inv) 
                            {
                                $gst = $gst + $inv['igst'] > 0 ? $inv['igst'] : ($inv['cgst'] + $inv['sgst']);
                            }
                            $report_array[$i]['credit'] = $value->amount - $gst;
                            $i++;
                        }
                    }*/

                    foreach ($debit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Debit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] = $value->before_total;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "debitnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }

                    foreach ($credit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                        // var_dump($value->invoice->formatted_number); exit;
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Credit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] = $value->before_total;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "creditnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                        
                    } 
                    
                }
                else
                {
                    foreach ($advances as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $bank_name = !empty($value->bank_account) ? $value->bank_account->display_name : "";
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Amount Debited From ".$bank_name."  On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Amount Debited To ".$bank_name."  On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "purchase_advance";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach ($invoices as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Invoice Created.-".$value->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] = $value->after_total;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "invoice";

                            $report_array[$i]['section'] = "invoice";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/invoice/add-edit-invoice/edit/".$value->id;
                            $report_array[$i]['status'] = $value->status;	
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach ($payments as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Payment Received Ref.-".$value->formatted_number." For Invoice Reference (".implode(',',array_column($value->invoices->toArray(),'formatted_number')).")";
                            $report_array[$i]['against'] = array_column($value->invoices->toArray(),'formatted_number');
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "payment";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/payment/add-edit-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach ($purchases as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Purchase Done Ref.-".$value->number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->number;
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = !empty($value->after_total) ? $value->after_total: $value->before_total;
                            $report_array[$i]['type'] = "purchase";
                            
                            $report_array[$i]['section'] = "purchase";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/purchase/add-edit-purchase/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }
                    foreach ($purchase_payments as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Purchase Payment Given From  Ref.-".$value->formatted_number." For Purchase (Dated ".implode(',',array_column($value->purchases->toArray(),'date')).",Reference No. = ".implode(',',array_column($value->purchases->toArray(),'number')).")";
                            $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "purchase_payment";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }

                    foreach ($debit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Debit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['debit'] = $value->after_total;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "debitnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/debitnote/add-edit-debitnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }

                    foreach ($credit_notes as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                        // var_dump($value->invoice->formatted_number); exit;
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] ="Credit Note Issued ". $value->formatted_number." Reference Invoice No - ". $value->invoice->formatted_number." Items - ".implode(',',array_column($value->items->toArray(),'name'));
                            $report_array[$i]['against'] = $value->invoice->formatted_number;
                            $report_array[$i]['description'] = $value->note;
                            $report_array[$i]['credit'] = $value->after_total;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['type'] = "receipt";
                            
                            $report_array[$i]['section'] = "creditnote";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = "";
                            $report_array[$i]['route'] = "/creditnote/add-edit-creditnote/edit/".$value->id;
                            $report_array[$i]['param'] = array();
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }
                    }

                    foreach ($cash_entries as $key => $value) 
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            if($value->type == 'debit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Cash Payment On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->amount;
                                $report_array[$i]['type'] = "debit";
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "Cash Received On - ".$d->format('d/m/Y');
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->amount;
                                $report_array[$i]['type'] = "credit";
                            }

                            $report_array[$i]['section'] = "cashbook";
                            $report_array[$i]['section_id'] = $value->id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/cashbook/add-edit-cashbook/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                            
                        }
                    }
                    foreach($journals as $key => $value)
                    {
                        if($d->format('Y-m-d') == $value->date)
                        {
                            $type = $value->journal_main->type == 'journal'?"Journal":"Account Voucher";

                            if($value->type == 'debit')
                            {
                                
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Debit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['credit'] = "";
                                $report_array[$i]['debit'] = $value->after_total;
                                $report_array[$i]['type'] =  $type;
                            }
                            elseif($value->type == 'credit')
                            {
                                $report_array[$i]['date'] = $d->format('Y-m-d');
                                $report_array[$i]['reference'] = "".$type." Credit Entry Remarks -".$value->remarks;
                                $report_array[$i]['against'] = "";
                                $report_array[$i]['description'] = $value->remarks;
                                $report_array[$i]['debit'] = "";
                                $report_array[$i]['credit'] = $value->after_total;
                                $report_array[$i]['type'] = $type;
                            }

                            $report_array[$i]['section'] = "journal";
                            $report_array[$i]['section_id'] = $value->journal_id;
                            $report_array[$i]['section_type'] = $value->type;
                            $report_array[$i]['route'] = "/journal/add-edit-journal/edit/".$value->id;
                            $report_array[$i]['param'] = array('type'=>$value->type);
                            $report_array[$i]['status'] = "";
                            $report_array[$i]['edit_access'] = $edit_access;
                            $i++;
                        }    
                        
                    } 

                }

                
            }
            
        }
       
        $request->input_gst = "";
        $request->output_gst = "";
        $request->input_cgst = "";
        $request->output_cgst = "";
        $request->input_sgst = "";
        $request->output_sgst = "";
        $request->input_igst = "";
        $request->output_igst = "";
        $request->customer_id = "";
        $request->item_id = "";
        $request->input_tcs = "";
        $request->output_tcs = "";
        $request->input_tds = "";
        $request->output_tds = ""; 

        return  $report_array;
      
    }
    public function profit_loss_report_pdf(Request $request)
    {
        $request->type = 'array';

        $data = $this->profit_loss_report($request);
        $left_array  =  $data['left'];
        $right_array  =  $data['right'];
        $print_data = array();
       
        if($invoice_account = InvoiceAccount::find(1))
        {
            $from = Carbon::parse($request->start_date);
            $to = Carbon::parse($request->end_date);

            $print_data['[START_DATE]'] = $from->format('d/m/Y');
            $print_data['[END_DATE]'] = $to->format('d/m/Y');

            $left_print_data_loop=array();
            $i=0;
            $left_item_str="";

            if(count($data['left']) > 0)
            {
                foreach ($data['left'] as $key => $value) 
                {
                   // $i++;
                   // $left_print_data_loop['[LEFTSLNO]']=$i;
                
                    $left_print_data_loop['[LEFTREFERENCE]']="<span style='font-weight:bold; float:left;'>".$value['reference']."</span>";
                    
                    $left_print_data_loop['[LEFTAMOUNT]']=number_format(floatval($value['amount']),2);
                    preg_match_all("~{[LEFTLOOP]+}(.*){\/[LEFTLOOP]+}~",$invoice_account->profit_loss_body,$matches);
    
                    $left_item_str .= $this->loop($matches,$left_print_data_loop);
                    $j = 0;
                    foreach ($value['children'] as $key1 => $value1) 
                    {
                       // $j++;
                       // $left_print_data_loop['[LEFTSLNO]']=$j;
                    
                        $left_print_data_loop['[LEFTREFERENCE]']="<span style='padding-left: 20px ; float:right; white-space: break-spaces;'>".$value1['reference']."</span>";
                        
                        $left_print_data_loop['[LEFTAMOUNT]']=number_format(floatval($value1['amount']),2);
                       
                        preg_match_all("~{[LEFTLOOP]+}(.*){\/[LEFTLOOP]+}~",$invoice_account->profit_loss_body,$matches);
    
                        $left_item_str .= $this->loop($matches,$left_print_data_loop);
                    }
                }
            }

            if(count($matches) > 0 && isset($matches[0][0]))
                $profit_loss_body =str_replace($matches[0][0], $left_item_str,$invoice_account->profit_loss_body);
            else
                $profit_loss_body = $invoice_account->profit_loss_body;

            $right_print_data_loop=array();
            $k=0;
            $right_item_str="";

            if(count($data['right']) > 0)
            {
                foreach ($data['right'] as $key => $value) 
                {
                    //$k++;
                    //$right_print_data_loop['[RIGHTSLNO]']=$i;
                
                    $right_print_data_loop['[RIGHTREFERENCE]']="<span style='font-weight:bold; float:left;'>".$value['reference']."</span>";
                    
                    $right_print_data_loop['[RIGHTAMOUNT]']=number_format(floatval($value['amount']),2);
                    preg_match_all("~{[RIGHTLOOP]+}(.*){\/[RIGHTLOOP]+}~",$invoice_account->profit_loss_body,$matches);
    
                    $right_item_str .= $this->loop($matches,$right_print_data_loop);
                    $l = 0;
                    foreach ($value['children'] as $key1 => $value1) 
                    {
                       // $l++;
                       // $right_print_data_loop['[RIGHTSLNO]']=$l;
                    
                        $right_print_data_loop['[RIGHTREFERENCE]']="<span style='padding-left: 20px ; float:right; white-space: break-spaces;'>".$value1['reference']."</span>";
                        
                        $right_print_data_loop['[RIGHTAMOUNT]']=number_format(floatval($value1['amount']),2);
                        
                        preg_match_all("~{[RIGHTLOOP]+}(.*){\/[RIGHTLOOP]+}~",$invoice_account->profit_loss_body,$matches1);
    
                        $right_item_str .= $this->loop($matches1,$right_print_data_loop);
                    }
                }
            }

            if(count($matches1) > 0 && isset($matches1[0][0]))
                $profit_loss_body =str_replace($matches1[0][0], $right_item_str,$profit_loss_body);
            else
                $profit_loss_body = $profit_loss_body;    

            $print_data['[RIGHT_TOTAL]'] = number_format($data['right_table_total'],2);
            $print_data['[LEFT_TOTAL]'] =  number_format($data['left_table_total'],2);  

            $profit_loss_body = $this->replace_variable($profit_loss_body,$print_data,$invoice_account->profit_loss_body);
			
            //Save The Final HTML to PDF
            $path = storage_path()."/report/profit-loss";
            if (!file_exists($path)) {
                 $this->createPath($path);
            }
            $fileName =  $path."/Profit-Loss-Report-".time().".pdf";

            PDF::loadHTML($profit_loss_body)->setPaper('a4', 'portrait')->setWarnings(false)->save($fileName);

            return  response()->file($fileName);   
        }
    }
    public function bankbook_report(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'bank_account_id'=>['required'],
            'start_date'=>['required'],
            'end_date'=>['required']

        ]);
        
        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            /*Calculation of Amount Before Start Date*/

            $payment_credit = Payment::where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->sum('amount'); //Credit

            $purchase_payment_debit = PurchasePayment::where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->sum('amount'); // Debit

            $contra_entry_credit = CashbookTransaction::where('identifier','bank')->where('main_id',$request->bank_account_id)->where('date','<',$request->start_date)->where('type','credit')->sum('amount'); // Credit

            $contra_entry_debit = CashbookTransaction::where('identifier','bank')->where('main_id',$request->bank_account_id)->where('type','debit')->where('date','<',$request->start_date)->sum('amount'); // Debit


            $advance_credit = PurchaseAdvancePayment::where('payment_type','bank')->where('auto_entry',0)->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->where('type','credit')->sum('amount'); //Credit

            $advance_debit = PurchaseAdvancePayment::where('payment_type','bank')->where('auto_entry',0)->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->where('type','debit')->sum('amount'); //Debit

            $voucher_debit = JournalMain::where('type','voucher')->where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->where('voucher_type','debit')->sum('amount'); //Debit

            $voucher_credit = JournalMain::where('type','voucher')->where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->where('date','<',$request->start_date)->where('voucher_type','credit')->sum('amount'); //Credit

            /*Bank Transactions Between Start Date and End Date */

            $payments = Payment::with('customer')->where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Credit

            $purchase_payments = PurchasePayment::with('customer')->where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->whereBetween('date',[$request->start_date,$request->end_date])->get(); // Debit


            $contra_entry = CashbookTransaction::with('main','bank_account')->where('identifier','bank')->where('main_id',$request->bank_account_id)->whereBetween('date',[$request->start_date,$request->end_date])->get();


            $advances = PurchaseAdvancePayment::where('payment_type','bank')->where('auto_entry',0)->where('bank_account_id',$request->bank_account_id)->whereBetween('date',[$request->start_date,$request->end_date])->get();

            $vouchers =  JournalMain::with('journals')->where('type','voucher')->where('payment_type','bank')->where('bank_account_id',$request->bank_account_id)->whereBetween('date',[$request->start_date,$request->end_date])->get();
            
            $opening = OpeningBalance::where('main_id',$request->bank_account_id)->where('identifier','bank')->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();

            $i = 0;
            $report_array = array();

            $from = Carbon::parse($request->start_date);
            $to = Carbon::parse($request->end_date);

            $opening_balance = (( floatval($payment_credit) + floatval($advance_credit) + floatval($contra_entry_credit) + floatval($voucher_credit)) - (floatval($purchase_payment_debit) + floatval($advance_debit) + floatval($contra_entry_debit) + floatval($voucher_debit)));

            if(isset($opening) && !empty($opening))
            {
                $opening_balance = $opening->type == 'debit' ? ((0 - $opening->amount) + $opening_balance) : ($opening->amount + $opening_balance);
            }

            $report_array = array();
            $report_array[$i]['date'] = $from->format('Y-m-d');
            $report_array[$i]['reference'] = "Opening Balance On ".$from->format('d/m/Y');


            if($opening_balance >= 0)
            {
                $report_array[$i]['debit'] = "";
                $report_array[$i]['credit'] = abs($opening_balance);
                $report_array[$i]['type'] = "credit";
            }
            elseif($opening_balance < 0)
            {
                $report_array[$i]['debit'] = abs($opening_balance);
                $report_array[$i]['credit'] = "";
                $report_array[$i]['type'] = "debit";
            }

            
            $i++;


           

            $edit_access =  $this->checkReportEditAccess();
            

            for($d = $from; $d->lte($to); $d->addDay()) 
            {

                foreach ($payments as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $report_array[$i]['reference'] = "Invoice Payment Received From ".$value->customer->full_name." Ref.-".$value->formatted_number." For Invoice Reference (".implode(',',array_column($value->invoices->toArray(),'formatted_number')).")";
                        $report_array[$i]['against'] = array_column($value->invoices->toArray(),'formatted_number');
                        $report_array[$i]['description'] = $value->remarks;
                        $report_array[$i]['credit'] = $value->amount;
                        $report_array[$i]['debit'] = "";
                        $report_array[$i]['type'] = "credit";
                        $report_array[$i]['amount'] = $value->amount;

                        $report_array[$i]['section'] = "payment";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/payment/add-edit-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                    }
                }

                foreach ($purchase_payments as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        $report_array[$i]['date'] = $d->format('Y-m-d');
                        $type = $value->type == "vendor" ? "Purchase":"Salary";
                        
                        if($value->type == 'vendor')
                             $report_array[$i]['reference'] = $type." Payment Given To ".$value->customer->full_name;
                        else
                            $report_array[$i]['reference'] = $type." Payment Given To ".$value->customer->full_name;

                        $report_array[$i]['against'] = array_column($value->purchases->toArray(),'number');
                        $report_array[$i]['description'] = $value->remarks;
                        $report_array[$i]['debit'] = $value->amount;
                        $report_array[$i]['credit'] = "";
                        $report_array[$i]['type'] = "debit";
                        
                        $report_array[$i]['amount'] = $value->amount;

                        $report_array[$i]['section'] = "purchase_payment";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = "";
                        $report_array[$i]['route'] = "/purchase-payment/add-edit-purchase-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array();
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                    }
                }

                foreach ($contra_entry as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {

                       
                        if(!empty($value->bank_account))
                          $bank_or_cash = $value->bank_account->display_name;
                        else
                          $bank_or_cash = "Cash";

                        if($value->type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Amount Transfered To ".$bank_or_cash." On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "debit";
                        }
                        elseif($value->type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Amount Received From ".$bank_or_cash." - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "credit";
                        }

                        $report_array[$i]['amount'] = $value->amount;
                        $report_array[$i]['section'] = "contra-entry";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/contra-entry/add-edit-contra-entry/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                        
                    }
                }

                foreach ($advances as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        if($value->type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Amount Refund To ".$value->item_name. " On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "debit";
                        }
                        elseif($value->type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Amount Received From ".$value->item_name." On - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "credit";
                        }

                        $report_array[$i]['amount'] = $value->amount;
                        $report_array[$i]['section'] = "purchase_advance";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/purchase-advance-payment/add-edit-purchase-advance-payment/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                        
                    }
                }

                foreach ($vouchers as $key => $value) 
                {
                    if($d->format('Y-m-d') == $value->date)
                    {
                        if($value->voucher_type == 'debit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Account Voucher Debited For ".implode(',',array_column($value->journals->toArray(),'item_name') ) ." - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['credit'] = "";
                            $report_array[$i]['debit'] = $value->amount;
                            $report_array[$i]['type'] = "debit";
                        }
                        elseif($value->voucher_type == 'credit')
                        {
                            $report_array[$i]['date'] = $d->format('Y-m-d');
                            $report_array[$i]['reference'] = "Account Voucher Credited For ".implode(',',array_column($value->journals->toArray(),'item_name') ) ." - ".$d->format('d/m/Y');
                            $report_array[$i]['against'] = "";
                            $report_array[$i]['description'] = $value->remarks;
                            $report_array[$i]['debit'] = "";
                            $report_array[$i]['credit'] = $value->amount;
                            $report_array[$i]['type'] = "credit";
                        }

                        $report_array[$i]['section'] = "account-voucher";
                        $report_array[$i]['section_id'] = $value->id;
                        $report_array[$i]['section_type'] = $value->type;
                        $report_array[$i]['route'] = "/account-voucher/add-edit-account-voucher/edit/".$value->id;
                        $report_array[$i]['param'] = array('type'=>$value->type);
                        $report_array[$i]['edit_access'] = $edit_access;
                        $i++;
                        
                    }
                }
            }

            if($request->return_type == 'array')
                return $report_array;
            else
                return response(['data' => $report_array,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        }
        
    }
    public function bankbook_report_pdf(Request $request)
    {
        $request->return_type = 'array';

        $return_array  = $this->bankbook_report($request);
        $print_data = array();

        if($invoice_account =InvoiceAccount::find(1))
        {

            //Ledger Item Name
            $print_data['[BANK_NAME]'] = $request->bank_name;
            //Set Account Data Variables
            $print_data = array_merge($print_data,$this->set_account_data($invoice_account,'invoice'));  

            if(count($return_array) > 0)
            {
                $print_data_loop=array();
                $i=0;
                $item_str="";
                $total_debit = 0;
                $total_credit = 0;

                foreach ($return_array as  $value) 
                {   
                    
                    $i++;

                    $print_data_loop['[SLNO]']=$i;
                    
                    $print_data_loop['[REFERENCE]']=$value['reference'];
                    $print_data_loop['[DATE]']=Carbon::parse($value['date'])->format('d/m/Y');
                    $print_data_loop['[TYPE]']=ucfirst($value['type']);
                    $print_data_loop['[DEBIT]']=number_format(floatval($value['debit']),2);
                    $print_data_loop['[CREDIT]'] = number_format(floatval($value['credit']),2);
                    
                    preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$invoice_account->bankbook_body,$matches);

                    $item_str .= $this->loop($matches,$print_data_loop);
                        
                    $total_debit=$total_debit+floatval($value['debit']);
                    $total_credit=$total_credit+floatval($value['credit']);
                }

                if(count($matches) > 0 && isset($matches[0][0]))
                    $bankbook_body =str_replace($matches[0][0], $item_str,$invoice_account->bankbook_body);
                else
                    $bankbook_body = $invoice_account->bankbook_body;

                $print_data['[TOTAL_CREDIT]'] = number_format($total_credit,2);
                $print_data['[TOTAL_DEBIT]'] = number_format($total_debit,2);

                
                if(($total_credit - $total_debit) >= 0)
                {
                    $print_data['[CLOSING_BALANCE_DEBIT]'] = number_format(abs($total_credit - $total_debit),2);
                    $print_data['[CLOSING_BALANCE_CREDIT]'] = "";

                    $print_data['[GRAND_DEBIT]'] = number_format($total_debit + abs($total_credit - $total_debit),2);
                    $print_data['[GRAND_CREDIT]'] = number_format($total_credit,2);
                }
                if(($total_credit - $total_debit) < 0)
                {
                    $print_data['[CLOSING_BALANCE_CREDIT]'] = number_format(abs($total_credit - $total_debit),2);
                    $print_data['[CLOSING_BALANCE_DEBIT]'] = "";

                    $print_data['[GRAND_CREDIT]'] = number_format($total_credit + abs($total_credit - $total_debit),2);
                    $print_data['[GRAND_DEBIT]'] = number_format($total_debit,2);
                }     

                $from = Carbon::parse($request->start_date);
                $to = Carbon::parse($request->end_date);

                $print_data['[START_DATE]'] = $from->format('d/m/Y');
                $print_data['[END_DATE]'] = $to->format('d/m/Y');

                $bankbook_body = $this->replace_variable($bankbook_body,$print_data,$invoice_account->bankbook_body);

                //Save The Final HTML to PDF
                $path = storage_path()."/report/bankbook";
                if (!file_exists($path)) {
                    $this->createPath($path);
                }
                $fileName =  $path."/".$request->bank_name."-Bankbook-Report-".time().".pdf";

                PDF::loadHTML($bankbook_body)->setPaper('a4', 'portrait')->setWarnings(false)->save($fileName);

                return  response()->file($fileName);

            }
        }
    }
    public function balance_sheet(Request $request)
    {
        $validator = Validator::make($request->all(), [

            'start_date'=>['required'],
            'end_date'=>['required']

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            $report_array = array();
            $i = 0;
            $fiscal_year = FiscalYear::whereRaw('((start_date between ? and ? ) or (end_date between ? and ? ))',[$request->start_date,$request->end_date,$request->start_date,$request->end_date])->first();

            
            $igst_rec = abs($this->gst_ledger($request,'igst_2'));
            $cgst_rec = abs($this->gst_ledger($request,'cgst_2'));
            $sgst_rec = abs($this->gst_ledger($request,'sgst_2'));
 
            $sgst_pay = abs($this->gst_ledger($request,'sgst_1'));
            $cgst_pay = abs($this->gst_ledger($request,'cgst_1'));
            $igst_pay = abs($this->gst_ledger($request,'igst_1'));
            $gst_in_out_total = 0; 
            if(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec) < 0)
            {
                $gst_in_out_total = abs(floatval(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec)));
            }
            elseif(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec) > 0)
            {
                $gst_in_out_total = -floatval(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec));
            }    
            $gst_key = 0;

            
            $tds_pay = $this->profit_loss_ledger($request,'tds_1');
            $tds_payable_arr = array();
            $tds_pay_cr = 0;
            $tds_pay_dr = 0;
            $tds_pay_total = 0;
            foreach ($tds_pay as $tdskey => $value) 
            {
                $tds_payable_arr[$tdskey]['reference'] = $value['reference'];
                $tds_payable_arr[$tdskey]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) :  sprintf('%0.2f',floatval($value['credit']));
                $tds_payable_arr[$tdskey]['children'] = array(); 

                $tds_pay_cr =  $tds_pay_cr + floatval($value['credit']);
                $tds_pay_dr =  $tds_pay_dr + floatval($value['debit']);
            }

            if(floatval($tds_pay_cr - $tds_pay_dr) > 0)
                $tds_pay_total = sprintf('%0.2f',-floatval($tds_pay_cr - $tds_pay_dr));
            else if(floatval($tds_pay_cr - $tds_pay_dr) < 0)
                $tds_pay_total = sprintf('%0.2f',abs(floatval($tds_pay_cr - $tds_pay_dr)));

            $tcs_pay = $this->profit_loss_ledger($request,'tcs_1');
            $tcs_payable_arr = array();
            $tcs_pay_cr = 0;
            $tcs_pay_dr = 0;
            $tcs_pay_total = 0;
            foreach ($tcs_pay as $tcskey => $value) 
            {
                $tcs_payable_arr[$tcskey]['reference'] = $value['reference'];
                $tcs_payable_arr[$tcskey]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) :  sprintf('%0.2f',floatval($value['credit']));
                $tcs_payable_arr[$tcskey]['children'] = array(); 

                $tcs_pay_cr =  $tcs_pay_cr + floatval($value['credit']);
                $tcs_pay_dr =  $tcs_pay_dr + floatval($value['debit']);
            }
            
            if(floatval($tds_pay_cr - $tds_pay_dr) > 0)
                $tcs_pay_total = sprintf('%0.2f',-floatval($tcs_pay_cr - $tcs_pay_dr));
            else if(floatval($tds_pay_cr - $tds_pay_dr) < 0)
                $tcs_pay_total = sprintf('%0.2f',abs(floatval($tcs_pay_cr - $tcs_pay_dr)));

            
            $liablity_items = Item::whereHas('categories', function($q) use ($request){
                $q->where('categories.id',9);
            })->where('status',1)->get();
            
            $liability_arr = array();
            if(count($liablity_items) > 0)
            {
                foreach($liablity_items as $ikey => $item)
                {
                    $liablity_items_ret = $this->profit_loss_ledger($request,'item_'.$item->id);

                    $in_journal_total_cr = 0;
                    $in_journal_total_dr = 0;
                    $in_journal_arr = array();
                    
                    foreach ($liablity_items_ret as $key => $value) {
                       $in_journal_arr[$key]['reference'] = $value['reference'];
                       $in_journal_arr[$key]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) :  sprintf('%0.2f',floatval($value['credit']));
                       $in_journal_arr[$key]['children'] = array();

                       $in_journal_total_cr =  $in_journal_total_cr + floatval($value['credit']);
                       $in_journal_total_dr =  $in_journal_total_dr + floatval($value['debit']);
                    }


                    $liability_arr[$ikey]['reference'] = $item->name;

                    if(floatval($in_journal_total_cr - $in_journal_total_dr) > 0)
                        $liability_arr[$ikey]['amount'] = sprintf('%0.2f',-floatval($in_journal_total_cr - $in_journal_total_dr));
                    elseif(floatval($in_journal_total_cr - $in_journal_total_dr) <= 0)
                        $liability_arr[$ikey]['amount'] = sprintf('%0.2f',abs(floatval($in_journal_total_cr - $in_journal_total_dr)));

                    $liability_arr[$ikey]['children'] = $in_journal_arr;
                }
            }    
            
            $creditors = Customer::where('category','Creditor')->where('status',1)->get();
            $sundry_total_cr = 0;
            $sundry_total_dr = 0;
            $sundry_arr = array();
            foreach($creditors as $crkey => $creditor)
            {
                
                $sundry_creditors_ret = $this->profit_loss_ledger($request,"customer_".$creditor->id);
                $sundry_cr_arr = array();
                $sundry_cr = 0;
                $sundry_dr = 0;
               
                foreach ($sundry_creditors_ret as $key => $value) 
                {
                    $sundry_cr_arr[$key]['reference'] = $value['reference'];
                    $sundry_cr_arr[$key]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) :  sprintf('%0.2f',floatval($value['credit']));
                    $sundry_cr_arr[$key]['children'] = array();
                    $sundry_cr =  $sundry_cr +  floatval($value['credit']);
                    $sundry_dr =  $sundry_dr +  floatval($value['debit']);
                }

                $sundry_arr[$crkey]['reference'] = $creditor->full_name;
                $sundry_arr[$crkey]['amount'] = sprintf('%0.2f',floatval( $sundry_cr -  $sundry_dr ));
                $sundry_arr[$crkey]['children'] = $sundry_cr_arr;

                if( floatval( $sundry_cr -  $sundry_dr ) > 0)
                    $sundry_total_cr = $sundry_total_cr - floatval( $sundry_cr -  $sundry_dr );
                elseif( floatval( $sundry_cr -  $sundry_dr ) <= 0)
                    $sundry_total_cr = $sundry_total_cr + abs(floatval( $sundry_cr -  $sundry_dr ));     
            }    
            array_push( $liability_arr ,array('reference'=>'GST Input & Output','amount'=> $gst_in_out_total,'children'=>array()));
            array_push( $liability_arr ,array('reference'=>'Sundry Creditors','amount'=>   sprintf('%0.2f',$sundry_total_cr) ,'children'=>$sundry_arr));
            array_push( $liability_arr ,array('reference'=>'TDS Payable','amount'=>sprintf('%0.2f',$tds_pay_total),'children'=>$tds_payable_arr));
            array_push( $liability_arr ,array('reference'=>'TCS Payable','amount'=>sprintf('%0.2f',$tcs_pay_total),'children'=>$tcs_payable_arr));
            
           
            $liability_total = 0;
            foreach($liability_arr as $lib){
                $liability_total =  $liability_total + floatval($lib['amount']);
            }
            
            $asset_arr = array();

            $request->return_type = 'array';

            $bank_accounts = BankAccount::where('status',1)->get();
            $bank_total = 0;

            foreach($bank_accounts as $bkey => $bank)
            {
               

                $total_bankbook_credit = 0;
                $total_bankbook_debit = 0;

                $request->merge(['bank_account_id' => $bank->id]);
                $bank_book_data = $this->bankbook_report($request);
               
                foreach ($bank_book_data as $key => $value) {
                    if($value['type'] == 'credit')
                        $total_bankbook_credit = $total_bankbook_credit + $value['credit'];
                    elseif($value['type'] == 'debit')
                        $total_bankbook_debit = $total_bankbook_debit + $value['debit'];    
                }
                if(($total_bankbook_credit - $total_bankbook_debit) >= 0)
                {
                    $bank_account_arr[$bkey]['reference'] = $bank->display_name;
                    $bank_account_arr[$bkey]['amount'] = floatval(($total_bankbook_credit - $total_bankbook_debit));
                    $bank_account_arr[$bkey]['children'] = array();
                    $bank_total = $bank_total + ($total_bankbook_credit - $total_bankbook_debit);
                }
                else
                {
                    $bank_account_arr[$bkey]['reference'] = $bank->display_name;
                    $bank_account_arr[$bkey]['amount'] = floatval(($total_bankbook_credit - $total_bankbook_debit));
                    $bank_account_arr[$bkey]['children'] = array();
                    $bank_total = $bank_total + ($total_bankbook_credit - $total_bankbook_debit);
                }

            }
            
            $cash_book_data = $this->cashbook_report($request);

            $total_cashbook_credit = 0;
            $total_cashbook_debit = 0;

            foreach ($cash_book_data as $key => $value) {
                if($value['type'] == 'credit')
                    $total_cashbook_credit = $total_cashbook_credit + $value['credit'];
                elseif($value['type'] == 'debit')
                    $total_cashbook_debit = $total_cashbook_debit + $value['debit'];    
            }
            if(($total_cashbook_credit - $total_cashbook_debit) >= 0)
            {
                $cash_array[0]['reference'] = "Cash-In-Hand";  
                $cash_array[0]['amount'] = floatval($total_cashbook_credit - $total_cashbook_debit);
                $cash_array[0]['children'] = array();
            }
            else
            {
                $cash_array[0]['reference'] = "Cash-In-Hand";  
                $cash_array[0]['amount'] = floatval($total_cashbook_credit - $total_cashbook_debit);
                $cash_array[0]['children'] = array();
            }
            
            $sens_hotel = Customer::find(26);
            $sens_hotels_ret = $this->profit_loss_ledger($request,'customer_'.$sens_hotel->id);

            $sen_hotels = array();
            $sen_hotel_cr = 0;
            $sen_hotel_dr = 0;

            foreach ($sens_hotels_ret as $key => $value) {
                $sen_hotels[$key]['reference'] = $value['reference'];
                $sen_hotels[$key]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) :  sprintf('%0.2f',floatval($value['credit']));
                $sen_hotels[$key]['children'] = array();
                $sen_hotel_cr =  $sen_hotel_cr + floatval($value['credit']);
                $sen_hotel_dr =  $sen_hotel_dr + floatval($value['debit']);
            }

            if(floatval($sen_hotel_cr - $sen_hotel_dr) > 0)
                $sen_hotel_total = -floatval($sen_hotel_cr - $sen_hotel_dr);
            elseif(floatval($sen_hotel_cr - $sen_hotel_dr) <= 0)
                $sen_hotel_total = abs(floatval($sen_hotel_cr - $sen_hotel_dr)); 

            array_push( $asset_arr ,array('reference'=> $sens_hotel->full_name,'amount'=>sprintf('%0.2f',$sen_hotel_total),'children'=>$sen_hotels));
            array_push( $asset_arr ,array('reference'=>'Cash In Hand','amount'=>sprintf('%0.2f',floatval($total_cashbook_credit - $total_cashbook_debit)),'children'=>$cash_array));
            array_push( $asset_arr ,array('reference'=>'Bank Accounts','amount'=>sprintf('%0.2f',floatval($bank_total)),'children'=>$bank_account_arr));


            $right_report_array = array();
            $r = 0;
            $right_report_array[$r]['reference']="Current Liabilities";
            $right_report_array[$r]['amount']= $liability_total;
            $right_report_array[$r]['children']=$liability_arr;
            $r++;

            $right_report_array[$r]['reference']="Current Asset";
            $right_report_array[$r]['amount']= bcsub(floatval(($total_cashbook_credit - $total_cashbook_debit) + $sen_hotel_total +  $bank_total ),0,2);
            $right_report_array[$r]['children']=$asset_arr;
            $r++;

            $right_side_total = sprintf('%0.2f',$sen_hotel_total + floatval($total_cashbook_credit - $total_cashbook_debit) +  $bank_total + $liability_total);
            /* Left Side */
            $left_report_array = array();
            $request->type = "array";
            
            $current_return_pl = $this->profit_loss_report($request);
            
            $last_fiscal_year = FiscalYear::where('start_date',date('Y-04-01', strtotime($request->start_date . " -1 year") ))->first();
            $request->start_date = $last_fiscal_year->start_date;
            $request->end_date = $last_fiscal_year->end_date;
           

            $last_return_pl = $this->profit_loss_report($request);
            $pl_array = array();
            $j = 0;
            if($last_return_pl['nett_profit'] == 0)
            {
                $opening_balance=OpeningBalance::where('main_id',0)->where('identifier','profit')->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();

                if(!empty($opening_balance))
                {
                    $pl_array[$j]['reference']="Opening Balance";
                    $pl_array[$j]['amount'] = floatval($opening_balance->amount);
                    $pl_array[$j]['children'] = array(); 
                    $last_return_pl['nett_profit'] = floatval($opening_balance->amount);
                }
                else
                {
                    $pl_array[$j]['reference']="Opening Balance";
                    $pl_array[$j]['amount'] = 0;
                    $pl_array[$j]['children'] = array();
                }
                $j++;
            }
            else
            {
                if($last_return_pl['nett_profit'] > 0)
                {
                    $pl_array[$j]['reference']="Opening Balance";
                    $pl_array[$j]['amount'] = $last_return_pl['nett_profit'];
                    $pl_array[$j]['children'] = array();
                    $j++;
                }
                
            }

            $pl_array[$j]['reference']="Current Period";
            $pl_array[$j]['amount'] = floatval($current_return_pl['nett_profit']);
            $pl_array[$j]['children'] = array();
            $j++;

            $k = 0;
            $left_report_array[$k]['reference']="Profit & Loss A/C";
            $left_report_array[$k]['amount']=bcsub(floatval(round($current_return_pl['nett_profit'] + $last_return_pl['nett_profit'],2)),0,2);
            $left_report_array[$k]['children']=$pl_array;
            $left_side_total = 0;
            $left_side_total = bcsub(floatval($current_return_pl['nett_profit'] + $last_return_pl['nett_profit']),0,2);

            if($request->is_pdf == 1)
                return array('left'=>$left_report_array, 'right'=>$right_report_array,'right_table_total'=>$right_side_total,'left_table_total'=>$left_side_total);
            else
                return response(['data' => array('left'=>$left_report_array, 'right'=>$right_report_array,'right_table_total'=>$right_side_total,'left_table_total'=>$left_side_total),'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        }  
    }

    public function balance_sheet_pdf(Request $request)
    {
        $request->return_type = 'array';
        $request->is_pdf = 1;

        $data = $this->balance_sheet($request);
        $left_array  =  $data['left'];
        $right_array  =  $data['right'];
        $print_data = array();
       
        if($invoice_account = InvoiceAccount::find(1))
        {
            $from = Carbon::parse($request->start_date);
            $to = Carbon::parse($request->end_date);

            $print_data['[START_DATE]'] = $from->format('d/m/Y');
            $print_data['[END_DATE]'] = $to->format('d/m/Y');

            $left_print_data_loop=array();
            $i=0;
            $left_item_str="";

            if(count($data['left']) > 0)
            {
                foreach ($data['left'] as $key => $value) 
                {
                   // $i++;
                   // $left_print_data_loop['[LEFTSLNO]']=$i;
                
                    $left_print_data_loop['[LEFTREFERENCE]']="<span style='font-weight:bold; float:left;'>".$value['reference']."</span>";
                    
                    $left_print_data_loop['[LEFTAMOUNT]']=number_format(floatval($value['amount']),2);
                    preg_match_all("~{[LEFTLOOP]+}(.*){\/[LEFTLOOP]+}~",$invoice_account->balance_sheet_body,$matches);
    
                    $left_item_str .= $this->loop($matches,$left_print_data_loop);
                    $j = 0;
                    foreach ($value['children'] as $key1 => $value1) 
                    {
                       // $j++;
                       // $left_print_data_loop['[LEFTSLNO]']=$j;
                    
                        $left_print_data_loop['[LEFTREFERENCE]']="<span style='padding-left: 20px ; float:right; white-space: break-spaces;'>".$value1['reference']."</span>";
                        
                        $left_print_data_loop['[LEFTAMOUNT]']=number_format(floatval($value1['amount']),2);
                       
                        preg_match_all("~{[LEFTLOOP]+}(.*){\/[LEFTLOOP]+}~",$invoice_account->balance_sheet_body,$matches);
    
                        $left_item_str .= $this->loop($matches,$left_print_data_loop);
                    }
                }
            }

            if(count($matches) > 0 && isset($matches[0][0]))
                $balance_sheet_body =str_replace($matches[0][0], $left_item_str,$invoice_account->balance_sheet_body);
            else
                $balance_sheet_body = $invoice_account->balance_sheet_body;

            $right_print_data_loop=array();
            $k=0;
            $right_item_str="";

            if(count($data['right']) > 0)
            {
                foreach ($data['right'] as $key => $value) 
                {
                    //$k++;
                    //$right_print_data_loop['[RIGHTSLNO]']=$i;
                
                    $right_print_data_loop['[RIGHTREFERENCE]']="<span style='font-weight:bold;float: left;'>".$value['reference']."</span>";
                    
                    $right_print_data_loop['[RIGHTAMOUNT]']=number_format(floatval($value['amount']),2);
                    preg_match_all("~{[RIGHTLOOP]+}(.*){\/[RIGHTLOOP]+}~",$invoice_account->balance_sheet_body,$matches);
    
                    $right_item_str .= $this->loop($matches,$right_print_data_loop);
                    $l = 0;
                    foreach ($value['children'] as $key1 => $value1) 
                    {
                       // $l++;
                       // $right_print_data_loop['[RIGHTSLNO]']=$l;
                    
                        $right_print_data_loop['[RIGHTREFERENCE]']="<span style='padding-left: 20px ; float:right; white-space: break-spaces;'>".$value1['reference']."</span>";
                        
                        $right_print_data_loop['[RIGHTAMOUNT]']=number_format(floatval($value1['amount']),2);
                        
                        preg_match_all("~{[RIGHTLOOP]+}(.*){\/[RIGHTLOOP]+}~",$invoice_account->balance_sheet_body,$matches1);
    
                        $right_item_str .= $this->loop($matches1,$right_print_data_loop);
                    }
                }
            }

            if(count($matches1) > 0 && isset($matches1[0][0]))
                $balance_sheet_body =str_replace($matches1[0][0], $right_item_str,$balance_sheet_body);
            else
                $balance_sheet_body = $balance_sheet_body;    

            $print_data['[RIGHT_TOTAL]'] = number_format($data['right_table_total'],2);
            $print_data['[LEFT_TOTAL]'] =  number_format($data['left_table_total'],2);  

            $balance_sheet_body = $this->replace_variable($balance_sheet_body,$print_data,$invoice_account->balance_sheet_body);

            //Save The Final HTML to PDF
            $path = storage_path()."/report/balance-sheet";
            if (!file_exists($path)) {
                 $this->createPath($path);
            }
            $fileName =  $path."/Balance-Sheet-Report-".time().".pdf";

            PDF::loadHTML($balance_sheet_body)->setPaper('a4', 'portrait')->setWarnings(false)->save($fileName);

            return  response()->file($fileName);   
        }
    }
    public function bank_realization_report(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date'=>['required'],
            'end_date'=>['required']

        ]);
        
        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
           

            $is_realization = $request->is_realization == true ? 1:0;

            $payments = Payment::with('account','fiscal_year','customer','invoices','files','bank_account')->when($request->bank_account_id, function($query) use ($request) {
                return $query->where('bank_account_id',$request->bank_account_id);
            })->where('is_realization',$is_realization)->whereBetween('date',[$request->start_date,$request->end_date])->get(); //Credit

            $purchase_payments = PurchasePayment::with('account','fiscal_year','customer','purchases','files','bank_account')->when($request->bank_account_id, function($query) use ($request) {
                return $query->where('bank_account_id',$request->bank_account_id);
            })->where('is_realization',$is_realization)->whereBetween('date',[$request->start_date,$request->end_date])->get(); // Debit


            $contra_entry = CashbookTransaction::with('account','fiscal_year','main')->when($request->bank_account_id, function($query) use ($request) {
                return $query->where('main_id',$request->bank_account_id);
            })->where('is_realization',$is_realization)->whereBetween('date',[$request->start_date,$request->end_date])->get();


            $advances = PurchaseAdvancePayment::with('account','fiscal_year','customer','files','bank_account')->when($request->bank_account_id, function($query) use ($request) {
                return $query->where('bank_account_id',$request->bank_account_id);
            })->where('auto_entry',0)->where('is_realization',$is_realization)->whereBetween('date',[$request->start_date,$request->end_date])->get();


            $vouchers = JournalMain::with('account','fiscal_year','files','bank_account','journals')->when($request->bank_account_id, function($query) use ($request) {
                return $query->where('bank_account_id',$request->bank_account_id);
            })->where('is_realization',$is_realization)->whereBetween('date',[$request->start_date,$request->end_date])->get();
            
            return response(['data' => array('payments'=>$payments,'purchase_payments'=>$purchase_payments,'contra_entry'=>$contra_entry,'advances'=>$advances,'vouchers'=>$vouchers),'success'=>true,'message' => 'Data Retrived Successfully'], 200);
            
        }    
    }

    public function bank_realization_update(Request $request,$id)
    {
        $validator = Validator::make($request->all(), [
            
            //'is_realization'=>['required'],
            'section'=>['required'],
            //'realization_date'=>['required']  

        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            if($request->section == 'payment')
            {
                $payment = Payment::findOrFail($id);
                
                DB::beginTransaction();
                try {
            
                    $payment->update($request->except(['invoice','number','date','invoice_account_id','fiscal_year_id','payment']));
                    DB::commit();
            
                    return response(['data' => new PaymentResource($payment),'success'=>true,'message' => 'Payment Updated Successfully'], 200);
                }
                catch (Exception $ex) {

                    DB::rollBack();
                    return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
                }
            }
            else if($request->section == 'purchase_payment')
            {
                $payment=PurchasePayment::findOrFail($id);
                DB::beginTransaction();
                try {


                    $payment->update($request->except(['purchase','number','date','invoice_account_id','fiscal_year_id','section']));

                    DB::commit();
            
                    return response(['data' => new PurchasePaymentResource($payment),'success'=>true,'message' => 'Purchase Payment Updated Successfully'], 200);
                }
                catch (Exception $ex) {

                    DB::rollBack();
                    return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
                }
            }
            else if($request->section == 'contra_entry')
            {
                $transaction=CashbookTransaction::findOrFail($id);
                DB::beginTransaction();
                try {
                    $transaction->update($request->except(['date','invoice_account_id','section']));

                    DB::commit();
            
                    return response(['data' => new CashbookResource($transaction),'success'=>true,'message' => 'Transaction Updated Successfully'], 200);
                }
                catch (Exception $ex) {

                    DB::rollBack();
                    return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
                }    
            }
            else if($request->section == 'purchase_advance')
            {
                $payment=PurchaseAdvancePayment::findOrFail($id);
                
                DB::beginTransaction();
                try {
                    
                    $payment->update($request->except(['date','invoice_account_id','fiscal_year_id','section']));
                    
                    DB::commit();
            
                    return response(['data' => new PurchaseAdvancePaymentResource($payment),'success'=>true,'message' => 'Advance Payment Updated Successfully'], 200);
                }
                catch (Exception $ex) {

                    DB::rollBack();
                    return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
                }    
            }
            else if($request->section == 'account_voucher')
            {
                $payment=JournalMain::findOrFail($id);
                
                DB::beginTransaction();
                try {
                    
                    $payment->update($request->except(['date','invoice_account_id','fiscal_year_id','section']));
                    
                    DB::commit();
            
                    return response(['data' => new JournalMainResource($payment),'success'=>true,'message' => 'Account Voucher Updated Successfully'], 200);
                }
                catch (Exception $ex) {

                    DB::rollBack();
                    return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
                }    
            }      
        }
    }
    public function customer_due_report(Request $request)
    {
       $customers = Customer::withCount([
            'invoices AS invoice_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(after_total),2) as invoice_total"));
            },
            'payments AS payment_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(IFNULL(amount,0) + IFNULL(tcs,0) + IFNULL(tds,0) + IFNULL(ods,0)),2) as payment_total"));
            },
            'debit_notes AS debit_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(after_total),2) as debit_total"));
            },
            'credit_notes AS credit_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(after_total),2) as credit_total"));
            },
            'cash_entries_credit AS cash_credit_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(amount),2) as cash_credit_total"));
            },
            'cash_entries_debit AS cash_debit_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(amount),2) as cash_debit_total"));
            },
            'advances_credit AS advances_credit_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(amount),2) as advances_credit_total"));
            },
            'advances_debit AS advances_debit_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(amount),2) as advances_debit_total"));
            },
            'purchases AS purchase_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(after_total),2) as purchase_total"));
            },
            'purchase_payments AS purchase_payment_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(IFNULL(amount,0) + IFNULL(tcs,0) + IFNULL(tds,0) + IFNULL(ods,0)),2) as purchase_payment_total"));
            },
            'journal_credit AS journal_credit_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(after_total),2) as journal_credit_total"));
            },
            'journal_debit AS journal_debit_total' => function ($query) {
                $query->select(DB::raw("ROUND(SUM(after_total),2) as journal_debit_total"));
            }
        ])->get();
          
        $customers = collect($customers->toArray())->map(function ($item){
             $item['closing_balance'] = (($item['payment_total'] + $item['credit_total'] + $item['cash_credit_total'] + $item['advances_credit_total'] + $item['purchase_total'] + $item['journal_credit_total']) - ($item['invoice_total'] + $item['debit_total'] + $item['cash_debit_total'] + $item['advances_debit_total'] + $item['purchase_payment_total'] + $item['journal_debit_total']));
             return $item;
        });
        
        return response(['data' => $customers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function json_reports(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date'=>['required'],
            'end_date'=>['required'],
            'type'=>['required']

        ]);
        
        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            $invoice_account = InvoiceAccount::find(1);
            $end_date = Carbon::parse($request->end_date);

            if($request->type == 'gstr-3b')
            {
               
                
                $osup_det = Invoice::select(DB::raw('SUM(before_total) as total_before,SUM(cgst) as total_cgst,SUM(sgst) as total_sgst,SUM(igst) as total_igst,SUM(case when igst > 0 then igst else cgst+sgst end) as total_tax'))->whereBetween('date',[$request->start_date,$request->end_date])->get();


                $report_data = array (
                    'gstin' => $invoice_account->gstin,
                    'ret_period' => $end_date->format('mY'),
                    'sup_details' => 
                    array (
                      'osup_det' => 
                      array (
                        'txval'=>round(($osup_det[0]->total_before + $osup_det[0]->total_tax),2),
                        'iamt'=>round($osup_det[0]->total_igst,2),
                        'camt'=>round($osup_det[0]->total_cgst,2),
                        'samt'=>round($osup_det[0]->total_sgst,2),
                        'csamt'=>0 
                      ),
                      'osup_zero' => 
                      array (
                        'txval' => 0.0,
                        'iamt' => 0.0,
                        'camt' => 0.0,
                        'samt' => 0.0,
                        'csamt' => 0.0,
                      ),
                      'osup_nil_exmp' => 
                      array (
                        'txval' => 0.0,
                        'iamt' => 0.0,
                        'camt' => 0.0,
                        'samt' => 0.0,
                        'csamt' => 0.0,
                      ),
                      'isup_rev' => 
                      array (
                        'txval' => 0.0,
                        'iamt' => 0.0,
                        'camt' => 0.0,
                        'samt' => 0.0,
                        'csamt' => 0.0,
                      ),
                      'osup_nongst' => 
                      array (
                        'txval' => 0.0,
                        'iamt' => 0.0,
                        'camt' => 0.0,
                        'samt' => 0.0,
                        'csamt' => 0.0,
                      ),
                    ),
                    'itc_elg' => 
                    array (
                      'itc_avl' => 
                      array (
                        0 => 
                        array (
                          'ty' => 'IMPG',
                          'iamt' => 0.0,
                          'camt' => 0.0,
                          'samt' => 0.0,
                          'csamt' => 0.0,
                        ),
                        1 => 
                        array (
                          'ty' => 'IMPS',
                          'iamt' => 0.0,
                          'camt' => 0.0,
                          'samt' => 0.0,
                          'csamt' => 0.0,
                        ),
                        2 => 
                        array (
                          'ty' => 'ISRC',
                          'iamt' => 0.0,
                          'camt' => 0.0,
                          'samt' => 0.0,
                          'csamt' => 0.0,
                        ),
                        3 => 
                        array (
                          'ty' => 'ISD',
                          'iamt' => 0.0,
                          'camt' => 0.0,
                          'samt' => 0.0,
                          'csamt' => 0.0,
                        ),
                        4 => 
                        array (
                          'ty' => 'OTH',
                          'iamt' => 0.0,
                          'camt' => 0.0,
                          'samt' => 0.0,
                          'csamt' => 0.0,
                        ),
                      ),
                      'itc_rev' => 
                      array (
                        0 => 
                        array (
                          'ty' => 'RUL',
                          'iamt' => 0.0,
                          'camt' => 0.0,
                          'samt' => 0.0,
                          'csamt' => 0.0,
                        ),
                        1 => 
                        array (
                          'ty' => 'OTH',
                          'iamt' => 0.0,
                          'camt' => 0.0,
                          'samt' => 0.0,
                          'csamt' => 0.0,
                        ),
                      ),
                      'itc_net' => 
                      array (
                        'iamt' => 0.0,
                        'camt' => 0.0,
                        'samt' => 0.0,
                        'csamt' => 0.0,
                      ),
                      'itc_inelg' => 
                      array (
                        0 => 
                        array (
                          'ty' => 'RUL',
                          'iamt' => 0.0,
                          'camt' => 0.0,
                          'samt' => 0.0,
                          'csamt' => 0.0,
                        ),
                        1 => 
                        array (
                          'ty' => 'OTH',
                          'iamt' => 0.0,
                          'camt' => 0.0,
                          'samt' => 0.0,
                          'csamt' => 0.0,
                        ),
                      ),
                    ),
                    'inward_sup' => 
                    array (
                      'isup_details' => 
                      array (
                        0 => 
                        array (
                          'ty' => 'GST',
                          'inter' => 0.0,
                          'intra' => 0.0,
                        ),
                        1 => 
                        array (
                          'ty' => 'NONGST',
                          'inter' => 0.0,
                          'intra' => 0.0,
                        ),
                      ),
                    ),
                    'intr_ltfee' => 
                    array (
                      'intr_details' => 
                      array (
                        'iamt' => 0.0,
                        'camt' => 0.0,
                        'samt' => 0.0,
                        'csamt' => 0.0,
                      ),
                      'ltfee_details' => 
                      array (
                      ),
                    ),
                    'inter_sup' => 
                    array (
                      'unreg_details' => 
                      array (
                      ),
                      'comp_details' => 
                      array (
                      ),
                      'uin_details' => 
                      array (
                      ),
                    ),
                );

               
                
            }
            elseif($request->type == 'gstr-1')
            {
                $report_data = array (
                    'gstin' => $invoice_account->gstin,
                    'fp' => $end_date->format('mY'),
                    'gt' => 0 ,
                    'cur_gt'=> 0
                ); 
                
                $customer_invoices = Customer::whereHas('invoices', function($q) use ($request){
                        $q->whereBetween('date',[$request->start_date,$request->end_date]);
                     })->with([
                    'invoices' => function ($q) use ($request){
                        $q->whereBetween('date',[$request->start_date,$request->end_date]);

                },'invoices.items'])->get()->toArray();
                
               $b2b = array();
               $b2cs = array(); 
               $i = 0;
               $j = 0;

               foreach($customer_invoices as $key => $customer)
               {
                   if(!empty($customer['gstin']))
                   {
                        $b2b[$i]['ctin'] = $customer['gstin'];

                        foreach($customer['invoices'] as $k1 => $inv)
                        {
                            $b2b[$i]['inv'][$k1]['inum'] = $inv['formatted_number'];
                            $b2b[$i]['inv'][$k1]['idt'] = Carbon::parse($inv['date'])->format('d-m-Y');
                            $b2b[$i]['inv'][$k1]['val'] = round(($inv['before_total'] + $inv['cgst'] + $inv['sgst'] + $inv['igst']),2) ;
                            
                            $place_of_supply_gst_code=State::where('name',$inv['place_of_supply'])->first();
                            
                            if($place_of_supply_gst_code)
                                $b2b[$i]['inv'][$k1]['pos'] =$place_of_supply_gst_code->gst_code; 
                            
                            $b2b[$i]['inv'][$k1]['rchrg'] = "N";
                            
                            foreach($inv['items'] as $k2 => $item)
                            {
                                $b2b[$i]['inv'][$k1]['itms'][$k2]['num'] = ($k2 + 1);
                                $b2b[$i]['inv'][$k1]['itms'][$k2]['itm_det']['txval'] = $item['pivot']['after_total'];
                                $b2b[$i]['inv'][$k1]['itms'][$k2]['itm_det']['rt'] = $inv['igst'] > 0 ? $item['pivot']['igst'] : ($item['pivot']['cgst'] + $item['pivot']['sgst']);
                                
                                if($inv['igst'] > 0)
                                {
                                    $b2b[$i]['inv'][$k1]['itms'][$k2]['itm_det']['iamt'] = $item['pivot']['tax'];
                                }
                                else
                                {
                                    $b2b[$i]['inv'][$k1]['itms'][$k2]['itm_det']['camt'] = round($item['pivot']['tax']/2,2);
                                    $b2b[$i]['inv'][$k1]['itms'][$k2]['itm_det']['samt'] = round($item['pivot']['tax']/2,2);
                                    
                                }
                                $b2b[$i]['inv'][$k1]['itms'][$k2]['itm_det']['csamt']=0;
                            }
                            $b2b[$i]['inv'][$k1]['inv_typ']="R";
                        }

                        $i++;
                   }
                   if(empty($customer['gstin']))
                   {
                        foreach($customer['invoices'] as $k1 => $inv)
                        {
                            $total_tax_percent = 0;
                            foreach($inv['items'] as $k2 => $item)
                            {
                                if($inv['igst'] > 0)
                                {
                                    $total_tax_percent =  $total_tax_percent +  $item['igst'];
                                }
                                else
                                {
                                    $total_tax_percent =  $total_tax_percent + ($item['cgst'] + $item['igst']);
                                }
                            }

                            $b2cs[$j]['rt'] = round($total_tax_percent / count($inv['items']));
                            $b2cs[$j]['sply_ty'] = $inv['igst'] > 0 ? "INTER":"INTRA";
                            $place_of_supply_gst_code=State::where('name',$inv['place_of_supply'])->first();
                            
                            if($place_of_supply_gst_code)
                                $b2cs[$j]['pos'] = $place_of_supply_gst_code->gst_code;
                            
                            $b2cs[$j]['typ'] = "E";
                          
                            $b2cs[$j]['txval'] = round(($inv['before_total'] + $inv['cgst'] + $inv['sgst'] + $inv['igst']),2); 
                            
                            if($inv['igst'] > 0)
                            {
                                $b2cs[$j]['iamt'] = $inv['igst'];
                            }
                            else
                            {
                                $b2cs[$j]['camt'] = $inv['cgst'];
                                $b2cs[$j]['samt'] = $inv['sgst']; 
                            }
                            $b2cs[$j]['csamt'] = 0;

                            $j++;
                        }
                   }
               }

                $items = Item::whereHas('invoices', function($q) use ($request){
                    $q->whereBetween('date',[$request->start_date,$request->end_date]);
                })->withCount([
                'invoices as invoice_before_total' => function ($query) use ($request){
                        $query->select(DB::raw('SUM(invoices.before_total) as total_before'))->whereBetween('invoices.date',[$request->start_date,$request->end_date]);
                },'invoices as invoice_tax_total' => function ($query) use ($request){
                    $query->select(DB::raw('SUM(case when invoices.igst > 0 then invoices.igst else invoices.cgst+invoices.sgst end) as total_tax'))->whereBetween('invoices.date',[$request->start_date,$request->end_date]);
                },'invoices as invoice_igst_total' => function ($query) use ($request){
                    $query->select(DB::raw('SUM(invoices.igst) as total_igst'))->whereBetween('invoices.date',[$request->start_date,$request->end_date]);
                },'invoices as invoice_cgst_total' => function ($query) use ($request){
                    $query->select(DB::raw('SUM(invoices.cgst) as total_cgst'))->whereBetween('invoices.date',[$request->start_date,$request->end_date]);
                },'invoices as invoice_sgst_total' => function ($query) use ($request){
                    $query->select(DB::raw('SUM(invoices.sgst) as total_sgst'))->whereBetween('invoices.date',[$request->start_date,$request->end_date]);
                },'invoices as invoice_total_qty' => function ($query) use ($request){
                    $query->select(DB::raw('SUM(invoice_items.quantity) as total_qty'))->whereBetween('invoices.date',[$request->start_date,$request->end_date]);
                }])->get()->toArray();
               
               $hsn = array();
               foreach( $items as $ikey => $item)
               {
                    $hsn['data'][$ikey]['num'] = ($ikey + 1);
                    $hsn['data'][$ikey]['hsn_sc'] = $item['hsn_sac_code'];
                    $hsn['data'][$ikey]['desc'] = $item['name'];
                    $hsn['data'][$ikey]['uqc'] = "OTH";
                    $hsn['data'][$ikey]['qty'] = 0;
                    $hsn['data'][$ikey]['val'] = round($item['invoice_before_total'],2);
                    $hsn['data'][$ikey]['txval'] = round(($item['invoice_before_total'] + $item['invoice_tax_total']),2);
                    $hsn['data'][$ikey]['iamt'] = round($item['invoice_igst_total'],2);
                    $hsn['data'][$ikey]['camt'] = round($item['invoice_cgst_total'],2);
                    $hsn['data'][$ikey]['samt'] = round($item['invoice_sgst_total'],2);
                    $hsn['data'][$ikey]['csamt'] = 0;
               } 
               
               $report_data['b2b'] =  $b2b;
               $report_data['b2cs'] =  $b2cs;
               $report_data['hsn'] =  $hsn;
            }
            return response(['data' => $report_data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        }
    }

    public function cash_flow_report(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date'=>['required'],
            'end_date'=>['required']

        ]);
        
        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            $report_array = array();
            $months = array();
            $startDate = $request->start_date;
            $endDate = $request->end_date;
            while (strtotime($startDate) <= strtotime($endDate)) {
                $months[] = array(
                    'year' => date('Y', strtotime($startDate)),
                    'month' => date('m', strtotime($startDate)),
                );

                // Set date to 1 so that new month is returned as the month changes.
                $startDate = date('01 M Y', strtotime($startDate . '+ 1 month'));
            }

            
            if(count($months) > 0)
            {
                foreach ($months as $key => $month) 
                {
                    $payment_credit = Payment::whereRaw('MONTH(date) = ? and YEAR(date) = ?',[$month['month'],$month['year']])->sum('amount'); //Credit

                    $purchase_payment_debit = PurchasePayment::whereRaw('MONTH(date) = ? and YEAR(date) = ?',[$month['month'],$month['year']])->sum('amount'); // Debit


                    $advance_credit = PurchaseAdvancePayment::whereRaw('MONTH(date) = ? and YEAR(date) = ?',[$month['month'],$month['year']])->where('auto_entry',0)->where('type','credit')->sum('amount'); //Credit

                    $advance_debit = PurchaseAdvancePayment::whereRaw('MONTH(date) = ? and YEAR(date) = ?',[$month['month'],$month['year']])->where('auto_entry',0)->where('type','debit')->sum('amount'); //Debit

                    $voucher_debit = JournalMain::where('type','voucher')->whereRaw('MONTH(date) = ? and YEAR(date) = ?',[$month['month'],$month['year']])->where('voucher_type','debit')->sum('amount'); //Debit

                    $voucher_credit = JournalMain::where('type','voucher')->whereRaw('MONTH(date) = ? and YEAR(date) = ?',[$month['month'],$month['year']])->where('voucher_type','credit')->sum('amount');  //Credit

                   $report_array[$key]['month'] =  date('F', mktime(0, 0, 0, $month['month'], 10));
                   $report_array[$key]['inflow'] =  $payment_credit + $advance_credit + $voucher_credit ;
                   $report_array[$key]['outflow'] =    $voucher_debit + $advance_debit + $purchase_payment_debit;
                   $report_array[$key]['nett_flow'] = $report_array[$key]['inflow'] - $report_array[$key]['outflow'];
                }
                
            }

            if($request->return_type == 'array')
                return $report_array;
            else
                return response(['data' => $report_array,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
        }
    }

    public function cash_flow_report_pdf(Request $request)
    {
        $request->return_type = 'array';

        $return_array  = $this->cash_flow_report($request);
        $print_data = array();

        if($invoice_account =InvoiceAccount::find(1))
        {

            //Ledger Item Name
            $print_data['[ITEM_NAME]'] = $request->item_name;
            //Set Account Data Variables
            $print_data = array_merge($print_data,$this->set_account_data($invoice_account,'invoice'));  

            if(count($return_array) > 0)
            {
                $print_data_loop=array();
                $i=0;
                $item_str="";
                $total_inflow = 0;
                $total_outflow = 0;
                $total_nettflow = 0;

                foreach ($return_array as  $value) 
                {   
                    
                    $i++;
                    
                    $print_data_loop['[MONTH]']=$value['month'];
                   
                    $print_data_loop['[INFLOW]']=number_format(floatval($value['inflow']),2);
                    $print_data_loop['[OUTFLOW]'] = number_format(floatval($value['outflow']),2);
                    $print_data_loop['[NETTFLOW]'] = number_format(floatval($value['nett_flow']),2);

                    preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$invoice_account->cashflow_body,$matches);

                    $item_str .= $this->loop($matches,$print_data_loop);
                        
                    $total_inflow=$total_inflow+floatval($value['inflow']);
                    $total_outflow=$total_outflow+floatval($value['outflow']);
                    $total_nettflow=$total_nettflow+floatval($value['nett_flow']);
                }

                if(count($matches) > 0 && isset($matches[0][0]))
                    $cashflow_body =str_replace($matches[0][0], $item_str,$invoice_account->cashflow_body);
                else
                    $cashflow_body = $invoice_account->cashflow_body;

                $print_data['[TOTAL_INFLOW]'] = number_format($total_inflow,2);
                $print_data['[TOTAL_OUTFLOW]'] = number_format($total_outflow,2);
                $print_data['[TOTAL_NETTFLOW]'] = number_format($total_nettflow,2);
                
                 

                $from = Carbon::parse($request->start_date);
                $to = Carbon::parse($request->end_date);

                $print_data['[START_DATE]'] = $from->format('d/m/Y');
                $print_data['[END_DATE]'] = $to->format('d/m/Y');

                $cashflow_body = $this->replace_variable($cashflow_body,$print_data,$invoice_account->cashflow_body);

                //Save The Final HTML to PDF
                $path = storage_path()."/report/cashflow";
                if (!file_exists($path)) {
                    $this->createPath($path);
                }
                $fileName =  $path."/"."Cash-Flow-Report-".time().".pdf";

                PDF::loadHTML($cashflow_body)->setPaper('a4', 'portrait')->setWarnings(false)->save($fileName);

                return  response()->file($fileName);

            }
        }
    }

    public function fund_flow_report_old(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date'=>['required'],
            'end_date'=>['required']

        ]);
        
        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            $return_array = array();

            $current_start_date = $request->start_date;
            $current_end_date = $request->end_date;

            $last_fiscal_year = FiscalYear::where('start_date',date('Y-04-01', strtotime($request->start_date . " -1 year") ))->first();
            $last_start_date = $last_fiscal_year->start_date;
            $last_end_date = $last_fiscal_year->end_date;

            $return_array[0]['item'] = "Current Assets";
            $return_array[0]['closing_balance'] = $this->assets($request,$current_start_date,$current_end_date);
            $return_array[0]['opening_balance'] = $this->assets($request,$last_start_date,$last_end_date);
            $return_array[0]['cap_increase'] =  $return_array[0]['closing_balance'] -  $return_array[0]['opening_balance'];

            $return_array[1]['item'] = "Current Liabilities";
            $return_array[1]['closing_balance'] = $this->liabilities($request,$current_start_date,$current_end_date);
            $return_array[1]['opening_balance'] = $this->liabilities($request,$last_start_date,$last_end_date);
            $return_array[1]['cap_increase'] =  $return_array[1]['closing_balance'] -  $return_array[1]['opening_balance'];

            if($request->return_data_type == 'array')
                return $return_array;
            else
                return response(['data' => $return_array,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

        }
    }

    public function fund_flow_report(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date'=>['required'],
            'end_date'=>['required']

        ]);
        
        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        else
        {
            $return_array = array();
            $current_start_date = $request->start_date;
            $current_end_date = $request->end_date;

            $months = array();
            $startDate = $request->start_date;
            $endDate = $request->end_date;
            while (strtotime($startDate) <= strtotime($endDate)) {
                $months[] = array(
                    'year' => date('Y', strtotime($startDate)),
                    'month' => date('m', strtotime($startDate)),
                );

                // Set date to 1 so that new month is returned as the month changes.
                $startDate = date('01 M Y', strtotime($startDate . '+ 1 month'));
            }

            if(count($months) > 0)
            {
                foreach ($months as $key => $month) 
                {
                   
                    $last_month['month'] = $month['month'] - 1;
                    $last_month['year'] = $month['year'];
                    

                    if($key == 0)
                    {
                        $return_array[$key]['month'] = date('F', mktime(0, 0, 0, $month['month'], 10));
                        $return_array[$key]['opening_balance'] = $this->asset_minus_liability($request,$last_month,$current_start_date, $current_end_date);  //opening balance
                        $return_array[$key]['closing_balance'] = $this->asset_minus_liability($request,$month,$current_start_date, $current_end_date);  //closing
                        $return_array[$key]['fund_flow'] = $return_array[$key]['closing_balance'] - $return_array[$key]['opening_balance'];
                    }
                    else if($key > 0)
                    {
                        $return_array[$key]['month'] = date('F', mktime(0, 0, 0, $month['month'], 10));
                        $return_array[$key]['opening_balance'] =  $return_array[$key - 1]['closing_balance']; // opening (last index closing)
                        $return_array[$key]['closing_balance'] = $this->asset_minus_liability($request,$month,$current_start_date, $current_end_date); //closing
                        $return_array[$key]['fund_flow'] = $return_array[$key]['closing_balance'] - $return_array[$key]['opening_balance'];
                    }
                    
                   
                }
            }    
            if($request->return_data_type == 'array')
                return $return_array;
            else
                return response(['data' => $return_array,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

        }
    }
    public function fund_flow_report_pdf(Request $request)
    {
   
        $return_array  = json_decode($request->transactions,true);
        $print_data = array();

        if($invoice_account =InvoiceAccount::find(1))
        {

           
            //Set Account Data Variables
            $print_data = array_merge($print_data,$this->set_account_data($invoice_account,'invoice'));  

            if(count($return_array) > 0)
            {
                $print_data_loop=array();
                $i=0;
                $item_str="";
                $total_opening_balance = 0;
                $total_closing_balance = 0;
                $total_fund_flow = 0;

                foreach ($return_array as  $value) 
                {   
                    
                    $i++;
                    
                    $print_data_loop['[MONTH]']=$value['month'];
                   
                    $print_data_loop['[OPENING_BALANCE]']=number_format(floatval($value['opening_balance']),2);
                    $print_data_loop['[CLOSING_BALANCE]'] = number_format(floatval($value['closing_balance']),2);
                    $print_data_loop['[FUND_FLOW]'] = number_format(floatval($value['fund_flow']),2);

                    preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$invoice_account->fundflow_body,$matches);

                    $item_str .= $this->loop($matches,$print_data_loop);
                        
                    $total_opening_balance=$total_opening_balance+floatval($value['opening_balance']);
                    $total_closing_balance=$total_closing_balance+floatval($value['closing_balance']);
                    $total_fund_flow=$total_fund_flow+floatval($value['fund_flow']);
                }

                if(count($matches) > 0 && isset($matches[0][0]))
                    $fundflow_body =str_replace($matches[0][0], $item_str,$invoice_account->fundflow_body);
                else
                    $fundflow_body = $invoice_account->fundflow_body;

                $print_data['[TOTAL_OPENING_BALANCE]'] = number_format($return_array[0]['opening_balance'],2);
                $print_data['[TOTAL_CLOSING_BALANCE]'] = number_format($return_array[count($return_array)-1]['closing_balance'],2);
                $print_data['[TOTAL_FUND_FLOW]'] = number_format($total_fund_flow,2);
                
               

                $from = Carbon::parse($request->start_date);
                $to = Carbon::parse($request->end_date);

                $print_data['[START_DATE]'] = $from->format('d/m/Y');
                $print_data['[END_DATE]'] = $to->format('d/m/Y');

                $fundflow_body = $this->replace_variable($fundflow_body,$print_data,$invoice_account->fundflow_body);

                //Save The Final HTML to PDF
                $path = storage_path()."/report/fundflow";
                if (!file_exists($path)) {
                    $this->createPath($path);
                }
                $fileName =  $path."/"."Fund-Flow-Report-".time().".pdf";

                PDF::loadHTML($fundflow_body)->setPaper('a4', 'portrait')->setWarnings(false)->save($fileName);

                return  response()->file($fileName);

            }
        }
    }
    public function fund_flow_report_pdf_old(Request $request)
    {
        $request->return_data_type = 'array';

        $return_array  = $this->fund_flow_report($request);
        $print_data = array();

        if($invoice_account =InvoiceAccount::find(1))
        {

           
            //Set Account Data Variables
            $print_data = array_merge($print_data,$this->set_account_data($invoice_account,'invoice'));  

            if(count($return_array) > 0)
            {
                $print_data_loop=array();
                $i=0;
                $item_str="";
                $total_opening_balance = 0;
                $total_closing_balance = 0;
                $total_cap_increase = 0;

                foreach ($return_array as  $value) 
                {   
                    
                    $i++;
                    
                    $print_data_loop['[ITEM]']=$value['item'];
                   
                    $print_data_loop['[OPENING_BALANCE]']=number_format(floatval($value['opening_balance']),2);
                    $print_data_loop['[CLOSING_BALANCE]'] = number_format(floatval($value['closing_balance']),2);
                    $print_data_loop['[CAP_INCREASE]'] = number_format(floatval($value['cap_increase']),2);

                    preg_match_all("~{[LOOP]+}(.*){\/[LOOP]+}~",$invoice_account->fundflow_body,$matches);

                    $item_str .= $this->loop($matches,$print_data_loop);
                        
                    $total_opening_balance=$total_opening_balance+floatval($value['opening_balance']);
                    $total_closing_balance=$total_closing_balance+floatval($value['closing_balance']);
                    $total_cap_increase=$total_cap_increase+floatval($value['cap_increase']);
                }

                if(count($matches) > 0 && isset($matches[0][0]))
                    $fundflow_body =str_replace($matches[0][0], $item_str,$invoice_account->fundflow_body);
                else
                    $fundflow_body = $invoice_account->fundflow_body;

                $print_data['[TOTAL_OPENING_BALANCE]'] = number_format($total_opening_balance,2);
                $print_data['[TOTAL_CLOSING_BALANCE]'] = number_format($total_closing_balance,2);
                $print_data['[TOTAL_CAP_INCREASE]'] = number_format($total_cap_increase,2);
                
                $print_data['[TOTAL_NET_PROFIT]'] =  number_format(($total_closing_balance - $total_opening_balance),2);

                $print_data['[PROFIT_LOSS]'] = ($total_closing_balance - $total_opening_balance) > 0 ? "Profit":"Loss";

                $from = Carbon::parse($request->start_date);
                $to = Carbon::parse($request->end_date);

                $print_data['[START_DATE]'] = $from->format('d/m/Y');
                $print_data['[END_DATE]'] = $to->format('d/m/Y');

                $fundflow_body = $this->replace_variable($fundflow_body,$print_data,$invoice_account->fundflow_body);

                //Save The Final HTML to PDF
                $path = storage_path()."/report/fundflow";
                if (!file_exists($path)) {
                    $this->createPath($path);
                }
                $fileName =  $path."/"."Fund-Flow-Report-".time().".pdf";

                PDF::loadHTML($fundflow_body)->setPaper('a4', 'portrait')->setWarnings(false)->save($fileName);

                return  response()->file($fileName);

            }
        }
    }

    public function asset_minus_liability(Request $request,$month, $current_start_date, $current_end_date)
    {
        // echo $this->liabilities($request, '2021-04-01','2021-10-31'); echo "--";
        // echo $this->assets($request, '2021-04-01','2021-10-31'); exit;
        // echo $this->assets($request, '2021-04-01','2021-10-31') - abs($this->liabilities($request, '2021-04-01','2021-10-31')); exit;
        $current_fiscal_year = FiscalYear::whereRaw('(? between start_date and end_date or ? between start_date and end_date)',[$current_start_date,$current_end_date])->first();
       
       // DB::enableQueryLog();
        $calculated_fiscal_year = FiscalYear::whereRaw('(? between start_date and end_date or ? between start_date and end_date)',[date(''.($month['year']-1).'-'.sprintf("%02d", $month['month']).'-01'),date(''.$month['year'].'-'.sprintf("%02d", $month['month']).'-t')])->first();
        //dd(DB::getQueryLog());
        // echo date(''.$month['year'].'-'.sprintf("%02d", $month['month']).'-01'); echo "---"; echo date(''.$month['year'].'-'.sprintf("%02d", $month['month']).'-t');
        // echo $current_fiscal_year->name; echo "---";
        // echo $calculated_fiscal_year->name;
        // echo "<br>";
        if($current_fiscal_year->id == $calculated_fiscal_year->id)
        {
            //date(''.$month['year'].'-04-01')


            $asset_minus_liability = $this->assets($request, date('Y-04-01',strtotime($current_fiscal_year->start_date)),date(''.$month['year'].'-'.sprintf("%02d",$month['month']).'-t')) + $this->liabilities($request, date('Y-04-01',strtotime($current_fiscal_year->start_date)),date(''.$month['year'].'-'.sprintf("%02d",$month['month']).'-t'));
        }
        else
        {
            $request->start_date = $calculated_fiscal_year->start_date;
            $request->end_date = $calculated_fiscal_year->end_date;
            $request->type = "array";

            $return_pl = $this->profit_loss_report($request);
            
            if($return_pl['nett_profit'] == 0)
            {
                $opening_balance=OpeningBalance::where('main_id',0)->where('identifier','profit')->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();

                if(!empty($opening_balance))
                {
                    if($opening_balance->type == 'credit')
                    {
                        
                        $asset_minus_liability  = floatval($opening_balance->amount);
                    }
                    elseif($opening_balance->type == 'debit')
                    {
                        
                        $asset_minus_liability  = -floatval($opening_balance->amount);
                    }
                }
                else
                {
                   
                    $asset_minus_liability  = floatval(0);
                }
                
            }
            else
            {
                $asset_minus_liability  = $return_pl['nett_profit'];
               
            }
        }

        // echo 'First Date    = ' . date(''.$month['year'].'-'.$month['month'].'-01') . '<br />';
        // echo 'Last Date     = ' . date(''.$month['year'].'-'.$month['month'].'-t')  . '<br />';ho 
        //echo date(''.$month['year'].'-'.sprintf("%02d", $month['month']).'-01'); exit;
        // echo date(''.$month['year'].'-'.sprintf("%02d", $month['month']).'-01');
        // echo "<br>";
        // echo date(''.$month['year'].'-'.sprintf("%02d", $month['month']).'-t');
        // exit;
        // echo $this->assets($request,date(''.$month['year'].'-'.sprintf("%02d", $month['month']).'-01'),date(''.$month['year'].'-'.sprintf("%02d", $month['month']).'-t'));exit;
        // $asset_minus_liability = $this->assets($request,date(''.$month['year'].'-'.$month['month'].'-01'),date(''.$month['year'].'-'.$month['month'].'-t')) - $this->liabilities($request,date(''.$month['year'].'-'.$month['month'].'-01'),date(''.$month['year'].'-'.$month['month'].'-t'));

        // if($asset_minus_liability == 0)
        // {
        //     $opening_balance=OpeningBalance::where('main_id',0)->where('identifier','profit')->whereRaw('(date <= ? or ?)',[date(''.$month['year'].'-'.$month['month'].'-01'),date(''.$month['year'].'-'.$month['month'].'-t')])->orderBy('date','desc')->first();

        //         if(!empty($opening_balance))
        //         {
        //             if($opening_balance->type == 'credit')
        //             {
                        
        //                 $asset_minus_liability  = floatval($opening_balance->amount);
        //             }
        //             elseif($opening_balance->type == 'debit')
        //             {
                        
        //                 $asset_minus_liability  = -floatval($opening_balance->amount);
        //             }
        //         }
        //         else
        //         {
                   
        //             $asset_minus_liability  = floatval(0);
        //         }
        // }
        // echo $asset_minus_liability; exit;
        $request->start_date = "";
        $request->end_date = "";
        return  $asset_minus_liability;
    }

    public function liabilities(Request $request,$start_date,$end_date)
    {
        $request->start_date = $start_date;
        $request->end_date = $end_date;

        $igst_rec = abs($this->gst_ledger($request,'igst_2'));
        $cgst_rec = abs($this->gst_ledger($request,'cgst_2'));
        $sgst_rec = abs($this->gst_ledger($request,'sgst_2'));

        $sgst_pay = abs($this->gst_ledger($request,'sgst_1'));
        $cgst_pay = abs($this->gst_ledger($request,'cgst_1'));
        $igst_pay = abs($this->gst_ledger($request,'igst_1'));
        $gst_in_out_total = 0; 
        if(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec) < 0)
        {
            $gst_in_out_total = abs(floatval(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec)));
        }
        elseif(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec) > 0)
        {
            $gst_in_out_total = -floatval(($sgst_pay + $cgst_pay + $igst_pay) - ($igst_rec +  $cgst_rec + $sgst_rec));
        }    
        $gst_key = 0;

        $tds_pay = $this->profit_loss_ledger($request,'tds_1');
        $tds_payable_arr = array();
        $tds_pay_cr = 0;
        $tds_pay_dr = 0;
        $tds_pay_total = 0;
        foreach ($tds_pay as $tdskey => $value) 
        {
            $tds_payable_arr[$tdskey]['reference'] = $value['reference'];
            $tds_payable_arr[$tdskey]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) :  sprintf('%0.2f',floatval($value['credit']));
            $tds_payable_arr[$tdskey]['children'] = array(); 

            $tds_pay_cr =  $tds_pay_cr + floatval($value['credit']);
            $tds_pay_dr =  $tds_pay_dr + floatval($value['debit']);
        }

        if(floatval($tds_pay_cr - $tds_pay_dr) > 0)
            $tds_pay_total = sprintf('%0.2f',-floatval($tds_pay_cr - $tds_pay_dr));
        else if(floatval($tds_pay_cr - $tds_pay_dr) < 0)
            $tds_pay_total = sprintf('%0.2f',abs(floatval($tds_pay_cr - $tds_pay_dr)));

        $tcs_pay = $this->profit_loss_ledger($request,'tcs_1');
        $tcs_payable_arr = array();
        $tcs_pay_cr = 0;
        $tcs_pay_dr = 0;
        $tcs_pay_total = 0;
        foreach ($tcs_pay as $tcskey => $value) 
        {
            $tcs_payable_arr[$tcskey]['reference'] = $value['reference'];
            $tcs_payable_arr[$tcskey]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) :  sprintf('%0.2f',floatval($value['credit']));
            $tcs_payable_arr[$tcskey]['children'] = array(); 

            $tcs_pay_cr =  $tcs_pay_cr + floatval($value['credit']);
            $tcs_pay_dr =  $tcs_pay_dr + floatval($value['debit']);
        }
        
        if(floatval($tds_pay_cr - $tds_pay_dr) > 0)
            $tcs_pay_total = sprintf('%0.2f',-floatval($tcs_pay_cr - $tcs_pay_dr));
        else if(floatval($tds_pay_cr - $tds_pay_dr) < 0)
            $tcs_pay_total = sprintf('%0.2f',abs(floatval($tcs_pay_cr - $tcs_pay_dr)));

        
        $liablity_items = Item::whereHas('categories', function($q) use ($request){
            $q->where('categories.id',9);
        })->where('status',1)->get();
        
        $liability_arr = array();
        if(count($liablity_items) > 0)
        {
            foreach($liablity_items as $ikey => $item)
            {
                $liablity_items_ret = $this->profit_loss_ledger($request,'item_'.$item->id);

                $in_journal_total_cr = 0;
                $in_journal_total_dr = 0;
                $in_journal_arr = array();
                
                foreach ($liablity_items_ret as $key => $value) {
                    $in_journal_arr[$key]['reference'] = $value['reference'];
                    $in_journal_arr[$key]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) :  sprintf('%0.2f',floatval($value['credit']));
                    $in_journal_arr[$key]['children'] = array();

                    $in_journal_total_cr =  $in_journal_total_cr + floatval($value['credit']);
                    $in_journal_total_dr =  $in_journal_total_dr + floatval($value['debit']);
                }


                $liability_arr[$ikey]['reference'] = $item->name;

                if(floatval($in_journal_total_cr - $in_journal_total_dr) > 0)
                    $liability_arr[$ikey]['amount'] = sprintf('%0.2f',-floatval($in_journal_total_cr - $in_journal_total_dr));
                elseif(floatval($in_journal_total_cr - $in_journal_total_dr) <= 0)
                    $liability_arr[$ikey]['amount'] = sprintf('%0.2f',abs(floatval($in_journal_total_cr - $in_journal_total_dr)));

                $liability_arr[$ikey]['children'] = $in_journal_arr;
            }
        }    
        
        $creditors = Customer::where('category','Creditor')->where('status',1)->get();
        $sundry_total_cr = 0;
        $sundry_total_dr = 0;
        $sundry_arr = array();
        foreach($creditors as $crkey => $creditor)
        {
            
            $sundry_creditors_ret = $this->profit_loss_ledger($request,"customer_".$creditor->id);
            $sundry_cr_arr = array();
            $sundry_cr = 0;
            $sundry_dr = 0;
            
            foreach ($sundry_creditors_ret as $key => $value) 
            {
                $sundry_cr_arr[$key]['reference'] = $value['reference'];
                $sundry_cr_arr[$key]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) :  sprintf('%0.2f',floatval($value['credit']));
                $sundry_cr_arr[$key]['children'] = array();
                $sundry_cr =  $sundry_cr +  floatval($value['credit']);
                $sundry_dr =  $sundry_dr +  floatval($value['debit']);
            }

            $sundry_arr[$crkey]['reference'] = $creditor->full_name;
            $sundry_arr[$crkey]['amount'] = sprintf('%0.2f',floatval( $sundry_cr -  $sundry_dr ));
            $sundry_arr[$crkey]['children'] = $sundry_cr_arr;

            if( floatval( $sundry_cr -  $sundry_dr ) > 0)
                $sundry_total_cr = $sundry_total_cr - floatval( $sundry_cr -  $sundry_dr );
            elseif( floatval( $sundry_cr -  $sundry_dr ) <= 0)
                $sundry_total_cr = $sundry_total_cr + abs(floatval( $sundry_cr -  $sundry_dr ));     
        }    
        array_push( $liability_arr ,array('reference'=>'GST Input & Output','amount'=> $gst_in_out_total,'children'=>array()));
        array_push( $liability_arr ,array('reference'=>'Sundry Creditors','amount'=>   sprintf('%0.2f',$sundry_total_cr) ,'children'=>$sundry_arr));
        array_push( $liability_arr ,array('reference'=>'TDS Payable','amount'=>sprintf('%0.2f',$tds_pay_total),'children'=>$tds_payable_arr));
        array_push( $liability_arr ,array('reference'=>'TCS Payable','amount'=>sprintf('%0.2f',$tcs_pay_total),'children'=>$tcs_payable_arr));
        
        
        $liability_total = 0;
        foreach($liability_arr as $lib){
            $liability_total =  $liability_total + floatval($lib['amount']);
        }

        if($liability_total == 0)
        {

           /* $last_fiscal_year = FiscalYear::where('start_date',date('Y-04-01', strtotime($request->start_date . " -1 year") ))->first();
            $request->start_date = $last_fiscal_year->start_date;
            $request->end_date = $last_fiscal_year->end_date;*/
           
            $opening_balance=OpeningBalance::where('main_id',0)->where('identifier','liability')->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();

            if(!empty($opening_balance))
            {
                if($opening_balance->type == 'credit')
                {
                    $liability_total =  floatval($opening_balance->amount);
                }
                elseif($opening_balance->type == 'debit')
                {
                    $liability_total =  -floatval($opening_balance->amount);
                }
            }
            else
            {
                $liability_total = 0;
            }
            
        }

        $request->start_date = "";
        $request->end_date = "";
        $request->return_type = "";
        return $liability_total;
    }

    public function assets(Request $request,$start_date,$end_date)
    {
       
        $request->start_date = $start_date;
        $request->end_date = $end_date;

        $asset_arr = array();

        $request->return_type = 'array';

        $bank_accounts = BankAccount::where('status',1)->get();
        $bank_total = 0;

        foreach($bank_accounts as $bkey => $bank)
        {
           

            $total_bankbook_credit = 0;
            $total_bankbook_debit = 0;

            $request->merge(['bank_account_id' => $bank->id,'return_type'=>'array','start_date'=> $start_date,'end_date'=>$end_date]);
            $bank_book_data = $this->bankbook_report($request);
           
            foreach ($bank_book_data as $key => $value) {
                if($value['type'] == 'credit')
                    $total_bankbook_credit = $total_bankbook_credit + $value['credit'];
                elseif($value['type'] == 'debit')
                    $total_bankbook_debit = $total_bankbook_debit + $value['debit'];    
            }
            if(($total_bankbook_credit - $total_bankbook_debit) >= 0)
            {
                $bank_account_arr[$bkey]['reference'] = $bank->display_name;
                $bank_account_arr[$bkey]['amount'] = floatval(($total_bankbook_credit - $total_bankbook_debit));
                $bank_account_arr[$bkey]['children'] = array();
                $bank_total = $bank_total + ($total_bankbook_credit - $total_bankbook_debit);
            }
            else
            {
                $bank_account_arr[$bkey]['reference'] = $bank->display_name;
                $bank_account_arr[$bkey]['amount'] = floatval(($total_bankbook_credit - $total_bankbook_debit));
                $bank_account_arr[$bkey]['children'] = array();
                $bank_total = $bank_total + ($total_bankbook_credit - $total_bankbook_debit);
            }

        }
        
        $cash_book_data = $this->cashbook_report($request);

        $total_cashbook_credit = 0;
        $total_cashbook_debit = 0;

        foreach ($cash_book_data as $key => $value) {
            if($value['type'] == 'credit')
                $total_cashbook_credit = $total_cashbook_credit + $value['credit'];
            elseif($value['type'] == 'debit')
                $total_cashbook_debit = $total_cashbook_debit + $value['debit'];    
        }
        if(($total_cashbook_credit - $total_cashbook_debit) >= 0)
        {
            $cash_array[0]['reference'] = "Cash-In-Hand";  
            $cash_array[0]['amount'] = floatval($total_cashbook_credit - $total_cashbook_debit);
            $cash_array[0]['children'] = array();
        }
        else
        {
            $cash_array[0]['reference'] = "Cash-In-Hand";  
            $cash_array[0]['amount'] = floatval($total_cashbook_credit - $total_cashbook_debit);
            $cash_array[0]['children'] = array();
        }
        
        $sens_hotel = Customer::find(26);
        $sens_hotels_ret = $this->profit_loss_ledger($request,'customer_'.$sens_hotel->id);

        $sen_hotels = array();
        $sen_hotel_cr = 0;
        $sen_hotel_dr = 0;

        foreach ($sens_hotels_ret as $key => $value) {
            $sen_hotels[$key]['reference'] = $value['reference'];
            $sen_hotels[$key]['amount'] = floatval($value['debit']) > 0 ? sprintf('%0.2f',floatval($value['debit'])) :  sprintf('%0.2f',floatval($value['credit']));
            $sen_hotels[$key]['children'] = array();
            $sen_hotel_cr =  $sen_hotel_cr + floatval($value['credit']);
            $sen_hotel_dr =  $sen_hotel_dr + floatval($value['debit']);
        }

        if(floatval($sen_hotel_cr - $sen_hotel_dr) > 0)
            $sen_hotel_total = -floatval($sen_hotel_cr - $sen_hotel_dr);
        elseif(floatval($sen_hotel_cr - $sen_hotel_dr) <= 0)
            $sen_hotel_total = abs(floatval($sen_hotel_cr - $sen_hotel_dr)); 

        array_push( $asset_arr ,array('reference'=> $sens_hotel->full_name,'amount'=>sprintf('%0.2f',$sen_hotel_total),'children'=>$sen_hotels));
        array_push( $asset_arr ,array('reference'=>'Cash In Hand','amount'=>sprintf('%0.2f',floatval($total_cashbook_credit - $total_cashbook_debit)),'children'=>$cash_array));
        array_push( $asset_arr ,array('reference'=>'Bank Accounts','amount'=>sprintf('%0.2f',floatval($bank_total)),'children'=>$bank_account_arr));


        $total_asset = bcsub(floatval(($total_cashbook_credit - $total_cashbook_debit) + $sen_hotel_total +  $bank_total ),0,2);

        if($total_asset == 0)
        {
 
            $opening_balance=OpeningBalance::where('main_id',0)->where('identifier','asset')->whereRaw('(date <= ? or ?)',[$request->start_date,$request->end_date])->orderBy('date','desc')->first();

            if(!empty($opening_balance))
            {
                if($opening_balance->type == 'credit')
                {
                    $total_asset =  floatval($opening_balance->amount);
                }
                elseif($opening_balance->type == 'debit')
                {
                    $total_asset =  -floatval($opening_balance->amount);
                }
            }
            else
            {
                $total_asset = 0;
            }
            
        }

        $request->start_date = "";
        $request->end_date = "";
        $request->return_type = "";
        return $total_asset;
    }

    public function dashboard(Request $request)
    {
        $current_fiscal_year = FiscalYear::where('status',1)->orderBy('created_at','desc')->first(); 
        $last_fiscal_year = FiscalYear::where('start_date',date('Y-04-01', strtotime($current_fiscal_year->start_date . " -1 year") ))->first();
        
        $sales_account_arr = array();
        $sales_account_arr['current']=DB::table('invoices')->select(DB::raw("ROUND(SUM(before_total),2) as total,MONTHNAME(date) as month"))->where('fiscal_year_id',$current_fiscal_year->id)->whereNull('deleted_at')->orderBy(DB::raw('MONTH(date)'))->orderBy(DB::raw('YEAR(date)'))->groupBy(DB::raw('MONTHNAME(date)'))->get();
        $sales_account_arr['last']=DB::table('invoices')->select(DB::raw("ROUND(SUM(before_total),2) as total,MONTHNAME(date) as month"))->where('fiscal_year_id',$last_fiscal_year->id)->whereNull('deleted_at')->orderBy(DB::raw('MONTH(date)'))->orderBy(DB::raw('YEAR(date)'))->groupBy(DB::raw('MONTHNAME(date)'))->get();

        $item_wise_invoice = DB::table('invoices')->select(DB::raw("ROUND(SUM(invoices.before_total),2) as total,items.name"))->leftJoin('invoice_items','invoices.id','=','invoice_items.invoice_id')->leftJoin('items','invoice_items.item_id','=','items.id')->where('invoices.fiscal_year_id',$current_fiscal_year->id)->whereNull('invoices.deleted_at')->whereNull('invoice_items.deleted_at')->groupBy('invoice_items.item_id')->get();
        
        $asset_liability['current_asset'] = $this->assets($request,$current_fiscal_year->start_date,date('Y-m-d'));
        $asset_liability['current_liability'] = $this->liabilities($request,$current_fiscal_year->start_date,date('Y-m-d'));

        $customer['sundry_debtors'] = Customer::where('category','Debtor')->where('status',1)->count();
        $customer['sundry_creditors'] =  Customer::where('category','Creditor')->where('status',1)->count();

        $month_wise_user['sundry_debtors'] =  DB::table('customers')->select(DB::raw("COUNT(*) as total,MONTHNAME(created_at) as month"))->where('category','Debtor')->whereBetween('customers.created_at',[$current_fiscal_year->start_date,date('Y-m-d')])->whereNull('customers.deleted_at')->orderBy(DB::raw('MONTH(created_at)'))->orderBy(DB::raw('YEAR(created_at)'))->groupBy(DB::raw('MONTHNAME(created_at)'))->get();
        
        $month_wise_user['sundry_creditors'] =  DB::table('customers')->select(DB::raw("COUNT(*) as total,MONTHNAME(created_at) as month"))->where('category','Creditor')->whereBetween('customers.created_at',[$current_fiscal_year->start_date,date('Y-m-d')])->whereNull('customers.deleted_at')->orderBy(DB::raw('MONTH(created_at)'))->orderBy(DB::raw('YEAR(created_at)'))->groupBy(DB::raw('MONTHNAME(created_at)'))->get();

        $request->return_type = 'array';
        $request->start_date = $current_fiscal_year->start_date;
        $request->end_date = date('Y-m-d');
        $cash_flow  = $this->cash_flow_report($request); 

        $expense['indirect_income'] = $this->expense_by_category($request,$current_fiscal_year->start_date,date('Y-m-d'),20);
        $expense['indirect_expense'] = $this->expense_by_category($request,$current_fiscal_year->start_date,date('Y-m-d'),14);

        $recent_invoices = Invoice::with('account','fiscal_year','customer','items','proforma_invoice')->checkPermission('created_by')->whereBetween('date',[date('Y-m-d', strtotime("this week")),date('Y-m-d')])->get(); //date('Y-m-d', strtotime("this week"))
       

        return response(['data' => array('sales_account'=>$sales_account_arr,'item_wise_sales'=>$item_wise_invoice,'asset_liability'=>$asset_liability,'cash_flow'=>$cash_flow,'recent_invoices'=> $recent_invoices,'customer'=>$customer,'month_wise_user'=>$month_wise_user,'expense'=>$expense),'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function expense_by_category(Request $request,$start_date,$end_date,$category_id)
    {
        $request->start_date = $start_date;
        $request->end_date = $end_date;
        $direct_expense_items = Item::whereHas('categories', function($q) use ($request,$category_id){
            $q->where('categories.id',$category_id);
        })->where('status',1)->get();
        $direct_expense_arr = array();
        $direct_expense_total = 0;
        if(count($direct_expense_items) > 0)
        {
            foreach($direct_expense_items as $item)
            {
                $direct_expense_ret = $this->profit_loss_ledger($request,'item_'.$item->id);

                $direct_expense_total_cr = 0 ;
                $direct_expense_total_dr = 0 ;
                $direct_arr = array();

                $kk = 0;
                foreach ($direct_expense_ret as $key => $value) {
                  
                   
                   
                    $direct_expense_total_cr = $direct_expense_total_cr + floatval($value['credit']);
                    $direct_expense_total_dr = $direct_expense_total_dr + floatval($value['debit']);
                    $kk++;
                }

                

                $direct_expense_total =  $direct_expense_total + abs(floatval($direct_expense_total_cr - $direct_expense_total_dr));
            }
        }
        $request->start_date = "";
        $request->end_date = "";
        return $direct_expense_total;
    }
}
