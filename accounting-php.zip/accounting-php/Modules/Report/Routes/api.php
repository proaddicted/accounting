<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware(['auth:api','masterauth'])->group(function () {

    Route::any('report_getlist',[Modules\Report\Http\Controllers\ReportController::class,'getlist']);
    Route::any('customer_ledger_report',[Modules\Report\Http\Controllers\ReportController::class,'customer_ledger_report']);
    Route::any('vendor_ledger_report',[Modules\Report\Http\Controllers\ReportController::class,'vendor_ledger_report']);
    Route::any('full_ledger_report',[Modules\Report\Http\Controllers\ReportController::class,'full_ledger_report']);
    Route::any('cashbook_report',[Modules\Report\Http\Controllers\ReportController::class,'cashbook_report']);
    Route::any('bank_reconciliation',[Modules\Report\Http\Controllers\ReportController::class,'bank_reconciliation']);
    Route::any('trial_balance',[Modules\Report\Http\Controllers\ReportController::class,'trial_balance']);
    Route::any('profit_loss_report',[Modules\Report\Http\Controllers\ReportController::class,'profit_loss_report']);
    Route::any('bankbook_report',[Modules\Report\Http\Controllers\ReportController::class,'bankbook_report']);
    Route::any('balance_sheet',[Modules\Report\Http\Controllers\ReportController::class,'balance_sheet']);
    Route::any('bank_realization_report',[Modules\Report\Http\Controllers\ReportController::class,'bank_realization_report']);
    Route::any('customer_due_report',[Modules\Report\Http\Controllers\ReportController::class,'customer_due_report']);
    Route::any('json_reports',[Modules\Report\Http\Controllers\ReportController::class,'json_reports']);
    Route::any('bank_realization_update/{id}/',[Modules\Report\Http\Controllers\ReportController::class,'bank_realization_update']);

    Route::any('full_ledger_report_pdf',[Modules\Report\Http\Controllers\ReportController::class,'full_ledger_report_pdf']);
    Route::any('cashbook_report_pdf',[Modules\Report\Http\Controllers\ReportController::class,'cashbook_report_pdf']);
    Route::any('bankbook_report_pdf',[Modules\Report\Http\Controllers\ReportController::class,'bankbook_report_pdf']);
    Route::any('bank_reconciliation_pdf',[Modules\Report\Http\Controllers\ReportController::class,'bank_reconciliation_pdf']);
    Route::any('balance_sheet_pdf',[Modules\Report\Http\Controllers\ReportController::class,'balance_sheet_pdf']);
    Route::any('profit_loss_report_pdf',[Modules\Report\Http\Controllers\ReportController::class,'profit_loss_report_pdf']);
    Route::any('trial_balance_pdf',[Modules\Report\Http\Controllers\ReportController::class,'trial_balance_pdf']);
    Route::any('cash_flow_report',[Modules\Report\Http\Controllers\ReportController::class,'cash_flow_report']);
    Route::any('cash_flow_report_pdf',[Modules\Report\Http\Controllers\ReportController::class,'cash_flow_report_pdf']);
    Route::any('fund_flow_report',[Modules\Report\Http\Controllers\ReportController::class,'fund_flow_report']);
    Route::any('fund_flow_report_pdf',[Modules\Report\Http\Controllers\ReportController::class,'fund_flow_report_pdf']);
    Route::get('dashboard',[Modules\Report\Http\Controllers\ReportController::class,'dashboard']);
    
    Route::any('invoice_summary_report',[Modules\Report\Http\Controllers\PivotReportController::class,'invoice_summary_report']);
    Route::any('purchase_summary_report',[Modules\Report\Http\Controllers\PivotReportController::class,'purchase_summary_report']);
    Route::any('debtors_report',[Modules\Report\Http\Controllers\PivotReportController::class,'debtors_report']);
    Route::any('creditors_report',[Modules\Report\Http\Controllers\PivotReportController::class,'creditors_report']);
   
    
    
});