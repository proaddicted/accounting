<?php

namespace Modules\Customer\Entities;

use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\DB;
use Modules\Cashbook\Entities\CashbookTransaction;
use Modules\Invoice\Entities\CreditNote;
use Modules\Invoice\Entities\DebitNote;
use Modules\Invoice\Entities\Invoice;
use Modules\Invoice\Entities\Journal;
use Modules\Invoice\Entities\Payment;
use Modules\Purchase\Entities\Purchase;
use Modules\Purchase\Entities\PurchaseAdvancePayment;
use Modules\Purchase\Entities\PurchasePayment;
use Ramsey\Uuid\Nonstandard\Uuid;
use Ramsey\Uuid\Uuid as UuidUuid;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;

class Customer extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes,Notifiable;

    protected $fillable = ['unique_id','category','title','fname','lname','nominal','mobile','address','country','state','city','pincode','email','aadhar_no','pan_no','whatapp_no','gstin','company_name','status','type','legal_name'];

    protected $searchableColumns = ['unique_id','fname','category', 'mobile','email','aadhar_no','pan_no','whatapp_no','gstin','company_name'];

    protected $appends = ['is_delete','is_edit','creator','editor','full_name'];

   

    public function setStatusAttribute($value)
    {
        $this->attributes['status'] = (int) $value;
    }
    public function getFullNameAttribute()
    {
        $full_name="";
        $full_name .=empty($this->attributes['title'])?'':$this->attributes['title'] . ' ';
        $full_name .=empty($this->attributes['fname'])?'':$this->attributes['fname'] . ' ';
        $full_name .=empty($this->attributes['mname'])?'':$this->attributes['mname'] . ' ';
        $full_name .=empty($this->attributes['lname'])?'':$this->attributes['lname'];
        $full_name .=empty($this->attributes['nominal'])?'':'('.$this->attributes['nominal'].')';
        $this->attributes['full_name']=$full_name ;
        return $this->attributes['full_name'];
    }

    /**
     * Below Functions Are Used For Closing Balance Calculation
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */

    /*Debit*/
    public function invoices()
    {
       return $this->hasMany(Invoice::class,'customer_id');
    }
    /*Credit*/
    public function payments()
    {
        return $this->hasMany(Payment::class,'customer_id');
    }

    /*Debit*/
    public function debit_notes()
    {
        return $this->hasMany(DebitNote::class,'customer_id');
    }

    /*Credit*/
    public function credit_notes()
    {
        return $this->hasMany(CreditNote::class,'customer_id');
    }

    /*Credit*/
    public function cash_entries_credit()
    {
        return $this->hasMany(CashbookTransaction::class,'main_id')->where('identifier','cash')->where('type','credit');
    }
    /*Debit*/
    public function cash_entries_debit()
    {
        return $this->hasMany(CashbookTransaction::class,'main_id')->where('identifier','cash')->where('type','debit');
    }

    /*Credit*/
    public function advances_credit()
    {
        return $this->hasMany(PurchaseAdvancePayment::class,'main_id')->where('identifier','customer')->where('type','credit');
    }

    /*Debit*/
    public function advances_debit()
    {
        return $this->hasMany(PurchaseAdvancePayment::class,'main_id')->where('identifier','customer')->where('type','debit');
    }

    /*Credit*/
    public function purchases()
    {
        return $this->hasMany(Purchase::class,'customer_id');
    }
    
    /*Debit*/
    public function purchase_payments()
    {
        return $this->hasMany(PurchasePayment::class,'customer_id');
    }
    /*Debit*/
    public function journal_debit()
    {
        return $this->hasMany(Journal::class,'main_id')->where('identifier','customer')->where('type','debit');
    }
    /*Credit*/
    public function journal_credit()
    {
        return $this->hasMany(Journal::class,'main_id')->where('identifier','customer')->where('type','credit');
    }

    protected static function boot() 
    {
        parent::boot();
    
       
        self::creating(function($model){
            
            do {
                $unique_id = str_pad(rand(0, '9' . round(microtime(true))), 11, "0", STR_PAD_LEFT);
            } 
            while ( DB::table( 'customers' )->where('master_id',request()->master_id)->where( 'unique_id', $unique_id )->whereNull('deleted_at')->exists() );
            
            $model->unique_id = $unique_id;
        });

        self::created(function($model){
            if(request()->opening_balance > 0)
            {
                $opening_balance = new OpeningBalance();
                $opening_balance->main_id = $model->id;
                $opening_balance->identifier = 'customer';
                $opening_balance->date = request()->date;
                $opening_balance->amount = request()->opening_balance;
                $opening_balance->save();
            } 
        });

        self::updating(function($model){
            
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
        });

       
    }
    
}
