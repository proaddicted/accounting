<?php

namespace Modules\Customer\Entities;

use App\Models\BankAccount;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Sofa\Eloquence\Eloquence;
use Wildside\Userstamps\Userstamps;
use App\Traits\MasterTrait;
use App\Traits\PermissionTrait;
use Modules\Customer\Entities\Customer;
use App\Models\FiscalYear;
use App\Traits\InvoiceModuleTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\Relation;
use Modules\Invoice\Entities\InvoiceAccount;

class OpeningBalance extends Model
{
    use HasFactory,Userstamps,MasterTrait,PermissionTrait,Eloquence,SoftDeletes,InvoiceModuleTrait;

    protected $fillable = ['main_id','identifier','date','amount','remarks','fiscal_year_id','type'];

    protected $searchableColumns = ['date','identifier'];

    protected $appends = ['is_delete','is_edit','creator','editor','item_name'];

    public $total_items; 

    public function __construct(array $attributes = array())
    {
        parent::__construct($attributes);

        $items = $this->getTotalItems();
        $data['bank_accounts']=BankAccount::where('status',1)->get();

        foreach ( $data['bank_accounts'] as $key => $value) 
        {
            array_push( $items ,array('id'=>'bank_'.$value->id,'name'=>$value->display_name,'group'=>'Bank Account'));
        }
        array_push( $items , array('id'=>'cash_0','name'=>'Cash Account','group'=>'Cash Account'));
        array_push( $items , array('id'=>'profit_0','name'=>'Profit & Loss Account','group'=>'Profit & Loss Account'));
        array_push( $items , array('id'=>'asset_0','name'=>'Current Assets','group'=>'Current Assets'));
        array_push( $items , array('id'=>'liability_0','name'=>'Current Liabilities','group'=>'Current Liabilities'));
        $this->total_items = $items;
    }

    public function fiscal_year()
    {
        return $this->belongsTo(FiscalYear::class,'fiscal_year_id');
    }
    public function getItemNameAttribute()
    {
        if(isset($this->attributes['main_id'])  && !empty($this->attributes['identifier']))
        {
            $items = array_column($this->total_items,'name', 'id');
            $item_name=$items[$this->attributes['identifier']."_".$this->attributes['main_id']];
            $this->attributes['item_name']=$item_name ;
            return $this->attributes['item_name'];
        }
       
    }
    protected static function boot() 
    {
        parent::boot();
    
        
        
        self::creating(function($model){
            
                
               if(!empty(request()->date))
               {
                    if($fiscal_year=FiscalYear::whereRaw('? BETWEEN start_date and end_date',[request()->date])->first())
                        $model->fiscal_year_id = $fiscal_year->id; 
               } 
              
                     
        });

        self::created(function($model){
           
        });

        self::updating(function($model){
            if(!empty(request()->date))
            {
                if($fiscal_year=FiscalYear::whereRaw('? BETWEEN start_date and end_date',[request()->date])->first())
                    $model->fiscal_year_id = $fiscal_year->id; 
            }
        });

        self::updated(function($model){
            
        });

        self::deleting(function($model){
           
        });

        self::deleted(function($model){
        });

       
    }
}
