<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware(['auth:api','masterauth'])->group(function () {
 
    Route::resource('customer', CustomerController::class);
    Route::any('customer_headers',[Modules\Customer\Http\Controllers\CustomerController::class,'headers']);
    Route::any('customer_getlist',[Modules\Customer\Http\Controllers\CustomerController::class,'getlist']);
    Route::any('customer_actionall',[Modules\Customer\Http\Controllers\CustomerController::class,'actionall']);


    Route::resource('opening_balance', OpeningBalanceController::class);
    Route::any('opening_balance_headers',[Modules\Customer\Http\Controllers\OpeningBalanceController::class,'headers']);
    Route::any('opening_balance_getlist',[Modules\Customer\Http\Controllers\OpeningBalanceController::class,'getlist']);
    Route::any('opening_balance_actionall',[Modules\Customer\Http\Controllers\OpeningBalanceController::class,'actionall']);

});

