<?php

namespace Modules\Customer\Http\Controllers;

use App\Models\Country;
use App\Models\MasterType;
use App\Models\State;
use App\Traits\PermissionTrait;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Exception;
use Modules\Customer\Entities\Customer;
use Modules\Customer\Entities\OpeningBalance;
use Modules\Customer\Transformers\CustomerResource;
use Spatie\QueryBuilder\QueryBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class CustomerController extends Controller
{
    use PermissionTrait;
    
    /**
     * This Controller used for Customer Resources Methods
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function getlist()
    {
        $data['countries']=Country::where('status',1)->get();
        $data['states']=State::where('status',1)->get();
        $data['titles']=MasterType::where('identifier','title')->where('status',1)->get();
        $data['nominals']=MasterType::where('identifier','nominal')->where('status',1)->get();
        return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }

    public function headers()
    {
        $headers = array(
            array('column_name'=>'unique_id','display_name'=>'Unique ID','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'name','display_name'=>'Name','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'legal_name','display_name'=>'Legal Name','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'mobile','display_name'=>'Mobile','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'email','display_name'=>'Email','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'whatapp_no','display_name'=>'Whatsapp','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'address','display_name'=>'Address','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'country','display_name'=>'Country','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'state','display_name'=>'State','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'city','display_name'=>'City','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'pincode','display_name'=>'Pincode','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'aadhar_no','display_name'=>'Aadhar No.','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'pan_no','display_name'=>'Pan No.','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'gstin','display_name'=>'GSTIN No.','is_display'=>1,'is_default'=>0,'is_sortable'=>1),
            array('column_name'=>'company_name','display_name'=>'Company','is_display'=>1,'is_default'=>0,'is_sortable'=>0)            
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    } 
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(Customer::class)->allowedFilters(['fname',AllowedFilter::exact('fname')->ignore(null),'lname',AllowedFilter::exact('mobile')->ignore(null),AllowedFilter::exact('whatapp_no')->ignore(null),AllowedFilter::exact('pan_no')->ignore(null),AllowedFilter::exact('aadhar_no')->ignore(null),AllowedFilter::exact('gstin')->ignore(null),'company_name','state','city','country',AllowedFilter::exact('pincode')->ignore(null),AllowedFilter::exact('email')->ignore(null),AllowedFilter::exact('category')->ignore(null)])->defaultSort('-created_at')->allowedSorts('fname','lname','company_name','unique_id','email','mobile','whatapp_no','state','city','pincode','aadhar_no','pan_no','gstin');

        $query->search(!empty($request->search)?$request->search:"");

        $users = $query->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $users,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        if(!$this->checkStoreAccess())
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403); 

        $validator = Validator::make($request->all(), [
            'mobile' => 'required|unique:customers,mobile,NULL,id,deleted_at,NULL,master_id,'.$request->master_id,
            'fname' => 'required'
        ]);

        if ($request->method != "quick-add" && $validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        DB::beginTransaction();
        try {

            $customer = Customer::create($request->except('date','opening_balance'));

            
            DB::commit();

            return response(['data' => $customer->toArray(),'success'=>true,'message' => 'Customer Created Successfully'], 200);

        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>false,'message' =>  $ex->getMessage()], 500);
        }

    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return response(['data' =>new CustomerResource(Customer::find($id)),'success'=>true,'message' => 'Customer Retrived Successfully'], 200);

    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2021, Prosanta Mitra
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $customer=Customer::find($id);
        
        if(!$this->checkUpdateAccess($customer))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
        
        $validator = Validator::make($request->all(), [
            //'unique_id' => 'required|unique:customers,unique_id,'.$customer->id.',id,deleted_at,NULL,master_id,'.$request->master_id,
            //'fname' => 'required',
            //'lname' => 'required',
            //'mobile' => 'required'
        ]);

        if ($validator->fails()) {

            return response(['data' => array(),'success'=>false,'message' => $validator->errors()->toArray()], 200);
        }
        DB::beginTransaction();
        try {
            
            $customer->update($request->all());

            DB::commit();

            return response(['data' =>new CustomerResource($customer),'success'=>true,'message' => 'Customer Updated Successfully'], 200);

        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>false,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
       
        $customer=Customer::find($id);
        if(!$this->checkDeleteAccess($customer))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);
       
        DB::beginTransaction();
        try {
           
            $customer->delete();
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Customer Deleted successfully'], 200);
    }

    /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @param int $id
     * @return Renderable
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess( $access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
                Customer::whereIn('id',request()->ids)->delete();
            elseif($access == 3)  
                Customer::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
