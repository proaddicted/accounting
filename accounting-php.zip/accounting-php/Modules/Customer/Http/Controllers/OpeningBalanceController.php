<?php

namespace Modules\Customer\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\BankAccount;
use App\Traits\InvoiceModuleTrait;
use Modules\Customer\Entities\Customer;
use App\Traits\PermissionTrait;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;
use Modules\Customer\Entities\OpeningBalance;
use Modules\Customer\Http\Requests\OpeningBalanceRequest;
use Modules\Customer\Transformers\OpeningBalanceResource;

class OpeningBalanceController extends Controller
{
    use PermissionTrait,InvoiceModuleTrait;
    
    public function getlist()
    {
        $data['customers']=Customer::where('status',1)->get();
        $data['bank_accounts']=BankAccount::where('status',1)->get();

        $total_items = $this->getTotalItems();

        foreach ( $data['bank_accounts'] as $key => $value) 
        {
            array_push( $total_items ,array('id'=>'bank_'.$value->id,'name'=>$value->display_name,'group'=>'Bank Account'));
        }
        array_push( $total_items , array('id'=>'cash_0','name'=>'Cash Account','group'=>'Cash Account'));
        array_push( $total_items , array('id'=>'profit_0','name'=>'Profit & Loss Account','group'=>'Profit & Loss Account'));
        array_push( $total_items , array('id'=>'asset_0','name'=>'Current Assets','group'=>'Current Assets'));
        array_push( $total_items , array('id'=>'liability_0','name'=>'Current Liabilities','group'=>'Current Liabilities'));

        $data['total_items'] = $total_items;

        $data['types']=array(
            array('name'=>'debit','display_name'=>"Debit"),
            array('name'=>'credit','display_name'=>"Credit")
        );
       return response(['data' => $data,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    public function headers()
    {
        $headers = array(
            
            array('column_name'=>'type','display_name'=>'Type','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'fiscal_year','display_name'=>'Fiscal Year','is_display'=>1,'is_default'=>0,'is_sortable'=>0),
            array('column_name'=>'item_name','display_name'=>'Account','is_display'=>1,'is_default'=>1,'is_sortable'=>0),
            array('column_name'=>'date','display_name'=>'Effective Date','is_display'=>1,'is_default'=>1,'is_sortable'=>1),

            array('column_name'=>'amount','display_name'=>'Opening Balance','is_display'=>1,'is_default'=>1,'is_sortable'=>1),
            array('column_name'=>'updated_at','display_name'=>'Last Updated','is_display'=>0,'is_default'=>0,'is_sortable'=>1)       
        );

        return response(['data' => $headers,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $query = QueryBuilder::for(OpeningBalance::class)->allowedFilters(['date',AllowedFilter::exact('identifier')->ignore(null),AllowedFilter::scope('date_between'),AllowedFilter::exact('main_id')->ignore(null),AllowedFilter::exact('fiscal_year_id')->ignore(null)])->defaultSort('-created_at')->allowedSorts('date','type','amount','updated_at');

        $query->search(!empty($request->search)?$request->search:"");

        $opening_balances = $query->with('fiscal_year')->checkPermission('created_by')->paginate($request->per_page);

        return response(['data' => $opening_balances,'success'=>true,'message' => 'Data Retrived Successfully'], 200);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(OpeningBalanceRequest $request)
    {
        if(!$this->checkStoreAccess())
        return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {
            
            $opening_balance = OpeningBalance::create($request->all());

            DB::commit();
            
            return response(['data' =>new OpeningBalanceResource($opening_balance),'success'=>true,'message' => 'Opening Balance Created Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $opening_balance = OpeningBalance::findOrFail($id);
        
        return response(['data' => new OpeningBalanceResource($opening_balance),'success'=>true,'message' => 'Opeing Balance Retrived Successfully'], 200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(OpeningBalanceRequest $request, $id)
    {
        $opening_balance=OpeningBalance::find($id);
        
        if(!$this->checkUpdateAccess($opening_balance))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        try {
            
            $opening_balance->update($request->all());

            DB::commit();
            
            return response(['data' => new OpeningBalanceResource($opening_balance),'success'=>true,'message' => 'Opening Balance Updated Successfully'], 200);
        }
        catch (Exception $ex) {

            DB::rollBack();
           
            return response(['data' => array(),'success'=>true,'message' =>  $ex->getMessage()], 500);
        }
    }

     /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $opening_balance=OpeningBalance::find($id);
        
        if(!$this->checkDeleteAccess($opening_balance))
            return response(['data' => array(),'success'=>false,'message' =>"Unauthirized Access"], 403);

        DB::beginTransaction();
        
        try {
            
            $opening_balance->delete();
            
            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Opening Balance Deleted Successfully'], 200);
    }

     /**
     * Bulk Action function of footer (pass 6  for delete and 3 for update)
     * @param int $id
     * @return Renderable
     */
    public function actionall()
    {
        
        $access = request()->action == 'delete' ? 6 : 3;

        if(!$this->checkBulkAcess($access))
            return response(['data' => array(),'success'=>false,'message' =>"You Don't Have Access For Bulk Action"], 200);

        DB::beginTransaction();
        try {
           
            if($access == 6)
              {
                OpeningBalance::whereIn('id',request()->ids)->get()->each(function($opening_balance) 
                {
                    $opening_balance->delete();
                });
              } 
            elseif($access == 3)  
                OpeningBalance::whereIn('id',request()->ids)->update([request()->column => request()->status]);

            DB::commit();
        } catch (Exception $ex) {

            DB::rollBack();
            return response()->json(['data' => array(),'success'=>false,'message'=>$ex->getMessage()], 500);
        }

        return response(['data' => array(),'success'=>true,'message' => 'Updated successfully'], 200);
    }
}
