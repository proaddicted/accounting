import { Component, HostBinding, Inject, OnDestroy, OnInit, Renderer2, ViewChild, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DOCUMENT } from '@angular/common';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import {RestApiService } from 'app/service/rest-api.service';
import { fuseAnimations } from '@fuse/animations';
import { FuseConfigService } from '@fuse/services/config.service';
import { FuseNavigationService } from '@fuse/components/navigation/navigation.service';
import { FuseSidebarService } from '@fuse/components/sidebar/sidebar.service';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import { DateRange } from "@angular/material/datepicker";
import * as _moment from 'moment';
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';

const moment =  _moment;

export const MY_FORMATS = {
    parse: {
        dateInput: 'YYYY-MM-DD'
    },
    display: {
      dateInput: "YYYY-MM-DD",
      monthYearLabel: "YYYY",
      dateA11yLabel: "LL",
      monthYearA11yLabel: "YYYY"
    }
};

@Component({
  selector: 'app-advance-search',
  templateUrl: './advance-search.component.html',
  styleUrls: ['./advance-search.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations,
  providers: [
        {
        provide: DateAdapter,
        useClass: MomentDateAdapter,
        deps: [MAT_DATE_LOCALE]
        },

        { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
    ]
})
export class AdvanceSearchComponent implements OnInit,OnDestroy {
  
fuseConfig: any;
form: FormGroup;

@HostBinding('class.bar-closed')
barClosed: boolean;

@ViewChild('clearAdvanceRange') clearAdvanceRange;

selected: any;
alwaysShowCalendars: boolean;
ranges: any = {
    
    'This Month': [moment().startOf('month'), moment().endOf('month')],
    'Last 3 Month': [moment().subtract(3, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
    'Last 6 Month': [moment().subtract(6, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
}
invalidDates: moment.Moment[] = [moment().add(2, 'days'), moment().add(3, 'days'), moment().add(5, 'days')];

isInvalidDate = (m: moment.Moment) =>  {
  return this.invalidDates.some(d => d.isSame(m, 'day') )
}

// range = new FormGroup({
//     start: new FormControl(),
//     end: new FormControl(),
// });    
// Private
private _unsubscribeAll: Subject<any>;
form_data;  

maxDate;
constructor(
    @Inject(DOCUMENT) private document: any,
        private _formBuilder: FormBuilder,
        private _fuseConfigService: FuseConfigService,
        private _fuseNavigationService: FuseNavigationService,
        private _fuseSidebarService: FuseSidebarService,
        private _renderer: Renderer2,
        private restApiService: RestApiService
) { 
    // Set the defaults
    this.barClosed = true;

    // Set the private defaults
    this._unsubscribeAll = new Subject();

    this.alwaysShowCalendars = true;

}


  ngOnInit(): void {
    this.maxDate = moment();

    this.restApiService.advance_search.subscribe(c => {
        

        console.log('c res',c);

        if(c.fields && c.fields.length > 0)
        {
            this.form_data = c;
            const controls = {};
            c.fields.forEach(res => {
              const validationsArray = [];
              if(res.validations.length > 0)
              {
                res.validations.forEach(val => {
                    if (val.name === 'required') {
                      validationsArray.push(
                        Validators.required
                      );
                    }
                    if (val.name === 'pattern') {
                      validationsArray.push(
                        Validators.pattern(val.validator)
                      );
                    }
                });
              }
              if(res.type == 'date-range')
              {
                controls[res.name] =  new FormControl({
                         start_date : new FormControl('', validationsArray),
                         end_date : new FormControl('', validationsArray)
                })  
                  
                // controls[res.name] = new FormControl('', validationsArray);
                // controls[res.start] = new FormControl('', validationsArray);
                // controls[res.end] = new FormControl('', validationsArray);
              }
              else
                 controls[res.name] = new FormControl(null, validationsArray);
            });
            this.form = new FormGroup(
              controls
            );
       
        }

        
    });
    // const controls = {};
    // this.form_data.fields.forEach(res => {
    //   const validationsArray = [];
    //   res.validations.forEach(val => {
    //     if (val.name === 'required') {
    //       validationsArray.push(
    //         Validators.required
    //       );
    //     }
    //     if (val.name === 'pattern') {
    //       validationsArray.push(
    //         Validators.pattern(val.validator)
    //       );
    //     }
    //   });
    //   controls[res.name] = new FormControl('', validationsArray);
    // });
    // this.form = new FormGroup(
    //   controls
    // );
  }

  clearDateRange(){
    this.clearAdvanceRange.nativeElement.value = '';
    this.form.controls['range'].reset();
  }
  /**
     * On destroy
     */
   ngOnDestroy(): void
   {
       // Unsubscribe from all subscriptions
       this._unsubscribeAll.next();
       this._unsubscribeAll.complete();

   }
   /**
     * Toggle sidebar open
     *
     * @param key
     */
    toggleSidebarOpen(key): void
    {
        this._fuseSidebarService.getSidebar(key).toggleOpen();
    }

    onSubmit(data){
        console.log('data',data);
        console.log('url',this.form_data.url);
        if(data.range && data.range != null)
        {
            if(data.range.start_date && data.range.start_date!=null && data.range.end_date && data.range.end_date!=null)
            {
                data.date_between = moment(data.range.start_date._d).format("YYYY-MM-DD")+','+moment(data.range.end_date._d).format("YYYY-MM-DD");
                
            }
        }
        

        this.restApiService.setAdvanceSubmitData(data);
    }
    resetSearch()
    {
        this.form.reset();
        this.restApiService.setAdvanceSubmitData({});
    }
    handleDateChanged(control: AbstractControl , event: MatDatepickerInputEvent<Date>){
        control.setValue(moment(event.value).format("YYYY-MM-DD"));
    }
}
