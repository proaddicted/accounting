import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'absoluteVal'
})
export class AbsoluteValPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return Math.abs(value);
  }

}
