import { AbsoluteValPipe } from './absolute-val.pipe';

describe('AbsoluteValPipe', () => {
  it('create an instance', () => {
    const pipe = new AbsoluteValPipe();
    expect(pipe).toBeTruthy();
  });
});
