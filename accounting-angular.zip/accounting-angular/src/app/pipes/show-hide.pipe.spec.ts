import { ShowHidePipe } from './show-hide.pipe';

describe('ShowHidePipe', () => {
  it('create an instance', () => {
    const pipe = new ShowHidePipe();
    expect(pipe).toBeTruthy();
  });
});
