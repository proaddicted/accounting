import { FuseNavigation } from '@fuse/types';

export const navigation: FuseNavigation[] = [
    {
        id       : 'applications',
        title    : 'Applications',
        translate: 'NAV.APPLICATIONS',
        type     : 'group',
        icon     : 'apps',
        children : [
            {
                id       : 'dashboards',
                title    : 'Dashboards',
                translate: 'NAV.DASHBOARDS',
                type     : 'collapsable',
                icon     : 'dashboard',
                children : [
                    {
                        id   : 'analytics',
                        title: 'Analytics',
                        type : 'item',
                        url  : '/apps/dashboards/analytics'
                    }
                ]
            },
            {
                id       : 'users',
                title    : 'Admins',
                translate: 'Admins',
                type     : 'collapsable',
                icon     : 'supervised_user_circle',
                children : [
                    {
                        id   : 'user',
                        title: 'All Admins',
                        type : 'item',
                        url  : '/user/users-list'
                    },
                    {
                        id   : 'user-add',
                        title: 'Add Admin',
                        type : 'item',
                        url  : '/user/add-edit-user/add/id'
                    }
                ]
            },
            {
                id       : 'customers',
                title    : 'Customers',
                translate: 'Customers',
                type     : 'collapsable',
                icon     : 'groups',
                children : [
                    {
                        id   : 'user',
                        title: 'All Customers',
                        type : 'item',
                        url  : '/customer/customers-list'
                    },
                    {
                        id   : 'customer-add',
                        title: 'Add Customer',
                        type : 'item',
                        url  : '/customer/add-edit-customer/add/id'
                    }
                ]
            },
            {
                id       : 'invoice',
                title    : 'Invoice Management',
                translate: 'Invoice Management',
                type     : 'collapsable',
                icon     : 'receipt',
                children : [
                    {
                        id   : 'item',
                        title: 'All Items',
                        type : 'item',
                        url  : '/item/items-list'
                    }
                ]
            },
            {
                id       : 'organization',
                title    : 'Organization Management',
                translate: 'Organization Management',
                type     : 'collapsable',
                icon     : 'home',
                children : [
                    {
                        id   : 'bank-account',
                        title: 'Manage Bank Account',
                        type : 'item',
                        url  : '/bank-account/bank-accounts-list'
                    },
                    {
                        id   : 'branch',
                        title: 'Manage Branch',
                        type : 'item',
                        url  : '/branch/branches-list'
                    },
                    {
                        id   : 'page-access',
                        title: 'Manage Pages',
                        type : 'item',
                        url  : '/page/pages-list'
                    },
                    {
                        id   : 'module',
                        title: 'Manage Modules',
                        type : 'item',
                        url  : '/module/modules-list'
                    }
                ]
            }
        ]
    }
];
