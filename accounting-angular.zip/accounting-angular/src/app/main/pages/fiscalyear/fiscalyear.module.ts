import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { FiscalyearListModule } from './fiscalyear-list/fiscalyear-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    FiscalyearListModule
  ]
})
export class FiscalyearModule { }
