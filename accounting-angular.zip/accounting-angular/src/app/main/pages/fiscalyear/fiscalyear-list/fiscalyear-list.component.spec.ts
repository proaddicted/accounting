import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FiscalyearListComponent } from './fiscalyear-list.component';

describe('FiscalyearListComponent', () => {
  let component: FiscalyearListComponent;
  let fixture: ComponentFixture<FiscalyearListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FiscalyearListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FiscalyearListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
