import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { OpeningBalanceAddModule } from './opening-balance-add/opening-balance-add.module';
import { OpeningBalanceListModule } from './opening-balance-list/opening-balance-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    OpeningBalanceAddModule,
    OpeningBalanceListModule
  ]
})
export class OpeningBalanceModule { }
