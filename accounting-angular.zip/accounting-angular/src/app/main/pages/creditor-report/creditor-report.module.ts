import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreditorReportListModule } from './creditor-report-list/creditor-report-list.module';
import { FuseConfirmDialogModule } from '@fuse/components';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CreditorReportListModule,
    FuseConfirmDialogModule
  ]
})
export class CreditorReportModule { }
