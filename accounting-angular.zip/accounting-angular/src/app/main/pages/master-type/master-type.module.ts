import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { MasterTypeAddModule } from './master-type-add/master-type-add.module';
import { MasterTypeListModule } from './master-type-list/master-type-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    MasterTypeAddModule,
    MasterTypeListModule
  ]
})
export class MasterTypeModule { }
