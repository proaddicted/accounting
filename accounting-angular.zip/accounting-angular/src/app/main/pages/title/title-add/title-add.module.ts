import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TitleAddComponent } from './title-add.component';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatStepperModule } from '@angular/material/stepper';

import { FuseSharedModule } from '@fuse/shared.module';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AccessGuard } from 'app/service/access.guard';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

const routes = [
    {
        path     : 'add-edit-title/:action/:id',
        component: TitleAddComponent,
        canActivate: [AccessGuard],
        data: {'access-type':2}
    }
];


@NgModule({
  declarations: [TitleAddComponent],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatStepperModule,
    MatCheckboxModule,
    FuseSharedModule,
    MatProgressSpinnerModule,
    MatSlideToggleModule
  ]
})
export class TitleAddModule { }
