import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TitleAddModule } from './title-add/title-add.module';
import { TitleListModule } from './title-list/title-list.module';
import { FuseConfirmDialogModule } from '@fuse/components';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TitleAddModule,
    TitleListModule,
    FuseConfirmDialogModule
  ]
})
export class TitleModule { }
