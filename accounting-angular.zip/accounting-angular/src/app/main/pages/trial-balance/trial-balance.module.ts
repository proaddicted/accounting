import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { TrialBalanceReportModule } from './trial-balance-report/trial-balance-report.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    TrialBalanceReportModule
  ]
})
export class TrialBalanceModule { }
