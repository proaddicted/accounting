import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { CustomerAddModule } from './customer-add/customer-add.module';
import { CustomerListModule } from './customer-list/customer-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    CustomerAddModule,
    CustomerListModule
  ]
})
export class CustomerModule { }
