import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { SalaryEntryAddModule } from './salary-entry-add/salary-entry-add.module';
import { SalaryEntryListModule } from './salary-entry-list/salary-entry-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    SalaryEntryAddModule,
    SalaryEntryListModule
  ]
})
export class SalaryEntryModule { }
