import { Component, OnDestroy, OnInit,ViewEncapsulation,ViewChild } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { RestApiService } from 'app/service/rest-api.service';
import { take, tap } from 'rxjs/operators';
import { invalid } from '@angular/compiler/src/render3/view/util';
import {MatAccordion} from '@angular/material/expansion';

import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-role-add',
  templateUrl: './role-add.component.html',
  styleUrls: ['./role-add.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations
})


export class RoleAddComponent implements OnInit,OnDestroy {

    model: any = {};  
    restApiURL : any = "role";  
    isLoading = false;
    form: FormGroup;  
    return_id:any;
    action:string;
    private _unsubscribeAll: Subject<any>;
  
    module:any = [];
    access_types:any = [];
    access_types_insert:any = [];
    access_element:any = [];

    selected_modules: any = [];
    @ViewChild(MatAccordion) accordion: MatAccordion;

    confirmDialogRef: MatDialogRef<FuseConfirmDialogComponent>;

    constructor(
      private _formBuilder:FormBuilder,
      private activatedRoute:ActivatedRoute,
      private restApi:RestApiService,
      private router: Router,
      private _matDialog: MatDialog
    ) {
      this._unsubscribeAll = new Subject();
     }
     ngOnInit(): void {
        
        this.isLoading = true;
        this.restApi.getlist(this.restApiURL).pipe(
            take(1)
        ).subscribe( res => {
                if(res.success)
                {
                    this.module = res.data.modules;
                    this.access_types = res.data.access_types;
                    this.access_types_insert = res.data.access_types_insert;
                    this.access_element = res.data.access_element;
                    

                    this.isLoading = false;
                }
                
        });
    
        this.form = this._formBuilder.group({
            name : ['', Validators.required],
            display_name : ['', Validators.required],
            modules:'',
            module: this._formBuilder.array([this._formBuilder.group(
                {
                    id:'',
                    display_name:'',
                    page:this._formBuilder.array
                    ([this._formBuilder.group(
                        {
                            id:'',
                            display_name:'',
                            permission:this._formBuilder.array([this._formBuilder.group(
                                {
                                    id:'',
                                    role_permission_id:'',
                                    display_name:'',
                                    options:this._formBuilder.array([this._formBuilder.group({value:''})]),
                                    access:''
                                })])
                            })])
                })]),
            status : [true]
        });
        
        this.return_id = this.activatedRoute.snapshot.paramMap.get('id');
        this.action = this.activatedRoute.snapshot.paramMap.get('action');
    
        if(this.action == 'edit' && this.return_id > 0)
            {
                this.isLoading = true;
               
                this.restApi.show(this.restApiURL,this.return_id).subscribe(res=>{
                
                    if(res.success)
                    {
                        let modules = [];
                        res.data.modules.forEach(x => {
                            
                            this.onAdd(x);
                            modules.push(x.id);
                        })

                        this.form.patchValue({
                            name: res.data.name,
                            display_name: res.data.display_name,
                            status : res.data.status,
                            modules : modules
                        })

                       
                        
                        
                    }
                       
                
                });
            }
      }

    pageReload()
    {
        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });
  
        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to reload, your unsaved data will be lost?';
  
        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                this.ngOnInit();
            }
           
            this.confirmDialogRef = null;
        });  
    }

    cancelForm()
    {
        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });
  
        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to navigate, your unsaved data will be lost?';
  
        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                this.router.navigateByUrl('role/roles-list');
            }
           
            this.confirmDialogRef = null;
        });  
    }
     onSubmit(data:any,event:any){

        if(this.action == 'edit' && this.return_id > 0)
        {
            this.restApi.update(`${this.restApiURL}/${this.return_id}`,data).pipe(
                take(1)
            ).subscribe( res => { 
               
                if(res.success)
                {
                    if( event == 'save')
                    {
                        let modules = [];
                        res.data.modules.forEach(x => {
                            
                            this.onAdd(x);
                            modules.push(x.id);
                        })

                        this.form.patchValue({
                            name: res.data.name,
                            display_name: res.data.display_name,
                            status : res.data.status,
                            modules : modules
                        })
                    }
                    else if(event == 'save_add')
                    {
                        this.selected_modules = [];   
                        this.form = this._formBuilder.group({
                            name : ['', Validators.required],
                            display_name : ['', Validators.required],
                            module: this._formBuilder.array([this._formBuilder.group(
                                {
                                    id:'',
                                    display_name:'',
                                    page:this._formBuilder.array
                                    ([this._formBuilder.group(
                                        {
                                            id:'',
                                            display_name:'',
                                            permission:this._formBuilder.array([this._formBuilder.group(
                                                {
                                                    id:'',
                                                    display_name:'',
                                                    options:this._formBuilder.array([this._formBuilder.group({value:''})]),
                                                    access:''
                                                })])
                                            })])
                                })]),
                            status : [true]
                        }); 
                        this.action = 'add';
                        this.return_id = 'id';
                        this.router.navigateByUrl('role/add-edit-role/add/id');
                    }
                    else if(event == 'save_exit')
                        this.router.navigateByUrl('role/roles-list');
    
                    
                }
    
            });
        }
        else
        {
            this.restApi.store(this.restApiURL,data).pipe(
                take(1)
            ).subscribe( res => { 
                console.log("Submit Success: " + res);
                if(res.success)
                   {
                        if( event == 'save')
                        {
                            let modules = [];
                            res.data.modules.forEach(x => {
                                
                                this.onAdd(x);
                                modules.push(x.id);
                            })

                            this.form.patchValue({
                                name: res.data.name,
                                display_name: res.data.display_name,
                                status : res.data.status,
                                modules : modules
                            });

                            this.action = 'edit';
                            this.return_id = res.data.id;
                            this.router.navigateByUrl('role/add-edit-role/edit/'+res.data.id);
                        }
                        else if(event == 'save_add')
                        {
                            this.selected_modules = [];   
                            this.form = this._formBuilder.group({
                                name : ['', Validators.required],
                                display_name : ['', Validators.required],
                                module: this._formBuilder.array([this._formBuilder.group(
                                    {
                                        id:'',
                                        display_name:'',
                                        page:this._formBuilder.array
                                        ([this._formBuilder.group(
                                            {
                                                id:'',
                                                display_name:'',
                                                permission:this._formBuilder.array([this._formBuilder.group(
                                                    {
                                                        id:'',
                                                        display_name:'',
                                                        options:this._formBuilder.array([this._formBuilder.group({value:''})]),
                                                        access:''
                                                    })])
                                                })])
                                    })]),
                                status : [true]
                            }); 
                            this.action = 'add';
                            this.return_id = 'id';
                            this.router.navigateByUrl('role/add-edit-role/add/id');
                        }
                        else if(event == 'save_exit')
                            this.router.navigateByUrl('role/roles-list');
                   }
    
            });  
        }
     }

    onAdd($event : any) {
        this.selected_modules.push($event);
        this.setPages(this.selected_modules);
    }

    setPages(selected_modules)
    {
      
       
        (this.form.controls['module'] as FormArray).clear();

        //let module_arr: any = []
        // selected_modules.forEach(module => {

        //     let page_arr: any = [];
        //     this.module().push(this.newModule(module.id));
            
        //     module.pages.forEach(page => {
        //         this.page(module.id).push(this.newPage(page.id));
        //     });
            
        // })

        // this.form.patchValue({'module':module_arr});
        this.form.get('module').markAsUntouched();
        (this.form.controls['module'] as FormArray).clear();
        let control = <FormArray>this.form.controls.module;
        let i = 0;
        selected_modules.forEach(module => {
        
            
            control.push(this._formBuilder.group({'id':module.id,'display_name':module.display_name,page: this.setPage(module.pages)}));
            
            
            i++;
        })
   }

    get modules() {
     return this.form.get('module') as FormArray;
    }
    setPage(pages)
    {
        let arr = new FormArray([]);

        if(this.action == 'edit' && this.return_id > 0)
        {   
            
            pages.forEach(page => {
                if(page.role_permission && page.role_permission.length > 0)
                {
                    arr.push(this._formBuilder.group({ 
                        id: page.id ,
                        display_name: page.display_name,
                        permission:this.setEditPermission(page.role_permission)
                    }))
                }
                else
                {
                    arr.push(this._formBuilder.group({ 
                        id: page.id ,
                        display_name: page.display_name,
                        permission:this.setPermission()
                    }))    
                }
               
            })
        }
        else{
            pages.forEach(page => {
            
                arr.push(this._formBuilder.group({ 
                    id: page.id ,
                    display_name: page.display_name,
                    permission:this.setPermission()
                }))
            })
        }
       

        return arr;
    }
    
    setPermission()
    {
        let arr = new FormArray([]);
        this.access_element.forEach(permission => {
            let options = [];

            if(permission.id == 1 || permission.id == 2 || permission.id == 4)
                options = this.access_types_insert;
            else
                options = this.access_types;

            arr.push(this._formBuilder.group({ 
                id: permission.id ,
                display_name:permission.name,
                options:[{value:options}],
                access:'',
                role_permission_id:'',
            }))
        })
        return arr;
    }

    setEditPermission(role_permission)
    {
        let arr = new FormArray([]);
        this.access_element.forEach(permission => {
            let options = [];

            if(permission.id == 1 || permission.id == 2 || permission.id == 4)
                options = this.access_types_insert;
            else
                options = this.access_types;
             
                     
                
                let permission_access = [];
                let role_permission_id = [];
                role_permission.forEach(rp => {

                    
                    if(rp.permission_id == permission.id)
                    {

                        arr.push(this._formBuilder.group({ 
                            id: permission.id ,
                            display_name:permission.name,
                            options:[{value:options}],
                            access: parseInt(rp.access),
                            role_permission_id:parseInt(rp.id),
                        }))
                        permission_access[permission.id] = parseInt(rp.access);
                        role_permission_id[permission.id] = parseInt(rp.id);
                    }

                })  

                
                
                
                
                
        })
        this.isLoading = false;
        return arr;
    }
   
    get inFormArray(): FormArray {
        return this.form.get('module') as FormArray;
    }
    removeMod(i:number) {
        this.inFormArray.removeAt(i);
    }
    clear(){
        this.inFormArray.reset();
        this.selected_modules= [];
    }
    onRemove($event : any) {

            this.removeMod(this.form.controls.module.value.findIndex(x=>x.id==$event.value.id))
            this.selected_modules.splice(this.form.controls.module.value.findIndex(x=>x.id==$event.value.id),1);
    }
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }
}
