import { CashFlowReportModule } from './cash-flow-report/cash-flow-report.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    CashFlowReportModule
  ]
})
export class CashFlowModule { }
