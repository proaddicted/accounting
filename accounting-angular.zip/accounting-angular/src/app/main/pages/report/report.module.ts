import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { CustomerLedgerModule } from './customer-ledger/customer-ledger.module';
import { VendorLedgerModule } from './vendor-ledger/vendor-ledger.module';
import { FullLedgerModule } from './full-ledger/full-ledger.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    CustomerLedgerModule,
    VendorLedgerModule,
    FullLedgerModule
  ]
})
export class ReportModule { }
