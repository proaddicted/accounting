import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { CountryListModule } from './country-list/country-list.module';
import { CountryAddModule } from './country-add/country-add.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    CountryListModule,
    CountryAddModule
  ]
})
export class CountryModule { }
