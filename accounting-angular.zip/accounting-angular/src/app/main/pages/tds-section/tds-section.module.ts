import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { TdsSectionAddModule } from './tds-section-add/tds-section-add.module';
import { TdsSectionListModule } from './tds-section-list/tds-section-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    TdsSectionAddModule,
    TdsSectionListModule
  ]
})
export class TdsSectionModule { }
