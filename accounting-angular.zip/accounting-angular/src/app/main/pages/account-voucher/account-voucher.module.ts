import { AccountVoucherListModule } from './account-voucher-list/account-voucher-list.module';
import { AccountVoucherAddModule } from './account-voucher-add/account-voucher-add.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    AccountVoucherAddModule,
    AccountVoucherListModule
  ]
})
export class AccountVoucherModule { }
