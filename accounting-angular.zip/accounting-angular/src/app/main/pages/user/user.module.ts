import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule, FuseSidebarModule } from '@fuse/components';
import { UserAddModule } from 'app/main/pages/user/user-add/user-add.module';
import { UserListModule } from 'app/main/pages/user/user-list/user-list.module';
import { FilterComponent } from './modal/filter/filter.component';

import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRippleModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule, } from '@angular/material/progress-spinner';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMatFileInputModule } from '@angular-material-components/file-input';

@NgModule({
  declarations: [FilterComponent],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    UserAddModule,
    UserListModule,

    MatButtonModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatRippleModule,
    MatTableModule,
    MatToolbarModule,
    MatCardModule,
    MatProgressSpinnerModule,
    NgxMatFileInputModule,
    FormsModule,    //added here too
    ReactiveFormsModule //added here too


  ],
  entryComponents: [
    FilterComponent
]
})
export class UserModule { }
