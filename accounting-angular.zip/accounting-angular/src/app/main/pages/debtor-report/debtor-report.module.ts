import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DebtorReportListModule } from './debtor-report-list/debtor-report-list.module';
import { FuseConfirmDialogModule } from '@fuse/components';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DebtorReportListModule,
    FuseConfirmDialogModule
  ]
})
export class DebtorReportModule { }
