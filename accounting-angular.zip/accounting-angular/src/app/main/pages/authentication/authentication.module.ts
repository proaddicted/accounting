import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginModule } from 'app/main/pages/authentication/login/login.module';
import { ResetPasswordModule } from './reset-password/reset-password.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    LoginModule,
    ResetPasswordModule
  ]
})
export class AuthenticationModule { }
