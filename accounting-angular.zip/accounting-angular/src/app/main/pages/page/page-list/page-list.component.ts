import { AfterViewInit, Component, OnDestroy, OnInit,ViewChild,ViewEncapsulation } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable, of, Subject, Subscription } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { CollectionViewer, DataSource , SelectionModel} from '@angular/cdk/collections';
import { ApiData, RestApiService } from 'app/service/rest-api.service';
import { catchError, finalize, take, tap, map } from 'rxjs/operators';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';
import { CommonHeaderComponent } from 'app/modal/common-header/common-header.component';
import { MatTable } from '@angular/material/table';

@Component({
  selector: 'app-page-list',
  templateUrl: './page-list.component.html',
  styleUrls: ['./page-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations
})
export class PageListComponent implements OnInit,OnDestroy {

    url:string='page';
    header_url = `${this.url}_headers`;
    isLoading = true;
    isDataLoading = false;
    search:any = '';   
    dialogRef: any;
    userdata:any = [];
    dataSource : ApiData = null;
    confirmDialogRef: MatDialogRef<FuseConfirmDialogComponent>;
    pageEvent: PageEvent;
    selection = new SelectionModel<ApiData>(true, []);

    @ViewChild(MatPaginator)
    paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort; 

    @ViewChild(MatTable) table: MatTable<any>;

    @ViewChild('search') clearInput;

    private itemsHeaderSubscribe: Subscription;
    tableHeaderData;
    tableHeaderDataDropdown;
    tableheaderDropdown;
    tableheaderDropdownChecked;
    tableDefaultChecked;
    displayedColumns : string[] = []; 
    private _unsubscribeAll: Subject<any>;
    
  constructor(private restApiService: RestApiService,private route: ActivatedRoute,private _matDialog: MatDialog) { 
    this._unsubscribeAll = new Subject();
  }

  ngOnInit(): void {
    this.onHeaderData(this.header_url);
    this.initDataSource(this.url,'','','',null,null);
  }
  initDataSource(url: string,search='',filter='',sort='',pageIndex=1,pageSize=10){
    pageIndex  =  pageIndex == null ? 1 : pageIndex;
    pageSize   =  pageSize  == null ? 10 : pageSize;
    this.isLoading = true;
    this.restApiService.index(url,search, filter, sort,
        pageIndex, pageSize)
        .pipe(
            map((ApiData : ApiData) => this.dataSource = ApiData)
        )
        .subscribe(res=>{
            this.isLoading = false;

        });
  }
  _search = function ($event: { target: { value: string; }; }) {

    this.search = $event.target.value
    this.isLoading = true;
    
    //fetch list params url,search,filter,sort,page,per_pate
    this.initDataSource(this.url,this.search,'','',null,null)
    
  }
  handleClear(){
        // clearing the value    
        this.clearInput.nativeElement.value = '';
        this.initDataSource(this.url,'','','',1,10);
    }
  onPaginateChange(event: PageEvent){
    let page = event.pageIndex;
    let size = event.pageSize;

    this.isDataLoading = true;

    let sorting = '';
    if(this.sort.active)
        sorting  = this.sort.direction == 'desc' ? '-'+this.sort.active : this.sort.active;

    page = page + 1;
   
    this.restApiService.index(this.url,this.search, '', sorting,
        page, size).pipe(
         map((UserData : ApiData) => this.dataSource = UserData)
    ).subscribe(res=>{
        this.isLoading = false;
        this.isDataLoading = false;
    });
    
  }
  deleteItem(item : any,index:number): void
  {
      this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
          disableClose: false
      });

      this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to delete?';

      this.confirmDialogRef.afterClosed().subscribe(result => {
          if ( result )
          {
              this.restApiService.destroy(this.url,item.id).pipe(
                  take(1)
                ).subscribe( res => { 
                  console.log("Submit Success: " + res);
                  if(res.success)
                  {
                        this.dataSource.data.splice(index,1);
                        this.dataSource.total = this.dataSource.total - 1;
                        this.table.renderRows();
                  }
      
              }); 
              
              
          }
          this.confirmDialogRef = null;
      });

  } 
  ngOnDestroy(): void
  {
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();   
  }
  _changeStatus(item){
   
    item.status = parseInt(item.status) ? 0 : 1;
    this.restApiService.update(`${this.url}/${item.id}`,{status:item.status,name:item.name,display_name:item.display_name,url:item.url}).pipe(
        take(1)
    ).subscribe( res => { 
        
        if(res.success)
        {
            item.status  = res.data.status ;
            
        }

    });
   } 

   // --------- table header function -----------//
   onHeaderData(_header_url) {

    this.isLoading = true;
    this.itemsHeaderSubscribe = this.restApiService.headerListData(_header_url).subscribe(
    resData => {
        this.tableHeaderData = resData[0];
        this.tableheaderDropdownChecked = resData[1];
        this.displayedColumns = ['position','selection',...resData[1].map(x=>x.column_name),'action'];
    },
    errRes => {
    }
    );
    }

    headerModal(){
        const dialogRef = this._matDialog.open(CommonHeaderComponent, {
            data: {
            headerName :this.header_url,
            allHeader:this.tableHeaderData,
            }
        });
        dialogRef.afterClosed().subscribe(result => {

            if(result != undefined){
                this.tableheaderDropdownChecked=[]
                this.tableHeaderData = [];
                this.tableHeaderData = [...result];
                this.tableheaderDropdownChecked = [...result.filter(y=>y.is_default == 1)];
                let reCol = result.filter(y=>y.is_default == 1).map(x=>x.column_name);
                this.displayedColumns = ['position','selection',...reCol,'action'];
                console.log('this.displayedColumns',this.displayedColumns);
            }
            
        },
        errRes=>{});
    }

    //----------- table header end function -----//
    //---------table footer functions----//
        isAllSelected() {
            const numSelected = this.selection.selected.length;
            const numRows = this.dataSource.data.length;
            return numSelected === numRows;
        }

        
        masterToggle() {
        this.isAllSelected() ?
            this.selection.clear() :
            this.dataSource.data.forEach(row => this.selection.select(row));
        }
        
        checkboxLabel(row?: ApiData): string {
        if (!row) {
            return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
        }
        
        }

        deleteAll(){
        
        

        let mutli_ids = [];

        this.selection.selected.forEach((element: any, key: number) => {
            mutli_ids.push(element.id);
        });

        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });

        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to delete selected items?';

        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                
                this.restApiService.actionAll(this.url,mutli_ids,'delete',1,'deleted_at').pipe(
                    take(1)
                    ).subscribe( res => { 
                    console.log("Submit Success: " + res);
                    if(res.success)
                        this.initDataSource(this.url,'','','',null,null);
        
                }); 
                
            }
            this.selection.clear();
            this.confirmDialogRef = null;
        });
        }

        statusChangeAll(status:any){
        
        let mutli_ids = [];

        this.selection.selected.forEach((element: any, key: number) => {
            mutli_ids.push(element.id);
        });

        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });

        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to update selected items?';

        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                
                this.restApiService.actionAll(this.url,mutli_ids,'update',status,'status').pipe(
                    take(1)
                    ).subscribe( res => { 
                    console.log("Submit Success: " + res);
                    if(res.success)
                        this.initDataSource(this.url,'','','',null,null);
        
                }); 
                
            }
            this.selection.clear();
            this.confirmDialogRef = null;
        });

        }

    //---------table footer functions end----//
    customSort(sort : Sort,event : PageEvent)
    {
        let page = event.pageIndex;
        let size = event.pageSize;

        page = page + 1;
        
        if(sort)
        {
            this.isDataLoading = true;
            let sorting = sort.direction == 'desc' ? '-'+sort.active : sort.active;

            this.restApiService.index(this.url,this.search, '', sorting,
            page, size).pipe(
                map((UserData : ApiData) => this.dataSource = UserData)
            ).subscribe(res=>{
                this.isLoading = false;
                this.isDataLoading = false;
            });
        }
        
    }
}
