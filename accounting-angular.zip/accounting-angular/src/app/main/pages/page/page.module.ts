import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { PageAddModule } from './page-add/page-add.module';
import { PageListModule } from './page-list/page-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    PageAddModule,
    PageListModule
  ]
})
export class PageModule { }
