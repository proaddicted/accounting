import { Component, OnDestroy, OnInit,ViewEncapsulation } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { RestApiService } from 'app/service/rest-api.service';
import { take } from 'rxjs/operators';
import { invalid } from '@angular/compiler/src/render3/view/util';

import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-page-add',
  templateUrl: './page-add.component.html',
  styleUrls: ['./page-add.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations
})
export class PageAddComponent implements OnInit,OnDestroy {

    model: any = {};  
    restApiURL : any = "page";  
    isLoading = false;
    form: FormGroup;  
    return_id:any;
    action:string;
    private _unsubscribeAll: Subject<any>;

    confirmDialogRef: MatDialogRef<FuseConfirmDialogComponent>;

  constructor(
    private _formBuilder:FormBuilder,
    private activatedRoute:ActivatedRoute,
    private restApi:RestApiService,
    private router: Router,
    private _matDialog: MatDialog
  ) {
    this._unsubscribeAll = new Subject();
   }

  ngOnInit(): void {
    this.form = this._formBuilder.group({
        name : ['', Validators.required],
        display_name : ['', Validators.required],
        url : ['', Validators.required],
        icon : [''],
        status : [true]
    });

    this.return_id = this.activatedRoute.snapshot.paramMap.get('id');
    this.action = this.activatedRoute.snapshot.paramMap.get('action');

    if(this.action == 'edit' && this.return_id > 0)
        {
            this.isLoading = true;
            this.restApi.show(this.restApiURL,this.return_id).pipe(
                take(1)
            ).subscribe( res => {
                    if(res.success)
                    {
                        this.form = this._formBuilder.group({
                            name : [res.data.name, Validators.required],
                            display_name : [res.data.display_name, Validators.required],
                            url : [res.data.url, Validators.required],
                            icon : [res.data.icon],
                            status : [res.data.status]
                        });
                        this.isLoading = false;
                    }
            });    
        }
  }

  pageReload()
    {
        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });
  
        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to reload, your unsaved data will be lost?';
  
        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                this.ngOnInit();
            }
           
            this.confirmDialogRef = null;
        });  
    }

    cancelForm()
    {
        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });
  
        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to navigate, your unsaved data will be lost?';
  
        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                this.router.navigateByUrl('page/pages-list');
            }
           
            this.confirmDialogRef = null;
        });  
    }
  onSubmit(data:any,event:any){

    if(this.action == 'edit' && this.return_id > 0)
    {
        this.restApi.update(`${this.restApiURL}/${this.return_id}`,data).pipe(
            take(1)
        ).subscribe( res => { 
            console.log("Submit Success: " + res);
            if(res.success)
            {
                if( event == 'save')
                {
                    this.form = this._formBuilder.group({
                        name : [res.data.name, Validators.required],
                        display_name : [res.data.display_name, Validators.required],
                        url : [res.data.url, Validators.required],
                        icon : [res.data.icon],
                        status : [res.data.status]
                    });
                }
                else if(event == 'save_add')
                {
                    this.form.reset();  
                    this.action = 'add';
                    this.return_id = 'id';
                    this.router.navigateByUrl('page/add-edit-page/add/id');
                }
                else if(event == 'save_exit')
                    this.router.navigateByUrl('page/pages-list');
                
            }

        });
    }
    else
    {
        this.restApi.store(this.restApiURL,data).pipe(
            take(1)
        ).subscribe( res => { 
            console.log("Submit Success: " + res);
            if(res.success)
            {
                if( event == 'save')
                {
                    this.form = this._formBuilder.group({
                        name : [res.data.name, Validators.required],
                        display_name : [res.data.display_name, Validators.required],
                        url : [res.data.url, Validators.required],
                        icon : [res.data.icon],
                        status : [res.data.status]
                    });

                    this.action = 'edit';
                    this.return_id = res.data.id;
                    this.router.navigateByUrl('page/add-edit-page/edit/'+res.data.id);
                }
                else if(event == 'save_add')
                {
                    this.form.reset();  
                    this.action = 'add';
                    this.return_id = 'id';
                    this.router.navigateByUrl('page/add-edit-page/add/id');
                }
                else if(event == 'save_exit')
                    this.router.navigateByUrl('page/pages-list');
            }

        });  
    }
  }
  ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }
}
