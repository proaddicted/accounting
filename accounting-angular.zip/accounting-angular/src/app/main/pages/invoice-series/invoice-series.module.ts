import { InvoiceSeriesListModule } from './invoice-series-list/invoice-series-list.module';
import { InvoiceSeriesAddModule } from './invoice-series-add/invoice-series-add.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InvoiceSeriesAddModule,
    InvoiceSeriesListModule,
    FuseConfirmDialogModule
  ]
})
export class InvoiceSeriesModule { }
