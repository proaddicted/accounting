import { AfterViewInit, Component, OnDestroy, OnInit,ViewChild,ViewEncapsulation } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BehaviorSubject, Observable, of, Subject, Subscription } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { CollectionViewer, DataSource, SelectionModel } from '@angular/cdk/collections';
import { ApiData, RestApiService } from 'app/service/rest-api.service';
import { catchError, finalize, take, tap, map } from 'rxjs/operators';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';
import { CommonHeaderComponent } from 'app/modal/common-header/common-header.component';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import * as _moment from 'moment';
import { InvoiceAddComponent } from '../../invoice/invoice-add/invoice-add.component';
import { HttpClient } from '@angular/common/http';

const moment =  _moment;

export interface Transaction{
    date: any;
    reference: string;
    type: string;
    debit: number;
    credit:number;
}

@Component({
  selector: 'app-cashbook-report-list',
  templateUrl: './cashbook-report-list.component.html',
  styleUrls: ['./cashbook-report-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations
})
export class CashbookReportListComponent implements OnInit,OnDestroy {

  displayedColumns: string[] = ['date', 'reference','type','debit','credit','action'];
  isLoading = true;
  isSearch = true;
  isDataLoading = false;
  customers=[];
  fiscal_years=[];  
  start_date : any;
  end_date : any;

  dataSource;
  transactions;

  form: FormGroup;

  private _unsubscribeAll: Subject<any>;

  alwaysShowCalendars: boolean;
  ranges: any;
  
  @ViewChild('clearRange') clearRange;
  
  maxDate;

  constructor(
    private _formBuilder:FormBuilder,
    private restApiService: RestApiService,
    private route: ActivatedRoute,
    private _matDialog: MatDialog,
    private http: HttpClient
  ) {
        this._unsubscribeAll = new Subject();
            
        this.maxDate = moment();
        
        this.restApiService.getlist('report').pipe(
        take(1)
        ).subscribe( res => {
            if(res.success)
            {
                
                this.customers = res.data.customers;
                this.fiscal_years = res.data.fiscal_years;
                
                this.ranges = {
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last 3 Month': [moment().subtract(3, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                    'Last 6 Month': [moment().subtract(6, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                    'Current Fiscal Year': [moment(res.data.fiscal_years[0].start_date), moment(res.data.fiscal_years[0].end_date)]
                }
                
                if(res.data.fiscal_years.length > 1)
                {
                    Object.assign(this.ranges, {'Previous Fiscal Year': [moment(res.data.fiscal_years[1].start_date), moment(res.data.fiscal_years[1].end_date)]});
                }     
                this.isLoading = false;
            }
        });
   }

   ngOnInit(): void {
    const controls = {};
    controls['range'] =  new FormControl({
        start_date : new FormControl(''),
        end_date : new FormControl('')
    })  
    this.form = new FormGroup(
        controls
    );
  }
  clearDateRange(){
    this.clearRange.nativeElement.value = '';
    this.form.controls['range'].reset();
  }

  onSubmit(data)
  {
    
    if(data.range && data.range != null)
    {
        if(data.range.start_date && data.range.start_date!=null && data.range.end_date && data.range.end_date!=null)
        {
            data.start_date = moment(data.range.start_date._d).format("YYYY-MM-DD");
            data.end_date = moment(data.range.end_date._d).format("YYYY-MM-DD");

            this.start_date = moment(data.range.start_date._d).format("DD/MM/YYYY");
            this.end_date = moment(data.range.end_date._d).format("DD/MM/YYYY");
            
        }
    }
    this.isSearch = true;
    this.isDataLoading = true;
    this.restApiService.searchDataByPost('cashbook_report',data)
      .subscribe((transactions: Transaction[]) => {
        
        this.transactions = transactions;
        this.dataSource = new MatTableDataSource(transactions);
        this.isSearch = false;
        this.isDataLoading = false;
        
      });
  }

  downloadPdf(data){

    if(data.range && data.range != null)
    {
        if(data.range.start_date && data.range.start_date!=null && data.range.end_date && data.range.end_date!=null)
        {
            data.start_date = moment(data.range.start_date._d).format("YYYY-MM-DD");
            data.end_date = moment(data.range.end_date._d).format("YYYY-MM-DD");
            
        }
    }

    const salt = (new Date()).getTime();
    return this.http.post(`cashbook_report_pdf?salt=${salt}`,data, {responseType:'blob'}).subscribe(res => {
    

        var FileSaver = require('file-saver');
        const blob = new Blob([res], {type: 'application/pdf'});
        FileSaver.saveAs(blob, `Cashbook-Report-${moment().format("DD-MM-YY")}.pdf`);
       
        
        
    }, err => {
        console.log(err);
    });

  }

  getTotalCredit() {
    
    const result = this.transactions.reduce( (acc, curr) => {
     
        if(curr['credit'] != '')
            acc.credit += parseFloat(curr['credit']);
      
      return acc;
    }, {credit: 0});

    return result.credit;
  }
  getTotalDebit() {
    const result = this.transactions.reduce( (acc, curr) => {
     
        if(curr['debit'] != '')
            acc.debit += parseFloat(curr['debit']);
      
      return acc;
    }, {debit: 0});

    return result.debit;
  }

  getTotalClosingBalance(){
    
    return  this.getTotalCredit() - this.getTotalDebit();
  }

  getTotalGrandCredit(){
    if(this.getTotalClosingBalance() < 0)
    {
      return  this.getTotalCredit() + Math.abs(this.getTotalClosingBalance())
    }
    else
        return  this.getTotalCredit()
  }

  getTotalGrandDebit(){
    if(this.getTotalClosingBalance() >= 0)
    {
      return  this.getTotalDebit() + Math.abs(this.getTotalClosingBalance());
    }
    else
        return  this.getTotalDebit()
  }
  ngOnDestroy(): void{
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
  }

}
