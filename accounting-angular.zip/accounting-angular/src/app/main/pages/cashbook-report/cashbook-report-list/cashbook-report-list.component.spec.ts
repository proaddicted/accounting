import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CashbookReportListComponent } from './cashbook-report-list.component';

describe('CashbookReportListComponent', () => {
  let component: CashbookReportListComponent;
  let fixture: ComponentFixture<CashbookReportListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CashbookReportListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CashbookReportListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
