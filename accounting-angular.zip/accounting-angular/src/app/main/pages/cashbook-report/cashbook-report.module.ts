import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CashbookReportListModule } from './cashbook-report-list/cashbook-report-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CashbookReportListModule
  ]
})
export class CashbookReportModule { }
