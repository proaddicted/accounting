import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JsonReportListModule } from './json-report-list/json-report-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    JsonReportListModule
  ]
})
export class JsonReportModule { }
