import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { InvoiceAddModule } from './invoice-add/invoice-add.module';
import { InvoiceListModule } from './invoice-list/invoice-list.module';
import { InvoiceViewModule } from './invoice-view/invoice-view.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    InvoiceAddModule,
    InvoiceListModule,
    InvoiceViewModule
  ]
})
export class InvoiceModule { }
