import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { ModuleAddModule } from './module-add/module-add.module';
import { ModuleListModule } from './module-list/module-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    ModuleAddModule,
    ModuleListModule
  ]
})
export class ModuleModule { }
