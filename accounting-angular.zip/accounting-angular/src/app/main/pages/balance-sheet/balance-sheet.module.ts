import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { BalanceSheetReportModule } from './balance-sheet-report/balance-sheet-report.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    BalanceSheetReportModule
  ]
})
export class BalanceSheetModule { }
