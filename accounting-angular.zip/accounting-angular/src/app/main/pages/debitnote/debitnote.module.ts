import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DebitnoteAddModule } from './debitnote-add/debitnote-add.module';
import { DebitnoteListModule } from './debitnote-list/debitnote-list.module';
import { FuseConfirmDialogModule } from '@fuse/components';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DebitnoteAddModule,
    DebitnoteListModule,
    FuseConfirmDialogModule
  ]
})
export class DebitnoteModule { }
