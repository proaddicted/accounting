import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { CreditnoteAddModule } from './creditnote-add/creditnote-add.module';
import { CreditnoteListModule } from './creditnote-list/creditnote-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    CreditnoteAddModule,
    CreditnoteListModule
  ]
})
export class CreditnoteModule { }
