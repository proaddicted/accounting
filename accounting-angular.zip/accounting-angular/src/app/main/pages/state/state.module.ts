import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { StateAddModule } from './state-add/state-add.module';
import { StateListModule } from './state-list/state-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    StateAddModule,
    StateListModule
  ]
})
export class StateModule { }
