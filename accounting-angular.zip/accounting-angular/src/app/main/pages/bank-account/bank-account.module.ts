import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { BankAccountAddModule } from './bank-account-add/bank-account-add.module';
import { BankAccountListModule } from './bank-account-list/bank-account-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    BankAccountAddModule,
    BankAccountListModule
  ]
})
export class BankAccountModule { }
