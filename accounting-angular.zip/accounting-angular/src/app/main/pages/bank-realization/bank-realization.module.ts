import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { BankRealizationListModule } from './bank-realization-list/bank-realization-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    BankRealizationListModule
  ]
})
export class BankRealizationModule { }
