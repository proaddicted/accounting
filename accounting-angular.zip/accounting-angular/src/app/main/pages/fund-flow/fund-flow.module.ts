import { FundFlowReportModule } from './fund-flow-report/fund-flow-report.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    FundFlowReportModule
  ]
})
export class FundFlowModule { }
