import { AfterViewInit, ChangeDetectorRef, Component, OnDestroy, OnInit,ViewChild,ViewEncapsulation } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable, of, Subject, Subscription } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { CollectionViewer, DataSource, SelectionModel } from '@angular/cdk/collections';
import { ApiData, RestApiService } from 'app/service/rest-api.service';
import { catchError, finalize, take, tap, map } from 'rxjs/operators';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';
import { CommonHeaderComponent } from 'app/modal/common-header/common-header.component';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import {FlatTreeControl} from '@angular/cdk/tree';
import {MatTreeFlatDataSource, MatTreeFlattener} from '@angular/material/tree';


interface CategoryNode {
    id: number;
    name: string;
    type: string;
    type_name: string;
    is_delete: number;
    is_edit: number;
    status:boolean;
    children?: CategoryNode[];
}

interface ExampleFlatNode {
    expandable: boolean;
    id: number;
    name: string;
    type: string;
    type_name: string;
    is_delete: number;
    is_edit: number;
    status:boolean;
    level: number;
}

@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations
})

export class CategoryListComponent implements OnInit,OnDestroy {

    url:string='category';
    isLoading = true;
    isDataLoading = false;
    search:any = '';   
    dialogRef: any;
    userdata:any = [];

    confirmDialogRef: MatDialogRef<FuseConfirmDialogComponent>;
    pageEvent: PageEvent;

    @ViewChild(MatSort) sort: MatSort; 
    
    @ViewChild(MatTable) table: MatTable<any>;
    
    @ViewChild('search') clearInput;

    private _unsubscribeAll: Subject<any>;

    displayedColumns: string[] = ['name', 'type','action'];

    private transformer = (node: CategoryNode, level: number) => {
        return {
          expandable: !!node.children && node.children.length > 0,
          id: node.id,
          name: node.name,
          type: node.type,
          type_name:node.type_name,
          is_edit:node.is_edit,
          is_delete:node.is_delete,
          status:node.status,
          level: level,
        };
    }

    treeControl = new FlatTreeControl<ExampleFlatNode>(
        node => node.level, node => node.expandable);
  
    treeFlattener = new MatTreeFlattener(
        this.transformer, node => node.level, 
        node => node.expandable, node => node.children);
  
    dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

    constructor(
        private restApiService: RestApiService,private route: ActivatedRoute,private _matDialog: MatDialog, private _changeDetectorRef: ChangeDetectorRef
    ) { 
        this._unsubscribeAll = new Subject();
    }

    ngOnInit(): void {

        this.initDataSource(this.url,'','','',null,null);
    }

    initDataSource(url: string,search='',filter='',sort='',pageIndex=1,pageSize=10){
        this.isLoading = true;
        
        this.restApiService.categoryData(this.url,search)
        .subscribe((transactions: CategoryNode[]) => {
            
            this.dataSource.data = transactions;
            this.isLoading = false;
            
        });
    }
    _search = function ($event: { target: { value: string; }; }) {

        this.search = $event.target.value
        this.isLoading = true;
        
        //fetch list params url,search,filter,sort,page,per_pate
        this.initDataSource(this.url,this.search,'','',null,null)
        
    }
    handleClear(){
        // clearing the value    
        this.clearInput.nativeElement.value = '';
        this.initDataSource(this.url,'','','',1,10);
    }
    deleteItem(item : any,index:number): void
    {
        
        // this.dataSource.data = this.dataSource.data.splice(index,1);
        // this.table.renderRows();                
       // this.dataSource.data = new MatTreeFlatDataSource( this.dataSource.data.splice(index,1));
        // this._changeDetectorRef.markForCheck();
        // let index: number = this.dataSource.data.findIndex(d => d === item);
        // this.dataSource.data.splice(index, 1);

        // console.log('this.dataSource.data',this.dataSource.data)
        // this.dataSource.data = this.dataSource.data;
        
        // this.dataChange.next(this.dataSource.data);
        // // new MatTableDataSource<ApiData>(this.dataSource.data);
        
        // this._changeDetectorRef.detectChanges();
        // this._changeDetectorRef.markForCheck();
        
        
        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });

        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to delete?';

        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                this.restApiService.destroy(this.url,item.id).pipe(
                    take(1)
                    ).subscribe( res => { 
                    console.log("Submit Success: " + res);
                    if(res.success)
                    {
                            this.initDataSource(this.url,'','','',null,null);
                            this.dataSource.data.splice(index,1);
                        
                            this.table.renderRows();
                            
                    }   
        
                }); 
                
                
            }
            this.confirmDialogRef = null;
        });

    } 

    _changeStatus(item){
   
        item.status = parseInt(item.status) ? 0 : 1;
        this.restApiService.update(`${this.url}/${item.id}`,{status:item.status,name:item.name}).pipe(
            take(1)
        ).subscribe( res => { 
            
            if(res.success)
            {
                item.status  = res.data.status ;
                
            }

        });
    }
    ngOnDestroy(): void
    {
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete(); 
    }

}
