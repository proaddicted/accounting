import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { CategoryAddModule } from './category-add/category-add.module';
import { CategoryListModule } from './category-list/category-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    CategoryAddModule,
    CategoryListModule
  ]
})
export class CategoryModule { }
