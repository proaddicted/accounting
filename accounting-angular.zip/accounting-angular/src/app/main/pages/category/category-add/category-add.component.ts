import { Component, OnDestroy, OnInit,ViewEncapsulation } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { RestApiService } from 'app/service/rest-api.service';
import { take } from 'rxjs/operators';
import { invalid } from '@angular/compiler/src/render3/view/util';

import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-category-add',
  templateUrl: './category-add.component.html',
  styleUrls: ['./category-add.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations
})
export class CategoryAddComponent implements OnInit ,OnDestroy {

    model: any = {};  
    restApiURL : any = "category";  
    isLoading = false;
    form: FormGroup;  
    return_id:any;
    action:string;
    categories = [];
    types = [];

    parent_read_only = false;

    private _unsubscribeAll: Subject<any>;
  
    confirmDialogRef: MatDialogRef<FuseConfirmDialogComponent>;
  
    constructor(
      private _formBuilder:FormBuilder,
      private activatedRoute:ActivatedRoute,
      private restApi:RestApiService,
      private router: Router,
      private _matDialog: MatDialog
    ) { 
      this._unsubscribeAll = new Subject();
    }
  
    ngOnInit(): void {

        this.form = this._formBuilder.group({
          name : ['', Validators.required],
          description : [''],
          parent_id : [null],
          type : [null],
          status : [true],
          is_taxable : [true]
      });
  
      this.return_id = this.activatedRoute.snapshot.paramMap.get('id');
      this.action = this.activatedRoute.snapshot.paramMap.get('action');

      this.activatedRoute.queryParams.subscribe(params => {
        let parent_id = decodeURIComponent(params['parent_id'])
        if(typeof parent_id !== undefined && parent_id !== null)
            this.form.controls['parent_id'].setValue(parseInt(parent_id));
        
            if(this.action == 'add' && parseInt(parent_id) > 0)
                this.parent_read_only = true;  
      });
      
      this.restApi.getlist(this.restApiURL).pipe(
          take(1)
      ).subscribe( res => {
              if(res.success)
              {
                  this.categories = res.data.categories;
                  this.types = res.data.types;
  
                 
              }
      });
      if(this.action == 'edit' && this.return_id > 0)
          {
              this.isLoading = true;
              this.restApi.show(this.restApiURL,this.return_id).pipe(
                  take(1)
              ).subscribe( res => {
                      if(res.success)
                      {
                          
                          this.form.patchValue({
                              name :res.data.name,
                              parent_id : parseInt(res.data.parent_id),
                              description:res.data.description,
                              type:parseInt(res.data.type),
                              status:res.data.status
                            })
                          this.isLoading = false;
                      }
              });    
      }
    }
    pageReload()
      {
          this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
              disableClose: false
          });
    
          this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to reload, your unsaved data will be lost?';
    
          this.confirmDialogRef.afterClosed().subscribe(result => {
              if ( result )
              {
                  this.ngOnInit();
              }
             
              this.confirmDialogRef = null;
          });  
    }
  
    cancelForm()
      {
          this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
              disableClose: false
          });
    
          this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to navigate, your unsaved data will be lost?';
    
          this.confirmDialogRef.afterClosed().subscribe(result => {
              if ( result )
              {
                  this.router.navigateByUrl('category/category-list');
              }
             
              this.confirmDialogRef = null;
          });  
    }
  
    onSubmit(data:any,event:any){
  
          if(this.action == 'edit' && this.return_id > 0)
          {
              this.isLoading = true;   
              this.restApi.update(`${this.restApiURL}/${this.return_id}`,data).pipe(
                  take(1)
              ).subscribe( res => { 
                  console.log("Submit Success: " + res);
                  if(res.success)
                  {
                      if( event == 'save')
                      {
                         
                          this.form.patchValue({
                                name :res.data.name,
                                parent_id : parseInt(res.data.parent_id),
                                description:res.data.description,
                                type:parseInt(res.data.type),
                                status:res.data.status
                          })
                      }
                      else if(event == 'save_add')
                      {
                          this.form.reset();  

                          this.restApi.getlist(this.restApiURL).pipe(
                            take(1)
                            ).subscribe( res => {
                                    if(res.success)
                                    {
                                        this.categories = res.data.categories;
                                        this.types = res.data.types;
                        
                                        if(this.action == 'add')
                                        {
                        
                                            this.activatedRoute.queryParams.subscribe(params => {
                                                let parent_id = decodeURIComponent(params['parent_id'])
                                                if(typeof parent_id !== undefined && parent_id !== null)
                                                    this.form.controls['parent_id'].setValue(parseInt(parent_id));
                                                    
                                                    this.form.controls['status'].setValue(true);
                                                    
                                                    if(this.action == 'add' && parseInt(parent_id) > 0)
                                                        this.parent_read_only = true;  
                                            });  
                                            
                        
                                        }
                        
                                        
                                    }
                          });

                          this.action = 'add';
                          this.return_id = 'id';
                          this.router.navigate(['category/add-edit-category/add/id'],{ queryParams: { parent_id: res.data.parent_id }});
                      }
                      else if(event == 'save_exit')
                          this.router.navigateByUrl('category/category-list');
  
                      this.isLoading = false;    
                      
                  }
  
              });
          }
          else
          {
              this.isLoading = true;   
              this.restApi.store(this.restApiURL,data).pipe(
                  take(1)
              ).subscribe( res => { 
                  console.log("Submit Success: " + res);
                  if(res.success)
                  {
                      if( event == 'save')
                      {
                          
                          this.form.patchValue({
                            name :res.data.name,
                            parent_id : parseInt(res.data.parent_id),
                            description:res.data.description,
                            type:parseInt(res.data.type),
                            status:res.data.status
                          })
  
                          this.action = 'edit';
                          this.return_id = res.data.id;
                          this.router.navigate(['category/add-edit-category/edit/'+res.data.id],{ queryParams: { parent_id: res.data.parent_id }});
                      }
                      else if(event == 'save_add')
                      {
                          this.form.reset(); 
                          
                          this.restApi.getlist(this.restApiURL).pipe(
                            take(1)
                            ).subscribe( res => {
                                    if(res.success)
                                    {
                                        this.categories = res.data.categories;
                                        this.types = res.data.types;
                        
                                        if(this.action == 'add')
                                        {
                        
                                            this.activatedRoute.queryParams.subscribe(params => {
                                                let parent_id = decodeURIComponent(params['parent_id'])
                                                if(typeof parent_id !== undefined && parent_id !== null)
                                                    this.form.controls['parent_id'].setValue(parseInt(parent_id));
                                                    
                                                    this.form.controls['status'].setValue(true);
                                                    
                                                    if(this.action == 'add' && parseInt(parent_id) > 0)
                                                        this.parent_read_only = true;  
                                            });  
                                            
                        
                                        }
                        
                                        
                                    }
                          });
                          
                          this.action = 'add';
                          this.return_id = 'id';
                          this.router.navigate(['category/add-edit-category/add/id'],{ queryParams: { parent_id: res.data.parent_id }});
                      }
                      else if(event == 'save_exit')
                          this.router.navigateByUrl('category/category-list');
  
                      this.isLoading = false;    
                  }
  
              });  
          }
    }

    ngOnDestroy(): void
      {
          // Unsubscribe from all subscriptions
          this._unsubscribeAll.next();
          this._unsubscribeAll.complete();
    }

}
