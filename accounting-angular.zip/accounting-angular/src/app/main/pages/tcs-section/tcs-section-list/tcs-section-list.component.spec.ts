import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TcsSectionListComponent } from './tcs-section-list.component';

describe('TcsSectionListComponent', () => {
  let component: TcsSectionListComponent;
  let fixture: ComponentFixture<TcsSectionListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TcsSectionListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TcsSectionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
