import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TcsSectionAddComponent } from './tcs-section-add.component';

describe('TcsSectionAddComponent', () => {
  let component: TcsSectionAddComponent;
  let fixture: ComponentFixture<TcsSectionAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TcsSectionAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TcsSectionAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
