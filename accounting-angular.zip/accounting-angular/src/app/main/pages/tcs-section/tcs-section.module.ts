import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { TcsSectionAddModule } from './tcs-section-add/tcs-section-add.module';
import { TcsSectionListModule } from './tcs-section-list/tcs-section-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    TcsSectionAddModule,
    TcsSectionListModule
  ]
})
export class TcsSectionModule { }
