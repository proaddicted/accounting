import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { ProfitLossReportModule } from './profit-loss-report/profit-loss-report.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    ProfitLossReportModule
  ]
})
export class ProfitLossModule { }
