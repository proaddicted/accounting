import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { ProformaInvoiceAddModule } from './proforma-invoice-add/proforma-invoice-add.module';
import { ProformaInvoiceListModule } from './proforma-invoice-list/proforma-invoice-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    ProformaInvoiceAddModule,
    ProformaInvoiceListModule
  ]
})
export class ProformaInvoiceModule { }
