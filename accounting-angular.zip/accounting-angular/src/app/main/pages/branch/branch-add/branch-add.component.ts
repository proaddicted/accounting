import { Component, OnDestroy, OnInit,ViewEncapsulation } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { RestApiService } from 'app/service/rest-api.service';
import { take } from 'rxjs/operators';
import { invalid } from '@angular/compiler/src/render3/view/util';
import { parseJSON } from 'date-fns';
import { FuseUtils } from '@fuse/utils';

import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-branch-add',
  templateUrl: './branch-add.component.html',
  styleUrls: ['./branch-add.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations
})
export class BranchAddComponent implements  OnInit,OnDestroy {

    model: any = {};  
    restApiURL : any = "branch";  
    isLoading = false;
    bank_accounts : any = [];
    form: FormGroup;  
    return_id:any;
    action:string;
    multi = [
        {
          "is_default":true
        }
      ];
    private _unsubscribeAll: Subject<any>;

    confirmDialogRef: MatDialogRef<FuseConfirmDialogComponent>;

    constructor(
      private _formBuilder:FormBuilder,
      private activatedRoute:ActivatedRoute,
      private restApi:RestApiService,
      private router: Router,
      private _matDialog: MatDialog
    ) { 
      this._unsubscribeAll = new Subject();
    }

  ngOnInit(): void {

        //Call Getlist API and Bind Select Box Data and Others Data
        this.restApi.getlist(this.restApiURL).pipe(
            take(1)
        ).subscribe( res => {
                if(res.success)
                {
                    //this.bank_accounts = res.data.bank_accounts;
                    this.bank_accounts = res.data.bank_accounts.map(item => {
                        return {
                          name: item.name,
                          id: item.id
                        };
                      });
                }
        });  
        this.return_id = this.activatedRoute.snapshot.paramMap.get('id');
        this.action = this.activatedRoute.snapshot.paramMap.get('action');
        
        this.form = this._formBuilder.group({
            name : ['', Validators.required],
            code : ['', Validators.required],
            address_line1: [''],
            address_line2: [''],
            country: [''],
            state: [''],
            city: [''],
            pan_no: ['',Validators.pattern("^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$")], //
            gstin_no: ['',Validators.pattern("^([0][1-9]|[1-2][0-9]|[3][0-7])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$")], //
            bank_account_id: [''],
            // selling_points: this._formBuilder.array([this._formBuilder.group({point:'1122'}),this._formBuilder.group({point:'9999'})]),
            pincode:['',Validators.pattern("^[0-9]*$")],
            status:[true]
        });

        // this.form.patchValue({
        //     name: 'Todd Motto',
        //     selling_points: [{
        //       point:15151

        //     },
        //     {
        //         point:99855
        //     }]
        //   });

        if(this.action == 'edit' && this.return_id > 0)
          {
              this.isLoading = true;
              this.restApi.show(this.restApiURL,this.return_id).pipe(
                  take(1)
              ).subscribe( res => {
                      if(res.success)
                      {
                          
                        let bank_acc_arr  = [];
                        if(res.data.bank_accounts.length > 0)
                        {
                            res.data.bank_accounts.forEach(element => {
                            
                                bank_acc_arr.push(element.id);
                                
                            });
                        }

                        this.form = this._formBuilder.group({
                            name : [res.data.name, Validators.required],
                            code : [res.data.code, Validators.required],
                            address_line1: [res.data.address_line1],
                            address_line2: [res.data.address_line2],
                            country: [res.data.country],
                            state: [res.data.state],
                            city: [res.data.city],
                            pan_no: [res.data.pan_no,Validators.pattern("^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$")],
                            gstin_no: [res.data.gstin_no,Validators.pattern("^([0][1-9]|[1-2][0-9]|[3][0-7])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$")],
                            bank_account_id: [bank_acc_arr],
                            pincode:[res.data.pincode,Validators.pattern("^[0-9]*$")],
                            status:[res.data.status]
                        });
                         
                        this.isLoading = false; 
                      }
                      
              });    
          }
          
        
    
        
  }
    pageReload()
    {
        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });
  
        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to reload, your unsaved data will be lost?';
  
        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                this.ngOnInit();
            }
           
            this.confirmDialogRef = null;
        });  
    }

    cancelForm()
    {
        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });
  
        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to navigate, your unsaved data will be lost?';
  
        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                this.router.navigateByUrl('branch/branches-list');
            }
           
            this.confirmDialogRef = null;
        });  
    }
  onSubmit(data:any,event:any){
    
    this.isLoading = true;

    if(this.action == 'edit' && this.return_id > 0)
    {
        this.restApi.update(`${this.restApiURL}/${this.return_id}`,data).pipe(
            take(1)
        ).subscribe( res => { 
            console.log("Submit Success: " + res);
            if(res.success)
            {
                if(event == 'save')
                {
                    let bank_acc_arr = [];
                    if(res.data.bank_accounts.length > 0)
                    {
                        res.data.bank_accounts.forEach(element => {
                        
                            bank_acc_arr.push(element.id);
                            
                        });
                    }

                    this.form = this._formBuilder.group({
                        name : [res.data.name, Validators.required],
                        code : [res.data.code, Validators.required],
                        address_line1: [res.data.address_line1],
                        address_line2: [res.data.address_line2],
                        country: [res.data.country],
                        state: [res.data.state],
                        city: [res.data.city],
                        pan_no: [res.data.pan_no,Validators.pattern("^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$")],
                        gstin_no: [res.data.gstin_no,Validators.pattern("^([0][1-9]|[1-2][0-9]|[3][0-7])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$")],
                        bank_account_id: [bank_acc_arr],
                        pincode:[res.data.pincode,Validators.pattern("^[0-9]*$")],
                        status:[res.data.status]
                    });
                }
                else if(event == 'save_add')
                {
                    this.form.reset();  
                    this.action = 'add';
                    this.return_id = 'id';
                    this.router.navigateByUrl('branch/add-edit-branch/add/id');
                }
                else if(event == 'save_exit')
                    this.router.navigateByUrl('branch/branches-list');    

                this.isLoading = false;
            }

        });
    }
    else
    {
        this.restApi.store(this.restApiURL,data).pipe(
            take(1)
        ).subscribe( res => { 
            console.log("Submit Success: " + res);
            if(res.success)
            {
                if(event == 'save')
                {
                    let bank_acc_arr = [];
                    if(res.data.bank_accounts.length > 0)
                    {
                        res.data.bank_accounts.forEach(element => {
                        
                            bank_acc_arr.push(element.id);
                            
                        });
                    }

                    this.form = this._formBuilder.group({
                        name : [res.data.name, Validators.required],
                        code : [res.data.code, Validators.required],
                        address_line1: [res.data.address_line1],
                        address_line2: [res.data.address_line2],
                        country: [res.data.country],
                        state: [res.data.state],
                        city: [res.data.city],
                        pan_no: [res.data.pan_no,Validators.pattern("^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$")],
                        gstin_no: [res.data.gstin_no,Validators.pattern("^([0][1-9]|[1-2][0-9]|[3][0-7])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$")],
                        bank_account_id: [bank_acc_arr],
                        pincode:[res.data.pincode,Validators.pattern("^[0-9]*$")],
                        status:[res.data.status]
                    });

                    this.action = 'edit';
                    this.return_id = res.data.id;
                    
                    this.router.navigateByUrl('branch/add-edit-branch/edit/'+res.data.id);
                }
                else if(event == 'save_add')
                {
                    this.form.reset();  
                    this.action = 'add';
                    this.return_id = 'id';
                    this.router.navigateByUrl('branch/add-edit-branch/add/id');
                }
                else if(event == 'save_exit')
                    this.router.navigateByUrl('branch/branches-list');
            }    
                
            this.isLoading = false;
        });  
    }
  }
  ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }
 
}
