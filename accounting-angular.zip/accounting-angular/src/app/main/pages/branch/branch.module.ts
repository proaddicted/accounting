import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { BranchListModule } from './branch-list/branch-list.module';
import { BranchAddModule } from './branch-add/branch-add.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    BranchListModule,
    BranchAddModule
  ]
})
export class BranchModule { }
