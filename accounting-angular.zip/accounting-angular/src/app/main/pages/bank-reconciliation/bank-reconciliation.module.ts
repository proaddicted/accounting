import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BankReconciliationReportModule } from './bank-reconciliation-report/bank-reconciliation-report.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    BankReconciliationReportModule
  ]
})
export class BankReconciliationModule { }
