import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { ItemGroupAddModule } from './item-group-add/item-group-add.module';
import { ItemGroupListModule } from './item-group-list/item-group-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    ItemGroupAddModule,
    ItemGroupListModule
  ]
})
export class ItemGroupModule { }
