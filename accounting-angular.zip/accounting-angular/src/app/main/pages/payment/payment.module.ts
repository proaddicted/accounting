import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { PaymentAddModule } from './payment-add/payment-add.module';
import { PaymentListModule } from './payment-list/payment-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    PaymentAddModule,
    PaymentListModule
  ]
})
export class PaymentModule { }
