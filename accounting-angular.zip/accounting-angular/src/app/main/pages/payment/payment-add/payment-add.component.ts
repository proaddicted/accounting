import { Component, OnDestroy, OnInit,ViewEncapsulation } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { RestApiService } from 'app/service/rest-api.service';
import { take } from 'rxjs/operators';
import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import * as _moment from 'moment';
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { at } from 'lodash';
import { ToastrService } from 'ngx-toastr';
import * as banks from '../../bank-account/bank-account-add/banks.json';

import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';

const moment =  _moment;

export const MY_FORMATS = {
    parse: {
      dateInput: "YYYY-MM-DD"
    },
    display: {
      dateInput: "YYYY-MM-DD",
      monthYearLabel: "YYYY",
      dateA11yLabel: "LL",
      monthYearA11yLabel: "YYYY"
    }
};

@Component({
  selector: 'app-payment-add',
  templateUrl: './payment-add.component.html',
  styleUrls: ['./payment-add.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations,
  providers: [
        {
        provide: DateAdapter,
        useClass: MomentDateAdapter,
        deps: [MAT_DATE_LOCALE]
        },

        { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
    ]
})
export class PaymentAddComponent implements OnInit,OnDestroy {

    model: any = {};  
    restApiURL : any = "payment";  
    isLoading = false;
    form: FormGroup;  
    return_id:any;
    action:string;
    private _unsubscribeAll: Subject<any>;
    header_text:string = "";
    isInvoiceLoading = false;

    accounts:any = [];
    customers:any = [];
    fiscal_years:any = [];
    minDate: Date;
    maxDate: Date;
    filteredinvoices = [];
    bank_accounts = [];
    payment_types = [];
    transaction_types = [];
    tds_sections = [];
    tcs_sections = [];
    selectedPayType :any;
    selectedTransactionType: any;
    readonly:boolean = false;
    banks:  any  = (banks  as  any).default;
    all_banks = [];
    customerreadonly:boolean = true;
    files: File[] = [];
    upload_files: File[] = [];
    isUploadLoad:boolean = false;
    bank_required = false;

    confirmDialogRef: MatDialogRef<FuseConfirmDialogComponent>;

    constructor(
      private _formBuilder:FormBuilder,
      private activatedRoute:ActivatedRoute,
      private restApi:RestApiService,
      private toastr:ToastrService,
      private router: Router,
      private _matDialog: MatDialog
    ) {
      this._unsubscribeAll = new Subject();
     }

  ngOnInit(): void {

    this.form = this._formBuilder.group({
        invoice_account_id : [null, Validators.required],
        fiscal_year_id: [null, Validators.required],
        customer_id: [null, Validators.required],
        date:['',Validators.required],
        transaction_date:[''],
        payment_type:[null,Validators.required],
        transaction_type:[null],
        transaction_branch:[''],
        transaction_id:[''],
        transaction_bank:[''],
        bank_account_id:[null],
        files: this._formBuilder.array([]),
        invoice: this._formBuilder.array([
            this._formBuilder.group({
                invoice_id:[null, Validators.required],
                due_amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                pay_amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                tcs_section_id:[null],
                tcs:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                tds_section_id:[null],
                tds_type:[1],
                tds_percent:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                tds:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                ods:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
            })    
        ]),
        remarks:[''],
        amount:[''],
        tcs:[''],
        tds:[''],
        ods:[''],
        realization_date:[''],
        is_realization:[false],
        realization_remarks:['']
    });

    this.return_id = this.activatedRoute.snapshot.paramMap.get('id');
    this.action = this.activatedRoute.snapshot.paramMap.get('action');
    this.isLoading = true;
    this.header_text = this.action == "edit" ? "edit" : "add";
    this.readonly = this.action == "edit" ? true : false;
    this.customerreadonly = this.action == "add" ? false : true;

    this.restApi.getlist(this.restApiURL).pipe(
        take(1)
    ).subscribe( res => {
            if(res.success)
            {
                this.customers = res.data.customers;
                this.accounts = res.data.accounts;
                this.fiscal_years = res.data.fiscal_years;
                this.bank_accounts = res.data.bank_accounts
                this.payment_types = res.data.payment_types;
                this.transaction_types = res.data.transaction_types;
                this.tds_sections = res.data.tds_sections;
                this.tcs_sections = res.data.tcs_sections;

                let outputArray = [];
                    for (let element in this.banks) {  
                        outputArray.push(this.banks[element]);  
                    } 
                
                
                // console.log('outputArray',outputArray)
                this.all_banks = outputArray;

                if(this.action == 'add' || this.action == 'invoice-multi' || this.action == 'invoice-single')
                {

                    this.minDate = new Date(res.data.fiscal_years[0].start_date);
                    this.maxDate = new Date();
                    this.form.controls['invoice_account_id'].setValue(res.data.accounts[0].id);
                    this.form.controls['fiscal_year_id'].setValue(res.data.fiscal_years[0].id);
                    this.form.controls['date'].setValue(moment().format("YYYY-MM-DD"));
                    this.form.controls['transaction_date'].setValue(moment().format("YYYY-MM-DD"));

                    if(this.action == 'add')
                    {
                        this.form.get('invoice').markAsUntouched();
                        (this.form.controls['invoice'] as FormArray).clear();
    
                        let tcs_section_id = this.tcs_sections.length == 1 ? this.tcs_sections[0].id : null;
    
                        let control = <FormArray>this.form.controls.invoice;
                        control.push(
                        this._formBuilder.group(
                            {
                                invoice_id:[null, Validators.required],
                                due_amount:[null,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                pay_amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                tcs_section_id:tcs_section_id,
                                tcs:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                tds_section_id:[null],
                                tds_type:[1],
                                tds_percent:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                tds:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                ods:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                
                            })
                            
                        );  
                    }
                    

                }

                this.isLoading = false;
            }
    });

    if(this.action == 'edit' && this.return_id > 0)
    {

        this.isLoading = true;
        this.restApi.show(this.restApiURL,this.return_id).pipe(
            take(1)
        ).subscribe( res => {
                if(res.success)
                {
                     

                    this.minDate = new Date(res.data.fiscal_year.start_date);
                    this.maxDate = new Date();
                    this.selectedPayType = res.data.payment_type;
                    this.selectedTransactionType = res.data.transaction_type;
                    this.bank_required = res.data.bank_account_id > 0 ? true: false;
                    
                    this.onCustomerChange(res.data.customer);

                    this.form.patchValue({
                        invoice_account_id :parseInt(res.data.invoice_account_id),
                        fiscal_year_id: parseInt(res.data.fiscal_year_id),
                        customer_id: parseInt(res.data.customer_id),
                        date:moment(res.data.date).format("YYYY-MM-DD"),
                        payment_type:res.data.payment_type,
                        transaction_type:res.data.transaction_type,
                        transaction_date:moment(res.data.transaction_date).format("YYYY-MM-DD"),
                        transaction_branch:res.data.transaction_branch,
                        transaction_id:res.data.transaction_id,
                        transaction_bank:res.data.transaction_bank,
                        bank_account_id:parseInt(res.data.bank_account_id),
                        amount:res.data.amount,
                        tcs:res.data.tcs,
                        tds:res.data.tds,
                        ods:res.data.ods,
                        remarks:res.data.remarks,
                        is_realization:res.data.is_realization,
                        realization_date:moment(res.data.realization_date).format("YYYY-MM-DD"),
                        realization_remarks:res.data.realization_remarks,
                    })

                    this.setItems(res.data.invoices);
                    if(res.data.files.length > 0) 
                        this.setFiles(res.data.files);  
                    
                }

                this.isLoading = false;
        });   
    }
    else if(this.action == 'invoice-single' && this.return_id > 0)
    {
        this.isLoading = true;
        this.restApi.show('invoice',this.return_id).pipe(
            take(1)
        ).subscribe( res => {
                if(res.success)
                {
                    

                    this.form.controls['customer_id'].setValue(parseInt(res.data.customer_id));
                    console.log('res.data.customer',res.data.customer);
                    this.onCustomerChange(res.data.customer);

                    this.form.get('invoice').markAsUntouched();
                    (this.form.controls['invoice'] as FormArray).clear();
                    
                    let tcs_section_id = this.tcs_sections.length == 1 ? this.tcs_sections[0].id : null;

                    let control = <FormArray>this.form.controls.invoice;
                    control.push(
                    this._formBuilder.group(
                        {
                            invoice_id:parseInt(res.data.id),
                            due_amount:[res.data.due_amount,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                            pay_amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                            amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                            tcs_section_id:tcs_section_id,
                            tcs:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                            tds_section_id:[null],
                            tds_type:[1],
                            tds_percent:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                            tds:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                            ods:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                            
                        })
                        
                    );

                    this.isLoading = false;
                }
        });
    }
    else if(this.action == 'invoice-multi' && this.return_id > 0)
    {
         this.isLoading = true;
         let invoices = [];
         this.activatedRoute.queryParams.subscribe(params => {
          
          invoices = JSON.parse(params['invoices']);
         });
        //console.log('sadassd',invoices);
        this.restApi.show('invoice',invoices[0].id).pipe(
            take(1)
        ).subscribe( res => {
                if(res.success)
                {
                    

                    this.form.controls['customer_id'].setValue(parseInt(res.data.customer_id));
                    
                    this.onCustomerChange(res.data.customer);

                    (this.form.controls['invoice'] as FormArray).clear();
                    this.form.get('invoice').markAsUntouched();
                    
                    let tcs_section_id = this.tcs_sections.length == 1 ? this.tcs_sections[0].id : null;

                    let control = <FormArray>this.form.controls.invoice;
                    invoices.forEach(x => {
     
                        control.push(
                            this._formBuilder.group(
                                {
                                  invoice_id:x.id,
                                  due_amount:[x.due_amount,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                  pay_amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                  amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                  tcs_section_id:tcs_section_id,
                                  tcs:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                  tds_section_id:[null],
                                  tds_type:[1],
                                  tds_percent:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                  tds:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                  ods:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                    
                                })
                              
                        );
                    });

                    this.isLoading = false;
                }
        });
       
    }

  }
  
  changeDate(event: MatDatepickerInputEvent<Date>) {
    this.form.controls['date'].setValue(moment(event.value).format("YYYY-MM-DD"));
  }
  changeTrasactionDate(event: MatDatepickerInputEvent<Date>) {
    this.form.controls['transaction_date'].setValue(moment(event.value).format("YYYY-MM-DD"));
  }

  changeRealizationDate(event: MatDatepickerInputEvent<Date>) {
    this.form.controls['realization_date'].setValue(moment(event.value).format("YYYY-MM-DD"));
  }
  onPaymentTypeChange(event){
      if(event)
      {
        this.selectedPayType = event.name;
        
        if(event.name == 'bank')
            this.bank_required = true;
        else
        {
            this.bank_required = false;
            this.form.controls['bank_account_id'].setValue(null);
        } 
      }  
      else
        this.selectedPayType = "";

  }
  onTransactionTypeChange(event){
    if(event)  
        this.selectedTransactionType = event.name;
    else
        this.selectedTransactionType = "";
  }
  onCustomerChange(event){
    this.isInvoiceLoading = true;
    
    this.restApi.loadRawURL('invoice_by_customer?customer_id='+event.id+'&action='+this.header_text).pipe(
        take(1)
    ).subscribe( res => {
            if(res.success)
            {
                this.filteredinvoices = res.data;

                this.isInvoiceLoading = false;
            }
    });
  }

  changeInvoice(e, index) {
    if(e){
        const faControl = (<FormArray>this.form.controls['invoice']).at(index);
        faControl['controls'].due_amount.setValue(e.due_amount);
        
       
    }
    
  }

  onAmountChange(){

    let total_amount:number = 0, total_tcs:number = 0 , total_ods:number = 0 , total_tds:number = 0 , total_pay = 0;  
    
    this.invoices.controls.forEach((element: any, key: number) => {

        if(element.value.pay_amount <= element.value.due_amount)
        {
            //parseFloat(Number.parseIntelement.value.amount) + element.value.tcs + element.value.tds + element.value.ods);

            if(element.value.pay_amount > 0)
            {
                if(element.value.tds_type == 2 && element.value.tds_percent > 0)
                {
                   
                    element.value.tds = ((Number.parseFloat(element.value.pay_amount))*(Number.parseFloat(element.value.tds_percent)/100))
                    const faControl = (<FormArray>this.form.controls['invoice']).at(key);  
                    faControl['controls'].tds.setValue(element.value.tds.toFixed(2));
                    faControl['controls'].amount.setValue((parseFloat(element.value.pay_amount) - element.value.tds).toFixed(2));
                }
                else if(element.value.tds_type == 1 && element.value.tds > 0)
                {
                    const faControl = (<FormArray>this.form.controls['invoice']).at(key);  
                    faControl['controls'].amount.setValue((parseFloat(element.value.pay_amount) - parseFloat(element.value.tds)).toFixed(2));
                }
                else
                {
                    const faControl = (<FormArray>this.form.controls['invoice']).at(key);
                    faControl['controls'].amount.setValue(parseFloat(element.value.pay_amount).toFixed(2));
                }
            }
            

        
            total_pay = Number.parseFloat(element.value.amount) + Number.parseFloat(element.value.tcs) + Number.parseFloat(element.value.tds) + Number.parseFloat(element.value.ods)

            //console.log('total_pay',total_pay);
            if(total_pay > element.value.due_amount)
            {
                this.toastr.error("Amount Sum Can' Be Greater Than Due Amount" ,'Please Check The Values');
                const faControl = (<FormArray>this.form.controls['invoice']).at(key);  
                faControl['controls'].tcs.setValue(0);
                faControl['controls'].amount.setValue(0);
                faControl['controls'].tds.setValue(0);
                faControl['controls'].ods.setValue(0);
            }
            else
            {
                total_amount = total_amount + parseFloat(element.value.amount);
                total_tcs = total_tcs + parseFloat(element.value.tcs);
                total_ods = total_ods + parseFloat(element.value.ods);
                total_tds = total_tds + parseFloat(element.value.tds);
            }
        }
        else
        {
            this.toastr.error("Pay Amount Can't Be Greater Than Due Amount" ,'Please Check The Values');
            const faControl = (<FormArray>this.form.controls['invoice']).at(key);  
            faControl['controls'].tcs.setValue(0);
            faControl['controls'].amount.setValue(0);
            faControl['controls'].pay_amount.setValue(0);
            faControl['controls'].tds.setValue(0);
            faControl['controls'].ods.setValue(0);
        }
        
        
        this.form.controls['amount'].setValue(total_amount.toFixed(2));
        this.form.controls['tds'].setValue(total_tds.toFixed(2));
        this.form.controls['tcs'].setValue(total_tcs.toFixed(2));
        this.form.controls['ods'].setValue(total_ods.toFixed(2));     
    });

  }

  pageReload()
        {
            this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
                disableClose: false
            });
    
            this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to reload, your unsaved data will be lost?';
    
            this.confirmDialogRef.afterClosed().subscribe(result => {
                if ( result )
                {
                    this.ngOnInit();
                }
            
                this.confirmDialogRef = null;
            });  
  }

  cancelForm()
{
    this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
        disableClose: false
    });

    this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to navigate, your unsaved data will be lost?';

    this.confirmDialogRef.afterClosed().subscribe(result => {
        if ( result )
        {
            this.router.navigateByUrl('payment/payments-list');
        }
        
        this.confirmDialogRef = null;
    });  
  }

  onSubmit(data:any,event:any){
    if(this.action == 'edit' && this.return_id > 0)
    {
        this.isLoading = true;

        this.restApi.update(`${this.restApiURL}/${this.return_id}`,data).pipe(
            take(1)
        ).subscribe( res => { 
            
            if(res.success)
            {
                 
                if( event == 'save')
                {
                    this.minDate = new Date(res.data.fiscal_year.start_date);
                    this.maxDate = new Date();
                    this.selectedPayType = res.data.payment_type;
                    this.selectedTransactionType = res.data.transaction_type;
                    this.onCustomerChange(res.data.customer);

                    this.form.patchValue({
                        invoice_account_id :parseInt(res.data.invoice_account_id),
                        fiscal_year_id: parseInt(res.data.fiscal_year_id),
                        customer_id: parseInt(res.data.customer_id),
                        date:moment(res.data.date).format("YYYY-MM-DD"),
                        payment_type:res.data.payment_type,
                        transaction_type:res.data.transaction_type,
                        transaction_date:moment(res.data.transaction_date).format("YYYY-MM-DD"),
                        transaction_branch:res.data.transaction_branch,
                        transaction_id:res.data.transaction_id,
                        transaction_bank:res.data.transaction_bank,
                        bank_account_id:parseInt(res.data.bank_account_id),
                        amount:res.data.amount,
                        tcs:res.data.tcs,
                        tds:res.data.tds,
                        ods:res.data.ods,
                        remarks:res.data.remarks
                    })

                    this.setItems(res.data.invoices);
                    
                    if(res.data.files.length > 0) 
                        this.setFiles(res.data.files);
                }
                else if( event == 'save_add')
                {
                    this.form.reset();
                    this.form.controls['invoice'].reset(); 
                    this.filteredinvoices = [];
                    
                    this.restApi.getlist(this.restApiURL).pipe(
                        take(1)
                    ).subscribe( res => {
                            if(res.success)
                            {
                                this.customers = res.data.customers;
                                this.accounts = res.data.accounts;
                                this.fiscal_years = res.data.fiscal_years;
                                this.bank_accounts = res.data.bank_accounts
                                this.payment_types = res.data.payment_types;
                                this.transaction_types = res.data.transaction_types;
                                this.tds_sections = res.data.tds_sections;
                                this.tcs_sections = res.data.tcs_sections;
                
                                let outputArray = [];
                                    for (let element in this.banks) {  
                                        outputArray.push(this.banks[element]);  
                                    } 
                                
                                
                                // console.log('outputArray',outputArray)
                                this.all_banks = outputArray;
                
                               
                
                                this.minDate = new Date(res.data.fiscal_years[0].start_date);
                                this.maxDate = new Date();
                                this.form.controls['invoice_account_id'].setValue(res.data.accounts[0].id);
                                this.form.controls['fiscal_year_id'].setValue(res.data.fiscal_years[0].id);
                                this.form.controls['date'].setValue(moment().format("YYYY-MM-DD"));
                                this.form.controls['transaction_date'].setValue(moment().format("YYYY-MM-DD"));
            
                                this.form.get('invoice').markAsUntouched();
                                (this.form.controls['invoice'] as FormArray).clear();
            
                                let tcs_section_id = this.tcs_sections.length == 1 ? this.tcs_sections[0].id : null;
            
                                let control = <FormArray>this.form.controls.invoice;
                                control.push(
                                this._formBuilder.group(
                                    {
                                        invoice_id:[null, Validators.required],
                                        due_amount:[null,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                        amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                        tcs_section_id:tcs_section_id,
                                        tcs:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                        tds_section_id:[null],
                                        tds:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                        ods:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                        
                                    })
                                    
                                );
                
                               
                
                                this.isLoading = false;
                            }
                    });
                    this.action = 'add';
                    this.return_id = 'id';
                    this.router.navigateByUrl('payment/add-edit-payment/add/id');
                }
                else if(event == 'save_exit')
                    this.router.navigateByUrl('payment/payments-list');
                 
            }

            this.isLoading = false;
            

        });
    }
    else
    {    
        this.isLoading = true;
        this.restApi.store(this.restApiURL,data).pipe(
            take(1)
        ).subscribe( res => { 
            console.log("Submit Success: " + res);
            if(res.success)
            {
                if( event == 'save')
                {
                    this.minDate = new Date(res.data.fiscal_year.start_date);
                    this.maxDate = new Date();
                    this.selectedPayType = res.data.payment_type;
                    this.selectedTransactionType = res.data.transaction_type;
                    this.header_text = 'edit';
                    this.onCustomerChange(res.data.customer);
                    

                    this.form.patchValue({
                        invoice_account_id :parseInt(res.data.invoice_account_id),
                        fiscal_year_id: parseInt(res.data.fiscal_year_id),
                        customer_id: parseInt(res.data.customer_id),
                        date:moment(res.data.date).format("YYYY-MM-DD"),
                        payment_type:res.data.payment_type,
                        transaction_type:res.data.transaction_type,
                        transaction_date:moment(res.data.transaction_date).format("YYYY-MM-DD"),
                        transaction_branch:res.data.transaction_branch,
                        transaction_id:res.data.transaction_id,
                        transaction_bank:res.data.transaction_bank,
                        bank_account_id:parseInt(res.data.bank_account_id),
                        amount:res.data.amount,
                        tcs:res.data.tcs,
                        tds:res.data.tds,
                        ods:res.data.ods,
                        remarks:res.data.remarks
                    })

                    this.setItems(res.data.invoices);
                    
                    if(res.data.files.length > 0) 
                        this.setFiles(res.data.files);

                    this.action = 'edit';
                    this.return_id = res.data.id;
                    this.router.navigateByUrl('payment/add-edit-payment/edit/'+res.data.id);    
                }
                else if( event == 'save_add')
                {
                    this.form.reset();
                    this.form.controls['invoice'].reset(); 
                    this.filteredinvoices = [];
                    this.restApi.getlist(this.restApiURL).pipe(
                        take(1)
                    ).subscribe( res => {
                            if(res.success)
                            {
                                this.customers = res.data.customers;
                                this.accounts = res.data.accounts;
                                this.fiscal_years = res.data.fiscal_years;
                                this.bank_accounts = res.data.bank_accounts
                                this.payment_types = res.data.payment_types;
                                this.transaction_types = res.data.transaction_types;
                                this.tds_sections = res.data.tds_sections;
                                this.tcs_sections = res.data.tcs_sections;
                
                                let outputArray = [];
                                    for (let element in this.banks) {  
                                        outputArray.push(this.banks[element]);  
                                    } 
                                
                                
                                // console.log('outputArray',outputArray)
                                this.all_banks = outputArray;
                
                               
                
                                this.minDate = new Date(res.data.fiscal_years[0].start_date);
                                this.maxDate = new Date();
                                this.form.controls['invoice_account_id'].setValue(res.data.accounts[0].id);
                                this.form.controls['fiscal_year_id'].setValue(res.data.fiscal_years[0].id);
                                this.form.controls['date'].setValue(moment().format("YYYY-MM-DD"));
                                this.form.controls['transaction_date'].setValue(moment().format("YYYY-MM-DD"));
            
                                this.form.get('invoice').markAsUntouched();
                                (this.form.controls['invoice'] as FormArray).clear();
            
                                let tcs_section_id = this.tcs_sections.length == 1 ? this.tcs_sections[0].id : null;
            
                                let control = <FormArray>this.form.controls.invoice;
                                control.push(
                                this._formBuilder.group(
                                    {
                                        invoice_id:[null, Validators.required],
                                        due_amount:[null,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                        amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                        tcs_section_id:tcs_section_id,
                                        tcs:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                        tds_section_id:[null],
                                        tds:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                        ods:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                        
                                    })
                                    
                                );
                
                               
                
                                this.isLoading = false;
                            }
                    });

                    this.action = 'add';
                    this.return_id = 'id';
                    this.header_text = 'add';
                    this.router.navigateByUrl('payment/add-edit-payment/add/id');
                }
                else if(event == 'save_exit')
                    this.router.navigateByUrl('payment/payments-list');
                
            }  
            this.isLoading = false;

        });  
    }
  }
  
  /*Multi Invoice Add More Section */
  get invoices() {
    return this.form.get('invoice') as FormArray;
  }
  addItem() {
    let tcs_section_id = this.tcs_sections.length == 1 ? this.tcs_sections[0].id : null;
       
    this.invoices.push(
        this._formBuilder.group({
            invoice_id:[null, Validators.required],
            due_amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
            pay_amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
            amount:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
            tcs_section_id:tcs_section_id,
            tcs:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
            tds_section_id:[null],
            tds_type:[1],
            tds_percent:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
            tds:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
            ods:[0,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
        })  
    );
  }
  deleteItem(index) {
    this.invoices.removeAt(index);
  }
  setItems(items){
    this.form.get('invoice').markAsUntouched();
    (this.form.controls['invoice'] as FormArray).clear();
    let control = <FormArray>this.form.controls.invoice;
    items.forEach(x => {
     
      control.push(
          this._formBuilder.group(
              {
                invoice_id:x.id,
                due_amount:x.pivot.due_amount,
                amount:x.pivot.amount,
                pay_amount:x.pivot.pay_amount,
                tds_section_id:parseInt(x.pivot.tds_section_id),
                tds_type:parseInt(x.pivot.tds_type),
                tds_percent:x.pivot.tds_percent,
                tds:x.pivot.tds,
                ods:x.pivot.ods,
                tcs_section_id:parseInt(x.pivot.tcs_section_id),
                tcs:x.pivot.tcs,
                  
              })
            
        );
    })
  }
  onFileSelect(event) {
    this.isUploadLoad = true;
    this.upload_files = [];

    this.files.push(...event.addedFiles);
    this.upload_files.push(...event.addedFiles);

    const formData = new FormData();

    for (var i = 0; i < this.upload_files.length; i++) { 
        formData.append("files[]", this.upload_files[i]);
    }

    this.restApi.tempFileUpload(`payment`,formData).pipe(
        take(1)
    ).subscribe( res => { 
        if(res.success)
        {
            if(res.data.length > 0)
            {
                res.data.forEach(x => {
                    
                    this.file_items.push(
                        this._formBuilder.group({
                                temp_id:x.id,
                                file_path:x.file_path,
                                file_name:x.file_name,
                                file_size:x.file_size,
                                file_extension:x.file_extension,
                                file_description:[''],
                                identifier:x.identifier,
                                id:[''],
                        })    
                    );
                     
                    
                })
            }
            
        }

        this.isUploadLoad = false;
    });
    

  }
  onFileRemove(index) {

        this.file_items.removeAt(index);
    

  }
  get file_items() {
    return this.form.get('files') as FormArray;
  }
  setFiles(files){
    (<FormArray>this.form.get('files')).clear();
    files.forEach(x => {
     
        this.file_items.push(
            this._formBuilder.group({
                    id:x.id,
                    file_path:x.file_path,
                    file_name:x.file_name,
                    file_size:x.file_size,
                    file_extension:x.file_extension,
                    file_description:x.file_description,
                    identifier:x.identifier,
                    temp_id:[''],
            })    
        );
    })
  }
  ngOnDestroy(): void{
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }
}
