import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaymentAddComponent } from './payment-add.component';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatStepperModule } from '@angular/material/stepper';

import { FuseSharedModule } from '@fuse/shared.module';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NgSelectModule } from '@ng-select/ng-select';
import { MatNativeDateModule } from '@angular/material/core';
import { MomentDateModule } from '@angular/material-moment-adapter';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { FormsModule } from '@angular/forms';
import { AccessGuard } from 'app/service/access.guard';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatRadioModule } from '@angular/material/radio';

const routes = [
    {
        path     : 'add-edit-payment/:action/:id',
        component: PaymentAddComponent,
        canActivate: [AccessGuard],
        data: {'access-type':2}
    }
];

@NgModule({
  declarations: [PaymentAddComponent],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatStepperModule,
    MatCheckboxModule,
    FuseSharedModule,
    MatProgressSpinnerModule,
    NgSelectModule,
    FormsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MomentDateModule,
    AutocompleteLibModule,
    NgxDropzoneModule,
    MatSlideToggleModule,
    MatProgressBarModule,
    MatRadioModule
  ]
})
export class PaymentAddModule { }
