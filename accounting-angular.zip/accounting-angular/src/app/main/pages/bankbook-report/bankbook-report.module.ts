import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { BankbookReportListModule } from './bankbook-report-list/bankbook-report-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    BankbookReportListModule
  ]
})
export class BankbookReportModule { }
