import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InvoiceSummaryReportModule } from './invoice-summary-report/invoice-summary-report.module';
import { PurchaseSummaryReportModule } from './purchase-summary-report/purchase-summary-report.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InvoiceSummaryReportModule,
    PurchaseSummaryReportModule
  ]
})
export class SummaryReportModule { }
