import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { PurchaseListModule } from './purchase-list/purchase-list.module';
import { PurchaseAddModule } from './purchase-add/purchase-add.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    PurchaseListModule,
    PurchaseAddModule
  ]
})
export class PurchaseModule { }
