import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { PurchasePaymentAddModule } from './purchase-payment-add/purchase-payment-add.module';
import { PurchasePaymentListModule } from './purchase-payment-list/purchase-payment-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    PurchasePaymentAddModule,
    PurchasePaymentListModule
  ]
})
export class PurchasePaymentModule { }
