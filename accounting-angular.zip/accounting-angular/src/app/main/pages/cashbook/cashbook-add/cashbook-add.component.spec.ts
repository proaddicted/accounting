import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CashbookAddComponent } from './cashbook-add.component';

describe('CashbookAddComponent', () => {
  let component: CashbookAddComponent;
  let fixture: ComponentFixture<CashbookAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CashbookAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CashbookAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
