import { Component, OnDestroy, OnInit,ViewEncapsulation } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { RestApiService } from 'app/service/rest-api.service';
import { take } from 'rxjs/operators';
import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import * as _moment from 'moment';
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { at } from 'lodash';
import { CustomerAddComponent } from 'app/modal/customer-add/customer-add.component';

import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';

const moment =  _moment;

export const MY_FORMATS = {
    parse: {
      dateInput: "YYYY-MM-DD"
    },
    display: {
      dateInput: "YYYY-MM-DD",
      monthYearLabel: "YYYY",
      dateA11yLabel: "LL",
      monthYearA11yLabel: "YYYY"
    }
};

@Component({
  selector: 'app-cashbook-add',
  templateUrl: './cashbook-add.component.html',
  styleUrls: ['./cashbook-add.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations,
  providers: [
        {
        provide: DateAdapter,
        useClass: MomentDateAdapter,
        deps: [MAT_DATE_LOCALE]
        },

        { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
    ]
})
export class CashbookAddComponent implements OnInit,OnDestroy {

    model: any = {};  
    restApiURL : any = "cashbook";  
    isLoading = false;
    form: FormGroup;  
    return_id:any;
    action:string;
    private _unsubscribeAll: Subject<any>;
  
    accounts:any = [];
    customers:any = [];
    fiscal_years:any = [];
    transaction_types=[];
    current_fiscal_year:any;
    minDate: Date;
    maxDate: Date;
    readonly:boolean =  false;
    header_text:string;
    type_readonly:boolean = false;
    
    confirmDialogRef: MatDialogRef<FuseConfirmDialogComponent>;

    constructor(
        private _formBuilder:FormBuilder,
        private activatedRoute:ActivatedRoute,
        private restApi:RestApiService,
        private _matDialog:MatDialog,
        private router: Router,
    ) {
        this._unsubscribeAll = new Subject();
    }

    ngOnInit(): void {
        this.form = this._formBuilder.group({
            invoice_account_id : [null, Validators.required],
            identifier:['cash'],
            main_id: [null, Validators.required],
            date:['',Validators.required],
            type:['',Validators.required],
            amount:['',[Validators.required,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")]], //Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")
            remarks:[''],
           
        });

        this.return_id = this.activatedRoute.snapshot.paramMap.get('id');
        this.action = this.activatedRoute.snapshot.paramMap.get('action');

        console.log('this.action',this.action);
        console.log('this.return_id',this.return_id);
            
        this.activatedRoute.queryParams.subscribe(params => {
            let type = decodeURIComponent(params['type'])
            if(typeof type !== undefined && type !== null)
                this.form.controls['type'].setValue(type);
            
            console.log('type',typeof type);
            
            if(this.action == 'edit')
                this.type_readonly = true;
            else if(this.action == 'add' && (type == "debit" || type == "credit"))
                this.type_readonly = true;     

            this.restApi.getlist(this.restApiURL).pipe(
                take(1)
                ).subscribe( res => {
                    if(res.success)
                    {
                        this.customers = res.data.customers;
    
                        if(this.form.controls['type'].value == 'debit')
                            this.customers = this.customers.filter(
                        value => value.category === 'Creditor');
                        else if(this.form.controls['type'].value == 'credit')
                            this.customers = this.customers.filter(
                        value => value.category === 'Debtor');
    
                        this.accounts = res.data.accounts;
                        this.transaction_types = res.data.transaction_types;
    
                        if(this.action == 'add')
                        {
                            this.maxDate = new Date();
                            this.form.controls['invoice_account_id'].setValue(this.accounts[0].id);
                            this.form.controls['date'].setValue(moment().format("YYYY-MM-DD"));
                        }
                        
                        this.isLoading = false;
                    }
            });   
                           
        });
        this.header_text = this.action == "edit" ? "edit" : "add";
        this.readonly = this.action == "edit" ? true : false;

        

        if(this.action == 'edit' && this.return_id > 0)
        {
            this.isLoading = true;
            this.restApi.show(this.restApiURL,this.return_id).pipe(
                take(1)
            ).subscribe( res => {
                    if(res.success)
                    {
                        
                        
                        this.maxDate = new Date(res.data.date);

                        this.form.patchValue({
                            invoice_account_id :parseInt(res.data.invoice_account_id),
                            main_id: parseInt(res.data.main_id),
                            date:moment(res.data.date).format("YYYY-MM-DD"),
                            amount:res.data.amount,
                            type:res.data.type,
                            remarks:res.data.remarks,
                            
                        })


                        
                    }

                    this.isLoading = false;
            });   
        }

       
    }
    changeDate(event: MatDatepickerInputEvent<Date>) {
        this.form.controls['date'].setValue(moment(event.value).format("YYYY-MM-DD"));
    }

    pageReload()
    {
        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });
  
        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to reload, your unsaved data will be lost?';
  
        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                this.ngOnInit();
            }
           
            this.confirmDialogRef = null;
        });  
    }

    cancelForm()
    {
        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });
  
        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to navigate, your unsaved data will be lost?';
  
        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                this.router.navigateByUrl('cashbook/cashbook-list');
            }
           
            this.confirmDialogRef = null;
        });  
    }

    onSubmit(data:any,event:any){

        if(this.action == 'edit' && this.return_id > 0)
        {
            this.isLoading = true;
            this.restApi.update(`${this.restApiURL}/${this.return_id}`,data).pipe(
                take(1)
            ).subscribe( res => { 
                if(res.success)
                {
                    if(event == 'save')
                    {
                        this.maxDate = new Date(res.data.date);

                        this.form.patchValue({
                            invoice_account_id :parseInt(res.data.invoice_account_id),
                            customer_id: parseInt(res.data.customer_id),
                            date:moment(res.data.date).format("YYYY-MM-DD"),
                            amount:res.data.amount,
                            identifier:res.data.identifier,
                            type:res.data.type,
                            remarks:res.data.remarks,
                            
                        })
                    }    
                    else if(event == 'save_add')
                    {
                        this.form.reset(); 

                        this.restApi.getlist(this.restApiURL).pipe(
                            take(1)
                        ).subscribe( res => {
                                if(res.success)
                                {
                                    this.customers = res.data.customers;
                                    this.accounts = res.data.accounts;
                                    this.transaction_types = res.data.transaction_types;
                    
                                    if(this.action == 'add')
                                    {
                    
                                        
                                        this.maxDate = new Date();
                                        this.form.controls['invoice_account_id'].setValue(res.data.accounts[0].id);
                                        this.form.controls['date'].setValue(moment().format("YYYY-MM-DD"));
                                        this.form.controls['identifier'].setValue('cash');

                                        this.activatedRoute.queryParams.subscribe(params => {
                                            let type = decodeURIComponent(params['type'])
                                            if(typeof type !== undefined && type !== null)
                                                this.form.controls['type'].setValue(type);
                                            
                                            console.log('type',typeof type);
                                            
                                            if(this.action == 'edit')
                                                this.type_readonly = true;
                                            else if(this.action == 'add' && (type == "debit" || type == "credit"))
                                                this.type_readonly = true;  

                                            if(this.form.controls['type'].value == 'debit')
                                                this.customers = this.customers.filter(
                                            value => value.category === 'Creditor');
                                            else if(this.form.controls['type'].value == 'credit')
                                                this.customers = this.customers.filter(
                                            value => value.category === 'Debtor');        
                                                        
                                        });
                    
                                    }
                    
                                    
                                }
                        }); 

                        this.action = 'add';
                        this.return_id = 'id';

                        this.router.navigate(['cashbook/add-edit-cashbook/add/id'],{ queryParams: { type: res.data.type }});
                    }
                    else if(event == 'save_exit')
                        this.router.navigateByUrl('cashbook/cashbook-list');     
                }

                this.isLoading = false;
            });
        }
        else
        {    
            this.isLoading = true;
            this.restApi.store(this.restApiURL,data).pipe(
                take(1)
            ).subscribe( res => { 
                console.log("Submit Success: " + res);
                if(res.success)
                {

                    if(event == 'save')
                    {
                        this.maxDate = new Date(res.data.date);

                        this.form.patchValue({
                            invoice_account_id :parseInt(res.data.invoice_account_id),
                            customer_id: parseInt(res.data.customer_id),
                            date:moment(res.data.date).format("YYYY-MM-DD"),
                            amount:res.data.amount,
                            identifier:res.data.identifier,
                            type:res.data.type,
                            remarks:res.data.remarks,
                            
                        })

                        this.action = 'edit';
                        this.return_id = res.data.id;
                        this.router.navigate(['cashbook/add-edit-cashbook/edit/'+res.data.id],{ queryParams: { type: res.data.type }});
                    }    
                    else if(event == 'save_add')
                    {
                        this.form.reset(); 
                    
                        this.restApi.getlist(this.restApiURL).pipe(
                            take(1)
                        ).subscribe( res => {
                                if(res.success)
                                {
                                    this.customers = res.data.customers;
                                    this.accounts = res.data.accounts;
                                    this.transaction_types = res.data.transaction_types;
                    
                                    if(this.action == 'add')
                                    {
                    
                                        
                                        this.maxDate = new Date();
                                        this.form.controls['invoice_account_id'].setValue(res.data.accounts[0].id);
                                        this.form.controls['date'].setValue(moment().format("YYYY-MM-DD"));
                                        this.form.controls['identifier'].setValue('cash');

                                        this.activatedRoute.queryParams.subscribe(params => {
                                            let type = decodeURIComponent(params['type'])
                                            if(typeof type !== undefined && type !== null)
                                                this.form.controls['type'].setValue(type);
                                            
                                            console.log('type',typeof type);
                                            
                                            if(this.action == 'edit')
                                                this.type_readonly = true;
                                            else if(this.action == 'add' && (type == "debit" || type == "credit"))
                                                this.type_readonly = true;
                                                
                                                
                                            if(this.form.controls['type'].value == 'debit')
                                                this.customers = this.customers.filter(
                                            value => value.category === 'Creditor');
                                            else if(this.form.controls['type'].value == 'credit')
                                                this.customers = this.customers.filter(
                                            value => value.category === 'Debtor');     
                                                        
                                        });
                    
                                    }
                    
                                    
                                }
                        });
                        
                        this.action = 'add';
                        this.return_id = 'id';

                        this.router.navigate(['cashbook/add-edit-cashbook/add/id'],{ queryParams: { type: res.data.type }});
                        
                    }
                    else if(event == 'save_exit')
                        this.router.navigateByUrl('cashbook/cashbook-list'); 
                    
                }  
                this.isLoading = false;

            });  
        }
    }
    quickAddCustomer(){
        const dialogRef = this._matDialog.open(CustomerAddComponent, {
            data: {
                form_header:'Quick Add Party',
                category:'vendor'
            },
            width:'auto',
            height: 'auto'
          });
          dialogRef.afterClosed().subscribe(result => {

            if(result && result != null)
            {
                
                this.customers = [...this.customers, result];
                console.log(' this.customers', this.customers);
                this.form.controls['main_id'].setValue(parseInt(result.id));

            }
          },
          errRes=>{});
    }
    ngOnDestroy(): void{
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }
}
