import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { CashbookAddModule } from './cashbook-add/cashbook-add.module';
import { CashbookListModule } from './cashbook-list/cashbook-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    CashbookAddModule,
    CashbookListModule
  ]
})
export class CashbookModule { }
