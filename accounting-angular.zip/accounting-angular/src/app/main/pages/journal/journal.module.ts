import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { JournalAddModule } from './journal-add/journal-add.module';
import { JournalListModule } from './journal-list/journal-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    JournalAddModule,
    JournalListModule
    
  ]
})
export class JournalModule { }
