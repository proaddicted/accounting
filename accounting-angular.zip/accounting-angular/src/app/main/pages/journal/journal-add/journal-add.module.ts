import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JournalAddComponent } from './journal-add.component';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatStepperModule } from '@angular/material/stepper';

import { FuseSharedModule } from '@fuse/shared.module';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NgSelectModule } from '@ng-select/ng-select';
import { AccessGuard } from 'app/service/access.guard';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MomentDateModule } from '@angular/material-moment-adapter';
import { MatRadioModule } from '@angular/material/radio';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { NgxNumberSpinnerModule } from 'ngx-number-spinner';

const routes = [
    {
        path     : 'add-edit-journal/:action/:id',
        component: JournalAddComponent,
        canActivate: [AccessGuard],
        data: {'access-type':2}
    }
];


@NgModule({
  declarations: [JournalAddComponent],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatStepperModule,
    MatCheckboxModule,
    MatSlideToggleModule,
    MatRadioModule,
    NgxNumberSpinnerModule,
    FuseSharedModule,
    MatProgressSpinnerModule,
    NgSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MomentDateModule,
    NgxDropzoneModule,
  ]
})
export class JournalAddModule { }
