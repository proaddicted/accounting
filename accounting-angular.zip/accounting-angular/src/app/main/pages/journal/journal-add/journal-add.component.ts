import { Component, OnDestroy, OnInit,ViewEncapsulation } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { RestApiService } from 'app/service/rest-api.service';
import { take } from 'rxjs/operators';
import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import * as _moment from 'moment';
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { at } from 'lodash';
import { CustomerAddComponent } from 'app/modal/customer-add/customer-add.component';

import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';
import { ItemAddComponent } from 'app/modal/item-add/item-add.component';
import { ToastrService } from 'ngx-toastr';

const moment =  _moment;

export const MY_FORMATS = {
    parse: {
      dateInput: "YYYY-MM-DD"
    },
    display: {
      dateInput: "YYYY-MM-DD",
      monthYearLabel: "YYYY",
      dateA11yLabel: "LL",
      monthYearA11yLabel: "YYYY"
    }
};


@Component({
  selector: 'app-journal-add',
  templateUrl: './journal-add.component.html',
  styleUrls: ['./journal-add.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations,
  providers: [
        {
        provide: DateAdapter,
        useClass: MomentDateAdapter,
        deps: [MAT_DATE_LOCALE]
        },

        { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
    ]
})
export class JournalAddComponent implements OnInit,OnDestroy {

    model: any = {};  
    restApiURL : any = "journal";  
    isLoading = false;
    form: FormGroup;  
    return_id:any;
    action:string;
    private _unsubscribeAll: Subject<any>;
  
    items:any = [];
    accounts:any = [];
    places:any = [];
    customers:any = [];
    fiscal_years:any = [];
    bank_accounts = [];
    payment_types = [];
    transaction_types=[];
    tds_sections=[];
    current_fiscal_year:any;
    minDate: Date;
    maxDate: Date;
    selectedAccount:any;
    selectedPayType:any = 'cash';
    place_match:boolean = true;
    readonly:boolean =  false;
    header_text:string;
    is_item_applicable:boolean = false;
    is_payment:boolean = false;
    files: File[] = [];
    upload_files: File[] = [];
    payment_readonly:boolean = false;
    selectedTransactionType: any;
    isUploadLoad:boolean = false;
    types = [];
    total_items = [];
    total_credit = 0;
    total_debit = 0;

    confirmDialogRef: MatDialogRef<FuseConfirmDialogComponent>;
    
    constructor(
        private _formBuilder:FormBuilder,
        private activatedRoute:ActivatedRoute,
        private restApi:RestApiService,
        private router: Router,
        private _matDialog:MatDialog,
        private toastr:ToastrService
    ) {
        this._unsubscribeAll = new Subject();
    }
    
    ngOnInit(): void {

        this.form = this._formBuilder.group({
            invoice_account_id : [null, Validators.required],
            date:['',Validators.required],
            type:['journal',Validators.required],
            files: this._formBuilder.array([]),
            amount:['',[Validators.required,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")]],
            journals: this._formBuilder.array([]),
            remarks:['']
        });

        this.return_id = this.activatedRoute.snapshot.paramMap.get('id');
        this.action = this.activatedRoute.snapshot.paramMap.get('action');

        this.header_text = this.action == "edit" ? "edit" : "add";
        this.readonly = this.action == "edit" ? true : false;

        this.restApi.getlist(this.restApiURL).pipe(
            take(1)
            ).subscribe( res => {
                if(res.success)
                {
                    
                    this.accounts = res.data.accounts;
                    this.types = res.data.types;
                    this.total_items = res.data.total_items;

                    if(this.action == 'add')
                    {

                        
                        this.maxDate = new Date();
                        this.form.controls['invoice_account_id'].setValue(this.accounts[0].id);
                        
                        this.form.controls['date'].setValue(moment().format("YYYY-MM-DD"));
                        
                       
                        (<FormArray>this.form.get('journals')).clear();
                        
                        this.journal_items.push(
                            this._formBuilder.group({
                                id:null,
                                main:[null,Validators.required],
                                type:[null,Validators.required],
                                amount:['',Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                            })
                        );
                        
                        this.selectedAccount =  this.accounts[0]; 
                    }

                    this.isLoading = false;
                }
        });

        if(this.action == 'edit' && this.return_id > 0)
        {
            this.isLoading = true;
            this.restApi.show(this.restApiURL,this.return_id).pipe(
                take(1)
            ).subscribe( res => {
                    if(res.success)
                    {
                         
                        
                        this.minDate = new Date(res.data.fiscal_year.start_date);
                        this.maxDate = new Date();
                        
                        this.total_credit = res.data.amount;
                        this.total_debit = res.data.amount;
                        
                        this.form.patchValue({
                            invoice_account_id :parseInt(res.data.invoice_account_id),
                            date:moment(res.data.date).format("YYYY-MM-DD"),
                            remarks:res.data.remarks,
                            type:res.data.type,
                            amount:res.data.amount
                        })
                        
                        if(res.data.files.length > 0) 
                            this.setFiles(res.data.files); 
                        if(res.data.journals.length > 0) 
                            this.setItems(res.data.journals);     
                        
                    }

                    this.isLoading = false;
            }); 
        }  
    }
   
    
    changeDate(event: MatDatepickerInputEvent<Date>) {
        this.form.controls['date'].setValue(moment(event.value).format("YYYY-MM-DD"));
    }

    onFileSelect(event) {

        this.isUploadLoad = true;

        this.upload_files = [];

        this.files.push(...event.addedFiles);
        this.upload_files.push(...event.addedFiles);
  
        const formData = new FormData();

        for (var i = 0; i < this.upload_files.length; i++) { 
            formData.append("files[]", this.upload_files[i]);
        }

        console.log('files data',this.upload_files
        );

        this.restApi.tempFileUpload(`journal`,formData).pipe(
            take(1)
        ).subscribe( res => { 
            if(res.success)
            {
                if(res.data.length > 0)
                {
                    res.data.forEach(x => {
                        
                        this.file_items.push(
                            this._formBuilder.group({
                                    temp_id:x.id,
                                    file_path:x.file_path,
                                    file_name:x.file_name,
                                    file_size:x.file_size,
                                    file_extension:x.file_extension,
                                    file_description:[''],
                                    identifier:x.identifier,
                                    id:[''],
                            })    
                        );
                         
                        
                    })
                }
                this.isUploadLoad = false;

            }

            
        });
        

    }
    onFileRemove(index) {

        this.file_items.removeAt(index);
       

    }

    pageReload()
    {
        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });

        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to reload, your unsaved data will be lost?';

        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                this.ngOnInit();
            }
        
            this.confirmDialogRef = null;
        });  
    }

    cancelForm()
        {
            this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
                disableClose: false
            });

            this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to navigate, your unsaved data will be lost?';

            this.confirmDialogRef.afterClosed().subscribe(result => {
                if ( result )
                {
                    this.router.navigateByUrl('journal/journal-list');
                }
                
                this.confirmDialogRef = null;
            });  
    }
    onSubmit(data:any,event:any){
        

        if(this.action == 'edit' && this.return_id > 0)
        {
            this.isLoading = true;

            this.restApi.update(`${this.restApiURL}/${this.return_id}`,data).pipe(
                take(1)
            ).subscribe( res => { 
                if(res.success)
                {
                    if( event == 'save')
                    {
                        
                        
                        this.maxDate = new Date();

                        this.form.patchValue({
                            invoice_account_id :parseInt(res.data.invoice_account_id),
                            date:moment(res.data.date).format("YYYY-MM-DD"),
                            remarks:res.data.remarks,
                            type:res.data.type,
                            amount:res.data.amount
                        })
                        
                        if(res.data.files.length > 0) 
                            this.setFiles(res.data.files); 
                        if(res.data.journals.length > 0) 
                            this.setItems(res.data.journals); 

                         
                    }
                    else if(event == 'save_add')
                    { 
                        this.form.reset();
                        
                      
                        this.restApi.getlist(this.restApiURL).pipe(
                            take(1)
                            ).subscribe( res => {
                                if(res.success)
                                {
                                    this.accounts = res.data.accounts;
                                    this.types = res.data.types;
                                    this.total_items = res.data.total_items;

                                    if(this.action == 'add')
                                    {
                
                                        this.maxDate = new Date();
                                        this.form.controls['invoice_account_id'].setValue(this.accounts[0].id);
                                        this.form.controls['date'].setValue(moment().format("YYYY-MM-DD"));
                                        
                                        (<FormArray>this.form.get('journals')).clear();
                        
                                        this.journal_items.push(
                                            this._formBuilder.group({
                                                id:null,
                                                main:[null,Validators.required],
                                                type:[null,Validators.required],
                                                amount:['',Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                            })
                                        );
                                        this.selectedAccount =  this.accounts[0]; 
                                    }
                                    this.isLoading = false;
                                }
                        });

                       

                        this.readonly = false;
                        this.action = 'add';
                        this.return_id = 'id';
                        this.router.navigateByUrl('journal/add-edit-journal/add/id');
                    }
                    else if(event == 'save_exit')
                    {
                        

                        this.router.navigateByUrl('journal/journal-list');
                    }   
                }

                this.isLoading = false;
            });
        }
        else
        {    
            this.isLoading = true;
            this.restApi.store(this.restApiURL,data).pipe(
                take(1)
            ).subscribe( res => { 
                console.log("Submit Success: " + res);
                if(res.success)
                {
                   
                    if( event == 'save')
                    {

                       
                        this.maxDate = new Date();
                        
                        
                        this.form.patchValue({
                            invoice_account_id :parseInt(res.data.invoice_account_id),
                            date:moment(res.data.date).format("YYYY-MM-DD"),
                            remarks:res.data.remarks,
                            type:res.data.type,
                            amount:res.data.amount
                        })
                        
                        if(res.data.files.length > 0) 
                            this.setFiles(res.data.files); 
                        if(res.data.journals.length > 0) 
                            this.setItems(res.data.journals); 

                        
                        this.action = 'edit';
                        this.return_id = res.data.id;
                        this.router.navigateByUrl('journal/add-edit-journal/edit/'+res.data.id);    
                            
                    }
                    else if(event == 'save_add')
                    { 
                        this.form.reset();
                        
                      
                        this.restApi.getlist(this.restApiURL).pipe(
                            take(1)
                            ).subscribe( res => {
                                if(res.success)
                                {
                                    
                                    this.accounts = res.data.accounts;
                                    this.types = res.data.types;
                                    this.total_items = res.data.total_items;

                                    if(this.action == 'add')
                                    {
                
                                        
                                        this.maxDate = new Date();
                                        this.form.controls['invoice_account_id'].setValue(this.accounts[0].id);
                                        this.form.controls['date'].setValue(moment().format("YYYY-MM-DD"));
                                       
                                        (<FormArray>this.form.get('journals')).clear();
                        
                                        this.journal_items.push(
                                            this._formBuilder.group({
                                                id:null,
                                                main:[null,Validators.required],
                                                type:[null,Validators.required],
                                                amount:['',Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                                            })
                                        );
                                        this.selectedAccount =  this.accounts[0]; 
                                    }
                                    this.form.get('journals').markAsUntouched();
                                    this.isLoading = false;
                                }
                        });

                       
                        this.readonly = false;
                        this.action = 'add';
                        this.return_id = 'id';
                        this.router.navigateByUrl('journal/add-edit-journal/add/id');
                    }
                    else if(event == 'save_exit')
                    {
                       
                        this.router.navigateByUrl('journal/journal-list');
                    }    
                    
                }  
                this.isLoading = false;

            });  
        }
    }
    onTypeChange(index:number,event){
       

        let total_amount:number = 0, total_debit = 0, total_credit = 0; 
    
        this.journal_items.controls.forEach((element: any, key: number) => {
              
            if(element.value.amount > 0)
            {
                if(element.value.type == 'debit')
                    total_debit = total_debit + parseFloat(element.value.amount);
                else if(element.value.type == 'credit')
                    total_credit = total_credit + parseFloat(element.value.amount); 

                total_amount = total_amount + parseFloat(element.value.amount);
            }
            
        })
        
        const faControl = (<FormArray>this.form.controls['journals']).at(0);  
        if(faControl['controls'].type.value != event.name)
        {
            const faControl2 = (<FormArray>this.form.controls['journals']).at(index);
            faControl2['controls'].amount.setValue(Math.abs((total_debit - total_credit)).toFixed(2));

           
            // if(Math.abs((total_debit - total_credit)) == 0)
            //     this.form.controls['amount'].setValue(null);
        }
        else
        {
            const faControl2 = (<FormArray>this.form.controls['journals']).at(index);
            faControl2['controls'].amount.setValue(null);
        }

        let  tot_amount = 0 ,tot_debit = 0, tot_credit = 0; 

        this.journal_items.controls.forEach((element: any, key: number) => {
              
            if(element.value.amount > 0)
            {
                if(element.value.type == 'debit')
                    tot_debit = tot_debit + parseFloat(element.value.amount);
                else if(element.value.type == 'credit')
                    tot_credit = tot_credit + parseFloat(element.value.amount); 

                tot_amount = tot_amount + parseFloat(element.value.amount);
            }
            
        });

        this.total_credit = tot_credit;
        this.total_debit = tot_debit;

        if(tot_amount > 0 && tot_debit.toFixed(2) == tot_credit.toFixed(2))
            this.form.controls['amount'].setValue(tot_credit);
       

    }
    onAmountChange(){

       
        let total_amount:number = 0, total_debit = 0, total_credit = 0; 
    
        this.journal_items.controls.forEach((element: any, key: number) => {
              
            if(element.value.amount > 0)
            {
                if(element.value.type == 'debit')
                    total_debit = total_debit + parseFloat(element.value.amount);
                else if(element.value.type == 'credit')
                    total_credit = total_credit + parseFloat(element.value.amount); 

                total_amount = total_amount + parseFloat(element.value.amount);

                const faControl2 = (<FormArray>this.form.controls['journals']).at(key);
                faControl2['controls'].amount.setValue(parseFloat(element.value.amount).toFixed(2));
            }
            
        })
       
        if((total_debit.toFixed(2) != total_credit.toFixed(2)))
        {
            this.toastr.error("Total Debit and Total Credit Must Match" ,'Please Check The Amounts');
            this.form.controls['amount'].setValue(null);
        }
        else if(total_amount == 0)
        {
            this.form.controls['amount'].setValue(null);
        }
        else
            this.form.controls['amount'].setValue(total_credit.toFixed(2));

        this.total_credit =  total_credit;
        this.total_debit = total_debit;


    }
    get file_items() {
        return this.form.get('files') as FormArray;
    }
    get journal_items() {
        return this.form.get('journals') as FormArray;
    }
    setFiles(files){
        (<FormArray>this.form.get('files')).clear();
        files.forEach(x => {
         
            this.file_items.push(
                this._formBuilder.group({
                        id:x.id,
                        file_path:x.file_path,
                        file_name:x.file_name,
                        file_size:x.file_size,
                        file_extension:x.file_extension,
                        file_description:x.file_description,
                        identifier:x.identifier,
                        temp_id:[''],
                })    
            );
        })
    }
    setItems(journals){
        this.form.get('journals').markAsUntouched();
        (this.form.controls['journals'] as FormArray).clear();
        let control = <FormArray>this.form.controls.journals;
        journals.forEach(x => {
         
          control.push(
              this._formBuilder.group(
                  {
                    id:x.id,
                    main:[x.main,Validators.required],
                    type:[x.type,Validators.required],
                    amount:[x.after_total,Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
                      
                  })
                
            );
        })
    }

    addItem() {
        this.journal_items.push(
            this._formBuilder.group({
                id:null,
                main:[null,Validators.required],
                type:[null,Validators.required],
                amount:['',Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
            })
        );
    }  
    deleteItem(index) {
        this.journal_items.removeAt(index);
    }
    ngOnDestroy(): void{
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

}
