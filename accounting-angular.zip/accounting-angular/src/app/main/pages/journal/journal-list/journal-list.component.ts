import { AfterViewInit, Component, OnDestroy, OnInit,ViewChild,ViewEncapsulation } from '@angular/core';
import { fuseAnimations } from '@fuse/animations';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable, of, Subject, Subscription } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute , Data} from '@angular/router';
import { CollectionViewer, DataSource, SelectionModel } from '@angular/cdk/collections';
import { ApiData, RestApiService } from 'app/service/rest-api.service';
import { catchError, finalize, take, tap, map } from 'rxjs/operators';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';
import { CommonHeaderComponent } from 'app/modal/common-header/common-header.component';
import { ShowHidePipe } from 'app/pipes/show-hide.pipe';
import { FuseSidebarService } from '@fuse/components/sidebar/sidebar.service';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { saveAs } from 'file-saver';
import { FileListComponent } from 'app/modal/file-list/file-list.component';
import { MatTable } from '@angular/material/table';
import { isEmpty } from 'lodash';


@Component({
  selector: 'app-journal-list',
  templateUrl: './journal-list.component.html',
  styleUrls: ['./journal-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations
})
export class JournalListComponent implements OnInit,OnDestroy  {

    url:string='journal';
    header_url = `${this.url}_headers`;
    isLoading = true;
    isDataLoading = false;
    search:any = '';   
    dialogRef: any;
    userdata:any = [];
    dataSource : ApiData = null;
    confirmDialogRef: MatDialogRef<FuseConfirmDialogComponent>;
    pageEvent: PageEvent;
    customNum=[];
    selection = new SelectionModel<ApiData>(true, []);

    @ViewChild(MatPaginator)
    paginator: MatPaginator;
   
    @ViewChild(MatTable) table: MatTable<any>;

    @ViewChild(MatSort) sort: MatSort; 
    
    @ViewChild('search') clearInput;

    private itemsHeaderSubscribe: Subscription;
    private advanceSearchDatasubscription: Subscription;

    private _unsubscribeAll: Subject<any>;
    tableHeaderData;
    tableHeaderDataDropdown;
    tableheaderDropdown;
    tableheaderDropdownChecked;
    tableDefaultChecked;
    displayedColumns : string[] = []; 

    customers=[];
    fiscal_years=[];
    users=[];
    types=[];
    items=[];

    advance_search_form : any;
    advance_search:any = {};

    constructor(private restApiService: RestApiService,private route: ActivatedRoute,private _matDialog: MatDialog,private _fuseSidebarService: FuseSidebarService,
        private router: Router, private http: HttpClient) { 
            this._unsubscribeAll = new Subject();
            this.advanceSearchDatasubscription = new Subscription();

            this.restApiService.getlist(this.url).pipe(
                take(1)
            ).subscribe( res => {
                    if(res.success)
                    {
                    
                        this.customers = res.data.customers;
                        this.fiscal_years = res.data.fiscal_years;
                        this.users = res.data.users;
                        this.types = res.data.types;
                        this.items = res.data.total_items;

                        this.advance_search_form = {
                            url:this.url,
                            fields:[
                                    {
                                    type: "select",
                                    label: "Select Fiscal Year",
                                    inputType: "single",
                                    multiple: false,
                                    name: "fiscal_year_id",
                                    bind_label: "name",
                                    bind_value:"id",
                                    start: "",
                                    end:"",
                                    validations: [],
                                    options:this.fiscal_years
                                },{
                                    type: "select-group",
                                    label: "Select Item",
                                    inputType: "single",
                                    multiple: false,
                                    name: "item_in",
                                    bind_label: "name",
                                    bind_value:"id",
                                    start: "",
                                    end:"",
                                    validations: [],
                                    options:this.items
                                },
                                {
                                    type: "select",
                                    label: "Select Type",
                                    inputType: "single",
                                    multiple: false,
                                    name: "type",
                                    bind_label: "display_name",
                                    bind_value:"name",
                                    validations: [],
                                    options:this.types
                                },
                                {
                                    type: "select",
                                    label: "Select Creator",
                                    inputType: "single",
                                    multiple: false,
                                    name: "created_by",
                                    bind_label: "name",
                                    bind_value:"id",
                                    validations: [],
                                    options:this.users
                                },
                                {
                                    type: "date-range",
                                    label: "Select Date Range",
                                    inputType: "single",
                                    multiple: false,
                                    bind_label: "",
                                    bind_value:"",
                                    name: "range",
                                    start: "start_date",
                                    end:"end_date",
                                    validations: [],
                                    options:[],
                                }
                            ]
                        };
                        
                    }
            });
    }

    ngOnInit(): void {
        this.onHeaderData(this.header_url);
        this.initDataSource(this.url,'','','',null,null);
       
        this.advanceSearchDatasubscription = this.restApiService.advance_submit_data.subscribe(d=>{
            
            if(d && d != null && !isEmpty(d))
            {   
                console.log('dddd',d);
                this.advance_search = d;
                this.initDataSource(this.url,'',d,'',1,10);
            }
        });
    }
    
    initDataSource(url: string,search='',filter='',sort='',pageIndex=1,pageSize=10){
        pageIndex  =  pageIndex == null ? 1 : pageIndex;
        pageSize   =  pageSize  == null ? 10 : pageSize;
        this.isLoading = true;
        this.restApiService.index(url,search, filter, sort,
            pageIndex, pageSize,`filter[type]=journal`)
            .pipe(
                map((ApiData : ApiData) => this.dataSource = ApiData)
            )
            .subscribe(res=>{
                this.isLoading = false;
    
            });
    }
    
    _search = function ($event: { target: { value: string; }; }) {
    
        this.search = $event.target.value
        this.isLoading = true;
        
        //fetch list params url,search,filter,sort,page,per_pate
        this.initDataSource(this.url,this.search,'','',null,null)
        
    }

    handleClear(){
        // clearing the value    
        this.clearInput.nativeElement.value = '';
        this.initDataSource(this.url,'','','',1,10);
    }

    onPaginateChange(event: PageEvent){
        let page = event.pageIndex;
        let size = event.pageSize;
        
        this.isDataLoading = true;

        let sorting = '';
        if(this.sort.active)
            sorting  = this.sort.direction == 'desc' ? '-'+this.sort.active : this.sort.active;

        page = page + 1;
       
        this.restApiService.index(this.url,this.search, this.advance_search, sorting,
            page, size,`filter[type]=journal`).pipe(
            map((UserData : ApiData) => this.dataSource = UserData)
        ).subscribe(res=>{
            this.isLoading = false;
            this.isDataLoading = false;
        });
        
    }

    ngOnDestroy(): void
    {
        this.advanceSearchDatasubscription.unsubscribe();
        this.restApiService.advance_submit_data.next({});
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    deleteItem(item : any,index : number): void
    {
          this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
              disableClose: false
          });
    
          this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to delete?';
    
          this.confirmDialogRef.afterClosed().subscribe(result => {
              if ( result )
              {
                  this.restApiService.destroy(this.url,item.id).pipe(
                      take(1)
                    ).subscribe( res => { 
                      console.log("Submit Success: " + res);
                      if(res.success)
                        {
                                this.dataSource.data.splice(index,1);
                                this.dataSource.total = this.dataSource.total - 1;
                                this.table.renderRows();
                        }
          
                  }); 
                  
                  
              }
              this.confirmDialogRef = null;
          });
    
    }

    _changeStatus(item){
   
        item.status = parseInt(item.status) ? 0 : 1;
        this.restApiService.update(`${this.url}/${item.id}`,{status:item.status,name:item.name,display_name:item.display_name}).pipe(
            take(1)
        ).subscribe( res => { 
            
            if(res.success)
            {
                item.status  = res.data.status ;
                
            }
    
        });
    }

    // --------- table header function -----------//
    onHeaderData(_header_url) {

            this.isLoading = true;
            this.itemsHeaderSubscribe = this.restApiService.headerListData(_header_url).subscribe(
            resData => {
                this.tableHeaderData = resData[0];
                this.tableheaderDropdownChecked = resData[1];
                this.displayedColumns = ['position','selection',...resData[1].map(x=>x.column_name),'action'];
            },
            errRes => {
            }
            );
    }
    
    headerModal(){
        const dialogRef = this._matDialog.open(CommonHeaderComponent, {
            data: {
            headerName :this.header_url,
            allHeader:this.tableHeaderData,
            }
        });
        dialogRef.afterClosed().subscribe(result => {

            if(result != undefined){
                this.tableheaderDropdownChecked=[]
                this.tableHeaderData = [];
                this.tableHeaderData = [...result];
                this.tableheaderDropdownChecked = [...result.filter(y=>y.is_default == 1)];
                let reCol = result.filter(y=>y.is_default == 1).map(x=>x.column_name);
                this.displayedColumns = ['position','selection',...reCol,'action'];
                console.log('this.displayedColumns',this.displayedColumns);
            }
            
        },
        errRes=>{});
    }

    //----------- table header end function -----//

    showItem(val,i){
        this.customNum[i] = val
    }

    hideItem(val,i){
        this.customNum[i] = val;
    } 

    /****************table footer functions***********/
    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.dataSource.data.length;
        return numSelected === numRows;
    }

    
    masterToggle() {
        this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
    }
        
    checkboxLabel(row?: ApiData): string {
        if (!row) {
            return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
        }
    
    }

    deleteAll(){
        let mutli_ids = [];

        this.selection.selected.forEach((element: any, key: number) => {
            mutli_ids.push(element.id);
        });

        this.confirmDialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
            disableClose: false
        });

        this.confirmDialogRef.componentInstance.confirmMessage = 'Are you sure you want to delete selected items?';

        this.confirmDialogRef.afterClosed().subscribe(result => {
            if ( result )
            {
                
                this.restApiService.actionAll(this.url,mutli_ids,'delete',1,'deleted_at').pipe(
                    take(1)
                    ).subscribe( res => { 
                    console.log("Submit Success: " + res);
                    if(res.success)
                        this.initDataSource(this.url,'','','',null,null);
        
                }); 
                
            }
            this.selection.clear();
            this.confirmDialogRef = null;
        });
    }
    customSort(sort : Sort,event : PageEvent)
        {
            let page = event.pageIndex;
            let size = event.pageSize;
    
            page = page + 1;
            
            if(sort)
            {
            this.isDataLoading = true;

            let sorting = sort.direction == 'desc' ? '-'+sort.active : sort.active;
    
                this.restApiService.index(this.url,this.search, this.advance_search, sorting,
                page, size,`filter[type]=journal`).pipe(
                    map((UserData : ApiData) => this.dataSource = UserData)
                ).subscribe(res=>{
                    this.isLoading = false;
                    this.isDataLoading = false;
                });
            }
            
    }

    /*****************table footer functions end***********/
    
    /**
     * Toggle sidebar open(Advance Search)
     *
     * @param key
     */
    toggleSidebarOpen(key): void
    {

        this._fuseSidebarService.getSidebar(key).toggleOpen();
        //this._fuseSidebarService.getSidebar(key).toggleOpenData(this.userdata,this.url);
        if(this.advance_search_form && this.advance_search_form != null)
            this.restApiService.setOption(this.advance_search_form);
        
    }

    /**********File List Modal***********/

    showFilesList(item){
        const dialogRef = this._matDialog.open(FileListComponent, {
            data: {
                form_header:'Journal Files List',
                files:item.files
            },
            width:'auto',
            height: 'auto'
            });
            dialogRef.afterClosed().subscribe(result => {

            
            },
            errRes=>{});
    }

    printVoucher(item){
        item.isPrintDownload = true;
        this.restApiService.printFile(this.url,item.id,'print').pipe(
            take(1)
            ).subscribe( res => {
                if(res.success)
                {
                    item.isPrintDownload = false;
                    var popupWinindow = window.open('', '_blank', 'width=2480,height=5000');
                    popupWinindow.document.open();
                    popupWinindow.document.write('<html><body onload="window.print()">' + res.data + '</html>');
                    popupWinindow.document.close();
                }
        });
    }
    downloadPDF(item){
            
        item.isPdfDownload =  true;
        
        const salt = (new Date()).getTime();
        return this.http.get(`${this.url}_print/${item.id}?salt=${salt}`, {responseType:'blob'}).subscribe(res => {
           
            
            item.isPdfDownload =  false;

            var FileSaver = require('file-saver');
            const blob = new Blob([res], {type: 'application/pdf'});
            FileSaver.saveAs(blob, `Journal-${item.id}.pdf`);
           
            
            
        }, err => {
            console.log(err);
        });
        
    }

}
