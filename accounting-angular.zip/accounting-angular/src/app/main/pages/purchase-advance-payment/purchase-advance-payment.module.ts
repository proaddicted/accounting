import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { PurchaseAdvancePaymentAddModule } from './purchase-advance-payment-add/purchase-advance-payment-add.module';
import { PurchaseAdvancePaymentListModule } from './purchase-advance-payment-list/purchase-advance-payment-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    PurchaseAdvancePaymentAddModule,
    PurchaseAdvancePaymentListModule
  ]
})
export class PurchaseAdvancePaymentModule { }
