import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { ItemListModule } from './item-list/item-list.module';
import { ItemAddModule } from './item-add/item-add.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    ItemListModule,
    ItemAddModule
  ]
})
export class ItemModule { }
