import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { CurrencyAddModule } from './currency-add/currency-add.module';
import { CurrencyListModule } from './currency-list/currency-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    CurrencyAddModule,
    CurrencyListModule
  ]
})
export class CurrencyModule { }
