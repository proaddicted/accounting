import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { ContraEntryAddModule } from './contra-entry-add/contra-entry-add.module';
import { ContraEntryListModule } from './contra-entry-list/contra-entry-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    ContraEntryAddModule,
    ContraEntryListModule
  ]
})
export class ContraEntryModule { }
