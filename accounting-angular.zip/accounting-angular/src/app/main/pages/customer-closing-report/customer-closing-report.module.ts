import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FuseConfirmDialogModule } from '@fuse/components';
import { CustomerClosingReportListModule } from './customer-closing-report-list/customer-closing-report-list.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FuseConfirmDialogModule,
    CustomerClosingReportListModule
  ]
})
export class CustomerClosingReportModule { }
