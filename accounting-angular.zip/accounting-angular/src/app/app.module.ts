import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { MatMomentDateModule, MomentDateAdapter, MomentDateModule } from '@angular/material-moment-adapter';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { TranslateModule } from '@ngx-translate/core';

import { FuseModule } from '@fuse/fuse.module';
import { FuseSharedModule } from '@fuse/shared.module';
import { FuseProgressBarModule, FuseSidebarModule, FuseThemeOptionsModule } from '@fuse/components';

import { fuseConfig } from 'app/fuse-config';
import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { FakeDbService } from 'app/fake-db/fake-db.service';
import { AppComponent } from 'app/app.component';
import { AppStoreModule } from 'app/store/store.module';
import { LayoutModule } from 'app/layout/layout.module';
import { InterceptorProvider } from './service/interceptor-provider';
import { ToastrModule } from 'ngx-toastr';
import { AuthGuard } from 'app/service/auth.guard';
import { CommonHeaderComponent } from './modal/common-header/common-header.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {MatListModule} from '@angular/material/list';
import { MatDialogModule } from '@angular/material/dialog';
import {MatSortModule} from '@angular/material/sort';
import {DragDropModule} from '@angular/cdk/drag-drop';
import { AdvanceSearchComponent } from './advance-search/advance-search.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { NgSelectModule } from '@ng-select/ng-select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { CustomerAddComponent } from './modal/customer-add/customer-add.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ItemAddComponent } from './modal/item-add/item-add.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FileListComponent } from './modal/file-list/file-list.component';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { MatCardModule } from '@angular/material/card';
import { DateAdapter, MatNativeDateModule, MAT_DATE_LOCALE, NativeDateAdapter } from '@angular/material/core';
import { BankRealizeUpdateComponent } from './modal/bank-realize-update/bank-realize-update.component';

const appRoutes: Routes = [
    {
        path        : 'apps',
        loadChildren: () => import('./main/apps/apps.module').then(m => m.AppsModule),
        canActivate: [AuthGuard]

    }, {
        path        : 'user',
        loadChildren: () => import('./main/pages/user/user.module').then(m => m.UserModule),
        canActivate: [AuthGuard]

    }, {
        path        : 'customer',
        loadChildren: () => import('./main/pages/customer/customer.module').then(m => m.CustomerModule),
        canActivate: [AuthGuard]

    }, {
        path        : 'item',
        loadChildren: () => import('./main/pages/item/item.module').then(m => m.ItemModule),
        canActivate: [AuthGuard]

    }, {
        path        : 'item-group',
        loadChildren: () => import('./main/pages/item-group/item-group.module').then(m => m.ItemGroupModule),
        canActivate: [AuthGuard]

    }, {
        path        : 'bank-account',
        loadChildren: () => import('./main/pages/bank-account/bank-account.module').then(m => m.BankAccountModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'branch',
        loadChildren: () => import('./main/pages/branch/branch.module').then(m => m.BranchModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'page',
        loadChildren: () => import('./main/pages/page/page.module').then(m => m.PageModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'module',
        loadChildren: () => import('./main/pages/module/module.module').then(m => m.ModuleModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'role',
        loadChildren: () => import('./main/pages/role/role.module').then(m => m.RoleModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'country',
        loadChildren: () => import('./main/pages/country/country.module').then(m => m.CountryModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'state',
        loadChildren: () => import('./main/pages/state/state.module').then(m => m.StateModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'currency',
        loadChildren: () => import('./main/pages/currency/currency.module').then(m => m.CurrencyModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'fiscalyear',
        loadChildren: () => import('./main/pages/fiscalyear/fiscalyear.module').then(m => m.FiscalyearModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'invoice',
        loadChildren: () => import('./main/pages/invoice/invoice.module').then(m => m.InvoiceModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'proforma-invoice',
        loadChildren: () => import('./main/pages/proforma-invoice/proforma-invoice.module').then(m => m.ProformaInvoiceModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'payment',
        loadChildren: () => import('./main/pages/payment/payment.module').then(m => m.PaymentModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'creditnote',
        loadChildren: () => import('./main/pages/creditnote/creditnote.module').then(m => m.CreditnoteModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'debitnote',
        loadChildren: () => import('./main/pages/debitnote/debitnote.module').then(m => m.DebitnoteModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'purchase',
        loadChildren: () => import('./main/pages/purchase/purchase.module').then(m => m.PurchaseModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'purchase-payment',
        loadChildren: () => import('./main/pages/purchase-payment/purchase-payment.module').then(m => m.PurchasePaymentModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'salary-entry',
        loadChildren: () => import('./main/pages/salary-entry/salary-entry.module').then(m => m.SalaryEntryModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'cashbook',
        loadChildren: () => import('./main/pages/cashbook/cashbook.module').then(m => m.CashbookModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'contra-entry',
        loadChildren: () => import('./main/pages/contra-entry/contra-entry.module').then(m => m.ContraEntryModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'purchase-advance-payment',
        loadChildren: () => import('./main/pages/purchase-advance-payment/purchase-advance-payment.module').then(m => m.PurchaseAdvancePaymentModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'report',
        loadChildren: () => import('./main/pages/report/report.module').then(m => m.ReportModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'summary-report',
        loadChildren: () => import('./main/pages/summary-report/summary-report.module').then(m => m.SummaryReportModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'cashbook-report',
        loadChildren: () => import('./main/pages/cashbook-report/cashbook-report.module').then(m => m.CashbookReportModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'bank-reconciliation',
        loadChildren: () => import('./main/pages/bank-reconciliation/bank-reconciliation.module').then(m => m.BankReconciliationModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'creditor-report',
        loadChildren: () => import('./main/pages/creditor-report/creditor-report.module').then(m => m.CreditorReportModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'debtor-report',
        loadChildren: () => import('./main/pages/debtor-report/debtor-report.module').then(m => m.DebtorReportModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'trial-balance',
        loadChildren: () => import('./main/pages/trial-balance/trial-balance.module').then(m => m.TrialBalanceModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'opening-balance',
        loadChildren: () => import('./main/pages/opening-balance/opening-balance.module').then(m => m.OpeningBalanceModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'profit-loss',
        loadChildren: () => import('./main/pages/profit-loss/profit-loss.module').then(m => m.ProfitLossModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'bankbook-report',
        loadChildren: () => import('./main/pages/bankbook-report/bankbook-report.module').then(m => m.BankbookReportModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'balance-sheet',
        loadChildren: () => import('./main/pages/balance-sheet/balance-sheet.module').then(m => m.BalanceSheetModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'tds-section',
        loadChildren: () => import('./main/pages/tds-section/tds-section.module').then(m => m.TdsSectionModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'tcs-section',
        loadChildren: () => import('./main/pages/tcs-section/tcs-section.module').then(m => m.TcsSectionModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'category',
        loadChildren: () => import('./main/pages/category/category.module').then(m => m.CategoryModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'journal',
        loadChildren: () => import('./main/pages/journal/journal.module').then(m => m.JournalModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'bank-realization',
        loadChildren: () => import('./main/pages/bank-realization/bank-realization.module').then(m => m.BankRealizationModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'customer-closing',
        loadChildren: () => import('./main/pages/customer-closing-report/customer-closing-report.module').then(m => m.CustomerClosingReportModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'json-report',
        loadChildren: () => import('./main/pages/json-report/json-report.module').then(m => m.JsonReportModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'master-type',
        loadChildren: () => import('./main/pages/master-type/master-type.module').then(m => m.MasterTypeModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'invoice-series',
        loadChildren: () => import('./main/pages/invoice-series/invoice-series.module').then(m => m.InvoiceSeriesModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'account-voucher',
        loadChildren: () => import('./main/pages/account-voucher/account-voucher.module').then(m => m.AccountVoucherModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'cash-flow',
        loadChildren: () => import('./main/pages/cash-flow/cash-flow.module').then(m => m.CashFlowModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'fund-flow',
        loadChildren: () => import('./main/pages/fund-flow/fund-flow.module').then(m => m.FundFlowModule),
        canActivate: [AuthGuard]

    },
    {
        path        : 'error-500',
        loadChildren: () => import('./main/pages/500/error-500.module').then(m => m.Error500Module),
        canActivate: [AuthGuard]

    },
    {
        path        : 'auth',
        loadChildren: () => import('./main/pages/authentication/authentication.module').then(m => m.AuthenticationModule)
    },
    {
        path      : '**',
        redirectTo: 'apps/dashboards/analytics', 
        canActivate: [AuthGuard]
    }
];

@NgModule({
    declarations: [
        AppComponent,
        CommonHeaderComponent,
        AdvanceSearchComponent,
        CustomerAddComponent,
        ItemAddComponent,
        FileListComponent,
        BankRealizeUpdateComponent    
    ],
    imports     : [
        BrowserModule,
        BrowserAnimationsModule,
        HttpClientModule,
        RouterModule.forRoot(appRoutes, { relativeLinkResolution: 'legacy' }), //,preloadingStrategy: PreloadAllModules
        
        TranslateModule.forRoot(),
        InMemoryWebApiModule.forRoot(FakeDbService, {
            delay             : 0,
            passThruUnknownUrl: true
        }),

        // Material moment date module
        MatMomentDateModule,

        // Material
        MatButtonModule,
        MatIconModule,
        MatCheckboxModule,
        MatListModule,
        MatDialogModule,
        DragDropModule,
        MatSortModule,
        MatFormFieldModule,
        MatInputModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatMomentDateModule,
        MatSlideToggleModule,
        MomentDateModule,
        MatTooltipModule,
        MatCardModule,
        //Select Module
        NgSelectModule,
        //Date Range Picker
        NgxDaterangepickerMd.forRoot(),
        // Fuse modules
        FuseModule.forRoot(fuseConfig),
        FuseProgressBarModule,
        FuseSharedModule,
        FuseSidebarModule,
        FuseThemeOptionsModule,

        // App modules
        LayoutModule,
        AppStoreModule,
        ToastrModule.forRoot({
            timeOut: 5000,
            positionClass: 'toast-bottom-center',
            preventDuplicates: true,
          }),
    ],
    providers: [{
        provide: HTTP_INTERCEPTORS,
        useClass: InterceptorProvider,
        multi: true
      },{provide: DateAdapter, useClass: NativeDateAdapter, deps: [MAT_DATE_LOCALE]}, ],
    bootstrap   : [
        AppComponent
    ],
    entryComponents: [CommonHeaderComponent,CustomerAddComponent,ItemAddComponent,FileListComponent,BankRealizeUpdateComponent]
})
export class AppModule
{
}
