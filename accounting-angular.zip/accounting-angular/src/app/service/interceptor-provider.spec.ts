import { InterceptorProvider } from './interceptor-provider';

describe('InterceptorProvider', () => {
  it('should create an instance', () => {
    expect(new InterceptorProvider()).toBeTruthy();
  });
});
