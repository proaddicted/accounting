import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable, of, Subject, throwError } from 'rxjs';
import { tap, delay } from 'rxjs/operators';
import { map, catchError,share } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { forEach } from 'lodash';
import { ActivatedRoute, ActivatedRouteSnapshot, Route, Router,Data } from '@angular/router';

export interface ApiData {
    current_page : number,
    data : [],
    first_page_url : string,
    from: number,
    last_page: 1,
    last_page_url: string,
    next_page_url: string,
    path: string,
    per_page: number,
    prev_page_url: string,
    to: number,
    total: number
}

@Injectable({
  providedIn: 'root'
})
export class RestApiService {
    advance_search: BehaviorSubject<any>;
    advance_submit_data: BehaviorSubject<any>;

  constructor(
      private http:HttpClient,
      private toastr:ToastrService,
      private router:Router,
      private route:ActivatedRoute
  ) {
    this.advance_search = new BehaviorSubject([]);
    this.advance_submit_data = new BehaviorSubject({});
   }

  index(url: any,_search:any,filter: any, sortDirection: any,pageIndex:any = 1, pageSize:any = 10, type:any=""):  Observable<any> {

        
        console.log('type',type);

        let advanceSearchParams = '';
        let onlySearch;

        // search
        if(_search === undefined || _search === null ||  _search == '' ){
            onlySearch = '';
        }else{
            onlySearch = _search;

        }

        // advance search
        let other_data = filter;
        if(other_data !== undefined && other_data !== null &&  other_data !== ''){
            for(var item in other_data){
                //console.log('item ------',item);
                if(other_data[item] != undefined && other_data[item] !='' ){
                    // other_data.other_data[item] = '';
                    advanceSearchParams = advanceSearchParams + '&'+'filter['+item+']'+'='+other_data[item];
                }
  
            }
        }
        if(type !== undefined && type !== null &&  type !== '')
        {
            if(advanceSearchParams !== '')
                advanceSearchParams = advanceSearchParams + '&'+type;
            else
                advanceSearchParams = '&'+type;  
        }   
        
       
        return this.http.get(`${url}?per_page=${pageSize}&page=${pageIndex}&search=${onlySearch}&sort=${sortDirection}${advanceSearchParams}&page_url=${this.router.url.split('/')[1]}`).pipe(
            map((ApiData : ApiData) => ApiData.data),
                catchError(err =>throwError(err))
        );

    }

  store(url:any , data:any) :Observable<any>{
    return this.http.post<any>(`${url}?page_url=${this.router.url.split('/')[1]}`, data)
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastr.success(res.message, 'Successfully Submitted');
            else
               {
                 
                 for (let [key, value] of Object.entries(res.message)) {
                    
                    this.toastr.error(
                        `${value}`
                         ,'Insertion Failed');
                  }  
                 
               }   

            return res;
        
        }

      }),
      share()
    );
  }

  show(url:any ,id: number) :  Observable<any> {

    return this.http.get(`${url}/${id}?page_url=${this.router.url.split('/')[1]}`, {
    }).pipe(
        map(res =>  res)
    );
  }

  update(url:any , data:any) :Observable<any>{
    return this.http.put<any>(`${url}?page_url=${this.router.url.split('/')[1]}`, data)
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastr.success(res.message, 'Successfully Updated');
            else
               {
                for (let [key, value] of Object.entries(res.message)) {
                    
                    this.toastr.error(
                        `${value}`
                         ,'Update Failed');
                  }
               }   

            return res;
        
        }

      }),
      share()
    );
  }

  destroy(url:any,id:number) : Observable<any>{
    return this.http.delete<any>(`${url}/${id}?page_url=${this.router.url.split('/')[1]}`)
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastr.success(res.message, 'Success');
            else
                this.toastr.error(res.message,'Deletion Failed');   

            return res;
        
        }

      }),
      share()
    );
  }

  getlist(url:any) :  Observable<any> {

    return this.http.get(`${url}_getlist?page_url=${this.router.url.split('/')[1]}`, {
    }).pipe(
        map(res =>  res)
    );
  }

  loadData(url:any) :  Observable<any> {

    return this.http.get(`${url}?page_url=${this.router.url.split('/')[1]}`, {
    }).pipe(
        map(res =>  res)
    );
  }

  loadDataByPost(url:any,data) :  Observable<any> {

    return this.http.post<any>(`${url}?page_url=${this.router.url.split('/')[1]}`,data).pipe(
        map(res =>  res)
    );
  }

  loadRawURL(url:any) :  Observable<any> {

    return this.http.get(`${url}`, {
    }).pipe(
        map(res =>  res)
    );
  }

  searchDataByPost(url:any,data:any) :  Observable<any> {

    return this.http.post<any>(`${url}?page_url=${this.router.url.split('/')[1]}`, data).pipe(
        map(res =>  {
            if (res) {
                if(res.success)
                 {
                    let fetched_data = [];
                    for (let [key, value] of Object.entries(res.data))
                    {
                        fetched_data.push(value);
                    }
                    
                    return fetched_data
                 }   
                else
                   {
                     
                     for (let [key, value] of Object.entries(res.message)) {
                        
                        this.toastr.error(
                            `${value}`
                             ,'Search Validation Failed');
                      }  
                     
                   }   
    
                return res.data;
            
            }
    
          }),
          share()
    );
  }

  searchRealizeDataByPost(url:any,data:any) :  Observable<any> {

    return this.http.post<any>(`${url}?page_url=${this.router.url.split('/')[1]}`, data).pipe(
        map(res =>  {
            if (res) {
                if(res.success)
                 {
                    return res.data
                 }   
                else
                   {
                     
                     for (let [key, value] of Object.entries(res.message)) {
                        
                        this.toastr.error(
                            `${value}`
                             ,'Search Validation Failed');
                      }  
                     
                   }   
    
                return res.data;
            
            }
    
          }),
          share()
    );
  }

  categoryData(url:any,_search:any) :  Observable<any> {

    let onlySearch;

    // search
    if(_search === undefined || _search === null ||  _search == '' ){
        onlySearch = '';
    }else{
        onlySearch = _search;

    }

    return this.http.get<any>(`${url}?page_url=${this.router.url.split('/')[1]}&search=${onlySearch}`).pipe(
        map(res =>  {
            if (res) {
                 
                return res.data;
            
            }
    
          }),
          share()
    );
  }
  profitLossData(url:any,start_date:any,end_date:any) :  Observable<any> {

    let onlySearch;

    

    return this.http.get<any>(`${url}?page_url=${this.router.url.split('/')[1]}&start_date=${start_date}&end_date=${end_date}`).pipe(
        map(res =>  {
            if (res) {
                 
                return res.data;
            
            }
    
          }),
          share()
    );
  }
  actionAll(url:any , ids: any , action:string , status:any , column:any): Observable<any>{
    return this.http.post<any>(`${url}_actionall?page_url=${this.router.url.split('/')[1]}`, {'ids':ids,'action':action,'status':status,'column':column})
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastr.success(res.message, 'Success');
            else
                this.toastr.error(res.message,'Action Failed');   

            return res;
        
        }

      }),
      share()
    );
  }

  sendMailSingle(url:any,item:any,data:any) :  Observable<any> {

    return this.http.post<any>(`${url}/${item.id}?page_url=${this.router.url.split('/')[1]}`, data)
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastr.success(res.message, 'Successfully Sent');
            else
               {
                for (let [key, value] of Object.entries(res.message)) {
                    
                    this.toastr.error(
                        `${value}`
                         ,'Notification Send Failed');
                  }
                  return res;
               }   

            return res;
        
        }

      }),
      share()
    );
  }

  tempFileUpload(identifier:string,data:any) :  Observable<any> {

    return this.http.post<any>(`fileupload?page_url=${this.router.url.split('/')[1]}&identifier=${identifier}`, data)
    .pipe(map(res => {
        if (res) {
            if(res.success)
                this.toastr.success(res.message, 'File Uploaded');
            else
               {
                for (let [key, value] of Object.entries(res.message)) {
                    
                    this.toastr.error(
                        `${value}`
                         ,'Upload Failed');
                  }
               }   

            return res;
        
        }

      }),
      share()
    );
  }

  printFile(url:any,id:number,type:any) :  Observable<any>
  {
    return this.http.get(`${url}_print/${id}?type=${type}&page_url=${this.router.url.split('/')[1]}`, {
    }).pipe(
        map(res =>  res)
    );
  }

  loadReportData(url:any) :  Observable<any> {

    return this.http.get<any>(`${url}?page_url=${this.router.url.split('/')[1]}`).pipe(
        map(res =>  {
            if (res) {
                
    
                return res.data;
            
            }
    
          }),
          share()
    );
  }

  loadJSONData(url:any,data:any) :  Observable<any> {

    return this.http.post<any>(`${url}?page_url=${this.router.url.split('/')[1]}`,data).pipe(
        map(res =>  {
            if (res) {
                
                if(res.success)
                {
                    return res.data;
                }   
                else
                {
                    
                    for (let [key, value] of Object.entries(res.message)) {
                       
                       this.toastr.error(
                           `${value}`
                            ,'Search Validation Failed');
                     }  
                    
                } 
               
            
            }
    
          }),
          share()
    );
  }
  //==========================  table header data start ======================
    items_header_data; //variable declar
    tableHeaderData;
    tableheaderDropdownChecked;
    tableHeaderDataDropdown;
    tableDefaultChecked;

    private _itemsHeader = new BehaviorSubject(
        []
    );

    get itemsHeaderData(){
        // return [...this._itemsHeader];
        return this._itemsHeader.asObservable();
    }

    headerListData( _getUrl ) : Observable<any>{

        this.items_header_data = []; //blank array items will be push

        // table header column selection
        this.tableHeaderData = [];
        this.tableheaderDropdownChecked = [];
        this.tableDefaultChecked = []

        let _stroageVal = JSON.parse(localStorage.getItem(_getUrl));

        if (_stroageVal != null ) {
            return new BehaviorSubject(_stroageVal).pipe(
                map((resData:any) => {
    
                    if( resData.length > 0){
                        for (const key in resData) {
                            if (resData.hasOwnProperty(key)) {
                            this.items_header_data.push(resData[key]);
                            }
                        }
                    }else{
                    // infinite scroll complite
                    // event.target.complete();
                    }
    
                    // ---- array filter by display and default array item start ---
                    this.items_header_data.forEach((val, ind) => {
                        // dropdown show item
                        if(val.is_display == 1){
                            if (this.tableHeaderData.indexOf(val.column_name) === -1) {
                            this.tableHeaderData.push(val);
                            }
                        }
            
                        // dropdown checked item
                        if(val.is_default == 1){
                            if (this.tableheaderDropdownChecked.indexOf(val.column_name) === -1) {
                            this.tableheaderDropdownChecked.push(val);
                            }
                            
                        }
                    });
    
                    return [
                        this.tableHeaderData, 
                        this.tableheaderDropdownChecked
                    ];
                }),
                tap(itmArry => {
                    // console.log('itmArry >>>>>>>>>>', itmArry);
                    this._itemsHeader.next(itmArry); //update observable data
                }) 
            );
        }
        return this.http.get(`${_getUrl}`).pipe(
            map((resData:any) => {
                // localStorage.setItem(`${_getUrl}_all`, JSON.stringify(resData));

                if( resData.data.length > 0){
                    localStorage.setItem(`${_getUrl}`, JSON.stringify(resData.data));
                    for (const key in resData.data) {
                        if (resData.data.hasOwnProperty(key)) {
                        this.items_header_data.push(resData.data[key]);
                        }
                    }
                }else{
                // infinite scroll complite
                // event.target.complete();
                }

                // ---- array filter by display and default array item start ---
                this.items_header_data.forEach((val, ind) => {
                    // dropdown show item
                    if(val.is_display == 1){
                        if (this.tableHeaderData.indexOf(val.column_name) === -1) {
                        this.tableHeaderData.push(val);
                        }
                    }
        
                    // dropdown checked item
                    if(val.is_default == 1){
                        if (this.tableheaderDropdownChecked.indexOf(val.column_name) === -1) {
                        this.tableheaderDropdownChecked.push(val);
                        }
                        
                    }
                });

                return [
                    this.tableHeaderData, 
                    this.tableheaderDropdownChecked
                ];
            }),
            tap(itmArry => {
                // console.log('itmArry >>>>>>>>>>', itmArry);
                this._itemsHeader.next(itmArry[0]); //update observable data
            }) 
        );
    }
    // table header data end

    //advance search data//
    // advData;
    // advanceSearchData(data){
    //     return of(this.advData)
    // }

      
  
    setOption(option) {      
       this.advance_search.next(option)  
    } 
    
    setAdvanceSubmitData(option) {      
        this.advance_submit_data.next(option)  
    }
   


     
}
