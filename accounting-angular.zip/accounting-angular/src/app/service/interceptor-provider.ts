import { Injectable } from '@angular/core';
import { HttpEvent, HttpRequest, HttpHandler, HttpInterceptor, HttpResponse, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { tap, shareReplay, retry, map, catchError, switchMap } from 'rxjs/operators';
import { environment } from 'environments/environment';
import { ToastrService } from 'ngx-toastr';
import { Route, Router } from '@angular/router';


const API_URL = environment.apiUrl;
const API_CODE = environment.apiCode;

@Injectable()
export class InterceptorProvider implements HttpInterceptor{
    
    constructor(private toastrService:ToastrService,private router:Router){};

    headers : any;

    intercept(req : HttpRequest<any>, next : HttpHandler): Observable<HttpEvent<any>>{

        if (req.url.includes("analytics-dashboard-widgets") || req.url.includes("project-dashboard-projects") || req.url.includes("project-dashboard-widgets"))
            return next.handle(req);
        
        console.log('req',req)    
        if(localStorage.getItem("AccessToken") != null)
        {   

            if(req.url.includes("fileupload"))
            {
                console.log('file up >>>');
                this.headers = {
                    'Cache-Control':  'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
                    'Access-Control-Allow-Origin':'*',
                    'Pragma': 'no-cache',
                    'Expires': '0',
                    
                    'Accept': 'application/json',
                    'X-MASTER-CODE':API_CODE,
                    'Authorization':`Bearer ${localStorage.getItem("AccessToken")}`
                  }
            }
            else
            {
                this.headers = {
                    'Cache-Control':  'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
                    'Pragma': 'no-cache',
                    'Expires': '0',
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-MASTER-CODE':API_CODE,
                    'Authorization':`Bearer ${localStorage.getItem("AccessToken")}`
                  }
            }
            
        }
        else
        {
            this.headers = {
                'Cache-Control':  'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
                'Pragma': 'no-cache',
                'Expires': '0',
                'Content-Type': 'application/json',
                'X-MASTER-CODE':API_CODE,
                'Accept': 'application/json'
              }

        }
        const reqWithAuth = req.clone({
            url:`${API_URL}/${req.url}`,
            setHeaders:this.headers
        })
        
    
        return next.handle(reqWithAuth).pipe(
            catchError((error: HttpErrorResponse) => {
                console.log('error sss',error);
                let errorMessage = '';
                if (error.error instanceof ErrorEvent) {
                    console.log('error',error);
                    // client-side error
                } else {
                    // server-side error
                    if(error.status == 404)
                    {
                        this.toastrService.error(error.error.message, 'Invalid Access');
                          
                    }
                    else if(error.status == 403 || error.status == 401)
                    {
                        this.toastrService.error(error.error.message, 'Invalid Access');
                        
                        localStorage.removeItem('AccessToken');
                        localStorage.removeItem('LoggedUser');
                        
                        this.router.navigate(['/auth/login']);
                    }
                    else if(error.status == 500)
                    {
                        this.toastrService.error('Internal Server Error', '500 Server Error');
                          
                    }
                }
                
                return throwError(errorMessage);
            })
        );        

      }
}
