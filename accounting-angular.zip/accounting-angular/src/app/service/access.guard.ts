import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { AuthService } from './auth.service';
import { RestApiService } from './rest-api.service';

@Injectable({
  providedIn: 'root'
})
export class AccessGuard implements CanActivate {
  constructor(
      private router: Router,
      private authService: AuthService,
      private restApiService: RestApiService
      ) {}
  
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | boolean | UrlTree {
        let page_url: string = state.url;
        let access_type = route.data["access-type"] as Array<string>;

        let logged_user = JSON.parse(localStorage.getItem('LoggedUser')); 
        if(logged_user.is_superadmin == 0) //change to 1 after testing
            return true;
        else
        {
                console.log('emtered');
                this.authService.checkPageAccess(page_url,access_type).subscribe( res =>{
                    console.log('res',res);
                    if(res > 0)
                    {
                        return true; 
                    }
                    else
                    {
                        console.log('error s',res);
                        this.router.navigateByUrl('error-500/error-500');   
                        return false;
                    }
                },error => {
                    console.log('error',error);
                    this.router.navigateByUrl('error-500/error-500');   
                    return false;
                }, () =>{
                    console.info('Observable Complete');
                  })
           
            return true;
            
       } 
    }
    
    
}
