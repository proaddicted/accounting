import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
    constructor(private router: Router) {}

    canActivate(
      route: ActivatedRouteSnapshot,
      state: RouterStateSnapshot): boolean | UrlTree {
        let url: string = state.url;
        
        return this.checkLogin(url);
      }
  
    checkLogin(url: string): true | UrlTree {
     
      let val: string = localStorage.getItem('AccessToken');
  
      
      if(val != null){
         if(url == "/auth/login")
            this.router.parseUrl('**');
         else 
            return true;
      } else {
         return this.router.parseUrl('/auth/login');
      }
    }
  
}
