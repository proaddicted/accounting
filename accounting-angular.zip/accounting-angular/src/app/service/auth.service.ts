import { Injectable } from '@angular/core';

import { environment } from 'environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable, Observer, of } from 'rxjs';
import { tap, delay, share } from 'rxjs/operators';
import { map, catchError } from 'rxjs/operators';
import { Location } from '@angular/common';


const API_URL = environment.apiUrl;

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient,private location:Location) { }

  login(email: string, password: string): Observable<any> {

    return this.http.post<any>(`login?`, {email: email, password: password})
    .pipe(map(user => {
        if (user && user.success) {
            localStorage.setItem('AccessToken',user.data.access_token);
            localStorage.setItem('LoggedUser',JSON.stringify(user.data.return_data));
            return user.success;
        
        }
      }),
      
    );


  }

  logout(): Observable<any> {
    return this.http.post<any>(`logout?`,{})
    .pipe(map(data => {
        if (data && data.success) {

            console.log('last location',this.location.path())
            localStorage.removeItem('AccessToken');
            localStorage.removeItem('LoggedUser');
            localStorage.removeItem('permissions');
            localStorage.setItem('LastLocation',this.location.path());
            return data.success;
        
        }
      }),
      
    );
  }

  checkPageAccess(page_url:any,access_type:any): Observable<any>{

    const custObserve = new Observable((observer: Observer<any>) =>{
      
      const permissions = JSON.parse(localStorage.getItem('permissions'));
    
      if(permissions.length > 0)
      {
        const pages: string[] = [];
        permissions.forEach((val, ind) => {
          if(val.page_url == page_url.substring(1))
          {
            pages.push(val.page_url);
            if(val.permission_id == access_type)
            {
              observer.next(val.access);
            }
          }         
          
        }); 

        if(pages.indexOf(page_url.substring(1)) === -1)
          observer.error(0);
        
        console.log('aaa >>>',pages.indexOf(page_url.substring(1)));
      }
    });
    return custObserve;
    
  }
  
}
