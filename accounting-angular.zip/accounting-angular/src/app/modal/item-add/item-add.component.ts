import { Component, OnInit,Inject,Output,EventEmitter } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { forEach } from 'lodash';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { RestApiService } from 'app/service/rest-api.service';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-item-add',
  templateUrl: './item-add.component.html',
  styleUrls: ['./item-add.component.scss']
})
export class ItemAddComponent implements OnInit {

  form: FormGroup; 
  form_header:string = "Quick Add Item";
  is_taxable:boolean=false;
  item_groups:any =[];

  constructor(
    private restApi:RestApiService,
    private _formBuilder:FormBuilder,  
    public dialogRef: MatDialogRef<ItemAddComponent>,
    @Inject(MAT_DIALOG_DATA,
        ) public data
  ) { }

  ngOnInit(): void {

    this.form = this._formBuilder.group({
        name : ['', Validators.required],
        description : [''],
        item_group_id : [''],
        rate : [''],
        hsn_code : [''],
        sac_code : [''],
        hsn_sac_code: [''],
        cgst:['',Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
        sgst:['',Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
        igst:['',Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")],
        status : ['1'],
        is_taxable : [false]

    });

    this.restApi.getlist(`item`).pipe(
        take(1)
    ).subscribe( res => {
            if(res.success)
            {
                this.item_groups = res.data.item_groups;
            
            }
    });
  }
  
  toggleTaxable(e){
    this.is_taxable= e.checked;
    if(!this.is_taxable)
        {
            this.form.controls['cgst'].setValue(0);
            this.form.controls['sgst'].setValue(0);
            this.form.controls['igst'].setValue(0);
        }
  }
  onSubmit(data:any){
    
        this.restApi.store(`item`,data).pipe(
            take(1)
        ).subscribe( res => { 
            console.log("Submit Success: " + res);
            if(res.success)
            {
                this.form.reset();
                this.dialogRef.close(res.data);
                
                
            }  
            

        });
  }

}
