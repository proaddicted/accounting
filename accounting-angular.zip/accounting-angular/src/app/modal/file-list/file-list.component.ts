import { Component, OnInit,Inject,Output,EventEmitter } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { forEach } from 'lodash';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { saveAs } from 'file-saver';
@Component({
  selector: 'app-file-list',
  templateUrl: './file-list.component.html',
  styleUrls: ['./file-list.component.scss']
})
export class FileListComponent implements OnInit {

  files:any = [];  
  form_header:string="";
  
  constructor(private http: HttpClient,public dialogRef: MatDialogRef<FileListComponent>,
    @Inject(MAT_DIALOG_DATA) public data) { }

  ngOnInit(): void {
      this.files = this.data.files;
      this.form_header = this.data.form_header;

      console.log('files',this.files);
  }

  fileDownload(item){
    const salt = (new Date()).getTime();
    return this.http.post(`filedownload?salt=${salt}`,item, {responseType:'blob'}).subscribe(res => {
        var FileSaver = require('file-saver');
        const blob = new Blob([res]);
        FileSaver.saveAs(blob, item.file_name);
        
        
    }, err => {
        console.log(err);
    });
  }
}
