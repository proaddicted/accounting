import { Component, OnInit,Inject,Output,EventEmitter } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { forEach } from 'lodash';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { RestApiService } from 'app/service/rest-api.service';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-customer-add',
  templateUrl: './customer-add.component.html',
  styleUrls: ['./customer-add.component.scss']
})
export class CustomerAddComponent implements OnInit{

  form: FormGroup; 
  form_header:string;
  contactShow:boolean=false;
  addressShow:boolean=false;
  gstShow:boolean=false;

  constructor(
    private restApi:RestApiService,
    private _formBuilder:FormBuilder,  
    public dialogRef: MatDialogRef<CustomerAddComponent>,
    @Inject(MAT_DIALOG_DATA,
        ) public data
  ) {
   }

  ngOnInit(): void {

    this.form_header = this.data.form_header;

    this.form = this._formBuilder.group({
        fname : ['', Validators.required],
        lname : [''],
        category : [this.data.category],
        method : ['quick-add'],
        status : ['1'],
        is_contact : [false],
        is_address : [false],
        is_gst : [false],
        mobile : ['', [Validators.pattern("^[0-9]*$")]],
        email: ['', [Validators.email]],
        pincode:['',Validators.pattern("^[0-9]*$")],
        address: [''],
        country: [''],
        state: [''],
        city: [''],
        aadhar_no: ['',Validators.pattern("^[2-9]{1}[0-9]{3}[0-9]{4}[0-9]{4}$")], 
        pan_no: ['',Validators.pattern("^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$")],
        gstin: ['',Validators.pattern("^([0][1-9]|[1-2][0-9]|[3][0-7])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$")],

    });
  }
  toggleContactShow(e){
    this.contactShow= e.checked;
    if(!this.contactShow)
    {
        
    }
  }
  toggleAddressShow(e){
    this.addressShow= e.checked;
    if(!this.addressShow)
    {
        
    }
  }
  toggleGstShow(e){
    this.gstShow= e.checked;
    if(!this.gstShow)
    {
        
    }
  }
  onSubmit(data:any){
    
        this.restApi.store(`customer`,data).pipe(
            take(1)
        ).subscribe( res => { 
            console.log("Submit Success: " + res);
            if(res.success)
            {
                this.form.reset();
                this.dialogRef.close(res.data);
                
                
            }  
            

        });
  }
}
