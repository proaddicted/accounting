import { Component, OnInit,Inject,Output,EventEmitter } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { RestApiService } from 'app/service/rest-api.service';
import { forEach } from 'lodash';


@Component({
  selector: 'app-common-header',
  templateUrl: './common-header.component.html',
  styleUrls: ['./common-header.component.scss']
})
export class CommonHeaderComponent implements OnInit {

    tableheaderDataPop
    tableheaderDataDropdown
    resetHeader
    headerName
    @Output() changeheader = new EventEmitter();

  constructor(
        private restApiService: RestApiService,
        public dialogRef: MatDialogRef<CommonHeaderComponent>,
        @Inject(MAT_DIALOG_DATA) public data) {

    }
 
  ngOnInit(): void {

      this.tableheaderDataDropdown = this.data.allHeader
      this.headerName = this.data.headerName;
      console.log(this.tableheaderDataDropdown);
  }
  isColumnSelection(option, event){

    if(event.checked) {

      if(this.tableheaderDataDropdown.indexOf(option) == -1){

      }else{
        option.is_default = 1;
        option.is_display = 1;
        option.is_checked = true;
      }

    } else {

        for(var i=0 ; i < this.tableheaderDataDropdown.length; i++) {
          if(this.tableheaderDataDropdown[i].column_name == option.column_name) {
            this.tableheaderDataDropdown[i].is_default = 0;
        }
      }
      
    }
 
    // set stroage value
    localStorage.setItem(`${this.data.headerName}`, JSON.stringify(this.tableheaderDataDropdown));

  }
  onNoClick(): void {

    localStorage.removeItem(`${this.headerName}`)
    this.restApiService.headerListData(this.headerName).subscribe(
      resData => {
        this.resetHeader = resData[0];
        this.dialogRef.close(this.resetHeader);
      },
      errRes => {
      }
      );
    
  }
}
