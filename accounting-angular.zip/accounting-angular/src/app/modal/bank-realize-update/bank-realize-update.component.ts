import { Component, OnInit,Inject,Output,EventEmitter, ViewEncapsulation } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { forEach } from 'lodash';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { RestApiService } from 'app/service/rest-api.service';
import { take } from 'rxjs/operators';
import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import * as _moment from 'moment';
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { fuseAnimations } from '@fuse/animations';

const moment =  _moment;

export const MY_FORMATS = {
    parse: {
      dateInput: "YYYY-MM-DD"
    },
    display: {
      dateInput: "YYYY-MM-DD",
      monthYearLabel: "YYYY",
      dateA11yLabel: "LL",
      monthYearA11yLabel: "YYYY"
    }
};

@Component({
  selector: 'app-bank-realize-update',
  templateUrl: './bank-realize-update.component.html',
  styleUrls: ['./bank-realize-update.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations   : fuseAnimations,
  providers: [
        {
        provide: DateAdapter,
        useClass: MomentDateAdapter,
        deps: [MAT_DATE_LOCALE]
        },

        { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
    ]
})
export class BankRealizeUpdateComponent implements OnInit {

    form: FormGroup; 
    form_header:string;
    contactShow:boolean=false;
    addressShow:boolean=false;
    gstShow:boolean=false;
    minDate: Date;
    maxDate: Date;

    constructor(
      private restApi:RestApiService,
      private _formBuilder:FormBuilder,  
      public dialogRef: MatDialogRef<BankRealizeUpdateComponent>,
      @Inject(MAT_DIALOG_DATA,
          ) public data
    ) {
     }

     ngOnInit(): void {

        

        this.form_header = this.data.form_header;
        this.minDate = new Date(this.data.date);
        this.maxDate = new Date();

        this.form = this._formBuilder.group({
            
            is_realization : [true],
            realization_date :[''],
            section:this.data.section,
            realization_remarks:[''],
    
        });

        this.maxDate = new Date();
        
        if(this.data.is_realization == 1)
            this.form.controls['is_realization'].setValue(this.data.is_realization);
        else
            this.form.controls['is_realization'].setValue(false);    
        if(this.data.realization_date != '')
            this.form.controls['realization_date'].setValue(moment(this.data.realization_date).format("YYYY-MM-DD"));
        else
            this.form.controls['realization_date'].setValue(moment().format("YYYY-MM-DD"));
      }
      changeDate(event: MatDatepickerInputEvent<Date>) {

            console.log('date',moment(event.value).format("YYYY-MM-DD"));
            this.form.controls['realization_date'].setValue(moment(event.value).format("YYYY-MM-DD"));
      }
      clearDate(event: MatDatepickerInputEvent<Date>){
        this.form.controls['realization_date'].setValue(null);
      }
      toggleIsRealize(event){
       
        if(!event.checked)
        {
            this.form.controls['realization_date'].setValue(null);
        }
      }
      onSubmit(data:any){
    
            this.restApi.update(`bank_realization_update/${this.data.id}`,data).pipe(
                take(1)
            ).subscribe( res => { 
                console.log("Submit Success: " + res);
                if(res.success)
                {
                    this.form.reset();
                    this.dialogRef.close(res.data);
                    
                    
                }  
                

            });
        }
}
