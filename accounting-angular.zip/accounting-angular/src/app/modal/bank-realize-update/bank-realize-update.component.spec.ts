import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BankRealizeUpdateComponent } from './bank-realize-update.component';

describe('BankRealizeUpdateComponent', () => {
  let component: BankRealizeUpdateComponent;
  let fixture: ComponentFixture<BankRealizeUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BankRealizeUpdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BankRealizeUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
