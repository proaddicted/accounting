import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { merge, Subject, throwError } from 'rxjs';
import { catchError, map, takeUntil ,take} from 'rxjs/operators';

import { FuseNavigationService } from '@fuse/components/navigation/navigation.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { RestApiService } from 'app/service/rest-api.service';


@Component({
    selector       : 'fuse-navigation',
    templateUrl    : './navigation.component.html',
    styleUrls      : ['./navigation.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class FuseNavigationComponent implements OnInit
{
    @Input()
    layout = 'vertical';


    navigation: any = [];

    isLoading:boolean = true;
    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     *
     * @param {ChangeDetectorRef} _changeDetectorRef
     * @param {FuseNavigationService} _fuseNavigationService
     */
    constructor(
        private _changeDetectorRef: ChangeDetectorRef,
        private _fuseNavigationService: FuseNavigationService,
        private router:Router,
        private http:HttpClient,
        private restApi:RestApiService
    )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {
        // Load the navigation either from the input or from the service
        // console.log(localStorage.getItem('AccessToken'));
        if(localStorage.getItem('AccessToken') != null)
        {
            let navi =[];
            this.restApi.loadData('user_menu').pipe(
                take(1)
            ).subscribe( res => {
                    if(res.success)
                    {
                        let nav = []
                        if(res.data.length > 0){
                            let module = [];
                            for(let d of res.data){

                                
                                let chld = [];
                                if(d.pages.length > 0){
                                    for(let p of d.pages){ 
                                        let part = (p.url||'').split('?');
                                        let queryParams = {};
                                        let url = "";
                                        if(part.length > 1)
                                        {
                                            queryParams = JSON.parse('{"' + decodeURI(part[1].replace(/&/g, "\",\"").replace(/=/g,"\":\"")) + '"}');
                                            url = part[0];
                                        }
                                        else
                                        {
                                            url = p.url;
                                        }    
                                        chld.push({
                                                    id   : p.name,
                                                    title: p.display_name,
                                                    type : 'item',
                                                    exactMatch:true,
                                                    icon     : p.icon,
                                                    url  : url,
                                                    params : queryParams
                                                }) 
                                        
                                    }
                                }
                                module.push({ ...module,
                                    id: d.name,
                                    title    : d.display_name,
                                    translate: d.display_name,
                                    type     : 'collapsable',
                                    icon     : d.icon,
                                    children :chld
                                });
                                // module.push({ ...module,
                                //         id: d.name,
                                //         title    : d.display_name,
                                //         translate: d.display_name,
                                //         type     : 'collapsable',
                                //         icon     : d.icon,
                                //         children : [{
                                //             id   : "test"+d.id,
                                //             title: "Test Sub Level",
                                //             type : 'collapsable',
                                //             icon     : "",
                                //             children:chld
                                //         }] })
                            
            
                            }

                            nav = module;
                        }
            
                        navi = [
                            {
                                id       : 'applications',
                                title    : 'Applications',
                                translate: 'NAV.APPLICATIONS',
                                type     : 'group',
                                icon     : 'apps',
                                children : nav        
                            }
                        ];
                        localStorage.removeItem('permissions');
                        localStorage.setItem('permissions',JSON.stringify(res.permissions)); 
                        this.navigation = navi;
                        this._changeDetectorRef.markForCheck();
                        this.isLoading = false;
                        console.log('this.navigation',this.navigation)
                    }
            }); 

            console.log('this.navigation',this.navigation)

            merge(
                this._fuseNavigationService.onNavigationItemAdded,
                this._fuseNavigationService.onNavigationItemUpdated,
                this._fuseNavigationService.onNavigationItemRemoved
            ).pipe(takeUntil(this._unsubscribeAll))
             .subscribe(() => {

                 // Mark for check
                 this._changeDetectorRef.markForCheck();
             });
        }
        
        

        // // Subscribe to the current navigation changes
        // this.navigation = this.navigation || this._fuseNavigationService.getCurrentNavigation();
        // this._fuseNavigationService.onNavigationChanged
        //     .pipe(takeUntil(this._unsubscribeAll))
        //     .subscribe(() => {

        //         // Load the navigation
        //         this.navigation = this._fuseNavigationService.getCurrentNavigation();

        //         // Mark for check
        //         this._changeDetectorRef.markForCheck();
        //     });

        // // Subscribe to navigation item
        // merge(
        //     this._fuseNavigationService.onNavigationItemAdded,
        //     this._fuseNavigationService.onNavigationItemUpdated,
        //     this._fuseNavigationService.onNavigationItemRemoved
        // ).pipe(takeUntil(this._unsubscribeAll))
        //  .subscribe(() => {

        //      // Mark for check
        //      this._changeDetectorRef.markForCheck();
        //  });
    }

    // getQueryParams(url){
    //     var qparams = {},
    //         parts = (url||'').split('?'),
    //         qparts, qpart,
    //          i:number =0;
    
    //     if(parts.length <= 1 ){
    //         return qparams;
    //     }else{
    //         qparts = parts[1].split('&');
    //         for(i in qparts){
    
    //             qpart = qparts[i].split('=');
    //             qparams[decodeURIComponent(qpart[0])] = 
    //                            decodeURIComponent(qpart[1] || '');
    //         }
    //     }
    
    //     return qparams;
    // };
}
