export const environment = {
    production: true,
    apiUrl:"https://accounts.orkosappointment.com/application/public/api",
    apiCode:'rnj',
    hmr       : false
};
